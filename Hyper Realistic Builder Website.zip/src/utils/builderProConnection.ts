/**
 * Builder Pro Connection Utilities
 * For connecting the Cox & Company website with the Builder Pro app
 * Both built in Figma Make
 */

export interface QuoteData {
  projectId: string;
  clientInfo: {
    name: string;
    email: string;
    phone: string;
    address: string;
  };
  projectDetails: {
    service: string;
    projectType: string;
    squareFootage: string;
    timeline: string;
    budget: string;
    description: string;
  };
  estimate: number;
  photos: string[];
  timestamp: string;
  status: 'pending' | 'in-progress' | 'completed';
}

/**
 * Save quote to localStorage and generate project ID
 */
export function saveQuoteToLocal(formData: any, estimate: number, files: File[]): string {
  const projectId = generateProjectId();
  
  const quoteData: QuoteData = {
    projectId,
    clientInfo: {
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      address: formData.address,
    },
    projectDetails: {
      service: formData.service,
      projectType: formData.projectType,
      squareFootage: formData.squareFootage,
      timeline: formData.timeline,
      budget: formData.budget,
      description: formData.description,
    },
    estimate,
    photos: files.map(f => f.name),
    timestamp: new Date().toISOString(),
    status: 'pending',
  };

  // Save to localStorage
  const existingQuotes = getLocalQuotes();
  existingQuotes.push(quoteData);
  localStorage.setItem('cox_company_quotes', JSON.stringify(existingQuotes));
  
  // Also save as current project for easy access
  localStorage.setItem('cox_company_current_project', JSON.stringify(quoteData));

  return projectId;
}

/**
 * Get all quotes from localStorage
 */
export function getLocalQuotes(): QuoteData[] {
  const quotes = localStorage.getItem('cox_company_quotes');
  return quotes ? JSON.parse(quotes) : [];
}

/**
 * Get specific quote by project ID
 */
export function getQuoteById(projectId: string): QuoteData | null {
  const quotes = getLocalQuotes();
  return quotes.find(q => q.projectId === projectId) || null;
}

/**
 * Generate unique project ID
 */
function generateProjectId(): string {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 9);
  return `COX-${timestamp}-${random}`.toUpperCase();
}

/**
 * Create Builder Pro app URL with project data
 */
export function createBuilderProLink(projectId: string, builderProUrl: string): string {
  const quote = getQuoteById(projectId);
  if (!quote) return builderProUrl;

  // Encode project data in URL parameters
  const params = new URLSearchParams({
    projectId: quote.projectId,
    clientName: quote.clientInfo.name,
    clientEmail: quote.clientInfo.email,
    clientPhone: quote.clientInfo.phone,
    service: quote.projectDetails.service,
    estimate: quote.estimate.toString(),
    timestamp: quote.timestamp,
  });

  return `${builderProUrl}?${params.toString()}`;
}

/**
 * Open Builder Pro app with project data
 */
export function openBuilderProWithProject(projectId: string, builderProUrl: string) {
  const link = createBuilderProLink(projectId, builderProUrl);
  
  // Open in new tab
  window.open(link, '_blank', 'noopener,noreferrer');
  
  return link;
}

/**
 * Check if coming from Builder Pro app
 */
export function getProjectFromURL(): QuoteData | null {
  const params = new URLSearchParams(window.location.search);
  const projectId = params.get('projectId');
  
  if (projectId) {
    return getQuoteById(projectId);
  }
  
  return null;
}

/**
 * Update project status
 */
export function updateProjectStatus(projectId: string, status: QuoteData['status']) {
  const quotes = getLocalQuotes();
  const index = quotes.findIndex(q => q.projectId === projectId);
  
  if (index !== -1) {
    quotes[index].status = status;
    localStorage.setItem('cox_company_quotes', JSON.stringify(quotes));
    return true;
  }
  
  return false;
}

/**
 * Get client projects by email
 */
export function getClientProjects(email: string): QuoteData[] {
  const quotes = getLocalQuotes();
  return quotes.filter(q => q.clientInfo.email.toLowerCase() === email.toLowerCase());
}

/**
 * Export project data for Builder Pro import
 */
export function exportProjectData(projectId: string): string {
  const quote = getQuoteById(projectId);
  if (!quote) return '';
  
  // Create JSON string for easy copy/paste
  return JSON.stringify(quote, null, 2);
}

/**
 * Import project data from Builder Pro
 */
export function importProjectData(jsonData: string): boolean {
  try {
    const quote: QuoteData = JSON.parse(jsonData);
    
    const existingQuotes = getLocalQuotes();
    const index = existingQuotes.findIndex(q => q.projectId === quote.projectId);
    
    if (index !== -1) {
      // Update existing
      existingQuotes[index] = quote;
    } else {
      // Add new
      existingQuotes.push(quote);
    }
    
    localStorage.setItem('cox_company_quotes', JSON.stringify(existingQuotes));
    return true;
  } catch (error) {
    console.error('Error importing project data:', error);
    return false;
  }
}
