/**
 * Performance monitoring utilities for production
 */

// Report Web Vitals (Core Web Vitals)
export function reportWebVitals(metric: any) {
  // In production, send to analytics service
  if (process.env.NODE_ENV === 'production') {
    console.log(metric);
    // Example: Send to Google Analytics, DataDog, etc.
    // gtag('event', metric.name, {
    //   value: Math.round(metric.value),
    //   event_label: metric.id,
    // });
  }
}

// Lazy load images with Intersection Observer
export function setupLazyLoading() {
  if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target as HTMLImageElement;
          if (img.dataset.src) {
            img.src = img.dataset.src;
            img.classList.remove('lazy');
            imageObserver.unobserve(img);
          }
        }
      });
    });

    document.querySelectorAll('img.lazy').forEach((img) => {
      imageObserver.observe(img);
    });
  }
}

// Prefetch critical resources
export function prefetchResources() {
  const criticalResources = [
    // Add critical CSS, fonts, or images
  ];

  criticalResources.forEach((resource) => {
    const link = document.createElement('link');
    link.rel = 'prefetch';
    link.href = resource;
    document.head.appendChild(link);
  });
}

// Performance timing
export function logPerformanceTiming() {
  if (window.performance && window.performance.timing) {
    const timing = window.performance.timing;
    const loadTime = timing.loadEventEnd - timing.navigationStart;
    const domReadyTime = timing.domContentLoadedEventEnd - timing.navigationStart;
    const renderTime = timing.domComplete - timing.domLoading;

    console.log('Performance Metrics:', {
      'Total Load Time': `${loadTime}ms`,
      'DOM Ready Time': `${domReadyTime}ms`,
      'Render Time': `${renderTime}ms`,
    });
  }
}

// Initialize performance monitoring
export function initPerformanceMonitoring() {
  if (typeof window !== 'undefined') {
    window.addEventListener('load', () => {
      logPerformanceTiming();
      setupLazyLoading();
    });
  }
}
