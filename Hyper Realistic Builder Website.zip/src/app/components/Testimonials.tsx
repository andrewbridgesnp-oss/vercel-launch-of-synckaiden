import { motion } from 'motion/react';
import { Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';
import Slider from 'react-slick';

export function Testimonials() {
  const testimonials = [
    {
      name: 'Michael Thompson',
      role: 'Homeowner',
      project: 'Kitchen Renovation',
      text: 'Cox&Co transformed our outdated kitchen into a modern masterpiece. Their attention to detail and professionalism exceeded all our expectations. Highly recommended!',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMG1hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc2ODIyNjYwMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      name: 'Sarah Johnson',
      role: 'Property Manager',
      project: 'Multi-Unit Painting',
      text: 'Working with Cox&Co has been an absolute pleasure. They completed our multi-unit painting project ahead of schedule and within budget. True professionals!',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1573496799652-408c2ac9fe98?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMHdvbWFuJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzY4MjI2NjEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      name: 'David Martinez',
      role: 'Homeowner',
      project: 'Bathroom Remodel',
      text: 'From start to finish, Cox&Co delivered exceptional service. The quality of workmanship on our bathroom remodel was outstanding. Worth every penny!',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMG1hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc2ODIyNjYwMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      name: 'Jennifer Williams',
      role: 'Business Owner',
      project: 'Office Renovation',
      text: 'Cox&Co renovated our office space with minimal disruption to our business. Their team was courteous, skilled, and delivered exactly what we envisioned.',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMHdvbWFuJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzY4MjI2NjEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      name: 'Robert Chen',
      role: 'Homeowner',
      project: 'Deck Construction',
      text: 'Outstanding craftsmanship! Cox&Co built us a beautiful deck that has become the centerpiece of our outdoor living. Their expertise is second to none.',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMG1hbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc2ODIyNjYwMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      name: 'Amanda Davis',
      role: 'Homeowner',
      project: 'Flooring Installation',
      text: 'Cox&Co installed hardwood flooring throughout our home with incredible precision. The quality is superb and the cleanup was immaculate. Could not be happier!',
      rating: 5,
      image: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwzfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMHdvbWFuJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzY4MjI2NjEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
  ];

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 640,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <section className="py-24 bg-[#1b263b]">
      <div className="max-w-7xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-block bg-slate-100/10 text-slate-200 px-4 py-2 rounded mb-4 text-sm font-medium border border-slate-400/30">
            Testimonials
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            What Clients Say
          </h2>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            Don't just take our word for it—hear from satisfied clients who've experienced our commitment to excellence.
          </p>
        </motion.div>

        <div className="testimonial-slider">
          <Slider {...settings}>
            {testimonials.map((testimonial, index) => (
              <div key={index} className="px-3">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-slate-700 rounded-lg p-8 hover:border-slate-400 transition-all duration-300 relative h-full"
                >
                  <Quote className="absolute top-6 right-6 w-12 h-12 text-slate-600/30" />
                  
                  <div className="flex gap-1 mb-4 justify-center">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className="w-5 h-5 fill-amber-400 text-amber-400"
                      />
                    ))}
                  </div>

                  <p className="text-slate-300 mb-6 leading-relaxed italic">
                    "{testimonial.text}"
                  </p>

                  <div className="border-t border-slate-700 pt-6 flex items-center gap-4">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-16 h-16 rounded-full object-cover border-2 border-slate-600"
                    />
                    <div>
                      <h4 className="font-bold text-white mb-1">{testimonial.name}</h4>
                      <p className="text-sm text-slate-400">{testimonial.role}</p>
                      <p className="text-sm text-slate-300 mt-1">{testimonial.project}</p>
                    </div>
                  </div>
                </motion.div>
              </div>
            ))}
          </Slider>
        </div>
      </div>

      <style>{`
        /* Slick Carousel Base Styles */
        .slick-slider {
          position: relative;
          display: block;
          box-sizing: border-box;
          user-select: none;
          touch-action: pan-y;
        }

        .slick-list {
          position: relative;
          display: block;
          overflow: hidden;
          margin: 0;
          padding: 0;
        }

        .slick-list:focus {
          outline: none;
        }

        .slick-track {
          position: relative;
          top: 0;
          left: 0;
          display: block;
          margin-left: auto;
          margin-right: auto;
        }

        .slick-track:before,
        .slick-track:after {
          display: table;
          content: '';
        }

        .slick-track:after {
          clear: both;
        }

        .slick-slide {
          display: none;
          float: left;
          height: 100%;
          min-height: 1px;
        }

        .slick-slide img {
          display: block;
        }

        .slick-initialized .slick-slide {
          display: block;
        }

        /* Dots */
        .testimonial-slider .slick-dots {
          position: relative;
          bottom: -50px;
          display: flex !important;
          justify-content: center;
          padding: 0;
          margin: 0;
          list-style: none;
        }

        .testimonial-slider .slick-dots li {
          position: relative;
          display: inline-block;
          width: 20px;
          height: 20px;
          margin: 0 5px;
          padding: 0;
          cursor: pointer;
        }

        .testimonial-slider .slick-dots li button {
          font-size: 0;
          line-height: 0;
          display: block;
          width: 20px;
          height: 20px;
          padding: 5px;
          cursor: pointer;
          color: transparent;
          border: 0;
          outline: none;
          background: transparent;
        }

        .testimonial-slider .slick-dots li button:before {
          font-size: 10px;
          line-height: 20px;
          position: absolute;
          top: 0;
          left: 0;
          width: 20px;
          height: 20px;
          content: '•';
          text-align: center;
          opacity: 0.5;
          color: #cbd5e1;
        }

        .testimonial-slider .slick-dots li.slick-active button:before {
          opacity: 1;
          color: #cbd5e1;
        }

        /* Arrows */
        .testimonial-slider .slick-prev,
        .testimonial-slider .slick-next {
          font-size: 0;
          line-height: 0;
          position: absolute;
          top: 50%;
          display: block;
          width: 40px;
          height: 40px;
          padding: 0;
          transform: translate(0, -50%);
          cursor: pointer;
          color: transparent;
          border: none;
          outline: none;
          background: transparent;
          z-index: 1;
        }

        .testimonial-slider .slick-prev:before,
        .testimonial-slider .slick-next:before {
          font-size: 32px;
          line-height: 1;
          opacity: 0.75;
          color: #cbd5e1;
        }

        .testimonial-slider .slick-prev:hover:before,
        .testimonial-slider .slick-next:hover:before {
          opacity: 1;
        }

        .testimonial-slider .slick-prev {
          left: -40px;
        }

        .testimonial-slider .slick-prev:before {
          content: '←';
        }

        .testimonial-slider .slick-next {
          right: -40px;
        }

        .testimonial-slider .slick-next:before {
          content: '→';
        }

        @media (max-width: 1024px) {
          .testimonial-slider .slick-prev {
            left: -30px;
          }
          .testimonial-slider .slick-next {
            right: -30px;
          }
        }

        @media (max-width: 640px) {
          .testimonial-slider .slick-prev {
            left: 0;
          }
          .testimonial-slider .slick-next {
            right: 0;
          }
        }
      `}</style>
    </section>
  );
}