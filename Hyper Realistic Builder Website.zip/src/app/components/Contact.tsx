import { motion } from 'motion/react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export function Contact() {
  const contactInfo = [
    {
      icon: Phone,
      title: 'Phone',
      details: '(706) 551-3304',
      link: 'tel:+17065513304',
      editable: true,
    },
    {
      icon: Mail,
      title: 'Email',
      details: 'coxsprofessionllc@gmail.com',
      link: 'mailto:coxsprofessionllc@gmail.com',
      editable: true,
    },
    {
      icon: MapPin,
      title: 'Service Area',
      details: 'Greater CSRA and Surrounding Areas',
      link: '#',
      editable: false,
    },
    {
      icon: Clock,
      title: 'Business Hours',
      details: 'Mon-Fri: 6AM-6PM, Sat: 8AM-4PM',
      link: '#',
      editable: false,
    },
  ];

  return (
    <section id="contact" className="py-24 bg-[#1b263b]">
      <div className="max-w-7xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-block bg-slate-100/10 text-slate-200 px-4 py-2 rounded mb-4 text-sm font-medium border border-slate-400/30">
            Get In Touch
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Contact Cox&Co
          </h2>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            Ready to start your project? Reach out today for a free consultation and quote.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {contactInfo.map((info, index) => (
            <motion.a
              key={index}
              href={info.link}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-slate-700 rounded-lg p-6 hover:border-slate-400 transition-all relative"
            >
              {info.editable && (
                <span className="absolute top-2 right-2 text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded border border-slate-600">
                  Editable
                </span>
              )}
              <div className="bg-slate-700/30 w-12 h-12 rounded-lg flex items-center justify-center mb-4 group-hover:bg-slate-300 transition-all">
                <info.icon className="w-6 h-6 text-slate-300 group-hover:text-[#0d1b2a] transition-colors" />
              </div>
              <h4 className="font-bold text-white mb-2">{info.title}</h4>
              <p className="text-slate-400 text-sm">{info.details}</p>
            </motion.a>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12"
        >
          <p className="text-slate-400 mb-6">
            Questions about your project? We're here to help!
          </p>
          <a
            href="#quote"
            className="inline-block bg-gradient-to-r from-slate-100 to-slate-300 text-[#0d1b2a] px-8 py-4 rounded hover:from-white hover:to-slate-100 transition-all font-bold shadow-lg shadow-slate-400/30"
          >
            Request a Free Quote
          </a>
        </motion.div>
      </div>
    </section>
  );
}