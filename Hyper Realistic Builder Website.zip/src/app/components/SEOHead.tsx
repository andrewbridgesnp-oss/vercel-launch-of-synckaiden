import { useEffect } from 'react';

export function SEOHead() {
  useEffect(() => {
    // Set document title
    document.title = 'Cox & Company Professional Services | Premier Contractor in Greater CSRA';
    
    // Set or update meta tags
    const metaTags = [
      { name: 'description', content: 'Cox & Company Professional Services offers over 30 years of expert construction, renovation, and contracting services in the Greater CSRA. Licensed, insured, and committed to excellence.' },
      { name: 'keywords', content: 'contractor, construction, renovation, painting, flooring, drywall, electrical, plumbing, CSRA, Augusta, professional services, licensed contractor' },
      { name: 'author', content: 'Cox & Company Professional Services' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1.0' },
      { name: 'theme-color', content: '#0d1b2a' },
      
      // Open Graph / Facebook
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Cox & Company Professional Services | Premier Contractor' },
      { property: 'og:description', content: 'Over 30 years of expert construction and renovation services in the Greater CSRA area.' },
      { property: 'og:site_name', content: 'Cox & Company Professional Services' },
      
      // Twitter
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: 'Cox & Company Professional Services' },
      { name: 'twitter:description', content: 'Premier contractor with 30+ years of experience in construction and renovation.' },
      
      // Additional SEO
      { name: 'robots', content: 'index, follow' },
      { name: 'googlebot', content: 'index, follow' },
      { name: 'revisit-after', content: '7 days' },
      { name: 'rating', content: 'general' },
      { name: 'geo.region', content: 'US-GA' },
      { name: 'geo.placename', content: 'Augusta, Georgia' },
    ];

    metaTags.forEach(({ name, property, content }) => {
      const attribute = name ? 'name' : 'property';
      const value = name || property || '';
      
      let meta = document.querySelector(`meta[${attribute}="${value}"]`);
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(attribute, value);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', content);
    });

    // Add structured data for local business
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Cox & Company Professional Services",
      "image": window.location.origin + "/logo.png",
      "description": "Professional construction and renovation services with over 30 years of experience",
      "address": {
        "@type": "PostalAddress",
        "addressRegion": "GA",
        "addressLocality": "Greater CSRA Area"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": "33.4735",
        "longitude": "-82.0105"
      },
      "telephone": "(706) 555-0100",
      "priceRange": "$$",
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          "opens": "06:00",
          "closes": "18:00"
        },
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": "Saturday",
          "opens": "08:00",
          "closes": "16:00"
        }
      ],
      "sameAs": [
        "https://facebook.com/coxandcompany",
        "https://instagram.com/coxandcompany"
      ]
    };

    let script = document.querySelector('script[type="application/ld+json"]');
    if (!script) {
      script = document.createElement('script');
      script.setAttribute('type', 'application/ld+json');
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(structuredData);
  }, []);

  return null;
}
