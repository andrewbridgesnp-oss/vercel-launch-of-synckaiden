import { Facebook, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';
import logo from 'figma:asset/c5b0d9c1da7b0c3e5bf00180311802e7bf71f0da.png';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#0d1b2a] border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <img src={logo} alt="Cox & Co Professional Services" className="h-10 w-auto mb-4" />
            <p className="text-slate-400 mb-4">
              Professional services delivered with over 30 years of expertise. Your trusted partner for quality craftsmanship.
            </p>
            <div className="flex gap-4">
              <a href="#" className="bg-slate-800/50 w-10 h-10 rounded flex items-center justify-center hover:bg-slate-300 transition-colors border border-slate-700 group">
                <Facebook className="w-5 h-5 text-slate-400 group-hover:text-[#0d1b2a]" />
              </a>
              <a href="#" className="bg-slate-800/50 w-10 h-10 rounded flex items-center justify-center hover:bg-slate-300 transition-colors border border-slate-700 group">
                <Instagram className="w-5 h-5 text-slate-400 group-hover:text-[#0d1b2a]" />
              </a>
              <a href="#" className="bg-slate-800/50 w-10 h-10 rounded flex items-center justify-center hover:bg-slate-300 transition-colors border border-slate-700 group">
                <Linkedin className="w-5 h-5 text-slate-400 group-hover:text-[#0d1b2a]" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-slate-400 hover:text-white transition-colors">Home</a></li>
              <li><a href="#services" className="text-slate-400 hover:text-white transition-colors">Services</a></li>
              <li><a href="#portfolio" className="text-slate-400 hover:text-white transition-colors">Portfolio</a></li>
              <li><a href="#about" className="text-slate-400 hover:text-white transition-colors">About</a></li>
              <li><a href="#contact" className="text-slate-400 hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-bold mb-4">Our Services</h4>
            <ul className="space-y-2">
              <li><a href="#services" className="text-slate-400 hover:text-white transition-colors">Painting</a></li>
              <li><a href="#services" className="text-slate-400 hover:text-white transition-colors">Flooring</a></li>
              <li><a href="#services" className="text-slate-400 hover:text-white transition-colors">Remodeling</a></li>
              <li><a href="#services" className="text-slate-400 hover:text-white transition-colors">Carpentry</a></li>
              <li><a href="#services" className="text-slate-400 hover:text-white transition-colors">General Contracting</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-bold mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-slate-400 flex-shrink-0 mt-1" />
                <a href="tel:+17065513304" className="text-slate-400 hover:text-white transition-colors">
                  (706) 551-3304
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-slate-400 flex-shrink-0 mt-1" />
                <a href="mailto:coxsprofessionllc@gmail.com" className="text-slate-400 hover:text-white transition-colors">
                  coxsprofessionllc@gmail.com
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-slate-400 flex-shrink-0 mt-1" />
                <span className="text-slate-400">
                  Greater CSRA and Surrounding Areas
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-400 text-sm">
            © {currentYear} Cox&Co Professional Services, LLC. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#legal" className="text-slate-400 hover:text-white transition-colors">Privacy Policy</a>
            <a href="#legal" className="text-slate-400 hover:text-white transition-colors">Terms of Service</a>
            <a href="#legal" className="text-slate-400 hover:text-white transition-colors">Legal Disclaimers</a>
          </div>
        </div>
      </div>
    </footer>
  );
}