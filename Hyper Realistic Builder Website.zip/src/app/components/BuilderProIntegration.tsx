import { motion } from 'motion/react';
import { Smartphone, Calendar, ClipboardCheck, FileText, Users, BarChart } from 'lucide-react';
import { useState } from 'react';

export function BuilderProIntegration() {
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');

  const features = [
    {
      icon: Calendar,
      title: 'Schedule Management',
      description: 'Sync project timelines and crew availability',
    },
    {
      icon: ClipboardCheck,
      title: 'Project Tracking',
      description: 'Real-time updates on all active projects',
    },
    {
      icon: FileText,
      title: 'Digital Documentation',
      description: 'Access contracts, estimates, and invoices',
    },
    {
      icon: Users,
      title: 'Client Portal',
      description: 'Direct communication and project visibility',
    },
    {
      icon: BarChart,
      title: 'Analytics Dashboard',
      description: 'Business insights and performance metrics',
    },
  ];

  const handleConnect = () => {
    setConnectionStatus('connecting');
    
    // Prompt for Builder Pro URL
    const builderProAppUrl = prompt(
      'Enter your published Builder Pro app URL:',
      'https://your-builder-pro-app.figmake.com'
    );
    
    if (builderProAppUrl) {
      // Save URL to localStorage for future use
      localStorage.setItem('builder_pro_url', builderProAppUrl);
      
      // Simulate connection
      setTimeout(() => {
        setConnectionStatus('connected');
        console.log('Connected to Builder Pro at:', builderProAppUrl);
        alert(`✅ Connected to Builder Pro!\n\nWhen clients submit quotes, they can now open your Builder Pro app with all project data automatically transferred.`);
      }, 2000);
    } else {
      setConnectionStatus('disconnected');
    }
  };

  return (
    <section id="builder-pro" className="py-24 bg-gradient-to-br from-[#0d1b2a] via-[#1b263b] to-[#0d1b2a] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle, #fbbf24 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-amber-400/10 text-amber-400 px-4 py-2 rounded-full mb-4 text-sm font-medium border border-amber-400/30">
            <Smartphone className="w-4 h-4" />
            Professional Tools Integration
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Connected to <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-amber-500">Builder Pro</span>
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Our custom Builder Pro app provides seamless project management, real-time updates, 
            and complete transparency throughout your construction journey.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-slate-700/50 rounded-lg p-6 hover:border-amber-400/50 transition-all hover:shadow-lg hover:shadow-amber-400/20"
            >
              <div className="bg-amber-400/10 w-14 h-14 rounded-lg flex items-center justify-center mb-4 border border-amber-400/30">
                <feature.icon className="w-7 h-7 text-amber-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-slate-400">{feature.description}</p>
            </motion.div>
          ))}

          {/* Connection Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="bg-gradient-to-br from-amber-500/20 to-amber-600/20 border-2 border-amber-400/50 rounded-lg p-6 flex flex-col items-center justify-center text-center"
          >
            <Smartphone className="w-14 h-14 text-amber-400 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">
              {connectionStatus === 'connected' ? 'Connected!' : 'Connect Your Project'}
            </h3>
            <p className="text-slate-300 mb-4 text-sm">
              {connectionStatus === 'connected' 
                ? 'Your project is synced with Builder Pro' 
                : 'Link this quote to Builder Pro App'}
            </p>
            {connectionStatus === 'disconnected' && (
              <button
                onClick={handleConnect}
                className="bg-gradient-to-r from-amber-400 to-amber-500 text-[#0d1b2a] px-6 py-3 rounded font-bold hover:from-amber-300 hover:to-amber-400 transition-all shadow-lg shadow-amber-400/30"
              >
                Connect Now
              </button>
            )}
            {connectionStatus === 'connecting' && (
              <div className="flex items-center gap-2 text-amber-400">
                <div className="w-5 h-5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                Connecting...
              </div>
            )}
            {connectionStatus === 'connected' && (
              <div className="flex items-center gap-2 text-green-400 font-semibold">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                Active
              </div>
            )}
          </motion.div>
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="bg-gradient-to-r from-slate-800/60 to-slate-900/60 backdrop-blur-md border border-slate-600/50 rounded-lg p-8 text-center"
        >
          <h3 className="text-2xl font-bold text-white mb-4">
            Ready to Experience Professional Project Management?
          </h3>
          <p className="text-slate-300 mb-6 max-w-2xl mx-auto">
            Once your project begins, you'll receive exclusive access to our Builder Pro app 
            for complete transparency, real-time updates, and seamless communication.
          </p>
          <a
            href="#quote"
            className="inline-block bg-gradient-to-r from-amber-400 to-amber-500 text-[#0d1b2a] px-8 py-4 rounded font-bold hover:from-amber-300 hover:to-amber-400 transition-all shadow-lg shadow-amber-400/30"
          >
            Get Started Today
          </a>
        </motion.div>
      </div>
    </section>
  );
}