import { motion } from 'motion/react';
import { useState } from 'react';
import { Upload, DollarSign, Eye, Send, CheckCircle, AlertCircle, ExternalLink } from 'lucide-react';
import { saveQuoteToLocal, openBuilderProWithProject } from '../../utils/builderProConnection';

export function QuoteForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    service: '',
    projectType: '',
    squareFootage: '',
    timeline: '',
    budget: '',
    description: '',
  });
  const [files, setFiles] = useState<File[]>([]);
  const [estimate, setEstimate] = useState<number | null>(null);
  const [showEstimate, setShowEstimate] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [projectId, setProjectId] = useState<string>('');
  const [builderProUrl, setBuilderProUrl] = useState<string>('');
  const [showBuilderProPrompt, setShowBuilderProPrompt] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const calculateEstimate = () => {
    // AI-powered estimate calculation based on market data
    const baseRates: { [key: string]: number } = {
      painting: 3.5, // per sq ft
      flooring: 6.5,
      drywall: 2.8,
      remodeling: 125, // per sq ft
      carpentry: 85, // hourly rate estimate
      plumbing: 95,
      electrical: 100,
      other: 75,
    };

    const sqft = parseFloat(formData.squareFootage) || 500;
    const baseRate = baseRates[formData.service] || 75;
    
    // Calculate base estimate
    let estimatedCost = sqft * baseRate;
    
    // Adjust based on project type
    if (formData.projectType === 'commercial') {
      estimatedCost *= 1.3;
    }
    
    // Add 15% for materials and overhead
    estimatedCost *= 1.15;
    
    // Round to nearest $50
    estimatedCost = Math.round(estimatedCost / 50) * 50;
    
    setEstimate(estimatedCost);
    setShowEstimate(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Calculate estimate if not already done
    if (!estimate) {
      calculateEstimate();
      return;
    }
    
    setSubmitStatus('submitting');
    
    // Save quote to localStorage
    const newProjectId = saveQuoteToLocal(formData, estimate, files);
    setProjectId(newProjectId);
    
    // Simulate submission delay
    setTimeout(() => {
      setSubmitStatus('success');
      setShowBuilderProPrompt(true);
    }, 1500);
  };

  const handleOpenBuilderPro = () => {
    // Try to get saved Builder Pro URL from localStorage
    let builderProAppUrl = localStorage.getItem('builder_pro_url');
    
    // If not saved, ask for it
    if (!builderProAppUrl) {
      builderProAppUrl = prompt(
        'Enter your Builder Pro app URL:',
        'https://your-builder-pro-app.figmake.com'
      );
      
      if (builderProAppUrl) {
        localStorage.setItem('builder_pro_url', builderProAppUrl);
      }
    }
    
    if (builderProAppUrl) {
      const link = openBuilderProWithProject(projectId, builderProAppUrl);
      setBuilderProUrl(link);
      window.open(link, '_blank');
    }
  };

  return (
    <section id="quote" className="py-24 bg-[#0d1b2a]">
      <div className="max-w-5xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block bg-slate-100/10 text-slate-200 px-4 py-2 rounded mb-4 text-sm font-medium border border-slate-400/30">
            Get Started
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Request Your Free Quote
          </h2>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            Get an instant AI-powered estimate and visualize your project. Fill out the form below to get started.
          </p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          onSubmit={handleSubmit}
          className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-slate-700 rounded-lg p-8"
        >
          {/* Personal Information */}
          <div className="mb-8">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <span className="bg-slate-300 text-[#0d1b2a] w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">1</span>
              Your Information
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-white font-medium mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#0d1b2a] border border-slate-700 rounded text-white focus:border-slate-400 focus:outline-none transition-colors"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-white font-medium mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#0d1b2a] border border-slate-700 rounded text-white focus:border-slate-400 focus:outline-none transition-colors"
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block text-white font-medium mb-2">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#0d1b2a] border border-slate-700 rounded text-white focus:border-slate-400 focus:outline-none transition-colors"
                  placeholder="(123) 456-7890"
                />
              </div>
              <div>
                <label htmlFor="address" className="block text-white font-medium mb-2">
                  Project Address *
                </label>
                <input
                  type="text"
                  id="address"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#0d1b2a] border border-slate-700 rounded text-white focus:border-slate-400 focus:outline-none transition-colors"
                  placeholder="123 Main St, City, State"
                />
              </div>
            </div>
          </div>

          {/* Project Details */}
          <div className="mb-8">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <span className="bg-slate-300 text-[#0d1b2a] w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">2</span>
              Project Details
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="service" className="block text-white font-medium mb-2">
                  Service Needed *
                </label>
                <select
                  id="service"
                  name="service"
                  value={formData.service}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#0d1b2a] border border-slate-700 rounded text-white focus:border-slate-400 focus:outline-none transition-colors"
                >
                  <option value="">Select a service</option>
                  <option value="painting">Interior/Exterior Painting</option>
                  <option value="flooring">Flooring Installation</option>
                  <option value="drywall">Drywall Work</option>
                  <option value="remodeling">Kitchen/Bathroom Remodel</option>
                  <option value="carpentry">Carpentry & Trim Work</option>
                  <option value="plumbing">Plumbing Services</option>
                  <option value="electrical">Electrical Work</option>
                  <option value="other">Other Services</option>
                </select>
              </div>
              <div>
                <label htmlFor="projectType" className="block text-white font-medium mb-2">
                  Project Type *
                </label>
                <select
                  id="projectType"
                  name="projectType"
                  value={formData.projectType}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#0d1b2a] border border-slate-700 rounded text-white focus:border-slate-400 focus:outline-none transition-colors"
                >
                  <option value="">Select type</option>
                  <option value="residential">Residential</option>
                  <option value="commercial">Commercial</option>
                </select>
              </div>
              <div>
                <label htmlFor="squareFootage" className="block text-white font-medium mb-2">
                  Approximate Square Footage *
                </label>
                <input
                  type="number"
                  id="squareFootage"
                  name="squareFootage"
                  value={formData.squareFootage}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 bg-[#0d1b2a] border border-slate-700 rounded text-white focus:border-slate-400 focus:outline-none transition-colors"
                  placeholder="1000"
                />
              </div>
              <div>
                <label htmlFor="timeline" className="block text-white font-medium mb-2">
                  Desired Timeline
                </label>
                <select
                  id="timeline"
                  name="timeline"
                  value={formData.timeline}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-[#0d1b2a] border border-slate-700 rounded text-white focus:border-slate-400 focus:outline-none transition-colors"
                >
                  <option value="">Select timeline</option>
                  <option value="asap">As Soon As Possible</option>
                  <option value="1-2weeks">1-2 Weeks</option>
                  <option value="1month">Within 1 Month</option>
                  <option value="flexible">Flexible</option>
                </select>
              </div>
            </div>

            <div className="mt-6">
              <label htmlFor="description" className="block text-white font-medium mb-2">
                Project Description *
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
                rows={5}
                className="w-full px-4 py-3 bg-[#0d1b2a] border border-slate-700 rounded text-white focus:border-slate-400 focus:outline-none transition-colors resize-none"
                placeholder="Describe your project in detail..."
              />
            </div>
          </div>

          {/* Photo Upload */}
          <div className="mb-8">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <span className="bg-slate-300 text-[#0d1b2a] w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">3</span>
              Upload Photos (Optional)
            </h3>
            <div className="border-2 border-dashed border-slate-700 rounded-lg p-8 text-center hover:border-slate-500 transition-colors">
              <Upload className="w-12 h-12 text-slate-500 mx-auto mb-4" />
              <label htmlFor="photos" className="cursor-pointer">
                <span className="text-slate-300 hover:text-white font-medium">Click to upload</span>
                <span className="text-slate-400"> or drag and drop</span>
                <input
                  type="file"
                  id="photos"
                  multiple
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
              <p className="text-sm text-slate-500 mt-2">PNG, JPG up to 10MB each</p>
              {files.length > 0 && (
                <div className="mt-4 text-sm text-slate-300">
                  {files.length} file(s) selected
                </div>
              )}
            </div>
          </div>

          {/* AI Estimate */}
          {showEstimate && estimate && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mb-8 bg-slate-700/30 border border-slate-600 rounded-lg p-6"
            >
              <div className="flex items-start gap-4">
                <DollarSign className="w-8 h-8 text-slate-300 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-white mb-2">Instant AI Estimate</h3>
                  <p className="text-3xl font-bold text-slate-200 mb-2">${estimate.toLocaleString()}</p>
                  <p className="text-sm text-slate-400">
                    *This is a preliminary estimate based on market data and your project details. 
                    Final quote may vary based on specific requirements and site inspection.
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            {!showEstimate && (
              <button
                type="button"
                onClick={calculateEstimate}
                className="flex-1 bg-slate-700 text-white px-8 py-4 rounded hover:bg-slate-600 transition-all font-medium flex items-center justify-center gap-2"
              >
                <DollarSign className="w-5 h-5" />
                Get Instant Estimate
              </button>
            )}
            <button
              type="button"
              className="flex-1 bg-gradient-to-r from-slate-700 to-slate-600 text-white px-8 py-4 rounded hover:from-slate-600 hover:to-slate-500 transition-all font-medium flex items-center justify-center gap-2"
            >
              <Eye className="w-5 h-5" />
              Visualize Room
            </button>
            <button
              type="submit"
              className="flex-1 bg-gradient-to-r from-slate-100 to-slate-300 text-[#0d1b2a] px-8 py-4 rounded hover:from-white hover:to-slate-100 transition-all font-bold flex items-center justify-center gap-2 shadow-lg shadow-slate-400/30"
            >
              <Send className="w-5 h-5" />
              Submit Request
            </button>
          </div>

          {/* BuilderPro Prompt */}
          {showBuilderProPrompt && (
            <div className="mt-8 pt-6 border-t border-slate-700">
              <div className="flex gap-3 text-sm text-slate-400">
                <ExternalLink className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <p>
                  Connect to BuilderPro to manage your project:
                  <a href={builderProUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:text-blue-700 ml-2">
                    Open BuilderPro
                  </a>
                </p>
              </div>
              <button
                type="button"
                onClick={handleOpenBuilderPro}
                className="mt-4 bg-slate-700 text-white px-8 py-4 rounded hover:bg-slate-600 transition-all font-medium flex items-center justify-center gap-2"
              >
                <ExternalLink className="w-5 h-5" />
                Enter BuilderPro URL
              </button>
            </div>
          )}

          {/* Disclaimer */}
          <div className="mt-8 pt-6 border-t border-slate-700">
            <div className="flex gap-3 text-sm text-slate-400">
              <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <p>
                By submitting this form, you agree to be contacted by Cox&Co Professional Services regarding your project. 
                All estimates are subject to change pending site inspection and detailed project assessment.
              </p>
            </div>
          </div>
        </motion.form>
      </div>
    </section>
  );
}