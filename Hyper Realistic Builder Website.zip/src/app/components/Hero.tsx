import { motion } from 'motion/react';
import { ArrowRight, Award, Users, Building2 } from 'lucide-react';
import heroImage from 'figma:asset/c5b0d9c1da7b0c3e5bf00180311802e7bf71f0da.png';

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Cox & Co Professional Services"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0d1b2a]/98 via-[#0d1b2a]/90 to-[#1b263b]/75" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-block bg-slate-100/10 text-slate-200 px-4 py-2 rounded mb-6 text-sm font-medium border border-slate-400/30 backdrop-blur-sm">
              Premium Professional Services
            </div>
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Precision.
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-200 to-amber-400">Excellence.</span>
              <span className="block text-slate-300">Delivered.</span>
            </h1>
            <p className="text-xl text-slate-300 mb-8 leading-relaxed">
              With over 30 years of dedicated expertise, Cox&Co delivers unmatched craftsmanship 
              and professional service for every residential and commercial project.
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                href="#quote"
                className="bg-gradient-to-r from-slate-100 to-slate-300 text-[#0d1b2a] px-8 py-4 rounded hover:from-white hover:to-slate-100 transition-all flex items-center gap-2 font-bold shadow-2xl shadow-slate-400/40 hover:shadow-slate-200/60"
              >
                Get Free Quote
                <ArrowRight className="w-5 h-5" />
              </a>
              <a
                href="#portfolio"
                className="border-2 border-slate-300 text-slate-200 px-8 py-4 rounded hover:bg-slate-200 hover:text-[#0d1b2a] transition-all font-bold"
              >
                View Portfolio
              </a>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="grid grid-cols-1 gap-6"
          >
            <div className="bg-gradient-to-br from-slate-800/60 to-slate-900/60 backdrop-blur-md border border-slate-600/50 rounded-lg p-6 hover:border-amber-400/50 transition-all shadow-xl hover:shadow-amber-400/20">
              <Award className="w-12 h-12 text-amber-400 mb-4" />
              <h3 className="text-3xl font-bold text-white mb-2">30+ Years</h3>
              <p className="text-slate-300">Professional Experience</p>
            </div>
            <div className="bg-gradient-to-br from-slate-800/60 to-slate-900/60 backdrop-blur-md border border-slate-600/50 rounded-lg p-6 hover:border-amber-400/50 transition-all shadow-xl hover:shadow-amber-400/20">
              <Building2 className="w-12 h-12 text-amber-400 mb-4" />
              <h3 className="text-3xl font-bold text-white mb-2">500+</h3>
              <p className="text-slate-300">Projects Completed</p>
            </div>
            <div className="bg-gradient-to-br from-slate-800/60 to-slate-900/60 backdrop-blur-md border border-slate-600/50 rounded-lg p-6 hover:border-amber-400/50 transition-all shadow-xl hover:shadow-amber-400/20">
              <Users className="w-12 h-12 text-amber-400 mb-4" />
              <h3 className="text-3xl font-bold text-white mb-2">100%</h3>
              <p className="text-slate-300">Client Satisfaction</p>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <div className="w-6 h-10 border-2 border-slate-400 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-slate-300 rounded-full mt-2" />
        </div>
      </motion.div>
    </section>
  );
}