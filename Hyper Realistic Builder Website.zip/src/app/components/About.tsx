import { motion } from 'motion/react';
import { CheckCircle, Target, Shield, Users } from 'lucide-react';
import logoImage from 'figma:asset/c5b0d9c1da7b0c3e5bf00180311802e7bf71f0da.png';

export function About() {
  const values = [
    {
      icon: Target,
      title: 'Precision',
      description: 'Meticulous attention to every detail',
    },
    {
      icon: Shield,
      title: 'Quality',
      description: 'Premium materials and methods',
    },
    {
      icon: Users,
      title: 'Integrity',
      description: 'Honest and transparent service',
    },
  ];

  const features = [
    'Licensed & Fully Insured',
    'Over 30 Years Experience',
    'On-Time Project Delivery',
    'Competitive Fair Pricing',
    'Premium Materials Only',
    'Quality Workmanship Guaranteed',
  ];

  return (
    <section id="about" className="py-24 bg-[#0d1b2a]">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Column - Images */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative">
              <div className="bg-gradient-to-br from-[#0d1b2a] to-[#1b263b] rounded-lg w-full h-96 flex items-center justify-center shadow-2xl border-2 border-amber-400/30 p-8">
                <img
                  src={logoImage}
                  alt="Cox & Company Professional Services"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="absolute -bottom-8 -right-8 bg-gradient-to-br from-amber-500 to-amber-600 text-[#0d1b2a] p-8 rounded-lg shadow-xl border-2 border-amber-400">
                <div className="text-5xl font-bold mb-2">30+</div>
                <div className="text-lg font-semibold">Years Experience</div>
              </div>
            </div>
          </motion.div>

          {/* Right Column - Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-block bg-slate-100/10 text-slate-200 px-4 py-2 rounded mb-4 text-sm font-medium border border-slate-400/30">
              About Cox&Co
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Excellence Through Experience
            </h2>
            
            {/* EDITABLE ABOUT SECTION */}
            <div className="space-y-4 mb-8">
              <p className="text-xl text-slate-300 leading-relaxed">
                With over 30 years of dedicated hands-on experience in the construction and renovation industry, 
                Cox&Co Professional Services has built a reputation for delivering exceptional craftsmanship and 
                reliable service that exceeds client expectations.
              </p>
              <p className="text-lg text-slate-400 leading-relaxed">
                From residential renovations to commercial projects, our skilled 1-4 man crew approaches every 
                job with professionalism, precision, and a commitment to quality that comes from decades of 
                expertise in the trade.
              </p>
              <p className="text-lg text-slate-400 leading-relaxed">
                We pride ourselves on transparent communication, honest pricing, and workmanship that stands 
                the test of time. Your project is not just another job—it's an opportunity to demonstrate 
                our dedication to excellence.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle className="w-6 h-6 text-amber-400 flex-shrink-0 mt-1" />
                  <span className="text-slate-300">{feature}</span>
                </div>
              ))}
            </div>

            {/* Values */}
            <div className="grid grid-cols-3 gap-6 mt-12">
              {values.map((value, index) => (
                <div key={index} className="text-center">
                  <div className="bg-slate-700/30 w-16 h-16 rounded-lg flex items-center justify-center mx-auto mb-3 border border-slate-600/50">
                    <value.icon className="w-8 h-8 text-slate-300" />
                  </div>
                  <h4 className="font-bold text-white mb-1">{value.title}</h4>
                  <p className="text-sm text-slate-400">{value.description}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}