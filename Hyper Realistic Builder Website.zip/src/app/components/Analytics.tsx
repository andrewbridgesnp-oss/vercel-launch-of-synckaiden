import { useEffect } from 'react';

/**
 * Analytics component for tracking user interactions
 * In production, integrate with Google Analytics, Mixpanel, or similar
 */
export function Analytics() {
  useEffect(() => {
    // Track page view
    const trackPageView = () => {
      if (typeof window !== 'undefined') {
        // Google Analytics example (uncomment when GA is set up)
        // window.gtag?.('config', 'GA_MEASUREMENT_ID', {
        //   page_path: window.location.pathname,
        // });
        
        console.log('Page view tracked:', window.location.pathname);
      }
    };

    trackPageView();

    // Track scroll depth
    let maxScroll = 0;
    const trackScrollDepth = () => {
      const scrollPercentage = Math.round(
        (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100
      );
      
      if (scrollPercentage > maxScroll) {
        maxScroll = scrollPercentage;
        
        // Track milestone scrolls
        if ([25, 50, 75, 100].includes(maxScroll)) {
          console.log(`Scroll depth: ${maxScroll}%`);
          // window.gtag?.('event', 'scroll', {
          //   event_category: 'engagement',
          //   event_label: `${maxScroll}%`,
          // });
        }
      }
    };

    window.addEventListener('scroll', trackScrollDepth, { passive: true });

    // Track time on page
    const startTime = Date.now();
    const trackTimeOnPage = () => {
      const timeSpent = Math.round((Date.now() - startTime) / 1000);
      console.log(`Time on page: ${timeSpent}s`);
      // window.gtag?.('event', 'timing_complete', {
      //   name: 'page_view',
      //   value: timeSpent,
      // });
    };

    window.addEventListener('beforeunload', trackTimeOnPage);

    return () => {
      window.removeEventListener('scroll', trackScrollDepth);
      window.removeEventListener('beforeunload', trackTimeOnPage);
    };
  }, []);

  return null;
}

/**
 * Track custom events
 */
export const trackEvent = (
  eventName: string,
  eventParams?: Record<string, any>
) => {
  if (typeof window !== 'undefined') {
    console.log('Event tracked:', eventName, eventParams);
    // window.gtag?.('event', eventName, eventParams);
  }
};

/**
 * Track form submissions
 */
export const trackFormSubmission = (formName: string, success: boolean) => {
  trackEvent('form_submission', {
    form_name: formName,
    success,
  });
};

/**
 * Track button clicks
 */
export const trackButtonClick = (buttonName: string, location: string) => {
  trackEvent('button_click', {
    button_name: buttonName,
    location,
  });
};

/**
 * Track quote requests
 */
export const trackQuoteRequest = (service: string, estimatedValue: number) => {
  trackEvent('quote_request', {
    service,
    value: estimatedValue,
    currency: 'USD',
  });
};
