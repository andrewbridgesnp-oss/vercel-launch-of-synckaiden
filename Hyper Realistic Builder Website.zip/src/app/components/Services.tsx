import { motion } from 'motion/react';
import { 
  Paintbrush, 
  Hammer, 
  Wrench, 
  Droplet, 
  Zap, 
  Home,
  DoorClosed,
  Fence,
  Square,
  PackageOpen,
  Ruler,
  Wind
} from 'lucide-react';

export function Services() {
  const services = [
    {
      icon: Paintbrush,
      title: 'Interior & Exterior Painting',
      description: 'Professional painting services for homes and businesses with premium finishes.',
      image: 'https://images.unsplash.com/photo-1674376360439-887ea33bce0d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBpbnRlcmlvciUyMHBhaW50aW5nJTIwd2FsbHxlbnwxfHx8fDE3NjgyMjc2MTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: Square,
      title: 'Drywall Installation & Repair',
      description: 'Expert drywall work including installation, patching, texturing, and finishing.',
      image: 'https://images.unsplash.com/photo-1566821988706-ec2b82a77c57?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkcnl3YWxsJTIwaW5zdGFsbGF0aW9uJTIwdGFwaW5nfGVufDF8fHx8MTc2ODIyNzYyMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: PackageOpen,
      title: 'Flooring Services',
      description: 'Hardwood, laminate, tile, vinyl, and carpet installation with precision.',
      image: 'https://images.unsplash.com/photo-1693948568453-a3564f179a84?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXJkd29vZCUyMGZsb29yJTIwaW5zdGFsbGF0aW9ufGVufDF8fHx8MTc2ODIyNzYyMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: Home,
      title: 'Kitchen & Bathroom Remodeling',
      description: 'Complete renovation services to transform your most important spaces.',
      image: 'https://images.unsplash.com/photo-1736390800504-d3963b553aa3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBraXRjaGVuJTIwcmVub3ZhdGlvbnxlbnwxfHx8fDE3NjgxMTI0NTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: Ruler,
      title: 'Cabinet Installation',
      description: 'Custom cabinet installation for kitchens, bathrooms, and storage areas.',
      image: 'https://images.unsplash.com/photo-1686023858213-9653d3248fdc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWJpbmV0JTIwaW5zdGFsbGF0aW9uJTIwa2l0Y2hlbnxlbnwxfHx8fDE3NjgyMjc2MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: Hammer,
      title: 'Trim & Crown Molding',
      description: 'Detailed finish carpentry including baseboards, crown molding, and wainscoting.',
      image: 'https://images.unsplash.com/photo-1707147948074-4bdb6ea49ef8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcm93biUyMG1vbGRpbmclMjB0cmltfGVufDF8fHx8MTc2ODIyNzYyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: DoorClosed,
      title: 'Door & Window Installation',
      description: 'Professional installation of interior/exterior doors and window units.',
      image: 'https://images.unsplash.com/photo-1719050817004-c76eb7c75c99?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb29yJTIwaW5zdGFsbGF0aW9uJTIwY29udHJhY3RvcnxlbnwxfHx8fDE3NjgyMjc2MjF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: Fence,
      title: 'Deck & Fence Construction',
      description: 'Custom deck building and fence installation for enhanced outdoor living.',
      image: 'https://images.unsplash.com/photo-1595844730289-b248c919d6f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWNrJTIwY29uc3RydWN0aW9uJTIwYnVpbGRpbmd8ZW58MXx8fHwxNzY4MjI3NjIyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: Droplet,
      title: 'Plumbing Services',
      description: 'Basic plumbing repairs, fixture installation, and water line work.',
      image: 'https://images.unsplash.com/photo-1751486289950-5c4898a4c773?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbHVtYmluZyUyMHBpcGVzJTIwaW5zdGFsbGF0aW9ufGVufDF8fHx8MTc2ODIyNjk4N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: Zap,
      title: 'Electrical Services',
      description: 'Licensed electrical work including outlet installation and lighting fixtures.',
      image: 'https://images.unsplash.com/photo-1767514536575-82aaf8b0afc4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJpY2FsJTIwd2lyaW5nJTIwb3V0bGV0fGVufDF8fHx8MTc2ODIyNzYyMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: Wind,
      title: 'Pressure Washing',
      description: 'Professional cleaning for siding, decks, driveways, and exterior surfaces.',
      image: 'https://images.unsplash.com/photo-1718152421680-d1580e843cc9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVzc3VyZSUyMHdhc2hpbmclMjBjbGVhbmluZ3xlbnwxfHx8fDE3NjgyMDcxMzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      icon: Wrench,
      title: 'General Carpentry',
      description: 'Custom woodworking and carpentry for any residential or commercial need.',
      image: 'https://images.unsplash.com/photo-1590880795696-20c7dfadacde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJwZW50cnklMjB3b29kd29ya2luZyUyMHRvb2xzfGVufDF8fHx8MTc2ODIyNzYyM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
  ];

  return (
    <section id="services" className="py-24 bg-[#0d1b2a]">
      <div className="max-w-7xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-block bg-slate-100/10 text-slate-200 px-4 py-2 rounded mb-4 text-sm font-medium border border-slate-400/30">
            Our Services
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Complete Professional Services
          </h2>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            From small repairs to major renovations, our 1-4 man crew delivers expert craftsmanship on every project.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-slate-700/50 rounded-lg overflow-hidden hover:border-amber-400/50 transition-all duration-300 hover:shadow-xl hover:shadow-amber-400/20"
            >
              {/* Background Image */}
              <div className="absolute inset-0 opacity-20 group-hover:opacity-30 transition-opacity duration-300">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Content */}
              <div className="relative p-8">
                <div className="bg-slate-700/30 w-16 h-16 rounded-lg flex items-center justify-center mb-6 group-hover:bg-amber-400/20 transition-all border border-slate-600/50 group-hover:border-amber-400/50">
                  <service.icon className="w-8 h-8 text-slate-300 group-hover:text-amber-400 transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-white mb-4">{service.title}</h3>
                <p className="text-slate-400 leading-relaxed">{service.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-16"
        >
          <p className="text-slate-300 mb-6 text-lg">
            Don't see what you need? We handle a wide variety of projects.
          </p>
          <a
            href="#quote"
            className="inline-block bg-gradient-to-r from-slate-100 to-slate-300 text-[#0d1b2a] px-8 py-4 rounded hover:from-white hover:to-slate-100 transition-all font-bold shadow-lg shadow-slate-400/30"
          >
            Discuss Your Project
          </a>
        </motion.div>
      </div>
    </section>
  );
}