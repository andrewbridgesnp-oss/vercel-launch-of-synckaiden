import { motion } from 'motion/react';
import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ExternalLink } from 'lucide-react';

export function Portfolio() {
  const [filter, setFilter] = useState('all');

  const projects = [
    {
      id: 1,
      title: 'Modern Kitchen Renovation',
      description: 'Complete kitchen remodel with custom cabinetry and quartz countertops',
      image: 'https://images.unsplash.com/photo-1736390800504-d3963b553aa3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxraXRjaGVuJTIwcmVub3ZhdGlvbiUyMG1vZGVybnxlbnwxfHx8fDE3NjgxNTY5NzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'renovation',
    },
    {
      id: 2,
      title: 'Interior Painting Project',
      description: 'Professional residential painting with premium finishes',
      image: 'https://images.unsplash.com/photo-1616697412153-7ad8ac8aa5d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbnRlcmlvciUyMHBhaW50aW5nJTIwY29udHJhY3RvcnxlbnwxfHx8fDE3NjgyMjYzOTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'painting',
    },
    {
      id: 3,
      title: 'Master Bathroom Remodel',
      description: 'Luxury bathroom renovation with modern fixtures and tile work',
      image: 'https://images.unsplash.com/photo-1618236444666-105ec54b5b69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYXRocm9vbSUyMHJlbW9kZWwlMjByZW5vdmF0aW9ufGVufDF8fHx8MTc2ODIyNjM5Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'renovation',
    },
    {
      id: 4,
      title: 'Hardwood Flooring Installation',
      description: 'Premium hardwood flooring with expert installation and finishing',
      image: 'https://images.unsplash.com/photo-1693948568453-a3564f179a84?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXJkd29vZCUyMGZsb29yaW5nJTIwaW5zdGFsbGF0aW9ufGVufDF8fHx8MTc2ODIyNjM5M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'flooring',
    },
    {
      id: 5,
      title: 'Custom Deck Construction',
      description: 'Beautiful outdoor deck building with weather-resistant materials',
      image: 'https://images.unsplash.com/photo-1595844730289-b248c919d6f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWNrJTIwYnVpbGRpbmclMjBjb25zdHJ1Y3Rpb258ZW58MXx8fHwxNzY4MjI2NTY1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'carpentry',
    },
    {
      id: 6,
      title: 'Drywall Installation & Repair',
      description: 'Expert drywall hanging, taping, and finishing services',
      image: 'https://images.unsplash.com/photo-1702392183172-17fdef8002b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkcnl3YWxsJTIwaW5zdGFsbGF0aW9uJTIwY29udHJhY3RvcnxlbnwxfHx8fDE3NjgyMjY1NjR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'renovation',
    },
    {
      id: 7,
      title: 'Fence Installation',
      description: 'Custom fence construction for privacy, security, and aesthetics',
      image: 'https://images.unsplash.com/photo-1767063007903-05c3233f3ad7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW5jZSUyMGNvbnN0cnVjdGlvbiUyMGJ1aWxkaW5nfGVufDF8fHx8MTc2ODIyNjU2NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'exterior',
    },
    {
      id: 8,
      title: 'Electrical & Plumbing Work',
      description: 'Licensed electrical and plumbing installations and repairs',
      image: 'https://images.unsplash.com/photo-1767514536570-83d70c024247?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJpY2FsJTIwd2lyaW5nJTIwd29ya3xlbnwxfHx8fDE3NjgyMjU1ODl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      category: 'technical',
    },
  ];

  const categories = [
    { id: 'all', label: 'All Projects' },
    { id: 'renovation', label: 'Renovations' },
    { id: 'painting', label: 'Painting' },
    { id: 'carpentry', label: 'Carpentry' },
    { id: 'flooring', label: 'Flooring' },
    { id: 'exterior', label: 'Exterior' },
    { id: 'technical', label: 'Technical' },
  ];

  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.category === filter);

  return (
    <section id="portfolio" className="py-24 bg-[#1b263b]">
      <div className="max-w-7xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-block bg-slate-100/10 text-slate-200 px-4 py-2 rounded mb-4 text-sm font-medium border border-slate-400/30">
            Our Work
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Portfolio of Excellence
          </h2>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto mb-8">
            Showcasing our commitment to quality craftsmanship and customer satisfaction.
          </p>

          {/* Filter Buttons */}
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setFilter(category.id)}
                className={`px-6 py-2 rounded transition-all font-medium ${
                  filter === category.id
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-[#0d1b2a] shadow-lg shadow-amber-400/30'
                    : 'bg-slate-800/50 text-slate-300 hover:bg-slate-700 border border-slate-700 hover:border-amber-400/50'
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-lg bg-slate-800/50 border border-slate-700 hover:border-slate-400 transition-all duration-300"
            >
              <div className="relative h-80 overflow-hidden">
                <ImageWithFallback
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d1b2a]/95 via-[#0d1b2a]/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                <div className="absolute inset-0 flex items-end p-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-full">
                    <h3 className="text-2xl font-bold text-white mb-2">{project.title}</h3>
                    <p className="text-slate-300 mb-4">{project.description}</p>
                    <button className="flex items-center gap-2 text-slate-200 hover:text-white transition-colors">
                      View Details <ExternalLink className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-slate-300 transition-colors">
                  {project.title}
                </h3>
                <p className="text-slate-400">{project.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}