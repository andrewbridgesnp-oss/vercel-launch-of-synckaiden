import { motion } from 'motion/react';
import { Shield, FileText, Lock, AlertTriangle } from 'lucide-react';

export function LegalDisclaimers() {
  return (
    <section className="py-16 bg-[#0d1b2a] border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-white mb-8 text-center">Legal Information & Disclaimers</h2>
          
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {/* Estimate Disclaimer */}
            <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-slate-700 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <AlertTriangle className="w-8 h-8 text-slate-300 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-white mb-3">Estimate Disclaimer</h3>
                  <p className="text-sm text-slate-400 leading-relaxed">
                    All estimates provided through our online system are preliminary and based on general market data. 
                    Final quotes are subject to change following a detailed on-site inspection and assessment of specific 
                    project requirements. Estimates do not constitute a binding contract or guarantee of final pricing.
                  </p>
                </div>
              </div>
            </div>

            {/* Liability Notice */}
            <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-slate-700 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <Shield className="w-8 h-8 text-slate-300 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-white mb-3">Liability & Insurance</h3>
                  <p className="text-sm text-slate-400 leading-relaxed">
                    Cox&Co Professional Services is fully licensed and insured. All work is performed in accordance with 
                    local building codes and regulations. We maintain comprehensive general liability insurance and workers' 
                    compensation coverage for your protection and peace of mind.
                  </p>
                </div>
              </div>
            </div>

            {/* Privacy Policy */}
            <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-slate-700 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <Lock className="w-8 h-8 text-slate-300 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-white mb-3">Privacy & Data Protection</h3>
                  <p className="text-sm text-slate-400 leading-relaxed">
                    Your personal information and project details are kept strictly confidential. We do not share, sell, 
                    or distribute your information to third parties. Photos and project information submitted may be used 
                    for portfolio purposes only with your explicit written consent.
                  </p>
                </div>
              </div>
            </div>

            {/* Terms of Service */}
            <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-slate-700 rounded-lg p-6">
              <div className="flex items-start gap-4">
                <FileText className="w-8 h-8 text-slate-300 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-white mb-3">Terms of Service</h3>
                  <p className="text-sm text-slate-400 leading-relaxed">
                    All projects are governed by a written contract specifying scope of work, timeline, payment terms, 
                    and warranty information. Changes to project scope require written authorization and may affect 
                    pricing and timeline. Warranties cover workmanship defects for a specified period post-completion.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Legal Text */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6">
            <h3 className="text-lg font-bold text-white mb-4">Important Legal Information</h3>
            <div className="space-y-3 text-sm text-slate-400">
              <p>
                <strong className="text-slate-300">Permits & Regulations:</strong> Cox&Co will advise on necessary 
                permits for your project. Permit fees are additional and will be clearly outlined in the final quote. 
                All work complies with local, state, and federal regulations.
              </p>
              <p>
                <strong className="text-slate-300">Payment Terms:</strong> Standard payment terms include a deposit 
                upon contract signing, progress payments at agreed milestones, and final payment upon project completion 
                and client approval. Specific terms will be detailed in your contract.
              </p>
              <p>
                <strong className="text-slate-300">Warranty:</strong> We stand behind our work with a comprehensive 
                warranty covering defects in workmanship. Material warranties are provided by manufacturers. Warranty 
                duration and specific coverage will be outlined in your project contract.
              </p>
              <p>
                <strong className="text-slate-300">Dispute Resolution:</strong> In the unlikely event of a dispute, 
                we commit to good-faith negotiation and mediation before pursuing legal action. All contracts are 
                governed by the laws of the jurisdiction where services are performed.
              </p>
              <p>
                <strong className="text-slate-300">Room Visualizer Disclaimer:</strong> The room visualization feature 
                is provided as a conceptual design tool. Actual results may vary based on lighting, materials, 
                installation conditions, and other factors. Visualizations are not guarantees of final appearance.
              </p>
              <p className="pt-2 border-t border-slate-800 mt-4">
                <strong className="text-slate-300">License Information:</strong> Cox&Co Professional Services operates 
                under all required local licenses and permits. License numbers and certifications available upon request. 
                All technicians are trained, background-checked professionals.
              </p>
            </div>
          </div>

          <p className="text-center text-xs text-slate-500 mt-8">
            Last Updated: January 12, 2026 | For questions regarding our legal policies, please contact us directly.
          </p>
        </motion.div>
      </div>
    </section>
  );
}