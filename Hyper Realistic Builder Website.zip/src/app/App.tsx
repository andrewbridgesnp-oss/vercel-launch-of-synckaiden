import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { About } from './components/About';
import { Testimonials } from './components/Testimonials';
import { QuoteForm } from './components/QuoteForm';
import { Contact } from './components/Contact';
import { BuilderProIntegration } from './components/BuilderProIntegration';
import { LegalDisclaimers } from './components/LegalDisclaimers';
import { Footer } from './components/Footer';
import { SEOHead } from './components/SEOHead';
import { BackToTop } from './components/BackToTop';
import { Analytics } from './components/Analytics';

export default function App() {
  return (
    <>
      <SEOHead />
      <Analytics />
      <div className="min-h-screen bg-[#0d1b2a]">
        <Header />
        <main>
          <Hero />
          <Services />
          <Portfolio />
          <About />
          <Testimonials />
          <QuoteForm />
          <BuilderProIntegration />
          <Contact />
          <LegalDisclaimers />
        </main>
        <Footer />
        <BackToTop />
      </div>
    </>
  );
}