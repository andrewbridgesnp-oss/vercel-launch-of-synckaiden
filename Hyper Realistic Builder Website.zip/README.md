
  # Hyper Realistic Builder Website

  This is a code bundle for Hyper Realistic Builder Website. The original project is available at https://www.figma.com/design/gH3h9KVX7a7BAyteIzKA3I/Hyper-Realistic-Builder-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  