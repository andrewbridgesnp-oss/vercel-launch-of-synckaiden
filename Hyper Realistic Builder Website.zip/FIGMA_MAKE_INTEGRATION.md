# How Cox & Company Website Connects with Builder Pro App

## 🎯 Both Apps Built in Figma Make - Here's How They Work Together

Since both your **Cox & Company website** and **Builder Pro app** are built in Figma Make (not deployed with backends), they connect using **browser storage** and **URL parameters**.

---

## 📱 **How It Works:**

### **Step 1: Client Submits Quote on Website**
1. Client fills out quote form on Cox & Company website
2. Clicks "Submit Request"
3. Quote is saved to browser's `localStorage` with unique Project ID (e.g., `COX-1736724000-abc123`)
4. Client sees success message with option to "Connect to Builder Pro"

### **Step 2: Data Transfer to Builder Pro**
When client clicks "Enter Builder Pro URL":
- You (or client) paste your published Builder Pro app URL
- Website creates special link with project data in URL:

```
https://your-builder-pro-app.com?projectId=COX-1736724000-abc123&clientName=John+Doe&clientEmail=john@email.com&service=painting&estimate=5000&...
```

### **Step 3: Builder Pro Receives Data**
Your Builder Pro app can read these URL parameters to:
- Auto-populate client information
- Display project details
- Show the estimate
- Start project management

---

## 💾 **What Gets Saved:**

### **In Browser localStorage:**
```json
{
  "projectId": "COX-1736724000-abc123",
  "clientInfo": {
    "name": "John Doe",
    "email": "john@email.com",
    "phone": "(706) 555-0100",
    "address": "123 Main St"
  },
  "projectDetails": {
    "service": "painting",
    "projectType": "residential",
    "squareFootage": "1500",
    "timeline": "1-2weeks",
    "description": "Need interior painting..."
  },
  "estimate": 5000,
  "photos": ["photo1.jpg", "photo2.jpg"],
  "status": "pending",
  "timestamp": "2026-01-12T10:30:00Z"
}
```

---

## 🔗 **Integration Steps:**

### **For Your Builder Pro App:**

Add this code to read the incoming project data:

```typescript
// In your Builder Pro App.tsx or main component
import { useEffect, useState } from 'react';

function BuilderProApp() {
  const [projectData, setProjectData] = useState(null);

  useEffect(() => {
    // Read URL parameters
    const params = new URLSearchParams(window.location.search);
    
    if (params.has('projectId')) {
      const project = {
        projectId: params.get('projectId'),
        clientName: params.get('clientName'),
        clientEmail: params.get('clientEmail'),
        clientPhone: params.get('clientPhone'),
        service: params.get('service'),
        estimate: params.get('estimate'),
        timestamp: params.get('timestamp'),
      };
      
      setProjectData(project);
      
      // Save to Builder Pro's own localStorage
      localStorage.setItem('builder_pro_projects', JSON.stringify([project]));
    }
  }, []);

  return (
    <div>
      {projectData && (
        <div>
          <h2>New Project: {projectData.projectId}</h2>
          <p>Client: {projectData.clientName}</p>
          <p>Service: {projectData.service}</p>
          <p>Estimate: ${projectData.estimate}</p>
        </div>
      )}
    </div>
  );
}
```

---

## 🚀 **How to Use (When Both Are Published):**

### **Scenario 1: You Testing Internally**
1. Publish Cox & Company website → Get URL A
2. Publish Builder Pro app → Get URL B
3. Submit quote on Website (URL A)
4. When prompted, enter Builder Pro URL (URL B)
5. Click "Open Builder Pro" - it opens with all data!

### **Scenario 2: Real Client Flow**
1. **Client visits website** → Fills out quote form
2. **You receive notification** (email/SMS - requires backend)
3. **You log into Builder Pro** → Create project manually
4. OR **Client clicks "Connect to Builder Pro"** → Automatically sends data to your dashboard

---

## 📋 **Current Limitations (No Backend):**

❌ **What DOESN'T Work:**
- Real-time sync between apps
- Automatic email notifications
- Data persistence across devices (localStorage is per-browser)
- Photo file uploads (only file names are stored)

✅ **What DOES Work:**
- Quote form submissions save locally
- Data transfers via URL
- Instant estimates
- All UI interactions
- Same-browser data access

---

## 🎯 **Setup Instructions:**

### **1. Publish Both Apps**
```
Cox & Company Website → https://site-abc123.figmake.com
Builder Pro App → https://app-xyz789.figmake.com
```

### **2. Add Builder Pro URL to Website**
Update the BuilderProIntegration component with your Builder Pro URL:

In `/src/app/components/BuilderProIntegration.tsx`, find the section with "Connect Now" button and add:

```typescript
const BUILDER_PRO_URL = 'https://app-xyz789.figmake.com';
```

### **3. Test the Flow**
1. Submit quote on website
2. Click "Enter Builder Pro URL"
3. Paste your Builder Pro app URL
4. Data transfers automatically!

---

## 🔄 **Future Enhancements (When You Add Backend):**

When you're ready to make it fully production:

1. **Add Supabase** (I can help!)
   - Real database for quotes
   - Automatic sync between apps
   - Email notifications
   - Photo storage

2. **Real-time Updates**
   - WebSocket connection
   - Live status changes
   - Push notifications

3. **Authentication**
   - Client logins
   - Secure project access
   - Team collaboration

---

## 📞 **Need Help?**

Just tell me:
- ✅ "Connect this to Supabase" - I'll set up real database
- ✅ "Add email notifications" - I'll integrate SendGrid
- ✅ "Make it work across devices" - I'll add cloud sync
- ✅ "I published Builder Pro, here's the URL" - I'll hardcode it in

**Right now, you can absolutely publish both and test the entire flow!**
