# Builder Pro App Integration Guide

## Overview
This document outlines how to integrate the Cox & Company Professional Services website with your Builder Pro app for seamless project management and client communication.

## Integration Points

### 1. Quote Form Submission
When a client submits a quote request, the data can be sent to your Builder Pro app.

**Endpoint**: `POST /api/quotes`

**Request Payload**:
```json
{
  "clientInfo": {
    "name": "string",
    "email": "string",
    "phone": "string",
    "address": "string"
  },
  "projectDetails": {
    "service": "string",
    "projectType": "residential|commercial",
    "squareFootage": "number",
    "timeline": "string",
    "description": "string"
  },
  "estimate": "number",
  "photos": ["file[]"],
  "timestamp": "datetime"
}
```

**Response**:
```json
{
  "success": true,
  "projectId": "string",
  "message": "Quote created successfully",
  "builderProLink": "https://builderpro.app/projects/{projectId}"
}
```

### 2. Project Synchronization
Real-time sync between website and Builder Pro app.

**Endpoint**: `GET /api/projects/{projectId}`

**Response**:
```json
{
  "projectId": "string",
  "status": "pending|in-progress|completed",
  "timeline": {
    "startDate": "date",
    "estimatedCompletion": "date",
    "actualCompletion": "date|null"
  },
  "updates": [
    {
      "date": "datetime",
      "message": "string",
      "photos": ["url[]"]
    }
  ],
  "team": [
    {
      "name": "string",
      "role": "string",
      "contact": "string"
    }
  ]
}
```

### 3. Client Authentication
Secure client portal access.

**Endpoint**: `POST /api/auth/client-login`

**Request**:
```json
{
  "email": "string",
  "projectId": "string"
}
```

**Response**:
```json
{
  "success": true,
  "token": "jwt-token",
  "clientPortalUrl": "https://builderpro.app/client/dashboard"
}
```

## Implementation Steps

### Step 1: Set Environment Variables
```bash
BUILDER_PRO_API_URL=https://api.builderpro.app
BUILDER_PRO_API_KEY=your-api-key-here
BUILDER_PRO_SECRET=your-secret-key-here
```

### Step 2: Update Quote Form Component
In `/src/app/components/QuoteForm.tsx`, update the `handleSubmit` function:

```typescript
const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setSubmitStatus('submitting');
  
  try {
    const response = await fetch(`${process.env.BUILDER_PRO_API_URL}/api/quotes`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.BUILDER_PRO_API_KEY}`,
      },
      body: JSON.stringify({
        clientInfo: {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          address: formData.address,
        },
        projectDetails: {
          service: formData.service,
          projectType: formData.projectType,
          squareFootage: parseFloat(formData.squareFootage),
          timeline: formData.timeline,
          description: formData.description,
        },
        estimate,
        timestamp: new Date().toISOString(),
      }),
    });
    
    const data = await response.json();
    
    if (data.success) {
      setSubmitStatus('success');
      // Optionally redirect to Builder Pro
      if (connectToBuilderPro) {
        window.location.href = data.builderProLink;
      }
    } else {
      setSubmitStatus('error');
    }
  } catch (error) {
    console.error('Error submitting quote:', error);
    setSubmitStatus('error');
  }
};
```

### Step 3: Enable Real-Time Updates
Use WebSocket connection for live project updates:

```typescript
// src/utils/builderProSocket.ts
import { io } from 'socket.io-client';

export const connectToBuilderPro = (projectId: string) => {
  const socket = io(process.env.BUILDER_PRO_API_URL, {
    auth: {
      token: process.env.BUILDER_PRO_API_KEY,
    },
  });
  
  socket.emit('join-project', projectId);
  
  socket.on('project-update', (update) => {
    console.log('Project update received:', update);
    // Update UI with new project status
  });
  
  return socket;
};
```

## Features Enabled by Integration

### ✅ Automated Project Creation
- Quote submissions automatically create projects in Builder Pro
- Client information is synced instantly

### ✅ Real-Time Status Updates
- Clients can see project progress on the website
- Automatic notifications for milestones

### ✅ Document Management
- Contracts and invoices generated in Builder Pro
- Accessible through client portal on website

### ✅ Schedule Synchronization
- Crew availability synced with project timelines
- Calendar integration for client appointments

### ✅ Photo & Progress Tracking
- Construction photos uploaded to Builder Pro
- Displayed in website client portal

### ✅ Communication Hub
- Direct messaging between client and crew
- Email/SMS notifications from Builder Pro

## Security Considerations

1. **API Key Management**: Never expose API keys in client-side code
2. **Authentication**: Use JWT tokens for client portal access
3. **Data Encryption**: All API calls should use HTTPS
4. **Rate Limiting**: Implement rate limits on API endpoints
5. **Input Validation**: Sanitize all user inputs before sending to Builder Pro

## Testing

### Development Environment
```bash
# Set test API endpoint
BUILDER_PRO_API_URL=https://api-staging.builderpro.app
```

### Production Checklist
- [ ] API credentials configured
- [ ] Webhooks set up for real-time updates
- [ ] Error handling implemented
- [ ] Analytics tracking configured
- [ ] Client notifications tested
- [ ] Security audit completed

## Support
For Builder Pro API documentation and support:
- Email: support@builderpro.app
- Documentation: https://docs.builderpro.app
- Status: https://status.builderpro.app

## Maintenance
- Review API logs weekly
- Monitor connection status
- Update API version as needed
- Backup client data regularly
