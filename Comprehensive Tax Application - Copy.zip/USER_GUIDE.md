# KAIDEN - Complete User Guide

## 🚀 How to Use KAIDEN Tax Platform

### **Navigation is Fixed!** ✅

Your app now has a **sidebar navigation** (desktop) and **mobile menu** that works everywhere.

---

## 📱 **Navigation Flow**

### **Desktop (Sidebar)**
- **Home** - Main welcome page
- **AI Chat** - Talk to KAIDEN about your taxes
- **Tax Calculator** - Full tax dashboard with results
- **Crypto Tax** - Cryptocurrency tax calculations
- **Import CSV** - Upload tax data from files
- **Upgrade** - View pricing plans

### **Mobile (Hamburger Menu)**
- Tap menu icon (top right)
- Same options as desktop
- Slides out from top

---

## 🎯 **3 Ways to Use KAIDEN**

### **Method 1: Manual Input (Recommended for First Time)**

1. Click **"Home"** in sidebar
2. Click **"Start Tax Calculation"** button
3. Fill out the tax input form:
   - Filing status
   - W-2 wages
   - Self-employment income
   - Crypto income
   - Deductions
4. Click **"Calculate My Taxes"**
5. See instant results on Tax Dashboard

**✅ Data is saved automatically in your browser**

---

### **Method 2: Import CSV (For CPAs/Power Users)**

1. Click **"Import CSV"** in sidebar
2. Click **"Open File Manager"**
3. Upload your CSV file:
   - **Tax Return CSV**: W-2s, 1099s, income data
   - **Crypto CSV**: Transaction history from exchanges
4. System imports data automatically
5. View results on appropriate dashboard

**CSV Format Examples:**

**Tax Return CSV:**
```csv
field,value
filing_status,single
w2_income,85000
self_employment_income,25000
crypto_income,15000
ira_contributions,6500
```

**Crypto CSV:**
```csv
date,type,asset,amount,price,fee
2024-01-15,buy,BTC,0.5,45000,25
2024-02-20,sell,BTC,0.3,52000,30
```

---

### **Method 3: AI Chat (Get Insights)**

1. Click **"AI Chat"** in sidebar
2. Press **spacebar** or click microphone
3. Ask KAIDEN questions:
   - "What deductions am I missing?"
   - "Should I contribute to an IRA?"
   - "How can I reduce my crypto taxes?"
4. Get instant AI-powered insights

**Quick Actions Available:**
- Tax calculation
- Crypto report
- Deduction analysis
- Planning scenarios

---

## 💾 **Data Storage Options**

### **Option 1: Browser Only (No Account)**
- ✅ Works immediately
- ✅ No login required
- ✅ Data saved in sessionStorage
- ⚠️ Data lost when browser closes
- **Perfect for:** Quick calculations, trying the app

### **Option 2: Save to Account (Recommended)**
- ✅ Data persists forever
- ✅ Access from any device
- ✅ CPA can access your data
- ✅ Required for paid plans
- **Perfect for:** Real tax planning

**To create account:**
1. Click **user icon** in sidebar
2. Sign up with email
3. Data automatically syncs

---

## 📊 **Tax Dashboard Features**

Once you calculate taxes, the dashboard shows:

### **Summary Cards:**
- 💰 Total Tax Owed
- 💵 Refund Amount
- 📈 Effective Tax Rate
- 🎯 Optimization Opportunities

### **Detailed Breakdown:**
- Federal tax calculation
- State tax calculation
- Self-employment tax
- Alternative Minimum Tax (AMT)

### **Export Options:**
1. **CSV Export** - Download for CPA
2. **Save to Account** - Store in cloud
3. **Print** - Physical copy

---

## 🪙 **Crypto Tax Features**

### **What It Does:**
- ✅ Calculates gains/losses per transaction
- ✅ Detects wash sales
- ✅ Supports FIFO, LIFO, HIFO methods
- ✅ Handles multiple exchanges
- ✅ Generates Schedule D forms

### **How to Use:**
1. Navigate to **Crypto Tax** in sidebar
2. Either:
   - Import CSV from exchange
   - Enter transactions manually
3. Select calculation method (FIFO/LIFO/HIFO)
4. Review results
5. Export to CSV for filing

---

## 🤖 **AI Chat Features**

### **What KAIDEN Can Do:**

**Tax Planning:**
- "What's my estimated tax?"
- "Should I bunch deductions?"
- "When should I sell investments?"

**Crypto Specific:**
- "How do I minimize crypto taxes?"
- "What are wash sales?"
- "Should I harvest losses?"

**Compliance:**
- "Do I need to file FBAR?"
- "What about AMT?"
- "State tax requirements?"

### **How It Works:**
1. Click AI Chat in sidebar
2. Press spacebar or mic button
3. Speak or type your question
4. KAIDEN analyzes your data
5. Provides personalized insights

**Keyboard Shortcuts:**
- `Space` - Activate microphone
- `H` - Command history
- `I` - Insights panel
- `Q` - Quick actions
- `?` - Keyboard help

---

## 👥 **CPA Workflow**

### **For Tax Preparers:**

**Import Client Data:**
1. Click **Import CSV**
2. Upload client's tax documents
3. System populates all fields
4. Review for accuracy
5. Run calculations

**Export for Client:**
1. Complete tax calculations
2. Click **Export CSV**
3. Send to client
4. Client imports to TurboTax/H&R Block

**Advantages:**
- ✅ Quality control layer
- ✅ Catch TurboTax errors
- ✅ Crypto tax specialization
- ✅ Fast scenario modeling

---

## 💳 **Pricing Plans**

Click **"Upgrade"** in sidebar to see plans:

### **Basic ($29)**
- Federal & State calculations
- CSV export
- Email support

### **Crypto Package ($79)** ⭐ Most Popular
- Everything in Basic
- Crypto wash sales
- FIFO/LIFO/HIFO
- Schedule D generation

### **Premium ($149)**
- Everything in Crypto
- AI optimization
- Multi-year analysis
- Priority support

### **Professional ($299)**
- Everything in Premium
- Unlimited clients
- White-label option
- Phone support

---

## 🔒 **Privacy & Security**

### **Data Storage:**
- **Without Account:** Browser only (sessionStorage)
- **With Account:** Encrypted database (AES-256)
- **Never Shared:** We don't sell your data

### **What We Don't Do:**
- ❌ File your taxes with IRS
- ❌ Provide tax advice
- ❌ Sell your data
- ❌ Store credit cards (Stripe handles it)

### **What We Do:**
- ✅ Calculate taxes accurately
- ✅ Export for your CPA
- ✅ Encrypt all data
- ✅ Give you full control

---

## ❓ **Common Questions**

### **Q: Do I need an account to use KAIDEN?**
A: No! You can use it immediately. Data saves in your browser. Create account to save data permanently.

### **Q: How do I get my tax data into the app?**
Three ways:
1. **Manual entry** - Fill out form
2. **CSV upload** - Import from file
3. **Type/paste** - Copy from other software

### **Q: Where does my data go?**
Without account: Browser only (sessionStorage)
With account: Encrypted Supabase database

### **Q: Can my CPA use this?**
Yes! CPAs can:
- Import client CSVs
- Run calculations
- Export results
- Use as quality control

### **Q: Does it file my taxes?**
No. KAIDEN calculates and exports. You or your CPA files with IRS.

### **Q: What about crypto taxes?**
We specialize in crypto! Features:
- Wash sale detection
- FIFO/LIFO/HIFO methods
- Multi-exchange support
- Schedule D generation

### **Q: Is this tax advice?**
No. KAIDEN is educational. Always consult a licensed tax professional.

---

## 🎯 **Quick Start Guide**

### **First-Time User (5 minutes):**

1. ✅ Accept terms (pops up automatically)
2. ✅ Click "Start Tax Calculation"
3. ✅ Enter your income & deductions
4. ✅ Click "Calculate My Taxes"
5. ✅ Review results on dashboard
6. ✅ Export CSV or create account to save

### **CPA User (2 minutes):**

1. ✅ Click "Import CSV"
2. ✅ Upload client data
3. ✅ Review auto-populated fields
4. ✅ Calculate taxes
5. ✅ Export results

### **Crypto Investor (3 minutes):**

1. ✅ Click "Crypto Tax"
2. ✅ Import exchange CSV
3. ✅ Select FIFO/LIFO/HIFO
4. ✅ Review gains/losses
5. ✅ Export Schedule D

---

## 🚨 **Troubleshooting**

### **"Buttons Don't Work"**
- ✅ FIXED! New navigation sidebar works everywhere
- Try clicking sidebar items
- Mobile: Use hamburger menu (top right)

### **"Where's My Data?"**
- Without account: Saved in browser (sessionStorage)
- Closing browser = data lost
- Solution: Create account to save permanently

### **"How Do I Input Tax Info?"**
- Click "Tax Calculator" in sidebar
- You'll see the input form
- Fill out and click "Calculate"

### **"Can't Find AI Chat"**
- Click "AI Chat" in sidebar
- Press spacebar to activate
- Or click microphone button

### **"CSV Won't Upload"**
- Click "Import CSV" in sidebar
- Then click "Open File Manager"
- Select your CSV file
- Supported formats: .csv only

---

## 📞 **Support**

### **Get Help:**
- Email: support@kaiden.tax
- Legal: legal@kaiden.tax
- Privacy: privacy@kaiden.tax

### **Response Time:**
- Basic: 48 hours
- Premium: 24 hours
- Professional: 4 hours

---

## 🎓 **Best Practices**

### **For Accuracy:**
1. ✅ Enter data carefully
2. ✅ Double-check numbers
3. ✅ Use CSV import for large datasets
4. ✅ Verify with CPA before filing

### **For CPAs:**
1. ✅ Import client CSVs first
2. ✅ Review auto-populated data
3. ✅ Run scenario analysis
4. ✅ Export for client records

### **For Crypto:**
1. ✅ Use exchange export feature
2. ✅ Include ALL transactions
3. ✅ Check for wash sales
4. ✅ Try different methods (FIFO vs HIFO)

---

## 🎉 **You're Ready!**

**Everything now works:**
- ✅ Navigation sidebar
- ✅ Data input forms
- ✅ Tax calculations
- ✅ CSV import/export
- ✅ AI chat insights
- ✅ Account creation
- ✅ Payment processing
- ✅ Legal compliance

**Start using KAIDEN in 3 steps:**
1. Click "Start Tax Calculation"
2. Enter your data
3. Export results

**Need help?** Use the AI Chat - KAIDEN can answer questions about your specific tax situation!

---

**Built with KAIDEN - Your AI Tax Intelligence Platform** 🚀
