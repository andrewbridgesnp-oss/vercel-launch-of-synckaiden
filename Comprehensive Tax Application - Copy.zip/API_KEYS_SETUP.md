# 🔑 API Keys Setup Guide - KAIDEN Tax Platform

## What You Need

To make KAIDEN fully functional with **REAL AI**, you need 2 API keys:

### 1. **OpenAI API Key** (Required for AI Chat) 🤖
- **What it does:** Powers KAIDEN's actual AI responses
- **Cost:** ~$0.50-2.00 per conversation (GPT-4 Turbo)
- **Where to get it:** https://platform.openai.com/api-keys

### 2. **ElevenLabs API Key** (Optional for Voice) 🔊
- **What it does:** Gives KAIDEN a real voice
- **Cost:** Free tier: 10,000 characters/month, Paid: $22/mo for 100K
- **Where to get it:** https://elevenlabs.io/app/settings/api-keys

### 3. **AWS Textract** (Optional for Document OCR) 📄
- **What it does:** Scans W-2s/1099s and extracts numbers
- **Cost:** $1.50 per 1,000 pages
- **Where to get it:** AWS Console (more complex setup)

---

## 🚀 Quick Start (Minimum Viable)

### **Option A: FREE Testing Mode**
**Cost:** $0
**What works:**
- ✅ Tax calculations (fully functional)
- ✅ Crypto tax engine (fully functional)
- ✅ CSV import/export
- ✅ All calculators
- ❌ AI chat (disabled)
- ❌ Voice synthesis (disabled)
- ❌ Document scanning (manual entry only)

**Setup:** Nothing! Just use the app.

---

### **Option B: AI-Powered ($5-20/month)**
**Cost:** ~$5-20 depending on usage
**What works:**
- ✅ Everything from Option A
- ✅ **Real AI chat** with GPT-4
- ✅ Personalized tax insights
- ✅ Smart recommendations
- ❌ Voice synthesis (optional)
- ❌ Document scanning (optional)

**Setup:** Just OpenAI API key (5 minutes)

---

### **Option C: Full Featured ($27-50/month)**
**Cost:** ~$27-50/month
**What works:**
- ✅ Everything from Option B
- ✅ **KAIDEN's voice** (ElevenLabs)
- ✅ Voice readback verification
- ✅ More natural interaction

**Setup:** OpenAI + ElevenLabs (10 minutes)

---

### **Option D: Professional ($50-100/month)**
**Cost:** Variable based on document volume
**What works:**
- ✅ Everything from Option C
- ✅ **Document OCR** - scan W-2s automatically
- ✅ CPA portal with document upload
- ✅ Auto-extract numbers from PDFs

**Setup:** OpenAI + ElevenLabs + AWS (30-60 minutes)

---

## 📝 Step-by-Step Setup

### **STEP 1: Get OpenAI API Key (Required for AI)**

1. **Go to OpenAI:** https://platform.openai.com/signup
2. **Create account** (or sign in)
3. **Add payment method:**
   - Click "Settings" → "Billing"
   - Add credit card
   - Set spending limit (recommend $20/month to start)
4. **Create API key:**
   - Click "API Keys" in left sidebar
   - Click "Create new secret key"
   - Name it "KAIDEN Tax Platform"
   - **COPY THE KEY** (you can't see it again!)
   - Should look like: `sk-proj-abc123...xyz789`

5. **Add to Supabase:**
   - Go to your Supabase project
   - Click "Project Settings" → "Edge Functions" → "Secrets"
   - Click "Add Secret"
   - Name: `OPENAI_API_KEY`
   - Value: Paste your key
   - Click "Save"

**Cost Estimate:**
- Each conversation: ~20,000-50,000 tokens
- Cost: $0.01 per 1,000 input tokens, $0.03 per 1,000 output tokens
- Average: $0.50-2 per conversation
- Budget: $20/month = 10-40 conversations

---

### **STEP 2: Get ElevenLabs Key (Optional - for Voice)**

1. **Go to ElevenLabs:** https://elevenlabs.io
2. **Sign up** for free account
3. **Verify email**
4. **Get API key:**
   - Click your profile icon
   - Click "Profile"
   - Scroll to "API Key"
   - Click "Copy" or "Generate"
   - Should look like: `e11a_abc123...`

5. **Add to Supabase:**
   - Same process as OpenAI
   - Name: `ELEVENLABS_API_KEY`
   - Value: Paste your key

**Cost Estimate:**
- Free tier: 10,000 characters/month
- Paid tier: $22/month for 100,000 characters
- Average response: 200-500 characters
- Free tier = ~20-50 voice responses/month

---

### **STEP 3: AWS Textract (Optional - for OCR)**

⚠️ **This is more complex - only do if you need document scanning**

1. **Create AWS Account:** https://aws.amazon.com
2. **Go to IAM Console**
3. **Create user with Textract permissions**
4. **Generate access keys**
5. **Add to Supabase:**
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`
   - `AWS_REGION` (e.g., "us-east-1")

**Alternative (Easier):**
Use manual data entry or simple CSV import instead.

---

## 🔍 How to Check If It's Working

### **Test OpenAI API:**

1. Go to AI Chat in your app
2. Press spacebar or click mic
3. Ask: "What tax deductions am I missing?"
4. **If working:** You'll get detailed, personalized response
5. **If not working:** You'll see error message

### **Test ElevenLabs API:**

1. In AI chat, get a response
2. **If working:** You'll hear KAIDEN's voice
3. **If not working:** Text only

### **Check Supabase Logs:**

1. Go to Supabase Dashboard
2. Click "Edge Functions"
3. Click "Logs"
4. Look for:
   - ✅ `200 OK` = Working
   - ❌ `500 Error` = Check API key
   - ❌ `401 Unauthorized` = Invalid key

---

## 💰 Cost Breakdown (Real Numbers)

### **Scenario 1: Solo Tax Filer**
- **Usage:** 5 tax conversations per year
- **OpenAI Cost:** $2.50-10/year
- **ElevenLabs:** Free tier (plenty)
- **Total:** ~$10/year

### **Scenario 2: CPA with 20 Clients**
- **Usage:** 20 clients × 2 conversations each = 40 conversations
- **OpenAI Cost:** $20-80/year
- **ElevenLabs:** $22/month during tax season (3 months) = $66
- **Textract:** 20 clients × 5 docs × $0.0015 = $0.15
- **Total:** ~$150/year

### **Scenario 3: Tax Firm (100+ clients)**
- **Usage:** Heavy
- **OpenAI Cost:** $50-200/month during tax season
- **ElevenLabs:** $99/month (creator tier)
- **Textract:** ~$50/month
- **Total:** ~$2,000/year (still cheaper than hiring staff!)

---

## 🛡️ Security Best Practices

### **DO:**
✅ Use separate API keys for dev vs production
✅ Set spending limits on OpenAI account
✅ Store keys in Supabase Secrets (never in code)
✅ Monitor usage regularly
✅ Rotate keys every 90 days

### **DON'T:**
❌ Commit API keys to GitHub
❌ Share keys via email/Slack
❌ Use same key across multiple projects
❌ Skip spending limits
❌ Ignore usage alerts

---

## 🆓 Free Alternatives (If You Can't Afford APIs)

### **For AI Chat:**
1. **Groq API** - Free, fast, but less smart
   - https://console.groq.com
   - Free tier: 14,400 requests/day
   - Use Llama 3 model

2. **Anthropic Claude** - $5 credit to start
   - https://console.anthropic.com
   - Often better for tax questions than GPT-4

3. **Disable AI** - Just use calculators
   - Still valuable as quality control tool
   - Export to TurboTax/CPA

### **For Voice:**
1. **Browser Web Speech API** - Free, built-in
   - Lower quality but $0 cost
   - Works offline

2. **Disable Voice** - Text only
   - Most users don't need voice anyway

### **For Document Scanning:**
1. **Manual entry** - Free
   - Still faster than TurboTax
   - Higher accuracy (you control it)

2. **CSV import** - Free
   - QuickBooks/Xero export directly

---

## ⚙️ Configuration in Supabase

### **Where to Add Secrets:**

```
Supabase Dashboard
  → Your Project
    → Settings (gear icon)
      → Edge Functions
        → Secrets
          → Add Secret
```

### **Required Secrets:**
```
OPENAI_API_KEY=sk-proj-...
```

### **Optional Secrets:**
```
ELEVENLABS_API_KEY=e11a_...
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=us-east-1
```

### **Already Configured (Don't Change):**
```
SUPABASE_URL=...
SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
SUPABASE_DB_URL=...
```

---

## 🐛 Troubleshooting

### **"OpenAI API error: Incorrect API key"**
- **Fix:** Double-check you copied the entire key
- Key should start with `sk-proj-` or `sk-`
- Make sure no extra spaces

### **"OpenAI API error: Insufficient funds"**
- **Fix:** Add payment method to OpenAI account
- Go to https://platform.openai.com/account/billing

### **"Rate limit exceeded"**
- **Fix:** You're using it too much
- Upgrade OpenAI tier or wait

### **"ElevenLabs quota exceeded"**
- **Fix:** Upgrade to paid plan or wait for next month
- Or disable voice temporarily

### **AI responses are slow**
- **Normal:** GPT-4 takes 3-10 seconds
- **If >30s:** Check Supabase logs for errors

---

## 📊 Monitoring Usage

### **OpenAI Dashboard:**
https://platform.openai.com/usage
- See daily costs
- Set alerts
- View API calls

### **ElevenLabs Dashboard:**
https://elevenlabs.io/app/usage
- Character count
- Remaining quota
- Quality metrics

### **Supabase Logs:**
Project → Edge Functions → Logs
- See all API calls
- Debug errors
- Monitor performance

---

## 🎯 Recommendations

### **For Testing/Personal Use:**
**Just get OpenAI API key**
- Cost: ~$5-20/month
- Setup time: 5 minutes
- Gives you 90% of value

### **For CPA Practice:**
**Get OpenAI + ElevenLabs**
- Cost: ~$30-50/month
- Setup time: 10 minutes
- Professional experience

### **For Tax Firm:**
**Get all three APIs**
- Cost: ~$100-200/month
- Setup time: 1 hour
- Full automation

---

## ✅ Quick Checklist

Before launching to clients:

- [ ] OpenAI API key added to Supabase
- [ ] Test AI chat with real question
- [ ] Set spending limit on OpenAI ($20-50/month)
- [ ] (Optional) ElevenLabs key added
- [ ] (Optional) Test voice synthesis
- [ ] Check Supabase logs for errors
- [ ] Test with sample tax data
- [ ] Verify CSV export works
- [ ] Test CPA portal link generation
- [ ] Add credit card to OpenAI account
- [ ] Set up usage alerts

---

## 🎓 Learning Resources

### **OpenAI Documentation:**
- API Quickstart: https://platform.openai.com/docs/quickstart
- Pricing: https://openai.com/api/pricing/
- Rate Limits: https://platform.openai.com/docs/guides/rate-limits

### **ElevenLabs Documentation:**
- API Docs: https://elevenlabs.io/docs/api-reference
- Voice Library: https://elevenlabs.io/voice-library
- Pricing: https://elevenlabs.io/pricing

### **Supabase Edge Functions:**
- Guide: https://supabase.com/docs/guides/functions
- Secrets: https://supabase.com/docs/guides/functions/secrets

---

## 🚀 Next Steps

1. **Get OpenAI API Key** (5 min)
2. **Add to Supabase Secrets** (2 min)
3. **Test AI Chat** (1 min)
4. **Celebrate!** 🎉

You now have a REAL AI-powered tax platform, not fake responses!

---

## 💬 Support

**API Issues:**
- OpenAI: https://help.openai.com
- ElevenLabs: support@elevenlabs.io

**KAIDEN Issues:**
- Email: support@kaiden.tax
- Check: /COMPLIANCE_AUDIT.md
- Read: /USER_GUIDE.md

---

**Cost Summary (TL;DR):**
- Personal use: ~$5-10/year
- CPA practice: ~$150/year
- Tax firm: ~$2,000/year

**Much cheaper than fake features = fraud charges!** 😄
