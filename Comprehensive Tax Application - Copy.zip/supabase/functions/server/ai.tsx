// Real AI Integration for KAIDEN
// Connects to OpenAI GPT-4 for actual tax analysis

export async function getAIResponse(userMessage: string, taxContext: any) {
  const apiKey = Deno.env.get('OPENAI_API_KEY');
  
  if (!apiKey) {
    throw new Error('OpenAI API key not configured. Please add OPENAI_API_KEY to Supabase secrets.');
  }

  const systemPrompt = `You are KAIDEN, an expert tax intelligence AI assistant. You provide accurate, helpful tax information based on current US tax law.

IMPORTANT LIMITATIONS:
- You do NOT file tax returns
- You do NOT provide tax advice
- You are an educational tool
- Users must verify all information with a licensed CPA

Your role:
- Analyze user's tax situation
- Identify optimization opportunities
- Explain tax concepts clearly
- Flag potential issues
- Suggest questions to ask their CPA

Always include: "This is educational information only. Consult a licensed tax professional before making decisions."

User's Tax Context:
${JSON.stringify(taxContext, null, 2)}`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4-turbo-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userMessage }
        ],
        temperature: 0.7,
        max_tokens: 800,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('OpenAI API error:', error);
      throw new Error(`OpenAI API error: ${error.error?.message || 'Unknown error'}`);
    }

    const data = await response.json();
    return {
      response: data.choices[0].message.content,
      tokens: data.usage.total_tokens,
      model: data.model,
    };
  } catch (error) {
    console.error('Error calling OpenAI:', error);
    throw error;
  }
}

export async function getVoiceSynthesis(text: string) {
  const apiKey = Deno.env.get('ELEVENLABS_API_KEY');
  
  if (!apiKey) {
    throw new Error('ElevenLabs API key not configured. Please add ELEVENLABS_API_KEY to Supabase secrets.');
  }

  // Professional female voice ID from ElevenLabs
  const voiceId = 'EXAVITQu4vr4xnSDxMaL'; // Rachel - professional female voice

  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': apiKey,
      },
      body: JSON.stringify({
        text: text,
        model_id: 'eleven_monolingual_v1',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75,
        },
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('ElevenLabs API error:', error);
      throw new Error(`ElevenLabs API error: ${error}`);
    }

    // Return audio blob
    const audioBlob = await response.blob();
    return audioBlob;
  } catch (error) {
    console.error('Error calling ElevenLabs:', error);
    throw error;
  }
}

// Analyze tax return and provide insights
export function analyzeTaxReturn(taxData: any) {
  const insights = [];
  const warnings = [];
  const opportunities = [];

  // Income analysis
  const totalIncome = (taxData.w2Income || 0) + 
                     (taxData.selfEmploymentIncome || 0) + 
                     (taxData.cryptoIncome || 0);

  if (totalIncome > 0) {
    insights.push(`Total reported income: $${totalIncome.toLocaleString()}`);
  }

  // Self-employment tax warning
  if (taxData.selfEmploymentIncome > 0) {
    warnings.push('Self-employment income requires paying self-employment tax (15.3%)');
    opportunities.push('Consider forming an S-Corp if self-employment income > $60,000');
  }

  // Crypto tax analysis
  if (taxData.cryptoIncome > 0) {
    warnings.push('Cryptocurrency transactions require detailed reporting');
    insights.push('Consider tax-loss harvesting for crypto positions');
  }

  // IRA contribution opportunity
  const iraLimit = taxData.filingStatus === 'married-joint' ? 13000 : 6500;
  const iraContributed = taxData.iraContributions || 0;
  if (iraContributed < iraLimit) {
    const remaining = iraLimit - iraContributed;
    opportunities.push(`You can contribute $${remaining} more to IRA for tax deduction`);
  }

  // AMT risk
  if (totalIncome > 200000) {
    warnings.push('High income may trigger Alternative Minimum Tax (AMT)');
  }

  // State tax
  if (taxData.state === 'CA' && totalIncome > 100000) {
    insights.push('California has high state income tax rates. Consider tax planning strategies.');
  }

  return {
    insights,
    warnings,
    opportunities,
    totalIncome,
    estimatedRefund: taxData.estimatedRefund || 0,
  };
}
