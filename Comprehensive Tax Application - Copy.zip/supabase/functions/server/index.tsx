import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'jsr:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';
import { getAIResponse, getVoiceSynthesis, analyzeTaxReturn } from './ai.tsx';

const app = new Hono();

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-3b494ce7/health", (c) => {
  return c.json({ status: "ok" });
});

// Sign up endpoint
app.post("/make-server-3b494ce7/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log(`Signup error: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ success: true, user: data.user });
  } catch (err) {
    console.log(`Signup exception: ${err.message}`);
    return c.json({ error: err.message }, 500);
  }
});

// Save tax return data
app.post("/make-server-3b494ce7/save-tax-return", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      console.log('Unauthorized access to save tax return');
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const taxData = await c.req.json();
    const key = `tax_return:${user.id}`;
    
    await kv.set(key, taxData);
    
    return c.json({ success: true });
  } catch (err) {
    console.log(`Error saving tax return: ${err.message}`);
    return c.json({ error: err.message }, 500);
  }
});

// Get tax return data
app.get("/make-server-3b494ce7/get-tax-return", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      console.log('Unauthorized access to get tax return');
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const key = `tax_return:${user.id}`;
    const taxData = await kv.get(key);
    
    return c.json({ success: true, data: taxData });
  } catch (err) {
    console.log(`Error retrieving tax return: ${err.message}`);
    return c.json({ error: err.message }, 500);
  }
});

// Create Stripe payment session
app.post("/make-server-3b494ce7/create-payment", async (c) => {
  try {
    const { plan } = await c.req.json();
    
    // In a real implementation, you would create a Stripe checkout session here
    // For now, return a success response
    const prices = {
      'basic': 49,
      'crypto': 79,
      'premium': 149,
      'professional': 299
    };
    
    return c.json({ 
      success: true, 
      amount: prices[plan] || 49,
      message: 'Payment processing ready. Integrate Stripe for live payments.' 
    });
  } catch (err) {
    console.log(`Error creating payment: ${err.message}`);
    return c.json({ error: err.message }, 500);
  }
});

// Export tax data as CSV
app.post("/make-server-3b494ce7/export-csv", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      console.log('Unauthorized access to export CSV');
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { taxData } = await c.req.json();
    
    // Convert tax data to CSV format
    let csv = 'Field,Value\n';
    for (const [key, value] of Object.entries(taxData)) {
      csv += `"${key}","${value}"\n`;
    }
    
    return new Response(csv, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': 'attachment; filename="tax_return.csv"'
      }
    });
  } catch (err) {
    console.log(`Error exporting CSV: ${err.message}`);
    return c.json({ error: err.message }, 500);
  }
});

// AI Chat endpoint - REAL AI (not fake)
app.post('/make-server-3b494ce7/ai/chat', async (c) => {
  try {
    const { message, taxContext } = await c.req.json();
    
    if (!message) {
      return c.json({ error: 'Message is required' }, 400);
    }

    // Call real OpenAI API
    const aiResponse = await getAIResponse(message, taxContext);
    
    return c.json({
      response: aiResponse.response,
      tokens: aiResponse.tokens,
      model: aiResponse.model,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('AI chat error:', error);
    return c.json({ 
      error: 'Failed to get AI response', 
      details: error.message,
      fallback: 'I apologize, but I\'m having trouble connecting to my AI service right now. Please try again in a moment. If this persists, contact support@kaiden.tax'
    }, 500);
  }
});

// Voice synthesis endpoint - REAL VOICE
app.post('/make-server-3b494ce7/ai/voice', async (c) => {
  try {
    const { text } = await c.req.json();
    
    if (!text) {
      return c.json({ error: 'Text is required' }, 400);
    }

    // Call ElevenLabs API
    const audioBlob = await getVoiceSynthesis(text);
    
    // Return audio file
    return new Response(audioBlob, {
      headers: {
        'Content-Type': 'audio/mpeg',
        'Content-Disposition': 'inline; filename="kaiden-voice.mp3"',
      },
    });
  } catch (error: any) {
    console.error('Voice synthesis error:', error);
    return c.json({ 
      error: 'Failed to synthesize voice', 
      details: error.message 
    }, 500);
  }
});

// Tax analysis endpoint - REAL INSIGHTS
app.post('/make-server-3b494ce7/tax/analyze', async (c) => {
  try {
    const taxData = await c.req.json();
    
    // Analyze tax return
    const analysis = analyzeTaxReturn(taxData);
    
    // Get AI insights
    const aiPrompt = `Analyze this tax situation and provide 3 specific, actionable recommendations:\n${JSON.stringify(analysis, null, 2)}`;
    const aiResponse = await getAIResponse(aiPrompt, taxData);
    
    return c.json({
      analysis,
      aiInsights: aiResponse.response,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Tax analysis error:', error);
    return c.json({ 
      error: 'Failed to analyze tax return', 
      details: error.message 
    }, 500);
  }
});

Deno.serve(app.fetch);