import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Redirect } from "wouter";
import { toast } from "sonner";
import {
  Globe,
  Plus,
  Settings,
  ExternalLink,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Trash2,
  Edit,
  Crown,
} from "lucide-react";

interface Subdomain {
  id: string;
  subdomain: string;
  fullUrl: string;
  status: "active" | "pending" | "error";
  clientName: string;
  createdAt: string;
  tier: "vip" | "premium" | "standard";
}

// Mock data - in production this would come from the backend
const mockSubdomains: Subdomain[] = [
  {
    id: "1",
    subdomain: "bougie",
    fullUrl: "bougie.synckaiden.com",
    status: "active",
    clientName: "Bougie Boutique",
    createdAt: "2025-01-01",
    tier: "vip",
  },
  {
    id: "2",
    subdomain: "coxandco",
    fullUrl: "coxandco.synckaiden.com",
    status: "pending",
    clientName: "Cox and Co Professional Solutions",
    createdAt: "2025-01-08",
    tier: "vip",
  },
];

export default function SubdomainManager() {
  const { user, isAuthenticated, loading } = useAuth();
  const [subdomains, setSubdomains] = useState<Subdomain[]>(mockSubdomains);
  const [newSubdomain, setNewSubdomain] = useState("");
  const [clientName, setClientName] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  // Check if user is admin
  const isAdmin = user?.role === "admin";

  const handleCreateSubdomain = async () => {
    if (!newSubdomain || !clientName) {
      toast.error("Please fill in all fields");
      return;
    }

    // Validate subdomain format
    const subdomainRegex = /^[a-z0-9-]+$/;
    if (!subdomainRegex.test(newSubdomain)) {
      toast.error("Subdomain can only contain lowercase letters, numbers, and hyphens");
      return;
    }

    // Check if subdomain already exists
    if (subdomains.some((s) => s.subdomain === newSubdomain)) {
      toast.error("This subdomain is already taken");
      return;
    }

    setIsCreating(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const newEntry: Subdomain = {
      id: Date.now().toString(),
      subdomain: newSubdomain,
      fullUrl: `${newSubdomain}.synckaiden.com`,
      status: "pending",
      clientName,
      createdAt: new Date().toISOString().split("T")[0],
      tier: "vip",
    };

    setSubdomains((prev) => [...prev, newEntry]);
    setNewSubdomain("");
    setClientName("");
    setIsCreating(false);
    toast.success("Subdomain created successfully! DNS propagation may take up to 24 hours.");
  };

  const handleDeleteSubdomain = (id: string) => {
    setSubdomains((prev) => prev.filter((s) => s.id !== id));
    toast.success("Subdomain removed");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
            <Globe className="h-8 w-8 text-primary" />
          </div>
          <p className="text-muted-foreground">Loading subdomain manager...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="luxury-card max-w-md">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-500/20 flex items-center justify-center">
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
            <h2 className="text-xl font-bold mb-2">Access Denied</h2>
            <p className="text-muted-foreground">
              Subdomain management is only available to administrators.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            <span className="gradient-text">Subdomain Manager</span>
          </h1>
          <p className="text-muted-foreground">
            Manage VIP client subdomains on synckaiden.com
          </p>
        </div>

        {/* Create New Subdomain */}
        <Card className="luxury-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-primary" />
              Create New Subdomain
            </CardTitle>
            <CardDescription>
              Add a new subdomain for a VIP client
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <Label htmlFor="subdomain">Subdomain</Label>
                <div className="flex items-center gap-2 mt-1">
                  <Input
                    id="subdomain"
                    placeholder="clientname"
                    value={newSubdomain}
                    onChange={(e) => setNewSubdomain(e.target.value.toLowerCase())}
                  />
                  <span className="text-muted-foreground whitespace-nowrap">.synckaiden.com</span>
                </div>
              </div>
              <div>
                <Label htmlFor="clientName">Client/Business Name</Label>
                <Input
                  id="clientName"
                  placeholder="Client Business Name"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>
            <Button
              onClick={handleCreateSubdomain}
              disabled={isCreating || !newSubdomain || !clientName}
              className="btn-shine"
            >
              {isCreating ? (
                <>
                  <Clock className="h-4 w-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Subdomain
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Existing Subdomains */}
        <Card className="luxury-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" />
              Active Subdomains
            </CardTitle>
            <CardDescription>
              {subdomains.length} subdomain(s) configured
            </CardDescription>
          </CardHeader>
          <CardContent>
            {subdomains.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No subdomains configured yet. Create your first one above.
              </div>
            ) : (
              <div className="space-y-4">
                {subdomains.map((subdomain) => (
                  <div
                    key={subdomain.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-secondary/50"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center">
                        <Globe className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{subdomain.fullUrl}</span>
                          <Badge
                            variant={subdomain.status === "active" ? "default" : "outline"}
                            className={subdomain.status === "active" ? "bg-green-500" : ""}
                          >
                            {subdomain.status === "active" && <CheckCircle2 className="h-3 w-3 mr-1" />}
                            {subdomain.status === "pending" && <Clock className="h-3 w-3 mr-1" />}
                            {subdomain.status}
                          </Badge>
                          {subdomain.tier === "vip" && (
                            <Badge className="bg-yellow-500/20 text-yellow-500">
                              <Crown className="h-3 w-3 mr-1" />
                              VIP
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {subdomain.clientName} - Created {subdomain.createdAt}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" asChild>
                        <a
                          href={`https://${subdomain.fullUrl}`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                      <Button variant="outline" size="sm">
                        <Settings className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-500 hover:text-red-600"
                        onClick={() => handleDeleteSubdomain(subdomain.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Info Alert */}
        <Alert className="mt-8">
          <Globe className="h-4 w-4" />
          <AlertTitle>DNS Configuration</AlertTitle>
          <AlertDescription>
            New subdomains are automatically configured with SSL certificates. DNS propagation typically takes 15-30 minutes but can take up to 24 hours in some cases.
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}
