/**
 * LEGAL COMPLIANCE FRAMEWORK
 * 
 * Implements:
 * - Terms of Service enforcement
 * - Privacy Policy compliance
 * - Financial disclaimers
 * - Consent recording (immutable)
 * - GDPR/CCPA compliance
 * - Data retention policies
 * - Right to be forgotten
 * - Audit trail for legal defense
 */

import crypto from 'crypto';
import { z } from 'zod';

/**
 * Consent types
 */
export enum ConsentType {
  TERMS_OF_SERVICE = 'TERMS_OF_SERVICE',
  PRIVACY_POLICY = 'PRIVACY_POLICY',
  FINANCIAL_DISCLAIMER = 'FINANCIAL_DISCLAIMER',
  DATA_PROCESSING = 'DATA_PROCESSING',
  MARKETING = 'MARKETING',
  THIRD_PARTY_SHARING = 'THIRD_PARTY_SHARING',
}

/**
 * Consent record (immutable)
 */
export interface ConsentRecord {
  id: string;
  userId: string;
  email: string;
  consentType: ConsentType;
  version: string;
  accepted: boolean;
  timestamp: number;
  ipAddress: string;
  userAgent: string;
  documentHash: string;
  signature: string;
}

/**
 * Legal document version
 */
export interface LegalDocument {
  type: ConsentType;
  version: string;
  content: string;
  effectiveDate: number;
  hash: string;
  lastUpdated: number;
}

/**
 * Generate document hash for immutability
 */
function generateDocumentHash(content: string): string {
  return crypto.createHash('sha256').update(content).digest('hex');
}

/**
 * Generate consent signature
 */
function generateConsentSignature(
  userId: string,
  consentType: ConsentType,
  documentHash: string,
  timestamp: number,
  ipAddress: string
): string {
  const data = `${userId}|${consentType}|${documentHash}|${timestamp}|${ipAddress}`;
  return crypto.createHash('sha256').update(data).digest('hex');
}

/**
 * Terms of Service
 */
export const TERMS_OF_SERVICE: LegalDocument = {
  type: ConsentType.TERMS_OF_SERVICE,
  version: '1.0.0',
  effectiveDate: Date.now(),
  lastUpdated: Date.now(),
  content: `
# TERMS OF SERVICE

**Effective Date:** ${new Date().toLocaleDateString()}

## 1. ACCEPTANCE OF TERMS

By accessing and using Synckaiden ("Service"), you accept and agree to be bound by the terms and provision of this agreement.

## 2. USE LICENSE

Permission is granted to temporarily download one copy of the materials (information or software) on Synckaiden for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:

- Modify or copy the materials
- Use the materials for any commercial purpose or for any public display
- Attempt to decompile or reverse engineer any software contained on Synckaiden
- Remove any copyright or other proprietary notations from the materials
- Transfer the materials to another person or "mirror" the materials on any other server
- Violate any applicable laws or regulations

## 3. DISCLAIMER

The materials on Synckaiden are provided on an 'as is' basis. Synckaiden makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.

## 4. LIMITATIONS

In no event shall Synckaiden or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Synckaiden.

## 5. ACCURACY OF MATERIALS

The materials appearing on Synckaiden could include technical, typographical, or photographic errors. Synckaiden does not warrant that any of the materials on Synckaiden are accurate, complete, or current.

## 6. MODIFICATIONS

Synckaiden may revise these terms of service for Synckaiden at any time without notice. By using this website, you are agreeing to be bound by the then current version of these terms of service.

## 7. GOVERNING LAW

These terms and conditions are governed by and construed in accordance with the laws of the United States, and you irrevocably submit to the exclusive jurisdiction of the courts in that location.

## 8. FINANCIAL DISCLAIMER

Synckaiden provides financial tools and information for educational purposes only. We are not financial advisors. All information provided is for informational purposes only and should not be construed as professional financial advice. Always consult with a qualified financial advisor before making investment decisions.

## 9. NO REFUNDS POLICY

All purchases are final. No refunds are provided after purchase. You may cancel your subscription at any time, and you will have access to the Service through the end of your current billing period.

## 10. LIMITATION OF LIABILITY

In no event shall Synckaiden, its directors, employees, or agents be liable to you for any damages, losses, and causes of action for accessing, using or attempting to use the Service, including any indirect, incidental, special, consequential, loss of profits, or exemplary damages, even if Synckaiden has been advised of the possibility of such damages.
`,
  hash: '',
};

/**
 * Privacy Policy
 */
export const PRIVACY_POLICY: LegalDocument = {
  type: ConsentType.PRIVACY_POLICY,
  version: '1.0.0',
  effectiveDate: Date.now(),
  lastUpdated: Date.now(),
  content: `
# PRIVACY POLICY

**Effective Date:** ${new Date().toLocaleDateString()}

## 1. INFORMATION WE COLLECT

We collect information you provide directly to us, such as when you create an account, make a purchase, or contact us for support. This includes:

- Name and email address
- Payment information
- Profile information
- Communication preferences

We also collect information automatically when you use our Service:

- IP address
- Browser type and version
- Device type
- Pages visited
- Time spent on pages
- Referring URL
- Log data

## 2. HOW WE USE YOUR INFORMATION

We use the information we collect to:

- Provide, maintain, and improve our Service
- Process transactions and send related information
- Send promotional communications (with your consent)
- Respond to your inquiries
- Comply with legal obligations
- Enforce our Terms of Service
- Prevent fraud and security issues

## 3. DATA RETENTION

We retain your personal information for as long as necessary to provide our Service and fulfill the purposes outlined in this Privacy Policy. You may request deletion of your data at any time, subject to legal obligations.

## 4. DATA SECURITY

We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the Internet is 100% secure.

## 5. THIRD-PARTY SHARING

We do not sell, trade, or rent your personal information to third parties. We may share information with:

- Service providers who assist us in operating our website and conducting our business
- Legal authorities when required by law
- Business partners with your consent

## 6. COOKIES

We use cookies to enhance your experience on our Service. You can control cookie settings through your browser.

## 7. YOUR RIGHTS

Depending on your location, you may have certain rights regarding your personal information, including:

- Right to access your data
- Right to correct inaccurate data
- Right to delete your data
- Right to opt-out of marketing communications
- Right to data portability

## 8. CONTACT US

If you have questions about this Privacy Policy, please contact us at support@synckaiden.com.

## 9. CHANGES TO THIS POLICY

We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on our website.
`,
  hash: '',
};

/**
 * Financial Disclaimer
 */
export const FINANCIAL_DISCLAIMER: LegalDocument = {
  type: ConsentType.FINANCIAL_DISCLAIMER,
  version: '1.0.0',
  effectiveDate: Date.now(),
  lastUpdated: Date.now(),
  content: `
# FINANCIAL DISCLAIMER

**Effective Date:** ${new Date().toLocaleDateString()}

## IMPORTANT - PLEASE READ CAREFULLY

This Financial Disclaimer applies to all financial information, tools, and services provided by Synckaiden.

## 1. NOT FINANCIAL ADVICE

Synckaiden provides financial tools, calculators, and information for educational purposes only. Nothing on Synckaiden should be construed as professional financial advice, investment advice, or a recommendation to buy or sell any security.

## 2. NO WARRANTY

All information provided is on an "as is" basis. Synckaiden makes no warranties, express or implied, regarding the accuracy, completeness, or timeliness of any information provided.

## 3. CONSULT A PROFESSIONAL

Before making any financial decisions, you should consult with a qualified financial advisor, accountant, or attorney. Past performance is not indicative of future results.

## 4. RISK DISCLOSURE

All investments involve risk, including possible loss of principal. Synckaiden is not responsible for any financial losses resulting from the use of our Service.

## 5. NO LIABILITY

Synckaiden shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising out of your use of or inability to use the Service, even if Synckaiden has been advised of the possibility of such damages.

## 6. MARKET CONDITIONS

Market conditions, interest rates, and other factors can change rapidly. Information provided may become outdated without notice.

## 7. THIRD-PARTY INFORMATION

Synckaiden may display information from third-party sources. We do not endorse or guarantee the accuracy of such information.

## 8. ACCEPTANCE

By using Synckaiden, you acknowledge that you have read this disclaimer and agree to be bound by its terms.
`,
  hash: '',
};

/**
 * Initialize document hashes
 */
function initializeDocuments(): void {
  TERMS_OF_SERVICE.hash = generateDocumentHash(TERMS_OF_SERVICE.content);
  PRIVACY_POLICY.hash = generateDocumentHash(PRIVACY_POLICY.content);
  FINANCIAL_DISCLAIMER.hash = generateDocumentHash(FINANCIAL_DISCLAIMER.content);
}

initializeDocuments();

/**
 * Record user consent
 */
export function recordConsent(
  userId: string,
  email: string,
  consentType: ConsentType,
  accepted: boolean,
  ipAddress: string,
  userAgent: string,
  documentHash: string
): ConsentRecord {
  const signature = generateConsentSignature(
    userId,
    consentType,
    documentHash,
    Date.now(),
    ipAddress
  );

  return {
    id: `consent_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`,
    userId,
    email,
    consentType,
    version: getDocumentVersion(consentType),
    accepted,
    timestamp: Date.now(),
    ipAddress,
    userAgent,
    documentHash,
    signature,
  };
}

/**
 * Get document version
 */
function getDocumentVersion(consentType: ConsentType): string {
  switch (consentType) {
    case ConsentType.TERMS_OF_SERVICE:
      return TERMS_OF_SERVICE.version;
    case ConsentType.PRIVACY_POLICY:
      return PRIVACY_POLICY.version;
    case ConsentType.FINANCIAL_DISCLAIMER:
      return FINANCIAL_DISCLAIMER.version;
    default:
      return '1.0.0';
  }
}

/**
 * Verify consent signature
 */
export function verifyConsentSignature(consent: ConsentRecord): boolean {
  const expectedSignature = generateConsentSignature(
    consent.userId,
    consent.consentType,
    consent.documentHash,
    consent.timestamp,
    consent.ipAddress
  );

  return consent.signature === expectedSignature;
}

/**
 * Get legal document
 */
export function getLegalDocument(consentType: ConsentType): LegalDocument {
  switch (consentType) {
    case ConsentType.TERMS_OF_SERVICE:
      return TERMS_OF_SERVICE;
    case ConsentType.PRIVACY_POLICY:
      return PRIVACY_POLICY;
    case ConsentType.FINANCIAL_DISCLAIMER:
      return FINANCIAL_DISCLAIMER;
    default:
      throw new Error(`Unknown consent type: ${consentType}`);
  }
}

/**
 * Check if user has accepted all required consents
 */
export function hasAcceptedAllConsents(consents: ConsentRecord[]): boolean {
  const requiredConsents = [
    ConsentType.TERMS_OF_SERVICE,
    ConsentType.PRIVACY_POLICY,
    ConsentType.FINANCIAL_DISCLAIMER,
  ];

  return requiredConsents.every((required) =>
    consents.some((consent) => consent.consentType === required && consent.accepted)
  );
}

/**
 * Get user consent history
 */
export function getUserConsentHistory(
  userId: string,
  consents: ConsentRecord[]
): ConsentRecord[] {
  return consents
    .filter((consent) => consent.userId === userId)
    .sort((a, b) => b.timestamp - a.timestamp);
}

/**
 * Prepare user data for deletion (GDPR right to be forgotten)
 */
export interface DataDeletionRequest {
  userId: string;
  email: string;
  requestedAt: number;
  reason?: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  completedAt?: number;
}

/**
 * Create data deletion request
 */
export function createDataDeletionRequest(
  userId: string,
  email: string,
  reason?: string
): DataDeletionRequest {
  return {
    userId,
    email,
    requestedAt: Date.now(),
    reason,
    status: 'pending',
  };
}

/**
 * Validation schemas
 */
export const consentRecordSchema = z.object({
  userId: z.string(),
  email: z.string().email(),
  consentType: z.nativeEnum(ConsentType),
  accepted: z.boolean(),
  ipAddress: z.string(),
  userAgent: z.string(),
  documentHash: z.string(),
});

export const dataDeletionRequestSchema = z.object({
  userId: z.string(),
  email: z.string().email(),
  reason: z.string().optional(),
});

export default {
  ConsentType,
  TERMS_OF_SERVICE,
  PRIVACY_POLICY,
  FINANCIAL_DISCLAIMER,
  recordConsent,
  verifyConsentSignature,
  getLegalDocument,
  hasAcceptedAllConsents,
  getUserConsentHistory,
  createDataDeletionRequest,
};
