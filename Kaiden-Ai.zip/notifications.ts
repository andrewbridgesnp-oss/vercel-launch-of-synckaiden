import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";

// Mock SendGrid and Twilio implementations
// In production, replace with actual API calls

const sendEmail = async (email: string, subject: string, content: string) => {
  console.log(`[Email] Sending to ${email}: ${subject}`);
  // TODO: Integrate SendGrid API
  // const sgMail = require("@sendgrid/mail");
  // sgMail.setApiKey(process.env.SENDGRID_API_KEY);
  // await sgMail.send({
  //   to: email,
  //   from: "noreply@kaiden.ai",
  //   subject,
  //   html: content,
  // });
  return { success: true };
};

const sendSMS = async (phone: string, message: string) => {
  console.log(`[SMS] Sending to ${phone}: ${message}`);
  // TODO: Integrate Twilio API
  // const twilio = require("twilio");
  // const client = twilio(
  //   process.env.TWILIO_ACCOUNT_SID,
  //   process.env.TWILIO_AUTH_TOKEN
  // );
  // await client.messages.create({
  //   body: message,
  //   from: process.env.TWILIO_PHONE_NUMBER,
  //   to: phone,
  // });
  return { success: true };
};

export const notificationRouter = router({
  // Send email notification
  sendEmail: protectedProcedure
    .input(
      z.object({
        recipientEmail: z.string().email(),
        subject: z.string(),
        templateType: z.enum(["welcome", "upgrade", "special", "reminder", "support"]),
        data: z.any().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const templates: Record<string, (data: any) => string> = {
          welcome: () => `
            <h1>Welcome to Sync with Kaiden</h1>
            <p>We're excited to have you on board!</p>
            <p>Get started by exploring your dashboard and creating your first agent.</p>
          `,
          upgrade: (data) => `
            <h1>Upgrade Your Plan</h1>
            <p>You're eligible for an upgrade to ${data?.planName || "our premium plan"}!</p>
            <p>Unlock unlimited agents, advanced analytics, and priority support.</p>
          `,
          special: (data) => `
            <h1>Special Offer for You</h1>
            <p>${data?.message || "Check out this exclusive offer just for you!"}</p>
          `,
          reminder: (data) => `
            <h1>Reminder</h1>
            <p>${data?.message || "Don't forget about your pending tasks!"}</p>
          `,
          support: (data) => `
            <h1>Support Ticket</h1>
            <p>Thank you for contacting us. We'll get back to you soon!</p>
            <p>Ticket ID: ${data?.ticketId || "N/A"}</p>
          `,
        };

        const content = templates[input.templateType]?.(input.data) || "Email content";
        await sendEmail(input.recipientEmail, input.subject, content);

        return { success: true, message: "Email sent successfully" };
      } catch (error) {
        console.error("Email send error:", error);
        return { success: false, error: "Failed to send email" };
      }
    }),

  // Send SMS notification
  sendSMS: protectedProcedure
    .input(
      z.object({
        recipientPhone: z.string(),
        message: z.string(),
        templateType: z.enum(["welcome", "upgrade", "special", "reminder", "appointment", "coupon"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        await sendSMS(input.recipientPhone, input.message);
        return { success: true, message: "SMS sent successfully" };
      } catch (error) {
        console.error("SMS send error:", error);
        return { success: false, error: "Failed to send SMS" };
      }
    }),

  // Get notification preferences
  getPreferences: protectedProcedure.query(async ({ ctx }) => {
    return {
      emailNotifications: true,
      smsNotifications: true,
      pushNotifications: false,
      marketingEmails: false,
      notificationFrequency: "real-time",
    };
  }),

  // Update notification preferences
  updatePreferences: protectedProcedure
    .input(
      z.object({
        emailNotifications: z.boolean().optional(),
        smsNotifications: z.boolean().optional(),
        pushNotifications: z.boolean().optional(),
        marketingEmails: z.boolean().optional(),
        notificationFrequency: z.enum(["real-time", "hourly", "daily", "weekly"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // TODO: Save to database
      return { success: true, preferences: input };
    }),

  // Get notification history
  getHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().default(50),
        type: z.enum(["email", "sms", "all"]).default("all"),
      })
    )
    .query(async ({ ctx, input }) => {
      // Mock notification history
      return [
        {
          id: 1,
          type: "email",
          recipient: ctx.user.email,
          subject: "Welcome to Kaiden",
          status: "sent",
          sentAt: new Date(Date.now() - 86400000),
        },
        {
          id: 2,
          type: "sms",
          recipient: "+1234567890",
          message: "Your appointment is confirmed",
          status: "sent",
          sentAt: new Date(Date.now() - 3600000),
        },
        {
          id: 3,
          type: "email",
          recipient: ctx.user.email,
          subject: "Special Offer",
          status: "sent",
          sentAt: new Date(),
        },
      ];
    }),

  // Mark notification as read
  markAsRead: protectedProcedure
    .input(z.object({ notificationId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // TODO: Update database
      return { success: true };
    }),

  // Delete notification
  delete: protectedProcedure
    .input(z.object({ notificationId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // TODO: Delete from database
      return { success: true };
    }),
});

export type NotificationRouter = typeof notificationRouter;
