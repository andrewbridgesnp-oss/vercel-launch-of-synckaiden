  BASIC_DASHBOARD: {
    id: 'basic_dashboard',
    name: 'Basic Dashboard',
    description: 'View basic financial dashboard',
    category: 'dashboard',
    requiredTier: SubscriptionTier.FREE,
  },
  ADVANCED_ANALYTICS: {
    id: 'advanced_analytics',
    name: 'Advanced Analytics',
    description: 'Access to advanced financial analytics',
    category: 'analytics',
    requiredTier: SubscriptionTier.PROFESSIONAL,
    rateLimit: 1000, // 1000 requests per hour
  },
  WEALTH_PLANNING: {
    id: 'wealth_planning',
    name: 'Wealth Planning Tools',
    description: 'Comprehensive wealth planning tools',
    category: 'planning',
    requiredTier: SubscriptionTier.PROFESSIONAL,
    quotaLimit: 100, // 100 plans per month
  },
  INVESTMENT_TRACKING: {
    id: 'investment_tracking',
    name: 'Investment Tracking',
    description: 'Track investments across multiple accounts',
    category: 'tracking',
    requiredTier: SubscriptionTier.STARTER,
  },
  PORTFOLIO_OPTIMIZATION: {
    id: 'portfolio_optimization',
    name: 'Portfolio Optimization',
    description: 'AI-powered portfolio optimization',
    category: 'optimization',
    requiredTier: SubscriptionTier.PROFESSIONAL,
  },
  TAX_PLANNING: {
    id: 'tax_planning',
    name: 'Tax Planning',
    description: 'Tax optimization strategies',
    category: 'tax',
    requiredTier: SubscriptionTier.PROFESSIONAL,
  },
  RETIREMENT_PLANNING: {
    id: 'retirement_planning',
    name: 'Retirement Planning',
    description: 'Retirement planning tools',
    category: 'planning',
    requiredTier: SubscriptionTier.PROFESSIONAL,
  },
  REAL_ESTATE_TOOLS: {
    id: 'real_estate_tools',
    name: 'Real Estate Tools',
    description: 'Real estate investment analysis',
    category: 'realestate',
    requiredTier: SubscriptionTier.PROFESSIONAL,
  },
  CREDIT_REPAIR: {
    id: 'credit_repair',
    name: 'Credit Repair',
    description: 'Credit score monitoring and repair',
    category: 'credit',
    requiredTier: SubscriptionTier.STARTER,
  },
  API_ACCESS: {
    id: 'api_access',
    name: 'API Access',
    description: 'REST API access for integrations',
    category: 'integration',
    requiredTier: SubscriptionTier.ENTERPRISE,
    rateLimit: 10000,
  },
  TEAM_COLLABORATION: {
    id: 'team_collaboration',
    name: 'Team Collaboration',
    description: 'Multi-user team features',
    category: 'collaboration',
    requiredTier: SubscriptionTier.ENTERPRISE,
  },
  CUSTOM_REPORTS: {
    id: 'custom_reports',
    name: 'Custom Reports',
    description: 'Generate custom financial reports',
    category: 'reporting',
    requiredTier: SubscriptionTier.PROFESSIONAL,
  },
};

/**
 * Pricing tiers
 */
export const PRICING_TIERS: Record<SubscriptionTier, Record<string, unknown>> = {