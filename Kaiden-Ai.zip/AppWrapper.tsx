/**
 * App Wrapper with tRPC Provider
 * 
 * This component wraps your entire application with the necessary providers
 * for tRPC, React Query, and authentication.
 * 
 * Usage: Wrap your main App component with this wrapper.
 */

import { ReactNode } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { trpc, queryClient, createTRPCClient } from "@/lib/trpc";
import { Toaster } from "sonner";
import { ThemeProvider } from "next-themes";

interface AppWrapperProps {
  children: ReactNode;
}

export default function AppWrapper({ children }: AppWrapperProps) {
  const trpcClient = createTRPCClient();

  return (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          {children}
          <Toaster
            theme="dark"
            position="bottom-right"
            richColors
            expand
          />
        </ThemeProvider>
      </QueryClientProvider>
    </trpc.Provider>
  );
}

/**
 * Usage in your main.tsx or index.tsx:
 * 
 * import React from 'react'
 * import ReactDOM from 'react-dom/client'
 * import App from './App.tsx'
 * import AppWrapper from './components/AppWrapper'
 * import './index.css'
 * 
 * ReactDOM.createRoot(document.getElementById('root')!).render(
 *   <React.StrictMode>
 *     <AppWrapper>
 *       <App />
 *     </AppWrapper>
 *   </React.StrictMode>,
 * )
 */
