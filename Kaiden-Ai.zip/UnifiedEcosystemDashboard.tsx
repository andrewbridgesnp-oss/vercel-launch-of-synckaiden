/**
 * Unified Ecosystem Dashboard
 * 
 * Master dashboard integrating all apps:
 * - Kayden AI (Business Consultant)
 * - Where's My Tribe (Social Matching)
 * - Syndica Forge (API Integration)
 * - VitalSync (Health Tracking)
 * - Bougie Boutique (E-Commerce)
 * - 80+ Existing Capabilities
 */

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Users,
  Brain,
  Heart,
  Zap,
  ShoppingCart,
  TrendingUp,
  Activity,
  Network,
  Sparkles,
  Settings,
  Bell,
  User,
} from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import ChatWidget from "./ChatWidget";
import AIArenaModule from "./AIArenaModule";
import BougieBoutiqueModule from "./BougieBoutiqueModule";
import WheresMytribeWidget from "./WheresMytribeWidget";
import VitalSyncDashboard from "./VitalSyncDashboard";
import SyndicaForgePanel from "./SyndicaForgePanel";

interface AppModule {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  color: string;
  component: React.ComponentType;
  enabled: boolean;
}

export default function UnifiedEcosystemDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");
  const [notifications, setNotifications] = useState(0);

  const appModules: AppModule[] = [
    {
      id: "kayden",
      name: "Kayden AI",
      icon: <Brain className="w-6 h-6" />,
      description: "AI Business Consultant",
      color: "from-cyan-500 to-blue-600",
      component: AIArenaModule,
      enabled: true,
    },
    {
      id: "tribe",
      name: "Where's My Tribe",
      icon: <Users className="w-6 h-6" />,
      description: "Community & Social Matching",
      color: "from-purple-500 to-pink-600",
      component: WheresMytribeWidget,
      enabled: true,
    },
    {
      id: "vitalsync",
      name: "VitalSync",
      icon: <Heart className="w-6 h-6" />,
      description: "Health & Wellness Tracking",
      color: "from-red-500 to-orange-600",
      component: VitalSyncDashboard,
      enabled: true,
    },
    {
      id: "syndica",
      name: "Syndica Forge",
      icon: <Network className="w-6 h-6" />,
      description: "API & Data Integration",
      color: "from-green-500 to-emerald-600",
      component: SyndicaForgePanel,
      enabled: true,
    },
    {
      id: "boutique",
      name: "Bougie Boutique",
      icon: <ShoppingCart className="w-6 h-6" />,
      description: "E-Commerce & Social Impact",
      color: "from-pink-500 to-rose-600",
      component: BougieBoutiqueModule,
      enabled: true,
    },
  ];

  return (
    <div className="min-h-screen bg-background luxury-gradient">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-border/50 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-white">Synckaiden Ecosystem</h1>
              <p className="text-xs text-gray-400">Unified Platform</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="relative p-2 text-gray-400 hover:text-white transition-colors">
              <Bell className="w-5 h-5" />
              {notifications > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
              )}
            </button>

            <button className="p-2 text-gray-400 hover:text-white transition-colors">
              <Settings className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 pl-4 border-l border-border/50">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <div className="text-sm">
                <p className="font-medium text-white">{user?.name || "User"}</p>
                <p className="text-xs text-gray-400">Premium</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          {/* Tab Navigation */}
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 mb-8 bg-background/50 border border-border/50">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="kayden" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              <span className="hidden sm:inline">Kayden</span>
            </TabsTrigger>
            <TabsTrigger value="tribe" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Tribe</span>
            </TabsTrigger>
            <TabsTrigger value="vitalsync" className="flex items-center gap-2">
              <Heart className="w-4 h-4" />
              <span className="hidden sm:inline">Health</span>
            </TabsTrigger>
            <TabsTrigger value="syndica" className="flex items-center gap-2">
              <Network className="w-4 h-4" />
              <span className="hidden sm:inline">Forge</span>
            </TabsTrigger>
            <TabsTrigger value="boutique" className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4" />
              <span className="hidden sm:inline">Shop</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {appModules.map((module) => (
                <Card
                  key={module.id}
                  className="glass border-border/50 cursor-pointer hover:border-cyan-500/50 transition-all"
                  onClick={() => setActiveTab(module.id)}
                >
                  <CardContent className="p-6 space-y-3">
                    <div
                      className={`w-12 h-12 rounded-lg bg-gradient-to-br ${module.color} flex items-center justify-center text-white`}
                    >
                      {module.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{module.name}</h3>
                      <p className="text-xs text-gray-400">{module.description}</p>
                    </div>
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveTab(module.id);
                      }}
                      className="w-full bg-gradient-to-r from-cyan-500/20 to-blue-600/20 border border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/30"
                    >
                      Open
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="glass border-border/50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">Active Conversations</p>
                      <p className="text-2xl font-bold text-white">24</p>
                    </div>
                    <Brain className="w-8 h-8 text-cyan-400 opacity-50" />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass border-border/50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">Tribe Members</p>
                      <p className="text-2xl font-bold text-white">342</p>
                    </div>
                    <Users className="w-8 h-8 text-purple-400 opacity-50" />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass border-border/50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">Health Score</p>
                      <p className="text-2xl font-bold text-white">87%</p>
                    </div>
                    <Heart className="w-8 h-8 text-red-400 opacity-50" />
                  </div>
                </CardContent>
              </Card>

              <Card className="glass border-border/50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">Integrations</p>
                      <p className="text-2xl font-bold text-white">80+</p>
                    </div>
                    <Zap className="w-8 h-8 text-yellow-400 opacity-50" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Dynamic Tab Content */}
          {appModules.map((module) => (
            <TabsContent key={module.id} value={module.id}>
              <module.component />
            </TabsContent>
          ))}
        </Tabs>
      </main>

      {/* Floating Chat Widget */}
      <ChatWidget />
    </div>
  );
}
