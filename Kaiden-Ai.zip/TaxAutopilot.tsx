/**
 * KAI(DEN) TAX - Year-Round Tax Autopilot Dashboard
 * Real-time tax health monitoring and quarterly estimate tracking
 */

import { useState, useMemo } from 'react';
import {
  TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, Clock,
  DollarSign, Calendar, Bell, Target, Zap, Shield, ArrowRight,
  ChevronDown, ChevronUp, Info, RefreshCw, Download, Settings
} from 'lucide-react';

interface MonthlyData {
  month: number;
  monthName: string;
  projectedIncome: number;
  actualIncome: number;
  projectedWithholding: number;
  actualWithholding: number;
  projectedDeductions: number;
  actualDeductions: number;
}

interface QuarterlyEstimate {
  quarter: string;
  dueDate: string;
  amount: number;
  status: 'paid' | 'due_soon' | 'upcoming' | 'overdue';
  paidAmount?: number;
  paidDate?: string;
}

interface TaxAlert {
  id: string;
  type: 'warning' | 'info' | 'success' | 'error';
  title: string;
  message: string;
  action?: string;
  actionUrl?: string;
  timestamp: Date;
}

// Mock data for demonstration
const MOCK_MONTHLY_DATA: MonthlyData[] = [
  { month: 1, monthName: 'Jan', projectedIncome: 6500, actualIncome: 6750, projectedWithholding: 1200, actualWithholding: 1250, projectedDeductions: 500, actualDeductions: 450 },
  { month: 2, monthName: 'Feb', projectedIncome: 6500, actualIncome: 6500, projectedWithholding: 1200, actualWithholding: 1200, projectedDeductions: 500, actualDeductions: 520 },
  { month: 3, monthName: 'Mar', projectedIncome: 6500, actualIncome: 7200, projectedWithholding: 1200, actualWithholding: 1350, projectedDeductions: 500, actualDeductions: 480 },
  { month: 4, monthName: 'Apr', projectedIncome: 6500, actualIncome: 6500, projectedWithholding: 1200, actualWithholding: 1200, projectedDeductions: 500, actualDeductions: 500 },
  { month: 5, monthName: 'May', projectedIncome: 6500, actualIncome: 6800, projectedWithholding: 1200, actualWithholding: 1280, projectedDeductions: 500, actualDeductions: 550 },
  { month: 6, monthName: 'Jun', projectedIncome: 6500, actualIncome: 6500, projectedWithholding: 1200, actualWithholding: 1200, projectedDeductions: 500, actualDeductions: 500 },
  { month: 7, monthName: 'Jul', projectedIncome: 6500, actualIncome: 0, projectedWithholding: 1200, actualWithholding: 0, projectedDeductions: 500, actualDeductions: 0 },
  { month: 8, monthName: 'Aug', projectedIncome: 6500, actualIncome: 0, projectedWithholding: 1200, actualWithholding: 0, projectedDeductions: 500, actualDeductions: 0 },
  { month: 9, monthName: 'Sep', projectedIncome: 6500, actualIncome: 0, projectedWithholding: 1200, actualWithholding: 0, projectedDeductions: 500, actualDeductions: 0 },
  { month: 10, monthName: 'Oct', projectedIncome: 6500, actualIncome: 0, projectedWithholding: 1200, actualWithholding: 0, projectedDeductions: 500, actualDeductions: 0 },
  { month: 11, monthName: 'Nov', projectedIncome: 6500, actualIncome: 0, projectedWithholding: 1200, actualWithholding: 0, projectedDeductions: 500, actualDeductions: 0 },
  { month: 12, monthName: 'Dec', projectedIncome: 6500, actualIncome: 0, projectedWithholding: 1200, actualWithholding: 0, projectedDeductions: 500, actualDeductions: 0 },
];

const MOCK_QUARTERLY_ESTIMATES: QuarterlyEstimate[] = [
  { quarter: 'Q1 2025', dueDate: 'Apr 15, 2025', amount: 1250, status: 'paid', paidAmount: 1250, paidDate: 'Apr 10, 2025' },
  { quarter: 'Q2 2025', dueDate: 'Jun 15, 2025', amount: 1250, status: 'due_soon' },
  { quarter: 'Q3 2025', dueDate: 'Sep 15, 2025', amount: 1250, status: 'upcoming' },
  { quarter: 'Q4 2025', dueDate: 'Jan 15, 2026', amount: 1250, status: 'upcoming' },
];

const MOCK_ALERTS: TaxAlert[] = [
  {
    id: '1',
    type: 'warning',
    title: 'Q2 Payment Due Soon',
    message: 'Your Q2 estimated tax payment of $1,250 is due in 14 days.',
    action: 'Pay Now',
    timestamp: new Date(),
  },
  {
    id: '2',
    type: 'info',
    title: 'Withholding On Track',
    message: 'Your current withholding is projected to result in a $4,832 refund.',
    action: 'Adjust W-4',
    timestamp: new Date(Date.now() - 86400000),
  },
  {
    id: '3',
    type: 'success',
    title: 'All 1099s Received',
    message: 'We\'ve detected and imported all expected 1099 forms for this tax year.',
    action: 'Review',
    timestamp: new Date(Date.now() - 172800000),
  },
];

export function TaxAutopilotDashboard() {
  const [selectedView, setSelectedView] = useState<'overview' | 'monthly' | 'quarterly'>('overview');
  const [expandedAlerts, setExpandedAlerts] = useState(true);

  // Calculate tax health metrics
  const metrics = useMemo(() => {
    const ytdIncome = MOCK_MONTHLY_DATA.reduce((sum, m) => sum + m.actualIncome, 0);
    const ytdWithholding = MOCK_MONTHLY_DATA.reduce((sum, m) => sum + m.actualWithholding, 0);
    const ytdDeductions = MOCK_MONTHLY_DATA.reduce((sum, m) => sum + m.actualDeductions, 0);
    
    const projectedAnnualIncome = ytdIncome + MOCK_MONTHLY_DATA.filter(m => m.actualIncome === 0).reduce((sum, m) => sum + m.projectedIncome, 0);
    const projectedAnnualWithholding = ytdWithholding + MOCK_MONTHLY_DATA.filter(m => m.actualWithholding === 0).reduce((sum, m) => sum + m.projectedWithholding, 0);
    
    // Simple tax calculation for projection
    const standardDeduction = 14600;
    const taxableIncome = Math.max(0, projectedAnnualIncome - standardDeduction);
    const estimatedTax = calculateSimpleTax(taxableIncome);
    const projectedRefund = projectedAnnualWithholding - estimatedTax;
    
    // Health score calculation
    const incomeVariance = Math.abs(ytdIncome - MOCK_MONTHLY_DATA.filter(m => m.actualIncome > 0).reduce((sum, m) => sum + m.projectedIncome, 0));
    const withholdingVariance = Math.abs(ytdWithholding - MOCK_MONTHLY_DATA.filter(m => m.actualWithholding > 0).reduce((sum, m) => sum + m.projectedWithholding, 0));
    const varianceScore = Math.max(0, 100 - (incomeVariance / 1000) - (withholdingVariance / 500));
    const healthScore = Math.round(varianceScore);
    
    return {
      ytdIncome,
      ytdWithholding,
      ytdDeductions,
      projectedAnnualIncome,
      projectedAnnualWithholding,
      estimatedTax,
      projectedRefund,
      healthScore,
    };
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Year-Round Tax Autopilot</h2>
          <p className="text-[#c0c0c0]/60">Real-time tax health monitoring for Tax Year 2025</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500/10 border border-green-500/30">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-sm text-green-400">Autopilot Active</span>
          </div>
          <button className="p-2 rounded-lg hover:bg-white/5 text-[#c0c0c0]/60 hover:text-white transition-colors">
            <RefreshCw className="w-5 h-5" />
          </button>
          <button className="p-2 rounded-lg hover:bg-white/5 text-[#c0c0c0]/60 hover:text-white transition-colors">
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* View Tabs */}
      <div className="flex gap-2">
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'monthly', label: 'Monthly Tracking' },
          { id: 'quarterly', label: 'Quarterly Estimates' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedView(tab.id as any)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedView === tab.id
                ? 'bg-[#c0c0c0]/10 text-white border border-[#c0c0c0]/20'
                : 'text-[#c0c0c0]/60 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Main Content */}
      {selectedView === 'overview' && (
        <OverviewView metrics={metrics} alerts={MOCK_ALERTS} expandedAlerts={expandedAlerts} setExpandedAlerts={setExpandedAlerts} />
      )}
      {selectedView === 'monthly' && (
        <MonthlyTrackingView data={MOCK_MONTHLY_DATA} />
      )}
      {selectedView === 'quarterly' && (
        <QuarterlyEstimatesView estimates={MOCK_QUARTERLY_ESTIMATES} />
      )}
    </div>
  );
}

function OverviewView({ 
  metrics, 
  alerts, 
  expandedAlerts, 
  setExpandedAlerts 
}: { 
  metrics: any; 
  alerts: TaxAlert[];
  expandedAlerts: boolean;
  setExpandedAlerts: (v: boolean) => void;
}) {
  return (
    <div className="space-y-6">
      {/* Health Score Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 rounded-xl bg-gradient-to-br from-[#1a2744] to-[#0f1d32] border border-[#c0c0c0]/20 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold">Tax Health Score</h3>
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-[#c0c0c0]/60" />
              <span className="text-xs text-[#c0c0c0]/60">Updated 2 hours ago</span>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <MetricCard
              label="Health Score"
              value={`${metrics.healthScore}`}
              suffix="/100"
              color={metrics.healthScore >= 80 ? 'text-green-400' : metrics.healthScore >= 60 ? 'text-amber-400' : 'text-red-400'}
              icon={Shield}
            />
            <MetricCard
              label="Projected Refund"
              value={formatCurrency(metrics.projectedRefund)}
              color={metrics.projectedRefund >= 0 ? 'text-green-400' : 'text-red-400'}
              icon={DollarSign}
              trend={metrics.projectedRefund >= 0 ? '+$342 vs last month' : undefined}
            />
            <MetricCard
              label="YTD Income"
              value={formatCurrency(metrics.ytdIncome)}
              icon={TrendingUp}
            />
            <MetricCard
              label="YTD Withholding"
              value={formatCurrency(metrics.ytdWithholding)}
              icon={Target}
            />
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-[#c0c0c0]/60">Tax Year Progress</span>
              <span>50% (6 of 12 months)</span>
            </div>
            <div className="h-2 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-[#c0c0c0] to-[#e8e8e8] rounded-full" style={{ width: '50%' }} />
            </div>
          </div>
        </div>

        {/* Withholding Status */}
        <div className="rounded-xl bg-[#1a2744]/50 border border-[#c0c0c0]/10 p-6">
          <h4 className="text-lg font-semibold mb-4">Withholding Status</h4>
          <div className="space-y-4">
            <div className="text-center py-4">
              <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${
                metrics.projectedRefund >= 0 
                  ? 'bg-green-500/20 text-green-400' 
                  : 'bg-red-500/20 text-red-400'
              }`}>
                {metrics.projectedRefund >= 0 ? (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    <span className="font-medium">On Track for Refund</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-5 h-5" />
                    <span className="font-medium">May Owe Taxes</span>
                  </>
                )}
              </div>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-[#c0c0c0]/60">Projected Tax</span>
                <span>{formatCurrency(metrics.estimatedTax)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#c0c0c0]/60">Projected Withholding</span>
                <span>{formatCurrency(metrics.projectedAnnualWithholding)}</span>
              </div>
              <div className="h-px bg-white/10 my-2" />
              <div className="flex justify-between font-medium">
                <span>{metrics.projectedRefund >= 0 ? 'Refund' : 'Owed'}</span>
                <span className={metrics.projectedRefund >= 0 ? 'text-green-400' : 'text-red-400'}>
                  {formatCurrency(Math.abs(metrics.projectedRefund))}
                </span>
              </div>
            </div>
            <button className="w-full mt-4 px-4 py-2 bg-white/5 border border-[#c0c0c0]/20 rounded-lg hover:bg-white/10 transition-colors text-sm">
              Adjust W-4 Withholding
            </button>
          </div>
        </div>
      </div>

      {/* Alerts Section */}
      <div className="rounded-xl bg-[#1a2744]/50 border border-[#c0c0c0]/10 overflow-hidden">
        <button
          onClick={() => setExpandedAlerts(!expandedAlerts)}
          className="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center gap-3">
            <Bell className="w-5 h-5 text-[#c0c0c0]" />
            <span className="font-semibold">Tax Alerts</span>
            <span className="px-2 py-0.5 text-xs rounded-full bg-amber-500/20 text-amber-400">
              {alerts.filter(a => a.type === 'warning').length} action needed
            </span>
          </div>
          {expandedAlerts ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
        
        {expandedAlerts && (
          <div className="border-t border-white/10 p-4 space-y-3">
            {alerts.map((alert) => (
              <AlertCard key={alert.id} alert={alert} />
            ))}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <QuickActionCard
          icon={Download}
          title="Export Tax Summary"
          description="Download YTD tax summary PDF"
        />
        <QuickActionCard
          icon={Calendar}
          title="Set Reminders"
          description="Configure payment reminders"
        />
        <QuickActionCard
          icon={Zap}
          title="Run Optimization"
          description="Find tax-saving opportunities"
        />
      </div>
    </div>
  );
}

function MonthlyTrackingView({ data }: { data: MonthlyData[] }) {
  return (
    <div className="space-y-6">
      {/* Monthly Chart */}
      <div className="rounded-xl bg-[#1a2744]/50 border border-[#c0c0c0]/10 p-6">
        <h3 className="text-lg font-semibold mb-6">Income vs Withholding by Month</h3>
        <div className="h-64 flex items-end gap-2">
          {data.map((month) => (
            <div key={month.month} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full flex gap-1 h-48">
                {/* Income bar */}
                <div className="flex-1 flex flex-col justify-end">
                  <div
                    className="w-full bg-blue-500/50 rounded-t"
                    style={{ height: `${(month.actualIncome / 8000) * 100}%` }}
                  />
                </div>
                {/* Withholding bar */}
                <div className="flex-1 flex flex-col justify-end">
                  <div
                    className="w-full bg-green-500/50 rounded-t"
                    style={{ height: `${(month.actualWithholding / 2000) * 100}%` }}
                  />
                </div>
              </div>
              <span className="text-xs text-[#c0c0c0]/60">{month.monthName}</span>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center gap-6 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-blue-500/50" />
            <span className="text-sm text-[#c0c0c0]/60">Income</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-green-500/50" />
            <span className="text-sm text-[#c0c0c0]/60">Withholding</span>
          </div>
        </div>
      </div>

      {/* Monthly Details Table */}
      <div className="rounded-xl bg-[#1a2744]/50 border border-[#c0c0c0]/10 overflow-hidden">
        <div className="p-4 border-b border-white/10">
          <h3 className="font-semibold">Monthly Details</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left p-4 text-sm font-medium text-[#c0c0c0]/60">Month</th>
                <th className="text-right p-4 text-sm font-medium text-[#c0c0c0]/60">Projected Income</th>
                <th className="text-right p-4 text-sm font-medium text-[#c0c0c0]/60">Actual Income</th>
                <th className="text-right p-4 text-sm font-medium text-[#c0c0c0]/60">Variance</th>
                <th className="text-right p-4 text-sm font-medium text-[#c0c0c0]/60">Withholding</th>
              </tr>
            </thead>
            <tbody>
              {data.map((month) => {
                const variance = month.actualIncome - month.projectedIncome;
                const hasData = month.actualIncome > 0;
                return (
                  <tr key={month.month} className="border-b border-white/5 hover:bg-white/5">
                    <td className="p-4 font-medium">{month.monthName}</td>
                    <td className="p-4 text-right text-[#c0c0c0]/60">{formatCurrency(month.projectedIncome)}</td>
                    <td className="p-4 text-right">
                      {hasData ? formatCurrency(month.actualIncome) : <span className="text-[#c0c0c0]/40">—</span>}
                    </td>
                    <td className="p-4 text-right">
                      {hasData ? (
                        <span className={variance >= 0 ? 'text-green-400' : 'text-red-400'}>
                          {variance >= 0 ? '+' : ''}{formatCurrency(variance)}
                        </span>
                      ) : (
                        <span className="text-[#c0c0c0]/40">—</span>
                      )}
                    </td>
                    <td className="p-4 text-right">
                      {hasData ? formatCurrency(month.actualWithholding) : <span className="text-[#c0c0c0]/40">—</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function QuarterlyEstimatesView({ estimates }: { estimates: QuarterlyEstimate[] }) {
  const totalDue = estimates.reduce((sum, e) => sum + e.amount, 0);
  const totalPaid = estimates.filter(e => e.status === 'paid').reduce((sum, e) => sum + (e.paidAmount || 0), 0);

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-xl bg-[#1a2744]/50 border border-[#c0c0c0]/10 p-5">
          <p className="text-sm text-[#c0c0c0]/60 mb-1">Total Estimated Tax</p>
          <p className="text-2xl font-bold">{formatCurrency(totalDue)}</p>
        </div>
        <div className="rounded-xl bg-green-500/10 border border-green-500/30 p-5">
          <p className="text-sm text-green-400/80 mb-1">Total Paid</p>
          <p className="text-2xl font-bold text-green-400">{formatCurrency(totalPaid)}</p>
        </div>
        <div className="rounded-xl bg-amber-500/10 border border-amber-500/30 p-5">
          <p className="text-sm text-amber-400/80 mb-1">Remaining</p>
          <p className="text-2xl font-bold text-amber-400">{formatCurrency(totalDue - totalPaid)}</p>
        </div>
      </div>

      {/* Quarterly Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {estimates.map((estimate) => (
          <div
            key={estimate.quarter}
            className={`rounded-xl p-6 ${
              estimate.status === 'paid'
                ? 'bg-green-500/10 border border-green-500/30'
                : estimate.status === 'due_soon'
                ? 'bg-amber-500/10 border border-amber-500/30'
                : estimate.status === 'overdue'
                ? 'bg-red-500/10 border border-red-500/30'
                : 'bg-[#1a2744]/50 border border-[#c0c0c0]/10'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-semibold">{estimate.quarter}</h4>
              <StatusBadge status={estimate.status} />
            </div>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-[#c0c0c0]/60">Due Date</span>
                <span>{estimate.dueDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#c0c0c0]/60">Amount Due</span>
                <span className="font-semibold">{formatCurrency(estimate.amount)}</span>
              </div>
              {estimate.status === 'paid' && (
                <>
                  <div className="flex justify-between text-green-400">
                    <span>Paid</span>
                    <span>{formatCurrency(estimate.paidAmount || 0)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-[#c0c0c0]/60">
                    <span>Paid On</span>
                    <span>{estimate.paidDate}</span>
                  </div>
                </>
              )}
            </div>
            {estimate.status !== 'paid' && (
              <button
                className={`w-full mt-4 px-4 py-2 rounded-lg font-medium transition-colors ${
                  estimate.status === 'due_soon' || estimate.status === 'overdue'
                    ? 'bg-gradient-to-r from-[#c0c0c0] to-[#e8e8e8] text-[#0a1628] hover:opacity-90'
                    : 'bg-white/5 border border-[#c0c0c0]/20 hover:bg-white/10'
                }`}
              >
                {estimate.status === 'due_soon' || estimate.status === 'overdue' ? 'Pay Now' : 'Schedule Payment'}
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Payment Methods */}
      <div className="rounded-xl bg-[#1a2744]/50 border border-[#c0c0c0]/10 p-6">
        <h3 className="text-lg font-semibold mb-4">Payment Methods</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <PaymentMethodCard
            title="IRS Direct Pay"
            description="Free, secure payment directly to IRS"
            recommended
          />
          <PaymentMethodCard
            title="EFTPS"
            description="Electronic Federal Tax Payment System"
          />
          <PaymentMethodCard
            title="Credit/Debit Card"
            description="1.87% - 1.98% processing fee"
          />
        </div>
      </div>
    </div>
  );
}

// Helper Components
function MetricCard({ label, value, suffix, color, icon: Icon, trend }: {
  label: string;
  value: string;
  suffix?: string;
  color?: string;
  icon: any;
  trend?: string;
}) {
  return (
    <div className="p-4 rounded-lg bg-white/5">
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4 text-[#c0c0c0]/60" />
        <span className="text-xs text-[#c0c0c0]/60">{label}</span>
      </div>
      <p className={`text-2xl font-bold ${color || 'text-white'}`}>
        {value}{suffix && <span className="text-base font-normal text-[#c0c0c0]/60">{suffix}</span>}
      </p>
      {trend && <p className="text-xs text-green-400 mt-1">{trend}</p>}
    </div>
  );
}

function AlertCard({ alert }: { alert: TaxAlert }) {
  const icons = {
    warning: AlertTriangle,
    info: Info,
    success: CheckCircle2,
    error: AlertTriangle,
  };
  const colors = {
    warning: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
    info: 'bg-blue-500/10 border-blue-500/30 text-blue-400',
    success: 'bg-green-500/10 border-green-500/30 text-green-400',
    error: 'bg-red-500/10 border-red-500/30 text-red-400',
  };
  const Icon = icons[alert.type];

  return (
    <div className={`flex items-center justify-between p-4 rounded-lg border ${colors[alert.type]}`}>
      <div className="flex items-center gap-3">
        <Icon className="w-5 h-5" />
        <div>
          <p className="font-medium">{alert.title}</p>
          <p className="text-sm opacity-80">{alert.message}</p>
        </div>
      </div>
      {alert.action && (
        <button className="text-sm font-medium hover:underline flex items-center gap-1">
          {alert.action} <ArrowRight className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}

function QuickActionCard({ icon: Icon, title, description }: {
  icon: any;
  title: string;
  description: string;
}) {
  return (
    <button className="p-4 rounded-xl bg-[#1a2744]/50 border border-[#c0c0c0]/10 hover:border-[#c0c0c0]/30 transition-colors text-left group">
      <Icon className="w-6 h-6 text-[#c0c0c0] mb-3 group-hover:text-white transition-colors" />
      <p className="font-medium mb-1">{title}</p>
      <p className="text-sm text-[#c0c0c0]/60">{description}</p>
    </button>
  );
}

function StatusBadge({ status }: { status: QuarterlyEstimate['status'] }) {
  const styles = {
    paid: 'bg-green-500/20 text-green-400',
    due_soon: 'bg-amber-500/20 text-amber-400',
    upcoming: 'bg-white/10 text-[#c0c0c0]',
    overdue: 'bg-red-500/20 text-red-400',
  };
  const labels = {
    paid: 'Paid',
    due_soon: 'Due Soon',
    upcoming: 'Upcoming',
    overdue: 'Overdue',
  };

  return (
    <span className={`px-2 py-1 text-xs font-medium rounded ${styles[status]}`}>
      {labels[status]}
    </span>
  );
}

function PaymentMethodCard({ title, description, recommended }: {
  title: string;
  description: string;
  recommended?: boolean;
}) {
  return (
    <div className={`p-4 rounded-lg border ${recommended ? 'bg-[#c0c0c0]/5 border-[#c0c0c0]/30' : 'bg-white/5 border-white/10'}`}>
      <div className="flex items-center gap-2 mb-2">
        <span className="font-medium">{title}</span>
        {recommended && (
          <span className="px-2 py-0.5 text-xs rounded bg-[#c0c0c0]/20 text-[#c0c0c0]">Recommended</span>
        )}
      </div>
      <p className="text-sm text-[#c0c0c0]/60">{description}</p>
    </div>
  );
}

// Utility functions
function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

function calculateSimpleTax(taxableIncome: number): number {
  // Simplified 2025 tax calculation for single filer
  const brackets = [
    { max: 11600, rate: 0.10 },
    { max: 47150, rate: 0.12 },
    { max: 100525, rate: 0.22 },
    { max: 191950, rate: 0.24 },
    { max: 243725, rate: 0.32 },
    { max: 609350, rate: 0.35 },
    { max: Infinity, rate: 0.37 },
  ];

  let tax = 0;
  let remaining = taxableIncome;
  let prevMax = 0;

  for (const bracket of brackets) {
    if (remaining <= 0) break;
    const taxable = Math.min(remaining, bracket.max - prevMax);
    tax += taxable * bracket.rate;
    remaining -= taxable;
    prevMax = bracket.max;
  }

  return Math.round(tax);
}

export default TaxAutopilotDashboard;
