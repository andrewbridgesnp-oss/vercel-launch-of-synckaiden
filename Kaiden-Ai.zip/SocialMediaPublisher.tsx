import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Share2, Calendar, TrendingUp, Clock } from "lucide-react";

export default function SocialMediaPublisher() {
  const [activeTab, setActiveTab] = useState("scheduled");

  const scheduledPosts = [
    {
      id: 1,
      platform: "youtube",
      title: "Kaiden AI - Business Automation",
      scheduledFor: "2024-01-12 14:00",
      status: "scheduled",
      engagement: "2.3K views",
    },
    {
      id: 2,
      platform: "tiktok",
      title: "30-second AI demo",
      scheduledFor: "2024-01-12 10:00",
      status: "scheduled",
      engagement: "pending",
    },
    {
      id: 3,
      platform: "instagram",
      title: "Time Restoration Technology",
      scheduledFor: "2024-01-11 18:00",
      status: "published",
      engagement: "5.1K likes",
    },
    {
      id: 4,
      platform: "facebook",
      title: "Agent Swarm Capabilities",
      scheduledFor: "2024-01-11 12:00",
      status: "published",
      engagement: "1.2K shares",
    },
  ];

  const platforms = [
    { name: "youtube", icon: "▶️", color: "text-red-500" },
    { name: "tiktok", icon: "🎵", color: "text-black dark:text-white" },
    { name: "instagram", icon: "📷", color: "text-pink-500" },
    { name: "facebook", icon: "f", color: "text-blue-600" },
    { name: "snapchat", icon: "👻", color: "text-yellow-400" },
  ];

  const getPlatformIcon = (platform: string) => {
    const p = platforms.find((x) => x.name === platform);
    return p ? p.icon : "📱";
  };

  const getPlatformColor = (platform: string) => {
    const p = platforms.find((x) => x.name === platform);
    return p ? p.color : "text-gray-500";
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Share2 className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold">Social Media Publisher</h1>
          </div>
          <p className="text-muted-foreground">Schedule and manage posts across all your social platforms</p>
        </div>

        {/* Platform Overview */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          {platforms.map((p) => (
            <Card key={p.name} className="text-center">
              <CardContent className="pt-6">
                <div className={`text-4xl mb-2 ${p.color}`}>{p.icon}</div>
                <p className="text-sm font-medium capitalize">{p.name}</p>
                <p className="text-xs text-muted-foreground mt-1">Connected</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Scheduled Posts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">12</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Published This Week</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">28</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Engagement</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">127K</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Best Time to Post</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">2 PM</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Post Management</CardTitle>
                <CardDescription>View and manage all your scheduled and published posts</CardDescription>
              </div>
              <Button className="btn-shine">
                <Share2 className="w-4 h-4 mr-2" />
                Create New Post
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
                <TabsTrigger value="published">Published</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>

              <TabsContent value="scheduled" className="space-y-4">
                <div className="space-y-3">
                  {scheduledPosts
                    .filter((p) => p.status === "scheduled")
                    .map((post) => (
                      <div
                        key={post.id}
                        className="p-4 rounded-lg border border-border/50 hover:border-primary/50 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <span className={`text-2xl ${getPlatformColor(post.platform)}`}>
                                {getPlatformIcon(post.platform)}
                              </span>
                              <div>
                                <h3 className="font-semibold">{post.title}</h3>
                                <p className="text-sm text-muted-foreground capitalize">{post.platform}</p>
                              </div>
                            </div>
                          </div>
                          <Badge variant="outline" className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {post.scheduledFor}
                          </Badge>
                        </div>
                        <div className="flex gap-2 justify-end">
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                          <Button variant="outline" size="sm" className="text-destructive">
                            Cancel
                          </Button>
                          <Button size="sm">Publish Now</Button>
                        </div>
                      </div>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="published" className="space-y-4">
                <div className="space-y-3">
                  {scheduledPosts
                    .filter((p) => p.status === "published")
                    .map((post) => (
                      <div
                        key={post.id}
                        className="p-4 rounded-lg border border-border/50 hover:border-primary/50 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <span className={`text-2xl ${getPlatformColor(post.platform)}`}>
                                {getPlatformIcon(post.platform)}
                              </span>
                              <div>
                                <h3 className="font-semibold">{post.title}</h3>
                                <p className="text-sm text-muted-foreground capitalize">{post.platform}</p>
                              </div>
                            </div>
                          </div>
                          <Badge className="bg-green-500/20 text-green-400 border border-green-500/30">
                            {post.engagement}
                          </Badge>
                        </div>
                        <div className="flex gap-2 justify-end">
                          <Button variant="outline" size="sm">
                            View Post
                          </Button>
                          <Button variant="outline" size="sm">
                            Share Again
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="analytics" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        <TrendingUp className="w-4 h-4" />
                        Top Platform
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold mb-2">Instagram</div>
                      <p className="text-sm text-muted-foreground">45.2K engagement this month</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Best Performing Post</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold mb-2">12.5K</div>
                      <p className="text-sm text-muted-foreground">Time Restoration Technology</p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
