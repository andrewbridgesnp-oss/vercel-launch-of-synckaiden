/**
 * Syndica Forge Integration Panel
 * 
 * Manages API integrations, data connections, and webhook management.
 */

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Network,
  Plus,
  Copy,
  Trash2,
  Eye,
  EyeOff,
  Check,
  AlertCircle,
  Loader2,
  RefreshCw,
  Code,
  Settings,
} from "lucide-react";
import { toast } from "sonner";

interface APIKey {
  id: string;
  name: string;
  key: string;
  secret: string;
  created: string;
  lastUsed: string;
  isActive: boolean;
}

interface Integration {
  id: string;
  name: string;
  type: string;
  status: "connected" | "disconnected" | "error";
  lastSync: string;
  endpoint: string;
}

interface Webhook {
  id: string;
  url: string;
  events: string[];
  isActive: boolean;
  lastTriggered: string;
  failureCount: number;
}

export default function SyndicaForgePanel() {
  const [activeTab, setActiveTab] = useState("integrations");
  const [apiKeys, setApiKeys] = useState<APIKey[]>([]);
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [webhooks, setWebhooks] = useState<Webhook[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showSecret, setShowSecret] = useState<Record<string, boolean>>({});
  const [newKeyName, setNewKeyName] = useState("");
  const [newWebhookUrl, setNewWebhookUrl] = useState("");
  const [selectedEvents, setSelectedEvents] = useState<string[]>([]);

  const availableEvents = [
    "user.created",
    "user.updated",
    "order.created",
    "order.completed",
    "payment.received",
    "health.metric.updated",
    "tribe.member.joined",
    "event.created",
  ];

  // Fetch data on mount
  useEffect(() => {
    fetchIntegrations();
    fetchAPIKeys();
    fetchWebhooks();
  }, []);

  const fetchIntegrations = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/syndica/integrations`,
        {
          credentials: "include",
        }
      );
      const data = await response.json();
      setIntegrations(data.integrations || []);
    } catch (error) {
      console.error("Error fetching integrations:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchAPIKeys = async () => {
    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/syndica/keys`,
        {
          credentials: "include",
        }
      );
      const data = await response.json();
      setApiKeys(data.keys || []);
    } catch (error) {
      console.error("Error fetching API keys:", error);
    }
  };

  const fetchWebhooks = async () => {
    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/syndica/webhooks`,
        {
          credentials: "include",
        }
      );
      const data = await response.json();
      setWebhooks(data.webhooks || []);
    } catch (error) {
      console.error("Error fetching webhooks:", error);
    }
  };

  const handleCreateAPIKey = async () => {
    if (!newKeyName.trim()) {
      toast.error("Please enter a key name");
      return;
    }

    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/syndica/keys`,
        {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: newKeyName }),
        }
      );
      const data = await response.json();
      setApiKeys([...apiKeys, data.key]);
      setNewKeyName("");
      toast.success("API key created successfully");
    } catch (error) {
      console.error("Error creating API key:", error);
      toast.error("Failed to create API key");
    }
  };

  const handleDeleteAPIKey = async (keyId: string) => {
    if (!confirm("Are you sure you want to delete this API key?")) return;

    try {
      await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/syndica/keys/${keyId}`,
        {
          method: "DELETE",
          credentials: "include",
        }
      );
      setApiKeys(apiKeys.filter((k) => k.id !== keyId));
      toast.success("API key deleted");
    } catch (error) {
      console.error("Error deleting API key:", error);
      toast.error("Failed to delete API key");
    }
  };

  const handleCopyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  const handleCreateWebhook = async () => {
    if (!newWebhookUrl.trim() || selectedEvents.length === 0) {
      toast.error("Please enter a URL and select events");
      return;
    }

    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/syndica/webhooks`,
        {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            url: newWebhookUrl,
            events: selectedEvents,
          }),
        }
      );
      const data = await response.json();
      setWebhooks([...webhooks, data.webhook]);
      setNewWebhookUrl("");
      setSelectedEvents([]);
      toast.success("Webhook created successfully");
    } catch (error) {
      console.error("Error creating webhook:", error);
      toast.error("Failed to create webhook");
    }
  };

  const handleDeleteWebhook = async (webhookId: string) => {
    if (!confirm("Are you sure you want to delete this webhook?")) return;

    try {
      await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/syndica/webhooks/${webhookId}`,
        {
          method: "DELETE",
          credentials: "include",
        }
      );
      setWebhooks(webhooks.filter((w) => w.id !== webhookId));
      toast.success("Webhook deleted");
    } catch (error) {
      console.error("Error deleting webhook:", error);
      toast.error("Failed to delete webhook");
    }
  };

  const handleTestIntegration = async (integrationId: string) => {
    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/syndica/integrations/${integrationId}/test`,
        {
          method: "POST",
          credentials: "include",
        }
      );
      const data = await response.json();
      if (data.success) {
        toast.success("Integration test successful");
      } else {
        toast.error("Integration test failed");
      }
    } catch (error) {
      console.error("Error testing integration:", error);
      toast.error("Failed to test integration");
    }
  };

  return (
    <div className="w-full space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Network className="w-12 h-12 text-green-400" />
        </div>
        <h2 className="text-4xl font-bold mb-2" style={{
          background: "linear-gradient(135deg, #e0e0e8 0%, #ffffff 50%, #c0c0d0 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}>
          Syndica Forge
        </h2>
        <p className="text-gray-400">
          Manage API integrations, webhooks, and data connections.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-background/50 border border-border/50">
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="api-keys">API Keys</TabsTrigger>
          <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
        </TabsList>

        {/* Integrations Tab */}
        <TabsContent value="integrations" className="space-y-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
          ) : integrations.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <p>No integrations configured yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {integrations.map((integration) => (
                <Card key={integration.id} className="glass border-border/50">
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-white">
                          {integration.name}
                        </h3>
                        <p className="text-xs text-gray-400 mt-1">
                          {integration.type}
                        </p>
                      </div>
                      <div
                        className={`w-3 h-3 rounded-full ${
                          integration.status === "connected"
                            ? "bg-green-500"
                            : integration.status === "error"
                            ? "bg-red-500"
                            : "bg-gray-500"
                        }`}
                      />
                    </div>

                    <div className="space-y-2 text-sm">
                      <p className="text-gray-400">
                        <span className="text-gray-500">Status:</span>{" "}
                        <span className="text-white capitalize">
                          {integration.status}
                        </span>
                      </p>
                      <p className="text-gray-400">
                        <span className="text-gray-500">Last Sync:</span>{" "}
                        <span className="text-white">
                          {new Date(integration.lastSync).toLocaleString()}
                        </span>
                      </p>
                      <p className="text-gray-400 break-all">
                        <span className="text-gray-500">Endpoint:</span>{" "}
                        <code className="text-cyan-300 text-xs">
                          {integration.endpoint}
                        </code>
                      </p>
                    </div>

                    <div className="flex gap-2 pt-2 border-t border-border/50">
                      <Button
                        onClick={() => handleTestIntegration(integration.id)}
                        size="sm"
                        variant="outline"
                        className="flex-1 border-border/50"
                      >
                        <RefreshCw className="w-3 h-3 mr-1" />
                        Test
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 border-border/50"
                      >
                        <Settings className="w-3 h-3 mr-1" />
                        Config
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* API Keys Tab */}
        <TabsContent value="api-keys" className="space-y-6">
          {/* Create New Key */}
          <Card className="glass border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Create New API Key
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                placeholder="Key name (e.g., 'Production API')"
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                className="bg-background/50 border-border/50"
              />
              <Button
                onClick={handleCreateAPIKey}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:opacity-90"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create API Key
              </Button>
            </CardContent>
          </Card>

          {/* Existing Keys */}
          <div className="space-y-4">
            {apiKeys.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <p>No API keys created yet</p>
              </div>
            ) : (
              apiKeys.map((key) => (
                <Card key={key.id} className="glass border-border/50">
                  <CardContent className="p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-white">{key.name}</h3>
                        <p className="text-xs text-gray-400 mt-1">
                          Created: {new Date(key.created).toLocaleDateString()}
                        </p>
                      </div>
                      <div
                        className={`px-2 py-1 rounded text-xs font-medium ${
                          key.isActive
                            ? "bg-green-500/20 text-green-300"
                            : "bg-gray-500/20 text-gray-300"
                        }`}
                      >
                        {key.isActive ? "Active" : "Inactive"}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <code className="flex-1 px-3 py-2 bg-background/50 rounded text-xs text-cyan-300 break-all">
                          {showSecret[key.id] ? key.key : "•".repeat(32)}
                        </code>
                        <Button
                          onClick={() =>
                            setShowSecret({
                              ...showSecret,
                              [key.id]: !showSecret[key.id],
                            })
                          }
                          size="sm"
                          variant="ghost"
                          className="text-gray-400 hover:text-white"
                        >
                          {showSecret[key.id] ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </Button>
                        <Button
                          onClick={() => handleCopyToClipboard(key.key)}
                          size="sm"
                          variant="ghost"
                          className="text-gray-400 hover:text-white"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t border-border/50">
                      <span>Last used: {new Date(key.lastUsed).toLocaleString()}</span>
                      <Button
                        onClick={() => handleDeleteAPIKey(key.id)}
                        size="sm"
                        variant="ghost"
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        {/* Webhooks Tab */}
        <TabsContent value="webhooks" className="space-y-6">
          {/* Create New Webhook */}
          <Card className="glass border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Create New Webhook
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                placeholder="Webhook URL (e.g., https://your-domain.com/webhook)"
                value={newWebhookUrl}
                onChange={(e) => setNewWebhookUrl(e.target.value)}
                className="bg-background/50 border-border/50"
              />

              <div>
                <label className="text-sm text-gray-300 block mb-2">
                  Select Events
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {availableEvents.map((event) => (
                    <label
                      key={event}
                      className="flex items-center gap-2 p-2 rounded hover:bg-background/50 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedEvents.includes(event)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedEvents([...selectedEvents, event]);
                          } else {
                            setSelectedEvents(
                              selectedEvents.filter((ev) => ev !== event)
                            );
                          }
                        }}
                        className="w-4 h-4"
                      />
                      <span className="text-sm text-gray-300">{event}</span>
                    </label>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleCreateWebhook}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:opacity-90"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Webhook
              </Button>
            </CardContent>
          </Card>

          {/* Existing Webhooks */}
          <div className="space-y-4">
            {webhooks.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <p>No webhooks configured yet</p>
              </div>
            ) : (
              webhooks.map((webhook) => (
                <Card key={webhook.id} className="glass border-border/50">
                  <CardContent className="p-6 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="text-sm font-mono text-cyan-300 break-all">
                          {webhook.url}
                        </p>
                        <div className="flex gap-1 mt-2 flex-wrap">
                          {webhook.events.map((event) => (
                            <span
                              key={event}
                              className="text-xs px-2 py-1 bg-purple-500/20 border border-purple-500/30 rounded text-purple-300"
                            >
                              {event}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div
                        className={`w-3 h-3 rounded-full flex-shrink-0 mt-1 ${
                          webhook.isActive ? "bg-green-500" : "bg-gray-500"
                        }`}
                      />
                    </div>

                    <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t border-border/50">
                      <span>
                        Last triggered:{" "}
                        {new Date(webhook.lastTriggered).toLocaleString()}
                      </span>
                      {webhook.failureCount > 0 && (
                        <span className="text-red-400 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {webhook.failureCount} failures
                        </span>
                      )}
                      <Button
                        onClick={() => handleDeleteWebhook(webhook.id)}
                        size="sm"
                        variant="ghost"
                        className="text-red-400 hover:text-red-300"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
