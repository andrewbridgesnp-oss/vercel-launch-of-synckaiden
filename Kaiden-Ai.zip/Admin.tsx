      console.log("[Admin] Received notification:", notification());
      setLiveUpdate());
      setTimeout(() => setLiveUpdate), 2000());

      // Invalidate queries to refresh data