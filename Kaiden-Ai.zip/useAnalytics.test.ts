/**
 * Unit tests for useAnalytics hook
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { renderHook, act, waitFor } from '@testing-library/react';
import { useAnalytics } from './useAnalytics';

describe('useAnalytics', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    global.fetch = vi.fn();
  });

  it('should initialize with correct default state', () => {
    const dateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { result } = renderHook(() => useAnalytics(dateRange));

    expect(result.current.kpiData).toBe(null);
    expect(result.current.dailyMetrics).toEqual([]);
    expect(result.current.revenueMetrics).toEqual([]);
    expect(result.current.loading).toBe(false);
    expect(result.current.error).toBe(null);
  });

  it('should fetch KPI data successfully', async () => {
    const mockKpiData = {
      totalActiveUsers: 1000,
      totalNewUsers: 100,
      totalSessions: 5000,
      totalEvents: 25000,
      avgSessionDuration: 12,
      avgBounceRate: 32.5,
      totalRevenue: 50000,
      totalSubscriptions: 150,
    };

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockKpiData,
    });

    const dateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { result } = renderHook(() => useAnalytics(dateRange));

    await waitFor(() => {
      expect(result.current.kpiData).toEqual(mockKpiData);
    });
  });

  it('should fetch daily metrics successfully', async () => {
    const mockDailyMetrics = [
      {
        date: '2024-01-01',
        activeUsers: 800,
        newUsers: 50,
        totalSessions: 4000,
        totalEvents: 20000,
        avgSessionDuration: 12,
        bounceRate: 32,
        totalRevenue: 5000,
      },
    ];

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockDailyMetrics,
    });

    const dateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { result } = renderHook(() => useAnalytics(dateRange));

    await waitFor(() => {
      expect(result.current.dailyMetrics).toEqual(mockDailyMetrics);
    });
  });

  it('should fetch revenue metrics successfully', async () => {
    const mockRevenueMetrics = [
      { tier: 'Starter', revenue: 9900, transactions: 100 },
      { tier: 'Professional', revenue: 29700, transactions: 100 },
    ];

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockRevenueMetrics,
    });

    const dateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { result } = renderHook(() => useAnalytics(dateRange));

    await waitFor(() => {
      expect(result.current.revenueMetrics).toEqual(mockRevenueMetrics);
    });
  });

  it('should handle fetch errors gracefully', async () => {
    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: false,
      json: async () => ({ message: 'API Error' }),
    });

    const dateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { result } = renderHook(() => useAnalytics(dateRange));

    await waitFor(() => {
      expect(result.current.error).toBeTruthy();
    });
  });

  it('should track events successfully', async () => {
    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => ({}),
    });

    const dateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { result } = renderHook(() => useAnalytics(dateRange));

    await act(async () => {
      await result.current.trackEvent('click', 'button_clicked', 'signup');
    });

    expect(global.fetch).toHaveBeenCalledWith(
      '/api/analytics/track',
      expect.objectContaining({
        method: 'POST',
        body: expect.stringContaining('button_clicked'),
      })
    );
  });

  it('should track feature usage successfully', async () => {
    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => ({}),
    });

    const dateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { result } = renderHook(() => useAnalytics(dateRange));

    await act(async () => {
      await result.current.trackFeatureUsage('voice-sync', 'Voice Sync');
    });

    expect(global.fetch).toHaveBeenCalledWith(
      '/api/analytics/feature-usage',
      expect.objectContaining({
        method: 'POST',
        body: expect.stringContaining('voice-sync'),
      })
    );
  });

  it('should refetch data when refetch methods are called', async () => {
    const mockKpiData = {
      totalActiveUsers: 1000,
      totalNewUsers: 100,
      totalSessions: 5000,
      totalEvents: 25000,
      avgSessionDuration: 12,
      avgBounceRate: 32.5,
      totalRevenue: 50000,
      totalSubscriptions: 150,
    };

    global.fetch = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => mockKpiData,
    });

    const dateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { result } = renderHook(() => useAnalytics(dateRange));

    await act(async () => {
      await result.current.refetch.kpi();
    });

    expect(result.current.kpiData).toEqual(mockKpiData);
  });

  it('should handle date range changes', async () => {
    const mockKpiData = {
      totalActiveUsers: 1000,
      totalNewUsers: 100,
      totalSessions: 5000,
      totalEvents: 25000,
      avgSessionDuration: 12,
      avgBounceRate: 32.5,
      totalRevenue: 50000,
      totalSubscriptions: 150,
    };

    global.fetch = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => mockKpiData,
    });

    const initialDateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { rerender } = renderHook(
      ({ dateRange }) => useAnalytics(dateRange),
      {
        initialProps: { dateRange: initialDateRange },
      }
    );

    const newDateRange = {
      startDate: new Date('2024-02-01'),
      endDate: new Date('2024-02-28'),
    };

    rerender({ dateRange: newDateRange });

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalled();
    });
  });

  it('should provide feature usage data', async () => {
    const mockFeatureUsage = [
      { featureName: 'Voice Sync', usageCount: 500, lastUsed: '2024-01-31', totalTimeSpent: 3600 },
      { featureName: 'Analytics', usageCount: 300, lastUsed: '2024-01-31', totalTimeSpent: 1800 },
    ];

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockFeatureUsage,
    });

    const dateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { result } = renderHook(() => useAnalytics(dateRange));

    await waitFor(() => {
      expect(result.current.featureUsage).toEqual(mockFeatureUsage);
    });
  });

  it('should provide performance metrics', async () => {
    const mockPerformanceMetrics = [
      { endpoint: '/api/users', avgResponseTime: 45, p95ResponseTime: 120, p99ResponseTime: 250, errorRate: 0.5, totalRequests: 1000 },
      { endpoint: '/api/analytics', avgResponseTime: 120, p95ResponseTime: 350, p99ResponseTime: 800, errorRate: 1.2, totalRequests: 500 },
    ];

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockPerformanceMetrics,
    });

    const dateRange = {
      startDate: new Date('2024-01-01'),
      endDate: new Date('2024-01-31'),
    };

    const { result } = renderHook(() => useAnalytics(dateRange));

    await waitFor(() => {
      expect(result.current.performanceMetrics).toEqual(mockPerformanceMetrics);
    });
  });
});
