/**
 * Unique Purchase Code System
 * Anti-theft protection for digital products
 * Each purchase generates a unique code tied to the user
 */

import crypto from 'crypto';
import { getDb } from './db';
import { purchaseCodes, downloadLogs, digitalProducts, digitalPurchases } from '../drizzle/schema';
import { eq, and, sql } from 'drizzle-orm';

// Configuration
const CODE_LENGTH = 32;
const MAX_DOWNLOADS_DEFAULT = 5;
const CODE_EXPIRY_DAYS = 365; // 1 year

/**
 * Generate a cryptographically secure unique purchase code
 */
export function generatePurchaseCode(): string {
  const timestamp = Date.now().toString(36);
  const random = crypto.randomBytes(16).toString('hex');
  const hash = crypto
    .createHash('sha256')
    .update(`${timestamp}-${random}-${process.env.JWT_SECRET || 'kaiden'}`)
    .digest('hex')
    .substring(0, CODE_LENGTH);
  
  return `KAI-${hash.toUpperCase()}`;
}

/**
 * Create a new purchase code for a user and product
 */
export async function createPurchaseCode(
  userId: number,
  productId: number,
  paymentId?: number,
  maxDownloads: number = MAX_DOWNLOADS_DEFAULT
): Promise<{ code: string; expiresAt: Date }> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const code = generatePurchaseCode();
  const expiresAt = new Date(Date.now() + CODE_EXPIRY_DAYS * 24 * 60 * 60 * 1000);

  await db.insert(purchaseCodes).values({
    code,
    userId,
    productId,
    paymentId,
    status: 'active',
    downloadCount: 0,
    maxDownloads,
    expiresAt,
  });

  return { code, expiresAt };
}

/**
 * Validate a purchase code
 * Returns validation result with product info if valid
 */
export async function validatePurchaseCode(
  code: string,
  userId: number
): Promise<{
  valid: boolean;
  reason?: string;
  productId?: number;
  remainingDownloads?: number;
}> {
  const db = await getDb();
  if (!db) return { valid: false, reason: 'Database not available' };

  // Find the purchase code
  const [purchaseCode] = await db
    .select()
    .from(purchaseCodes)
    .where(eq(purchaseCodes.code, code))
    .limit(1);

  if (!purchaseCode) {
    return { valid: false, reason: 'Invalid purchase code' };
  }

  // Check if code belongs to user (anti-sharing)
  if (purchaseCode.userId !== userId) {
    // Log potential sharing attempt
    console.warn(`[SECURITY] Purchase code sharing attempt: code=${code}, owner=${purchaseCode.userId}, attempted_user=${userId}`);
    return { valid: false, reason: 'This purchase code belongs to another account' };
  }

  // Check status
  if (purchaseCode.status === 'revoked') {
    return { valid: false, reason: 'This purchase code has been revoked' };
  }

  if (purchaseCode.status === 'expired') {
    return { valid: false, reason: 'This purchase code has expired' };
  }

  // Check expiration
  if (purchaseCode.expiresAt && new Date(purchaseCode.expiresAt) < new Date()) {
    // Update status to expired
    await db
      .update(purchaseCodes)
      .set({ status: 'expired' })
      .where(eq(purchaseCodes.id, purchaseCode.id));
    
    return { valid: false, reason: 'This purchase code has expired' };
  }

  // Check download limit
  const remainingDownloads = purchaseCode.maxDownloads! - purchaseCode.downloadCount!;
  if (remainingDownloads <= 0) {
    return { 
      valid: false, 
      reason: 'Download limit reached. Contact support for assistance.',
      remainingDownloads: 0
    };
  }

  return {
    valid: true,
    productId: purchaseCode.productId,
    remainingDownloads,
  };
}

/**
 * Record a download and increment counter
 */
export async function recordDownload(
  code: string,
  userId: number,
  ipAddress?: string,
  userAgent?: string
): Promise<{ success: boolean; remainingDownloads: number }> {
  const db = await getDb();
  if (!db) return { success: false, remainingDownloads: 0 };

  // First validate
  const validation = await validatePurchaseCode(code, userId);
  if (!validation.valid) {
    return { success: false, remainingDownloads: 0 };
  }

  // Get purchase code
  const [purchaseCode] = await db
    .select()
    .from(purchaseCodes)
    .where(eq(purchaseCodes.code, code))
    .limit(1);

  if (!purchaseCode) {
    return { success: false, remainingDownloads: 0 };
  }

  // Increment download count
  await db
    .update(purchaseCodes)
    .set({
      downloadCount: sql`${purchaseCodes.downloadCount} + 1`,
      lastDownloadAt: new Date(),
    })
    .where(eq(purchaseCodes.id, purchaseCode.id));

  // Log the download
  await db.insert(downloadLogs).values({
    purchaseCodeId: purchaseCode.id,
    userId,
    productId: purchaseCode.productId,
    ipAddress,
    userAgent,
    success: true,
  });

  return {
    success: true,
    remainingDownloads: validation.remainingDownloads! - 1,
  };
}

/**
 * Revoke a purchase code (for fraud, refund, etc.)
 */
export async function revokePurchaseCode(
  code: string,
  reason: string
): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  await db
    .update(purchaseCodes)
    .set({
      status: 'revoked',
      revokedAt: new Date(),
      revokedReason: reason,
    })
    .where(eq(purchaseCodes.code, code));

  return true;
}

/**
 * Get all purchase codes for a user
 */
export async function getUserPurchaseCodes(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select({
      code: purchaseCodes.code,
      productId: purchaseCodes.productId,
      status: purchaseCodes.status,
      downloadCount: purchaseCodes.downloadCount,
      maxDownloads: purchaseCodes.maxDownloads,
      expiresAt: purchaseCodes.expiresAt,
      createdAt: purchaseCodes.createdAt,
    })
    .from(purchaseCodes)
    .where(eq(purchaseCodes.userId, userId));
}

/**
 * Get download history for a purchase code
 */
export async function getDownloadHistory(code: string, userId: number) {
  const db = await getDb();
  if (!db) return [];

  const [purchaseCode] = await db
    .select()
    .from(purchaseCodes)
    .where(and(
      eq(purchaseCodes.code, code),
      eq(purchaseCodes.userId, userId)
    ))
    .limit(1);

  if (!purchaseCode) {
    return [];
  }

  return db
    .select({
      downloadedAt: downloadLogs.downloadedAt,
      ipAddress: downloadLogs.ipAddress,
      success: downloadLogs.success,
    })
    .from(downloadLogs)
    .where(eq(downloadLogs.purchaseCodeId, purchaseCode.id));
}

/**
 * Check for suspicious activity (multiple IPs, rapid downloads)
 */
export async function checkSuspiciousActivity(
  code: string
): Promise<{ suspicious: boolean; reason?: string }> {
  const db = await getDb();
  if (!db) return { suspicious: false };

  const [purchaseCode] = await db
    .select()
    .from(purchaseCodes)
    .where(eq(purchaseCodes.code, code))
    .limit(1);

  if (!purchaseCode) {
    return { suspicious: false };
  }

  // Get download logs
  const logs = await db
    .select()
    .from(downloadLogs)
    .where(eq(downloadLogs.purchaseCodeId, purchaseCode.id));

  // Check for multiple unique IPs
  const uniqueIps = new Set(logs.map(l => l.ipAddress).filter(Boolean));
  if (uniqueIps.size > 3) {
    return { 
      suspicious: true, 
      reason: `Downloads from ${uniqueIps.size} different IP addresses` 
    };
  }

  // Check for rapid downloads (more than 3 in 1 hour)
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const recentDownloads = logs.filter(l => l.downloadedAt && new Date(l.downloadedAt) > oneHourAgo);
  if (recentDownloads.length > 3) {
    return { 
      suspicious: true, 
      reason: `${recentDownloads.length} downloads in the last hour` 
    };
  }

  return { suspicious: false };
}

/**
 * Process a complete purchase flow
 */
export async function processPurchase(
  userId: number,
  productId: number,
  paymentId: string,
  paymentProcessor: 'stripe' | 'gumroad' | 'square',
  amount: number
): Promise<{ success: boolean; purchaseCode?: string; error?: string }> {
  const db = await getDb();
  if (!db) return { success: false, error: 'Database not available' };

  try {
    // Create purchase record
    const result = await db.insert(digitalPurchases).values({
      userId,
      productId,
      amount,
      paymentProcessor,
      paymentId,
      status: 'completed',
    }).$returningId();
    const purchaseId = result[0]?.id;

    // Generate unique purchase code
    const { code } = await createPurchaseCode(
      userId,
      productId,
      purchaseId
    );

    // Update product sales count
    await db
      .update(digitalProducts)
      .set({ salesCount: sql`${digitalProducts.salesCount} + 1` })
      .where(eq(digitalProducts.id, productId));

    return { success: true, purchaseCode: code };
  } catch (error) {
    console.error('Purchase processing error:', error);
    return { success: false, error: 'Failed to process purchase' };
  }
}
