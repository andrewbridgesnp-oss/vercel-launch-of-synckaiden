import Stripe from "stripe";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

export const stripeRouter = router({
  // Create checkout session for subscription
  createCheckout: protectedProcedure
    .input(
      z.object({
        priceId: z.string(),
        planName: z.string(),
        planPrice: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const session = await stripe.checkout.sessions.create({
          customer_email: ctx.user.email || "",
          client_reference_id: ctx.user.id.toString(),
          line_items: [
            {
              price: input.priceId,
              quantity: 1,
            },
          ],
          mode: "subscription",
          success_url: `${ctx.req.headers.origin}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${ctx.req.headers.origin}/pricing`,
          metadata: {
            user_id: ctx.user.id.toString(),
            customer_email: ctx.user.email || "",
            customer_name: ctx.user.name || "User",
            plan_name: input.planName,
          },
          allow_promotion_codes: true,
        });

        return { success: true, checkoutUrl: session.url };
      } catch (error) {
        console.error("Stripe checkout error:", error);
        return { success: false, error: "Failed to create checkout session" };
      }
    }),

  // Create one-time payment checkout
  createPayment: protectedProcedure
    .input(
      z.object({
        amount: z.number(),
        description: z.string(),
        productName: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const session = await stripe.checkout.sessions.create({
          customer_email: ctx.user.email || "",
          client_reference_id: ctx.user.id.toString(),
          line_items: [
            {
              price_data: {
                currency: "usd",
                product_data: {
                  name: input.productName,
                  description: input.description,
                },
                unit_amount: Math.round(input.amount * 100),
              },
              quantity: 1,
            },
          ],
          mode: "payment",
          success_url: `${ctx.req.headers.origin}/dashboard?payment_success=true`,
          cancel_url: `${ctx.req.headers.origin}/pricing`,
          metadata: {
            user_id: ctx.user.id.toString(),
            customer_email: ctx.user.email || "",
            customer_name: ctx.user.name || "User",
            product_name: input.productName,
          },
          allow_promotion_codes: true,
        });

        return { success: true, checkoutUrl: session.url };
      } catch (error) {
        console.error("Stripe payment error:", error);
        return { success: false, error: "Failed to create payment session" };
      }
    }),

  // Get payment history
  getPaymentHistory: protectedProcedure.query(async ({ ctx }) => {
    try {
      // Fetch customer's invoices from Stripe
      const invoices = await stripe.invoices.list({
        customer: ctx.user.email || "",
        limit: 50,
      });

      return invoices.data.map((invoice: any) => ({
        id: invoice.id,
        amount: invoice.amount_paid / 100,
        currency: invoice.currency,
        status: invoice.status,
        date: new Date(invoice.created * 1000),
        description: invoice.description || "Payment",
        pdfUrl: (invoice as any).pdf || null,
      }));
    } catch (error) {
      console.error("Error fetching payment history:", error);
      return [];
    }
  }),

  // Get subscription status
  getSubscription: protectedProcedure.query(async ({ ctx }) => {
    try {
      const subscriptions = await stripe.subscriptions.list({
        limit: 1,
      });

      if (subscriptions.data.length === 0) {
        return null;
      }

      const sub = subscriptions.data[0];
      return {
        id: sub.id,
        status: sub.status,
        currentPeriodEnd: new Date((sub as any).current_period_end * 1000),
        cancelAtPeriodEnd: sub.cancel_at_period_end,
        items: sub.items.data.map((item: any) => ({
          priceId: item.price.id,
          productName: (item.price.product as any)?.name || "Product",
          amount: item.price.unit_amount ? item.price.unit_amount / 100 : 0,
        })),
      };
    } catch (error) {
      console.error("Error fetching subscription:", error);
      return null;
    }
  }),

  // Cancel subscription
  cancelSubscription: protectedProcedure.mutation(async ({ ctx }) => {
    try {
      const subscriptions = await stripe.subscriptions.list({
        limit: 1,
      });

      if (subscriptions.data.length === 0) {
        return { success: false, error: "No subscription found" };
      }

      await stripe.subscriptions.update(subscriptions.data[0].id, {
        cancel_at_period_end: true,
      });

      return { success: true, message: "Subscription will be cancelled at the end of the billing period" };
    } catch (error) {
      console.error("Error cancelling subscription:", error);
      return { success: false, error: "Failed to cancel subscription" };
    }
  }),

  // Webhook handler (called from Express middleware)
  handleWebhook: publicProcedure
    .input(
      z.object({
        event: z.object({
          id: z.string(),
          type: z.string(),
          data: z.any(),
        }),
      })
    )
    .mutation(async ({ input }) => {
      const event = input.event;

      // Handle test events
      if (event.id.startsWith("evt_test_")) {
        console.log("[Webhook] Test event detected:", event.type);
        return { verified: true };
      }

      console.log("[Webhook] Processing event:", event.type, event.id);

      // Handle different event types
      switch (event.type) {
        case "checkout.session.completed":
          console.log("[Webhook] Checkout completed:", event.data.object);
          // Update user subscription status in database
          break;

        case "customer.subscription.created":
          console.log("[Webhook] Subscription created:", event.data.object);
          // Store subscription ID for user
          break;

        case "customer.subscription.updated":
          console.log("[Webhook] Subscription updated:", event.data.object);
          // Update subscription status
          break;

        case "customer.subscription.deleted":
          console.log("[Webhook] Subscription cancelled:", event.data.object);
          // Mark subscription as cancelled
          break;

        case "invoice.paid":
          console.log("[Webhook] Invoice paid:", event.data.object);
          // Update payment status
          break;

        case "invoice.payment_failed":
          console.log("[Webhook] Invoice payment failed:", event.data.object);
          // Notify user of failed payment
          break;

        default:
          console.log("[Webhook] Unhandled event type:", event.type);
      }

      return { verified: true };
    }),
});

export type StripeRouter = typeof stripeRouter;
