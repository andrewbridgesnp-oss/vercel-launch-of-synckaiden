/**
 * Analytics API Service
 * Provides endpoints for retrieving analytics data
 */

import { getDb } from '../db';
import {
  dailyMetrics,
  userBehavior,
  revenueMetrics,
  featureUsage,
  performanceMetrics,
  cohortAnalysis,
  funnelAnalysis,
  customEvents,
} from '../../drizzle/analytics-schema';
import { eq, gte, lte, and, desc } from 'drizzle-orm';

export interface DateRange {
  startDate: Date;
  endDate: Date;
}

export interface AnalyticsFilters {
  userId?: string;
  featureId?: string;
  status?: string;
  dateRange?: DateRange;
}

export class AnalyticsApiService {
  /**
   * Get daily metrics for a date range
   */
  async getDailyMetrics(dateRange: DateRange) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db
      .select()
      .from(dailyMetrics)
      .where(
        and(
          gte(dailyMetrics.date, dateRange.startDate),
          lte(dailyMetrics.date, dateRange.endDate)
        )
      )
      .orderBy(dailyMetrics.date);
  }

  /**
   * Get KPI summary for dashboard
   */
  async getKpiSummary(dateRange: DateRange) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const metrics = await db
      .select()
      .from(dailyMetrics)
      .where(
        and(
          gte(dailyMetrics.date, dateRange.startDate),
          lte(dailyMetrics.date, dateRange.endDate)
        )
      );

    if (metrics.length === 0) {
      return {
        totalActiveUsers: 0,
        totalNewUsers: 0,
        totalSessions: 0,
        totalEvents: 0,
        avgSessionDuration: 0,
        avgBounceRate: 0,
        totalRevenue: 0,
        totalSubscriptions: 0,
      };
    }

    const totalRevenue = metrics.reduce((sum, m) => {
      const amount = typeof m.totalRevenue === 'string' 
        ? parseFloat(m.totalRevenue) 
        : m.totalRevenue;
      return sum + (amount || 0);
    }, 0);

    const avgDuration = metrics.reduce((sum, m) => {
      const duration = typeof m.avgSessionDuration === 'string'
        ? parseFloat(m.avgSessionDuration)
        : m.avgSessionDuration;
      return sum + (duration || 0);
    }, 0) / metrics.length;

    const avgBounce = metrics.reduce((sum, m) => {
      const bounce = typeof m.bounceRate === 'string'
        ? parseFloat(m.bounceRate)
        : m.bounceRate;
      return sum + (bounce || 0);
    }, 0) / metrics.length;

    return {
      totalActiveUsers: metrics.reduce((sum, m) => sum + (m.activeUsers || 0), 0),
      totalNewUsers: metrics.reduce((sum, m) => sum + (m.newUsers || 0), 0),
      totalSessions: metrics.reduce((sum, m) => sum + (m.totalSessions || 0), 0),
      totalEvents: metrics.reduce((sum, m) => sum + (m.totalEvents || 0), 0),
      avgSessionDuration: Math.round(avgDuration),
      avgBounceRate: Math.round(avgBounce * 100) / 100,
      totalRevenue: Math.round(totalRevenue * 100) / 100,
      totalSubscriptions: metrics.reduce((sum, m) => sum + (m.newSubscriptions || 0), 0),
    };
  }

  /**
   * Get user behavior events
   */
  async getUserBehavior(filters: AnalyticsFilters, limit: number = 100) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const conditions = [];
    if (filters.userId) {
      conditions.push(eq(userBehavior.userId, filters.userId));
    }
    if (filters.dateRange) {
      conditions.push(
        gte(userBehavior.createdAt, filters.dateRange.startDate),
        lte(userBehavior.createdAt, filters.dateRange.endDate)
      );
    }

    return await db
      .select()
      .from(userBehavior)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(userBehavior.createdAt))
      .limit(limit);
  }

  /**
   * Get revenue metrics
   */
  async getRevenueMetrics(dateRange: DateRange) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, dateRange.startDate),
          lte(revenueMetrics.createdAt, dateRange.endDate),
          eq(revenueMetrics.status, 'completed')
        )
      )
      .orderBy(desc(revenueMetrics.createdAt));
  }

  /**
   * Get revenue summary by subscription tier
   */
  async getRevenueByTier(dateRange: DateRange) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const data = await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, dateRange.startDate),
          lte(revenueMetrics.createdAt, dateRange.endDate),
          eq(revenueMetrics.status, 'completed')
        )
      );

    const tiers = new Map<string, { total: number; count: number }>();
    data.forEach((item) => {
      const tier = item.subscriptionTier;
      const amount = typeof item.amount === 'string' 
        ? parseFloat(item.amount) 
        : item.amount;
      
      if (!tiers.has(tier)) {
        tiers.set(tier, { total: 0, count: 0 });
      }
      const current = tiers.get(tier)!;
      current.total += amount;
      current.count += 1;
    });

    return Array.from(tiers.entries()).map(([tier, { total, count }]) => ({
      tier,
      revenue: Math.round(total * 100) / 100,
      transactions: count,
    }));
  }

  /**
   * Get feature usage statistics
   */
  async getFeatureUsage(filters: AnalyticsFilters) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const conditions = [];
    if (filters.userId) {
      conditions.push(eq(featureUsage.userId, filters.userId));
    }
    if (filters.featureId) {
      conditions.push(eq(featureUsage.featureId, filters.featureId));
    }

    return await db
      .select()
      .from(featureUsage)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(featureUsage.usageCount));
  }

  /**
   * Get performance metrics
   */
  async getPerformanceMetrics(dateRange: DateRange) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db
      .select()
      .from(performanceMetrics)
      .where(
        and(
          gte(performanceMetrics.createdAt, dateRange.startDate),
          lte(performanceMetrics.createdAt, dateRange.endDate)
        )
      )
      .orderBy(desc(performanceMetrics.responseTime));
  }

  /**
   * Get API performance summary
   */
  async getApiPerformanceSummary(dateRange: DateRange) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const data = await db
      .select()
      .from(performanceMetrics)
      .where(
        and(
          gte(performanceMetrics.createdAt, dateRange.startDate),
          lte(performanceMetrics.createdAt, dateRange.endDate)
        )
      );

    if (data.length === 0) {
      return {
        avgResponseTime: 0,
        p95ResponseTime: 0,
        p99ResponseTime: 0,
        errorRate: 0,
        totalRequests: 0,
      };
    }

    const responseTimes = data.map((d) => d.responseTime).sort((a, b) => a - b);
    const errors = data.filter((d) => d.statusCode >= 400).length;

    return {
      avgResponseTime: Math.round(
        responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length
      ),
      p95ResponseTime: responseTimes[Math.floor(responseTimes.length * 0.95)],
      p99ResponseTime: responseTimes[Math.floor(responseTimes.length * 0.99)],
      errorRate: Math.round((errors / data.length) * 10000) / 100,
      totalRequests: data.length,
    };
  }

  /**
   * Get cohort retention data
   */
  async getCohortRetention(cohortName: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db
      .select()
      .from(cohortAnalysis)
      .where(eq(cohortAnalysis.cohortName, cohortName))
      .orderBy(cohortAnalysis.retentionDay);
  }

  /**
   * Get funnel conversion data
   */
  async getFunnelConversion(funnelName: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const data = await db
      .select()
      .from(funnelAnalysis)
      .where(eq(funnelAnalysis.funnelName, funnelName));

    // Group by step and calculate conversion
    const steps = new Map<number, { stepName: string; total: number; completed: number }>();

    data.forEach((item) => {
      if (!steps.has(item.step)) {
        steps.set(item.step, {
          stepName: item.stepName,
          total: 0,
          completed: 0,
        });
      }
      const step = steps.get(item.step)!;
      step.total += 1;
      if (item.completed) step.completed += 1;
    });

    return Array.from(steps.values())
      .sort((a, b) => a.stepName.localeCompare(b.stepName))
      .map((step) => ({
        ...step,
        conversionRate: Math.round((step.completed / step.total) * 10000) / 100,
      }));
  }

  /**
   * Get custom events
   */
  async getCustomEvents(filters: AnalyticsFilters, limit: number = 100) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const conditions = [];
    if (filters.userId) {
      conditions.push(eq(customEvents.userId, filters.userId));
    }
    if (filters.dateRange) {
      conditions.push(
        gte(customEvents.createdAt, filters.dateRange.startDate),
        lte(customEvents.createdAt, filters.dateRange.endDate)
      );
    }

    return await db
      .select()
      .from(customEvents)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(customEvents.createdAt))
      .limit(limit);
  }

  /**
   * Track a user event
   */
  async trackEvent(
    userId: string,
    eventType: string,
    eventName: string,
    eventValue?: string,
    metadata?: any
  ) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db.insert(userBehavior).values({
      userId,
      eventType,
      eventName,
      eventValue,
      metadata,
    });
  }

  /**
   * Track feature usage
   */
  async trackFeatureUsage(userId: string, featureId: string, featureName: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const existing = await db
      .select()
      .from(featureUsage)
      .where(
        and(
          eq(featureUsage.userId, userId),
          eq(featureUsage.featureId, featureId)
        )
      );

    if (existing.length > 0) {
      return await db
        .update(featureUsage)
        .set({
          usageCount: (existing[0].usageCount || 0) + 1,
          lastUsed: new Date(),
        })
        .where(eq(featureUsage.id, existing[0].id));
    } else {
      return await db.insert(featureUsage).values({
        userId,
        featureId,
        featureName,
        usageCount: 1,
      });
    }
  }

  /**
   * Record API performance
   */
  async recordApiPerformance(
    endpoint: string,
    method: string,
    responseTime: number,
    statusCode: number,
    userId?: string,
    errorMessage?: string
  ) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db.insert(performanceMetrics).values({
      endpoint,
      method,
      responseTime,
      statusCode,
      userId,
      errorMessage,
    });
  }
}

export const analyticsApi = new AnalyticsApiService();
