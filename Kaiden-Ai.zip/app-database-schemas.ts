/**
 * Unified Database Schemas for All 10 Kaiden Apps
 * Each app has isolated tables with {appId}_ prefix
 * Shared user and subscription tables
 */

import { mysqlTable, varchar, int, text, timestamp, boolean, decimal, json, index } from 'drizzle-orm/mysql-core';
import { relations } from 'drizzle-orm';

// ============================================================================
// SHARED TABLES (All Apps)
// ============================================================================

export const appInstallations = mysqlTable(
  'app_installations',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    appId: varchar({ length: 100 }).notNull(),
    licenseKey: varchar({ length: 255 }).notNull().unique(),
    tier: varchar({ length: 50 }).default('free'),
    status: varchar({ length: 50 }).default('active'),
    installDate: timestamp().defaultNow(),
    expiresAt: timestamp(),
    metadata: json(),
  },
  table => ({
    userAppIdx: index('user_app_idx').on(table.userId, table.appId),
  })
);

export const appUsageTracking = mysqlTable(
  'app_usage_tracking',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    appId: varchar({ length: 100 }).notNull(),
    action: varchar({ length: 100 }).notNull(),
    resourceId: varchar({ length: 255 }),
    timestamp: timestamp().defaultNow(),
    metadata: json(),
  },
  table => ({
    userAppIdx: index('usage_user_app_idx').on(table.userId, table.appId),
  })
);

// ============================================================================
// AGENTIC AI BUSINESS SWARM
// ============================================================================

export const agenticAIAgents = mysqlTable(
  'agentic_ai_agents',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    name: varchar({ length: 255 }).notNull(),
    description: text(),
    type: varchar({ length: 100 }),
    status: varchar({ length: 50 }).default('active'),
    config: json(),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('agentic_user_idx').on(table.userId),
  })
);

export const agenticAIWorkflows = mysqlTable(
  'agentic_ai_workflows',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    name: varchar({ length: 255 }).notNull(),
    agentIds: json(),
    steps: json(),
    status: varchar({ length: 50 }).default('active'),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('agentic_workflow_user_idx').on(table.userId),
  })
);

// ============================================================================
// AUDIO MASTERING APPLICATION
// ============================================================================

export const audioMasteringProjects = mysqlTable(
  'audio_mastering_projects',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    name: varchar({ length: 255 }).notNull(),
    description: text(),
    tracks: int().default(0),
    duration: int(),
    status: varchar({ length: 50 }).default('draft'),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('audio_project_user_idx').on(table.userId),
  })
);

export const audioMasteringTracks = mysqlTable(
  'audio_mastering_tracks',
  {
    id: int().primaryKey().autoincrement(),
    projectId: int().notNull(),
    userId: int().notNull(),
    name: varchar({ length: 255 }).notNull(),
    fileUrl: varchar({ length: 255 }),
    duration: int(),
    effects: json(),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    projectIdx: index('audio_track_project_idx').on(table.projectId),
  })
);

// ============================================================================
// AVERY AI RECEPTIONIST
// ============================================================================

export const averyAICalls = mysqlTable(
  'avery_ai_calls',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    phoneNumber: varchar({ length: 20 }),
    duration: int(),
    transcript: text(),
    status: varchar({ length: 50 }),
    recordingUrl: varchar({ length: 255 }),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('avery_call_user_idx').on(table.userId),
  })
);

export const averyAIBookings = mysqlTable(
  'avery_ai_bookings',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    callerName: varchar({ length: 255 }),
    callerPhone: varchar({ length: 20 }),
    appointmentTime: timestamp(),
    service: varchar({ length: 255 }),
    status: varchar({ length: 50 }).default('confirmed'),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('avery_booking_user_idx').on(table.userId),
  })
);

// ============================================================================
// BUILDWEALTH PRO
// ============================================================================

export const buildwealthProfiles = mysqlTable(
  'buildwealth_profiles',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    businessName: varchar({ length: 255 }),
    industry: varchar({ length: 100 }),
    annualRevenue: decimal({ precision: 15, scale: 2 }),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('buildwealth_profile_user_idx').on(table.userId),
  })
);

export const buildwealthCreditAccounts = mysqlTable(
  'buildwealth_credit_accounts',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    accountName: varchar({ length: 255 }),
    balance: decimal({ precision: 15, scale: 2 }),
    status: varchar({ length: 50 }),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('buildwealth_credit_user_idx').on(table.userId),
  })
);

// ============================================================================
// FINANCIAL CO-PILOT
// ============================================================================

export const financialTransactions = mysqlTable(
  'financial_transactions',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    amount: decimal({ precision: 15, scale: 2 }).notNull(),
    category: varchar({ length: 100 }),
    description: text(),
    date: timestamp(),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('financial_transaction_user_idx').on(table.userId),
  })
);

export const financialBudgets = mysqlTable(
  'financial_budgets',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    category: varchar({ length: 100 }),
    limit: decimal({ precision: 15, scale: 2 }),
    spent: decimal({ precision: 15, scale: 2 }).default(0),
    month: varchar({ length: 7 }),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('financial_budget_user_idx').on(table.userId),
  })
);

// ============================================================================
// HEALTHSYNC SCRIBE
// ============================================================================

export const healthsyncNotes = mysqlTable(
  'healthsync_notes',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    patientId: varchar({ length: 255 }),
    content: text(),
    codedData: json(),
    status: varchar({ length: 50 }).default('draft'),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('healthsync_note_user_idx').on(table.userId),
  })
);

export const healthsyncPatients = mysqlTable(
  'healthsync_patients',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    name: varchar({ length: 255 }),
    dob: varchar({ length: 10 }),
    mrn: varchar({ length: 50 }),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('healthsync_patient_user_idx').on(table.userId),
  })
);

// ============================================================================
// HOUSEHACK 203K
// ============================================================================

export const househackDeals = mysqlTable(
  'househack_deals',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    propertyAddress: varchar({ length: 255 }),
    purchasePrice: decimal({ precision: 15, scale: 2 }),
    renovationBudget: decimal({ precision: 15, scale: 2 }),
    status: varchar({ length: 50 }).default('active'),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('househack_deal_user_idx').on(table.userId),
  })
);

export const househackCalculations = mysqlTable(
  'househack_calculations',
  {
    id: int().primaryKey().autoincrement(),
    dealId: int().notNull(),
    userId: int().notNull(),
    cashFlow: decimal({ precision: 15, scale: 2 }),
    roiPercentage: decimal({ precision: 5, scale: 2 }),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    dealIdx: index('househack_calc_deal_idx').on(table.dealId),
  })
);

// ============================================================================
// PANTRY INVENTORY MANAGEMENT
// ============================================================================

export const pantryItems = mysqlTable(
  'pantry_items',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    name: varchar({ length: 255 }).notNull(),
    quantity: int(),
    unit: varchar({ length: 50 }),
    expiryDate: timestamp(),
    category: varchar({ length: 100 }),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('pantry_item_user_idx').on(table.userId),
  })
);

export const pantryShoppingLists = mysqlTable(
  'pantry_shopping_lists',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    name: varchar({ length: 255 }),
    items: json(),
    completed: boolean().default(false),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('pantry_list_user_idx').on(table.userId),
  })
);

// ============================================================================
// REALITY SYNC
// ============================================================================

export const realitySyncVaults = mysqlTable(
  'realitysync_vaults',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    name: varchar({ length: 255 }),
    description: text(),
    pinProtected: boolean().default(true),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('realitysync_vault_user_idx').on(table.userId),
  })
);

export const realitySyncAssets = mysqlTable(
  'realitysync_assets',
  {
    id: int().primaryKey().autoincrement(),
    vaultId: int().notNull(),
    userId: int().notNull(),
    name: varchar({ length: 255 }),
    fileUrl: varchar({ length: 255 }),
    fileType: varchar({ length: 50 }),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    vaultIdx: index('realitysync_asset_vault_idx').on(table.vaultId),
  })
);

// ============================================================================
// SPAMSLAYER SYNC
// ============================================================================

export const spamslayerSubscriptions = mysqlTable(
  'spamslayer_subscriptions',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    serviceName: varchar({ length: 255 }),
    monthlyPrice: decimal({ precision: 10, scale: 2 }),
    renewalDate: timestamp(),
    status: varchar({ length: 50 }).default('active'),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('spamslayer_sub_user_idx').on(table.userId),
  })
);

export const spamslayerPriceAlerts = mysqlTable(
  'spamslayer_price_alerts',
  {
    id: int().primaryKey().autoincrement(),
    userId: int().notNull(),
    subscriptionId: int(),
    alertThreshold: decimal({ precision: 10, scale: 2 }),
    triggered: boolean().default(false),
    createdAt: timestamp().defaultNow(),
  },
  table => ({
    userIdx: index('spamslayer_alert_user_idx').on(table.userId),
  })
);

// ============================================================================
// RELATIONS (For type safety)
// ============================================================================

export const appInstallationsRelations = relations(appInstallations, ({ many }) => ({
  usageTracking: many(appUsageTracking),
}));

export const appUsageTrackingRelations = relations(appUsageTracking, ({ one }) => ({
  installation: one(appInstallations, {
    fields: [appUsageTracking.userId, appUsageTracking.appId],
    references: [appInstallations.userId, appInstallations.appId],
  }),
}));
