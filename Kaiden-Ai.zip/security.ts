import { Request, Response, NextFunction } from 'express';
import { createHash, randomBytes } from 'crypto';
import { createAuditLog } from '../db';

/**
 * Security Middleware & Utilities
 */

/**
 * CSRF Protection
 */
export function generateCSRFToken(): string {
  return randomBytes(32).toString('hex');
}

export function validateCSRFToken(token: string, sessionToken: string): boolean {
  return token === sessionToken;
}

export function csrfMiddleware(req: Request, res: Response, next: NextFunction) {
  if (req.method === 'GET') {
    const token = generateCSRFToken();
    res.locals.csrfToken = token;
    res.cookie('csrf-token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
    });
  } else if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method)) {
    const token = req.headers['x-csrf-token'] as string;
    const cookieToken = req.cookies['csrf-token'];

    if (!token || !validateCSRFToken(token, cookieToken)) {
      return res.status(403).json({ error: 'CSRF token invalid' });
    }
  }

  next();
}

/**
 * Rate Limiting Middleware
 */
const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

export function rateLimitMiddleware(windowMs = 60000, maxRequests = 100) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = `${req.ip}:${req.path}`;
    const now = Date.now();

    let record = rateLimitStore.get(key);

    if (!record || now > record.resetTime) {
      record = { count: 0, resetTime: now + windowMs };
      rateLimitStore.set(key, record);
    }

    record.count++;

    res.setHeader('X-RateLimit-Limit', maxRequests);
    res.setHeader('X-RateLimit-Remaining', Math.max(0, maxRequests - record.count));
    res.setHeader('X-RateLimit-Reset', record.resetTime);

    if (record.count > maxRequests) {
      return res.status(429).json({ error: 'Too many requests' });
    }

    next();
  };
}

/**
 * Input Validation & Sanitization
 */
export function sanitizeInput(input: string): string {
  return input
    .replace(/[<>]/g, '') // Remove angle brackets
    .replace(/["']/g, '') // Remove quotes
    .trim();
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validateURL(url: string): boolean {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}

export function validatePhoneNumber(phone: string): boolean {
  const phoneRegex = /^[\d\s\-\+\(\)]{10,}$/;
  return phoneRegex.test(phone);
}

/**
 * Password Security
 */
export function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

export function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

export function validatePasswordStrength(password: string): {
  isStrong: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters');
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain uppercase letter');
  }
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain lowercase letter');
  }
  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain number');
  }
  if (!/[!@#$%^&*]/.test(password)) {
    errors.push('Password must contain special character');
  }

  return {
    isStrong: errors.length === 0,
    errors,
  };
}

/**
 * Encryption/Decryption
 */
import { createCipheriv, createDecipheriv } from 'crypto';

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'default-key-32-characters-long!!';
const ALGORITHM = 'aes-256-cbc';

export function encryptData(data: string): string {
  const iv = randomBytes(16);
  const cipher = createCipheriv(ALGORITHM, Buffer.from(ENCRYPTION_KEY.padEnd(32)), iv);
  let encrypted = cipher.update(data, 'utf-8', 'hex');
  encrypted += cipher.final('hex');
  return `${iv.toString('hex')}:${encrypted}`;
}

export function decryptData(encryptedData: string): string {
  const [ivHex, encrypted] = encryptedData.split(':');
  const iv = Buffer.from(ivHex, 'hex');
  const decipher = createDecipheriv(ALGORITHM, Buffer.from(ENCRYPTION_KEY.padEnd(32)), iv);
  let decrypted = decipher.update(encrypted, 'hex', 'utf-8');
  decrypted += decipher.final('utf-8');
  return decrypted;
}

/**
 * Audit Logging Middleware
 */
export function auditLoggingMiddleware(req: Request, res: Response, next: NextFunction) {
  const originalSend = res.send;

  res.send = function (data: any) {
    // Log sensitive operations
    if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method)) {
      const userId = (req as any).user?.id;
      if (userId) {
        createAuditLog({
          userId,
          action: req.method,
          resource: req.path,
          status: res.statusCode < 400 ? 'success' : 'failed',
          ipAddress: req.ip,
          userAgent: req.headers['user-agent'],
        }).catch(console.error);
      }
    }

    res.send = originalSend;
    return originalSend.call(this, data);
  };

  next();
}

/**
 * Security Headers Middleware
 */
export function securityHeadersMiddleware(req: Request, res: Response, next: NextFunction) {
  // Content Security Policy
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'"
  );

  // X-Content-Type-Options
  res.setHeader('X-Content-Type-Options', 'nosniff');

  // X-Frame-Options
  res.setHeader('X-Frame-Options', 'DENY');

  // X-XSS-Protection
  res.setHeader('X-XSS-Protection', '1; mode=block');

  // Strict-Transport-Security
  if (process.env.NODE_ENV === 'production') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }

  // Referrer-Policy
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  // Permissions-Policy
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');

  next();
}

/**
 * CORS Configuration
 */
export function getCORSOptions() {
  return {
    origin: (process.env.ALLOWED_ORIGINS || 'http://localhost:3000').split(','),
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-CSRF-Token'],
    maxAge: 86400,
  };
}

/**
 * JWT Token Management
 */
import jwt from 'jsonwebtoken';

export function generateJWT(payload: Record<string, any>, expiresIn = '24h'): string {
  return jwt.sign(payload, process.env.JWT_SECRET || 'secret', { expiresIn });
}

export function verifyJWT(token: string): Record<string, any> | null {
  try {
    return jwt.verify(token, process.env.JWT_SECRET || 'secret') as Record<string, any>;
  } catch {
    return null;
  }
}

/**
 * API Key Management
 */
export function generateAPIKey(): string {
  return `sk_${randomBytes(32).toString('hex')}`;
}

export function validateAPIKey(key: string): boolean {
  return key.startsWith('sk_') && key.length === 67;
}

/**
 * Two-Factor Authentication
 */
export function generateTOTPSecret(): string {
  return randomBytes(32).toString('base64');
}

export function generateBackupCodes(count = 10): string[] {
  const codes: string[] = [];
  for (let i = 0; i < count; i++) {
    codes.push(randomBytes(4).toString('hex').toUpperCase());
  }
  return codes;
}

/**
 * Session Security
 */
export function generateSessionId(): string {
  return randomBytes(32).toString('hex');
}

export function validateSessionId(sessionId: string): boolean {
  return /^[a-f0-9]{64}$/.test(sessionId);
}

/**
 * IP Whitelisting
 */
export function isIPWhitelisted(ip: string, whitelist: string[]): boolean {
  return whitelist.includes(ip);
}

/**
 * Geo-blocking
 */
export function isGeoBlocked(country: string, blockedCountries: string[]): boolean {
  return blockedCountries.includes(country);
}

/**
 * Request Signing
 */
export function signRequest(data: Record<string, any>, secret: string): string {
  const message = JSON.stringify(data);
  return createHash('sha256').update(message + secret).digest('hex');
}

export function verifyRequestSignature(data: Record<string, any>, signature: string, secret: string): boolean {
  const expectedSignature = signRequest(data, secret);
  return signature === expectedSignature;
}

/**
 * Webhook Signature Verification
 */
export function verifyWebhookSignature(payload: string, signature: string, secret: string): boolean {
  const expectedSignature = createHash('sha256').update(payload + secret).digest('hex');
  return signature === expectedSignature;
}

/**
 * Data Masking
 */
export function maskSensitiveData(data: any, fieldsToMask: string[]): any {
  const masked = { ...data };
  fieldsToMask.forEach((field) => {
    if (masked[field]) {
      masked[field] = '***MASKED***';
    }
  });
  return masked;
}

/**
 * PII Detection
 */
export function containsPII(text: string): boolean {
  // Simple PII detection patterns
  const patterns = [
    /\d{3}-\d{2}-\d{4}/, // SSN
    /\d{16}/, // Credit card
    /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i, // Email
    /\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/, // Phone
  ];

  return patterns.some((pattern) => pattern.test(text));
}
