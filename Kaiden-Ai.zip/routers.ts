import { z } from "zod";
import { userProfiles, users } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { workflowsRouter } from "./api/routers/workflows";
import { workspacesRouter } from "./api/routers/workspaces";
import { contractsRouter } from "./api/routers/contracts";
import { invoicesRouter } from "./api/routers/invoices";
import { collaborationRouter } from "./api/routers/collaboration";
import { calendarRouter } from "./api/routers/calendar";
import { integrationsRouter } from "./api/routers/integrations";
import { crmRouter } from "./api/routers/crm";
import { formsRouter } from "./api/routers/forms";
import { marketplaceRouter } from "./api/routers/marketplace";
import { stripeRouter } from "./api/routers/stripe";
import { shopifyRouter } from "./api/routers/shopify";
import { directoryRouter } from "./api/routers/directory";
import { emailRouter } from "./api/routers/email";
import { pdfRouter } from "./api/routers/pdf";
import { printfulRouter } from "./api/routers/printful";
import { TRPCError } from "@trpc/server";
import { invokeLLM } from "./_core/llm";
import { transcribeAudio } from "./_core/voiceTranscription";
import { 
  createConversation, 
  getConversationsByUserId, 
  getConversationById,
  updateConversationTitle,
  createMessage, 
  getMessagesByConversationId,
  createAuditLog,
  createSecurityEvent,
  getUnresolvedSecurityEvents,
  createWebsite,
  getWebsitesByUserId,
  createProduct,
  getProductsByUserId,
  updateProduct,
  createAppointment,
  getAppointmentsByUserId,
  createLead,
  getLeadsByUserId,
  createVideo,
  getVideosByUserId,
  createCampaign,
  getCampaignsByUserId,
  updateCampaignMetrics,
  createApprovalRequest,
  getPendingApprovalRequests,
  updateApprovalRequest,
  getDb,
  getSavedMedicalCodes,
  getSavedMedicalCodesByType,
  addSavedMedicalCode,
  updateSavedMedicalCode,
  deleteSavedMedicalCode,
  incrementCodeUsage,
  checkCodeExists,
  createExpense,
  getExpensesByUserId,
  deleteExpense,
  createIncome,
  getIncomeByUserId,
  deleteIncome,
  createScheduledAppointment,
  getScheduledAppointmentsByUserId,
  updateScheduledAppointment,
  deleteScheduledAppointment
} from "./db";
import { 
  buildSystemPrompt, 
  sanitizeUserInput, 
  filterSensitiveOutput 
} from "./smith-personality";
import type { Message as LLMMessage } from "./_core/llm";

// Helper function to calculate similarity between two hex strings
function calculateSimilarity(hash1: string, hash2: string): number {
  if (hash1.length !== hash2.length) return 0;
  let matches = 0;
  for (let i = 0; i < hash1.length; i++) {
    if (hash1[i] === hash2[i]) matches++;
  }
  return matches / hash1.length;
}

export const appRouter = router({
  system: systemRouter,
  stripe: stripeRouter,
  shopify: shopifyRouter,
  directory: directoryRouter,
  email: emailRouter,
  pdf: pdfRouter,
  printful: printfulRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    
    // Enroll voiceprint
    enrollVoiceprint: protectedProcedure
      .input(z.object({
        recordings: z.array(z.string()), // base64 audio
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
        
        // Create hash from recordings (simplified - in production use proper audio fingerprinting)
        const crypto = await import("crypto");
        const combinedAudio = input.recordings.join("");
        const voiceprintHash = crypto.createHash("sha256").update(combinedAudio).digest("hex");
        
        await db.update(users)
          .set({
            voiceprintHash,
            voiceprintEnrolled: true,
            voiceAuthRequired: true,
          })
          .where(eq(users.id, ctx.user.id));
        
        return { success: true, enrolled: true };
      }),
    
    // Verify voiceprint
    verifyVoiceprint: protectedProcedure
      .input(z.object({
        recording: z.string(), // base64 audio
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
        
        const user = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (!user[0] || !user[0].voiceprintHash) {
          throw new TRPCError({ code: "NOT_FOUND", message: "No voiceprint enrolled" });
        }
        
        // Verify hash with fuzzy matching (simplified - in production use proper voice biometric matching)
        const crypto = await import("crypto");
        const recordingHash = crypto.createHash("sha256").update(input.recording).digest("hex");
        
        // Calculate similarity score (Hamming distance for hex strings)
        const similarity = calculateSimilarity(recordingHash, user[0].voiceprintHash);
        const threshold = 0.85; // 85% similarity required
        const verified = similarity >= threshold;
        
        return { verified, message: verified ? "Voice verified" : "Voice not recognized" };
      }),
    
    // Update voice auth setting
    updateVoiceAuthSetting: protectedProcedure
      .input(z.object({
        enabled: z.boolean(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
        
        await db.update(users)
          .set({ voiceAuthRequired: input.enabled })
          .where(eq(users.id, ctx.user.id));
        
        return { success: true };
      }),
  }),

  // ============ CHAT & CONVERSATIONS ============
  chat: router({
    // Create new conversation
    createConversation: protectedProcedure
      .input(z.object({ title: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const conversation = await createConversation({
          userId: ctx.user.id,
          title: input.title || "New Conversation",
        });

        await createAuditLog({
          userId: ctx.user.id,
          action: "conversation.create",
          resource: "conversation",
          resourceId: String(conversation.id),
          status: "success",
          riskLevel: "low",
        });

        return conversation;
      }),

    // Get all conversations for user
    getConversations: protectedProcedure.query(async ({ ctx }) => {
      return getConversationsByUserId(ctx.user.id);
    }),

    // Get single conversation with messages
    getConversation: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const conversation = await getConversationById(input.id);
        if (!conversation || conversation.userId !== ctx.user.id) {
          throw new Error("Conversation not found");
        }

        const messages = await getMessagesByConversationId(input.id);
        return { conversation, messages };
      }),

    // Send message and get AI response
    sendMessage: protectedProcedure
      .input(z.object({
        conversationId: z.number(),
        content: z.string(),
        isVoice: z.boolean().optional(),
        audioUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Security: Sanitize user input
        const sanitized = sanitizeUserInput(input.content);
        
        if (!sanitized.safe) {
          // Log security event
          await createSecurityEvent({
            userId: ctx.user.id,
            eventType: "prompt_injection_attempt",
            severity: "warning",
            description: `Potential security threat detected: ${sanitized.threats.join(", ")}`,
            metadata: { originalInput: input.content, threats: sanitized.threats },
          });

          await createAuditLog({
            userId: ctx.user.id,
            action: "message.send",
            resource: "message",
            status: "blocked",
            riskLevel: "high",
            metadata: { threats: sanitized.threats },
          });

          throw new Error("Your message contains potentially unsafe content. Please rephrase and try again.");
        }

        // Save user message
        const userMessage = await createMessage({
          conversationId: input.conversationId,
          role: "user",
          content: input.content,
          isVoice: input.isVoice || false,
          audioUrl: input.audioUrl,
        });

        // Get conversation history for context
        const history = await getMessagesByConversationId(input.conversationId);
        const contextMessages: LLMMessage[] = history.slice(-10).map(msg => ({
          role: msg.role as "user" | "assistant" | "system",
          content: msg.content,
        }));

        // Build system prompt with security constraints
        const systemPrompt = buildSystemPrompt(true);

        // Call LLM with Smith personality
        try {
          const response = await invokeLLM({
            messages: [
              { role: "system", content: systemPrompt },
              ...contextMessages,
            ],
          });

          const rawContent = response.choices[0]?.message?.content;
          const assistantContent = typeof rawContent === 'string' 
            ? rawContent 
            : "I apologize, but I couldn't generate a response. Please try again.";

          // Security: Filter sensitive output
          const filteredContent = filterSensitiveOutput(assistantContent);

          // Save assistant message
          const assistantMessage = await createMessage({
            conversationId: input.conversationId,
            role: "assistant",
            content: filteredContent,
          });

          // Auto-generate conversation title from first exchange
          if (history.length === 0) {
            const titlePrompt = `Generate a short 3-5 word title for a conversation that starts with: "${input.content.slice(0, 100)}"`;
            const titleResponse = await invokeLLM({
              messages: [{ role: "user", content: titlePrompt }],
            });
            const rawTitle = titleResponse.choices[0]?.message?.content;
            const title = typeof rawTitle === 'string' 
              ? rawTitle.replace(/['"]/g, '').slice(0, 50) 
              : "New Conversation";
            await updateConversationTitle(input.conversationId, title);
          }

          await createAuditLog({
            userId: ctx.user.id,
            action: "message.send",
            resource: "message",
            resourceId: String(assistantMessage.id),
            status: "success",
            riskLevel: "low",
          });

          return { userMessage, assistantMessage };
        } catch (error) {
          await createAuditLog({
            userId: ctx.user.id,
            action: "message.send",
            resource: "message",
            status: "failure",
            riskLevel: "medium",
            metadata: { error: String(error) },
          });
          throw error;
        }
      }),

    // Transcribe voice input
    transcribeVoice: protectedProcedure
      .input(z.object({ audioUrl: z.string() }))
      .mutation(async ({ ctx, input }) => {
        try {
          const result = await transcribeAudio({
            audioUrl: input.audioUrl,
            language: "en",
          });

          if ('error' in result) {
            throw new Error(result.error);
          }

          await createAuditLog({
            userId: ctx.user.id,
            action: "voice.transcribe",
            resource: "audio",
            status: "success",
            riskLevel: "low",
          });

          return { text: result.text, language: result.language };
        } catch (error) {
          await createAuditLog({
            userId: ctx.user.id,
            action: "voice.transcribe",
            resource: "audio",
            status: "failure",
            riskLevel: "low",
            metadata: { error: String(error) },
          });
          throw error;
        }
      }),
  }),

  // ============ SECURITY & MONITORING ============
  security: router({
    // Get unresolved security events
    getEvents: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized: Admin access required");
      }
      return getUnresolvedSecurityEvents();
    }),

    // Get pending approval requests
    getPendingApprovals: protectedProcedure.query(async ({ ctx }) => {
      return getPendingApprovalRequests(ctx.user.id);
    }),

    // Approve or reject high-risk action
    reviewApproval: protectedProcedure
      .input(z.object({
        id: z.number(),
        action: z.enum(["approve", "reject"]),
        reason: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await updateApprovalRequest(input.id, {
          status: input.action === "approve" ? "approved" : "rejected",
          approvedBy: input.action === "approve" ? ctx.user.id : undefined,
          rejectedReason: input.action === "reject" ? input.reason : undefined,
        });

        await createAuditLog({
          userId: ctx.user.id,
          action: `approval.${input.action}`,
          resource: "approval",
          resourceId: String(input.id),
          status: "success",
          riskLevel: "high",
        });

        return { success: true };
      }),
  }),

  // ============ BUSINESS TOOLS ============
  websites: router({
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        config: z.any().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const website = await createWebsite({
          userId: ctx.user.id,
          name: input.name,
          description: input.description,
          config: input.config,
        });

        await createAuditLog({
          userId: ctx.user.id,
          action: "website.create",
          resource: "website",
          resourceId: String(website.id),
          status: "success",
          riskLevel: "medium",
        });

        return website;
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return getWebsitesByUserId(ctx.user.id);
    }),
  }),

  products: router({
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        sku: z.string().optional(),
        price: z.number(),
        stock: z.number().optional(),
        imageUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const product = await createProduct({
          userId: ctx.user.id,
          ...input,
        });

        await createAuditLog({
          userId: ctx.user.id,
          action: "product.create",
          resource: "product",
          resourceId: String(product.id),
          status: "success",
          riskLevel: "low",
        });

        return product;
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return getProductsByUserId(ctx.user.id);
    }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          description: z.string().optional(),
          price: z.number().optional(),
          stock: z.number().optional(),
          status: z.enum(["active", "inactive", "out_of_stock"]).optional(),
        }),
      }))
      .mutation(async ({ ctx, input }) => {
        await updateProduct(input.id, input.data);

        await createAuditLog({
          userId: ctx.user.id,
          action: "product.update",
          resource: "product",
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)