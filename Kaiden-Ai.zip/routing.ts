import type { Capability, Module, NavigationItem } from '@/types';

/**
 * Dynamic Routing System
 * Generates routes and navigation from capability registry
 */

/**
 * Generate route path for a capability
 */
export function getCapabilityPath(capability: Capability): string {
  const modulePath = capability.module.toLowerCase().replace(/\s+/g, '-');
  const capabilityPath = capability.name.toLowerCase().replace(/\s+/g, '-');
  return `/capabilities/${modulePath}/${capabilityPath}`;
}

/**
 * Generate route path for a module
 */
export function getModulePath(module: Module | string): string {
  const moduleName = typeof module === 'string' ? module : module.name;
  const path = moduleName.toLowerCase().replace(/\s+/g, '-');
  return `/capabilities/${path}`;
}

/**
 * Parse capability path to get IDs
 */
export function parseCapabilityPath(path: string): {
  module: string;
  capability: string;
} | null {
  const match = path.match(/^\/capabilities\/([^/]+)\/([^/]+)$/);
  if (!match) return null;

  return {
    module: match[1].replace(/-/g, ' '),
    capability: match[2].replace(/-/g, ' '),
  };
}

/**
 * Generate navigation items from capabilities
 */
export function generateNavigationItems(
  capabilities: Capability[],
  modules?: Module[]
): NavigationItem[] {
  const moduleMap = new Map<string, Capability[]>();

  // Group capabilities by module
  capabilities.forEach((cap) => {
    if (!moduleMap.has(cap.module)) {
      moduleMap.set(cap.module, []);
    }
    moduleMap.get(cap.module)!.push(cap);
  });

  // Create navigation items
  const items: NavigationItem[] = Array.from(moduleMap.entries()).map(
    ([moduleName, caps], index) => {
      const moduleId = `module_${index}`;
      const modulePath = moduleName.toLowerCase().replace(/\s+/g, '-');

      return {
        id: moduleId,
        label: moduleName,
        path: `/capabilities/${modulePath}`,
        badge: caps.length,
        children: caps
          .filter((c) => c.status === 'LIVE') // Only show live capabilities in nav
          .slice(0, 10) // Limit to 10 per module
          .map((cap) => ({
            id: cap.id,
            label: cap.name,
            path: getCapabilityPath(cap),
            isVisible: cap.status === 'LIVE',
          })),
      };
    }
  );

  return items.sort((a, b) => (b.badge as number) - (a.badge as number)); // Sort by count
}

/**
 * Generate breadcrumb navigation
 */
export function generateBreadcrumbs(
  path: string,
  capabilities: Capability[]
): NavigationItem[] {
  const breadcrumbs: NavigationItem[] = [
    {
      id: 'home',
      label: 'Home',
      path: '/',
    },
    {
      id: 'capabilities',
      label: 'Capabilities',
      path: '/capabilities',
    },
  ];

  const parsed = parseCapabilityPath(path);
  if (!parsed) return breadcrumbs;

  // Find module
  const module = capabilities.find(
    (c) => c.module.toLowerCase() === parsed.module.toLowerCase()
  );
  if (module) {
    breadcrumbs.push({
      id: `module_${module.module}`,
      label: module.module,
      path: getModulePath(module.module),
    });
  }

  // Find capability
  const capability = capabilities.find(
    (c) =>
      c.module.toLowerCase() === parsed.module.toLowerCase() &&
      c.name.toLowerCase() === parsed.capability.toLowerCase()
  );
  if (capability) {
    breadcrumbs.push({
      id: capability.id,
      label: capability.name,
      path: getCapabilityPath(capability),
    });
  }

  return breadcrumbs;
}

/**
 * Generate sitemap for SEO
 */
export function generateSitemap(capabilities: Capability[], baseUrl: string): string {
  const urls = [
    baseUrl,
    `${baseUrl}/capabilities`,
    ...capabilities.map((cap) => `${baseUrl}${getCapabilityPath(cap)}`),
  ];

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map((url) => `  <url><loc>${url}</loc></url>`).join('\n')}
</urlset>`;

  return xml;
}

/**
 * Generate meta tags for a capability
 */
export function generateMetaTags(capability: Capability) {
  return {
    title: `${capability.name} - Synckaiden`,
    description: capability.description,
    keywords: [capability.module, capability.name, ...((capability.tags as string[]) || [])].join(
      ', '
    ),
    og: {
      title: capability.name,
      description: capability.description,
      type: 'website',
    },
  };
}

/**
 * Generate related links for a capability
 */
export function generateRelatedLinks(
  capability: Capability,
  allCapabilities: Capability[]
): NavigationItem[] {
  // Find related capabilities in same module
  const related = allCapabilities
    .filter(
      (c) =>
        c.id !== capability.id &&
        (c.module === capability.module || c.subsection === capability.subsection) &&
        c.status === 'LIVE'
    )
    .slice(0, 5);

  return related.map((cap) => ({
    id: cap.id,
    label: cap.name,
    path: getCapabilityPath(cap),
  }));
}

/**
 * Generate quick links for dashboard
 */
export function generateQuickLinks(capabilities: Capability[]): NavigationItem[] {
  // Get high-priority, live capabilities
  return capabilities
    .filter((c) => c.status === 'LIVE' && c.priority === 'HIGH')
    .slice(0, 8)
    .map((cap) => ({
      id: cap.id,
      label: cap.name,
      path: getCapabilityPath(cap),
      icon: cap.icon,
    }));
}

/**
 * Generate featured capabilities for homepage
 */
export function generateFeaturedCapabilities(capabilities: Capability[]): Capability[] {
  return capabilities
    .filter((c) => c.status === 'LIVE')
    .sort((a, b) => {
      // Sort by priority, then by complexity
      const priorityOrder = { HIGH: 0, MEDIUM: 1, LOW: 2 };
      const complexityOrder = { COMPLEX: 0, MEDIUM: 1, SIMPLE: 2 };

      const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
      if (priorityDiff !== 0) return priorityDiff;

      return complexityOrder[a.complexity] - complexityOrder[b.complexity];
    })
    .slice(0, 12);
}

/**
 * Generate capability URL slug
 */
export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '') // Remove special characters
    .replace(/\s+/g, '-') // Replace spaces with hyphens
    .replace(/-+/g, '-') // Replace multiple hyphens with single hyphen
    .trim();
}

/**
 * Resolve capability by slug
 */
export function resolveCapabilityBySlug(
  slug: string,
  capabilities: Capability[]
): Capability | undefined {
  return capabilities.find((c) => generateSlug(c.name) === slug);
}

/**
 * Generate canonical URL
 */
export function generateCanonicalUrl(path: string, baseUrl: string): string {
  return `${baseUrl}${path}`.replace(/\/$/, '');
}

/**
 * Generate next/previous navigation
 */
export function generatePrevNextNavigation(
  currentCapabilityId: string,
  capabilities: Capability[]
): {
  prev: NavigationItem | null;
  next: NavigationItem | null;
} {
  const currentIndex = capabilities.findIndex((c) => c.id === currentCapabilityId);

  if (currentIndex === -1) {
    return { prev: null, next: null };
  }

  const prev =
    currentIndex > 0
      ? {
          id: capabilities[currentIndex - 1].id,
          label: capabilities[currentIndex - 1].name,
          path: getCapabilityPath(capabilities[currentIndex - 1]),
        }
      : null;

  const next =
    currentIndex < capabilities.length - 1
      ? {
          id: capabilities[currentIndex + 1].id,
          label: capabilities[currentIndex + 1].name,
          path: getCapabilityPath(capabilities[currentIndex + 1]),
        }
      : null;

  return { prev, next };
}
