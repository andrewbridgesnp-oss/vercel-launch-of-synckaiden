import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Redirect } from "wouter";
import {
  Search,
  Filter,
  Grid3X3,
  List,
  Zap,
  Brain,
  Users,
  TrendingUp,
  Shield,
  DollarSign,
  FileText,
  MessageSquare,
  Calendar,
  BarChart3,
  Settings,
  Briefcase,
  Heart,
  Home,
  ShoppingCart,
  Utensils,
  Star,
  Clock,
  CheckCircle2,
  ArrowRight,
} from "lucide-react";

// Capability categories
const categories = [
  { id: 'all', label: 'All', icon: Grid3X3, count: 282 },
  { id: 'business', label: 'Business', icon: Briefcase, count: 45 },
  { id: 'finance', label: 'Finance', icon: DollarSign, count: 38 },
  { id: 'sales', label: 'Sales & CRM', icon: TrendingUp, count: 32 },
  { id: 'marketing', label: 'Marketing', icon: MessageSquare, count: 28 },
  { id: 'operations', label: 'Operations', icon: Settings, count: 35 },
  { id: 'legal', label: 'Legal', icon: FileText, count: 25 },
  { id: 'hr', label: 'HR & Team', icon: Users, count: 22 },
  { id: 'analytics', label: 'Analytics', icon: BarChart3, count: 20 },
  { id: 'health', label: 'Health', icon: Heart, count: 15 },
  { id: 'lifestyle', label: 'Lifestyle', icon: Home, count: 12 },
  { id: 'ai', label: 'AI Tools', icon: Brain, count: 10 },
];

// Sample capabilities (representing the 282)
const capabilities = [
  // Business
  { id: 1, name: 'LLC Formation Wizard', category: 'business', status: 'live', priority: 'high', description: 'Complete LLC formation with state filing assistance' },
  { id: 2, name: 'Business Plan Generator', category: 'business', status: 'live', priority: 'high', description: 'AI-powered business plan creation' },
  { id: 3, name: 'Pitch Deck Builder', category: 'business', status: 'live', priority: 'high', description: 'Create investor-ready presentations' },
  { id: 4, name: 'Competitor Analysis', category: 'business', status: 'live', priority: 'medium', description: 'Deep dive into competitor strategies' },
  { id: 5, name: 'Market Research', category: 'business', status: 'live', priority: 'high', description: 'Comprehensive market analysis' },
  
  // Finance
  { id: 6, name: 'Credit Repair Wizard', category: 'finance', status: 'live', priority: 'high', description: 'Dispute letters and credit improvement' },
  { id: 7, name: 'Budget Planner', category: 'finance', status: 'live', priority: 'high', description: 'Personal and business budgeting' },
  { id: 8, name: 'Invoice Generator', category: 'finance', status: 'live', priority: 'medium', description: 'Professional invoice creation' },
  { id: 9, name: 'Expense Tracker', category: 'finance', status: 'live', priority: 'high', description: 'Track and categorize expenses' },
  { id: 10, name: 'Financial Forecasting', category: 'finance', status: 'beta', priority: 'high', description: 'AI-powered financial predictions' },
  
  // Sales & CRM
  { id: 11, name: 'Lead Management', category: 'sales', status: 'live', priority: 'high', description: 'Track and nurture leads' },
  { id: 12, name: 'Sales Pipeline', category: 'sales', status: 'live', priority: 'high', description: 'Visual pipeline management' },
  { id: 13, name: 'Email Sequences', category: 'sales', status: 'live', priority: 'medium', description: 'Automated email campaigns' },
  { id: 14, name: 'Proposal Generator', category: 'sales', status: 'live', priority: 'medium', description: 'Create winning proposals' },
  { id: 15, name: 'Contract Management', category: 'sales', status: 'beta', priority: 'high', description: 'Digital contract workflows' },
  
  // Marketing
  { id: 16, name: 'Social Media Scheduler', category: 'marketing', status: 'live', priority: 'high', description: 'Schedule posts across platforms' },
  { id: 17, name: 'Content Calendar', category: 'marketing', status: 'live', priority: 'medium', description: 'Plan your content strategy' },
  { id: 18, name: 'SEO Analyzer', category: 'marketing', status: 'live', priority: 'high', description: 'Optimize for search engines' },
  { id: 19, name: 'Ad Campaign Manager', category: 'marketing', status: 'beta', priority: 'high', description: 'Manage paid advertising' },
  { id: 20, name: 'Brand Kit Generator', category: 'marketing', status: 'live', priority: 'medium', description: 'Create brand guidelines' },
  
  // Operations
  { id: 21, name: 'Project Management', category: 'operations', status: 'live', priority: 'high', description: 'Track projects and tasks' },
  { id: 22, name: 'Inventory Management', category: 'operations', status: 'live', priority: 'high', description: 'Track stock and supplies' },
  { id: 23, name: 'Workflow Automation', category: 'operations', status: 'live', priority: 'high', description: 'Automate repetitive tasks' },
  { id: 24, name: 'Document Management', category: 'operations', status: 'live', priority: 'medium', description: 'Organize and share files' },
  { id: 25, name: 'Quality Control', category: 'operations', status: 'beta', priority: 'medium', description: 'Ensure quality standards' },
  
  // Legal
  { id: 26, name: 'Contract Templates', category: 'legal', status: 'live', priority: 'high', description: 'Legal document templates' },
  { id: 27, name: 'NDA Generator', category: 'legal', status: 'live', priority: 'medium', description: 'Non-disclosure agreements' },
  { id: 28, name: 'Terms of Service', category: 'legal', status: 'live', priority: 'medium', description: 'Website legal pages' },
  { id: 29, name: 'Compliance Checker', category: 'legal', status: 'beta', priority: 'high', description: 'Regulatory compliance' },
  { id: 30, name: 'Trademark Search', category: 'legal', status: 'coming_soon', priority: 'medium', description: 'Search trademark databases' },
  
  // AI Tools
  { id: 31, name: 'AI Chat Assistant', category: 'ai', status: 'live', priority: 'high', description: 'Conversational AI helper' },
  { id: 32, name: 'AI Arena', category: 'ai', status: 'live', priority: 'high', description: 'Multi-AI consensus debates' },
  { id: 33, name: 'Content Writer', category: 'ai', status: 'live', priority: 'high', description: 'AI-powered content creation' },
  { id: 34, name: 'Image Generator', category: 'ai', status: 'beta', priority: 'medium', description: 'Create images with AI' },
  { id: 35, name: 'Voice Assistant', category: 'ai', status: 'coming_soon', priority: 'high', description: 'Voice-controlled AI' },
  
  // Health
  { id: 36, name: 'VitalSync Dashboard', category: 'health', status: 'live', priority: 'high', description: 'Health metrics tracking' },
  { id: 37, name: 'Meal Planner', category: 'health', status: 'live', priority: 'medium', description: 'Nutrition and meal planning' },
  { id: 38, name: 'Fitness Tracker', category: 'health', status: 'live', priority: 'medium', description: 'Exercise and activity logs' },
  { id: 39, name: 'Sleep Analysis', category: 'health', status: 'beta', priority: 'medium', description: 'Sleep quality insights' },
  { id: 40, name: 'Mental Wellness', category: 'health', status: 'coming_soon', priority: 'high', description: 'Stress and mood tracking' },
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'live': return 'bg-green-500/20 text-green-500 border-green-500/30';
    case 'beta': return 'bg-yellow-500/20 text-yellow-500 border-yellow-500/30';
    case 'coming_soon': return 'bg-blue-500/20 text-blue-500 border-blue-500/30';
    default: return 'bg-muted text-muted-foreground';
  }
};

const getStatusLabel = (status: string) => {
  switch (status) {
    case 'live': return 'Live';
    case 'beta': return 'Beta';
    case 'coming_soon': return 'Coming Soon';
    default: return status;
  }
};

export default function Capabilities() {
  const { isAuthenticated, loading } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
            <Zap className="h-8 w-8 text-primary" />
          </div>
          <p className="text-muted-foreground">Loading capabilities...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  const filteredCapabilities = capabilities.filter((cap) => {
    const matchesSearch = cap.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         cap.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || cap.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            <span className="gradient-text">282 Capabilities</span>
          </h1>
          <p className="text-muted-foreground">
            Everything you need to run and grow your business, all in one place.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search capabilities..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="icon"
              onClick={() => setViewMode('grid')}
            >
              <Grid3X3 className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="icon"
              onClick={() => setViewMode('list')}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className="gap-2"
              >
                <Icon className="h-4 w-4" />
                {category.label}
                <Badge variant="secondary" className="ml-1 text-xs">
                  {category.count}
                </Badge>
              </Button>
            );
          })}
        </div>

        {/* Capabilities Grid/List */}
        <div className={viewMode === 'grid' 
          ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"
          : "space-y-4"
        }>
          {filteredCapabilities.map((capability) => (
            <Card key={capability.id} className="luxury-card card-hover cursor-pointer">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center mb-2">
                    <Zap className="h-5 w-5 text-primary" />
                  </div>
                  <Badge className={getStatusColor(capability.status)}>
                    {getStatusLabel(capability.status)}
                  </Badge>
                </div>
                <CardTitle className="text-lg">{capability.name}</CardTitle>
                <CardDescription>{capability.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {capability.priority === 'high' && (
                      <Badge variant="secondary" className="text-xs">
                        <Star className="h-3 w-3 mr-1" />
                        Popular
                      </Badge>
                    )}
                  </div>
                  <Button variant="ghost" size="sm" className="gap-1">
                    Open
                    <ArrowRight className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredCapabilities.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
              <Search className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No capabilities found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search or filter criteria.
            </p>
          </div>
        )}

        {/* Stats Footer */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="luxury-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">282</div>
              <div className="text-sm text-muted-foreground">Total Capabilities</div>
            </CardContent>
          </Card>
          <Card className="luxury-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-500">180+</div>
              <div className="text-sm text-muted-foreground">Live</div>
            </CardContent>
          </Card>
          <Card className="luxury-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-yellow-500">70+</div>
              <div className="text-sm text-muted-foreground">In Beta</div>
            </CardContent>
          </Card>
          <Card className="luxury-card">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-500">30+</div>
              <div className="text-sm text-muted-foreground">Coming Soon</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
