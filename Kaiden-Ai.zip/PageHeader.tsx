import { LucideIcon } from "lucide-react";

interface PageHeaderProps {
  title: string;
  description?: string;
  icon?: LucideIcon;
  className?: string;
  action?: React.ReactNode;
}

export function PageHeader({ 
  title, 
  description, 
  icon: Icon, 
  className = "",
  action
}: PageHeaderProps) {
  return (
    <div className={`bg-gradient-to-r from-slate-900 to-slate-800 border-b border-slate-700 ${className}`}>
      <div className="container py-8">
        <div className="flex items-start justify-between gap-6">
          <div className="flex items-start gap-4 flex-1">
            {Icon && (
              <div className="p-3 rounded-lg bg-blue-500/10 text-blue-400 mt-1">
                <Icon className="h-6 w-6" />
              </div>
            )}
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-white mb-2">{title}</h1>
              {description && (
                <p className="text-slate-400 text-lg">{description}</p>
              )}
            </div>
          </div>
          {action && (
            <div className="mt-1">
              {action}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
