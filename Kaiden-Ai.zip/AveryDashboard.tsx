import React, { useState } from 'react';
import { Phone, Calendar, CreditCard, Users, BarChart3, Settings, ChevronRight, Zap, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SubscriptionData {
  id: string;
  tier: 'free_trial' | 'starter' | 'professional' | 'enterprise';
  status: 'active' | 'paused' | 'cancelled';
  businessName: string;
  monthlyPrice: number;
  billingCycleEnd: string;
  trialEndsAt?: string;
}

interface KPICard {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: number;
  color: string;
}

const AveryDashboard: React.FC = () => {
  const [subscription] = useState<SubscriptionData>({
    id: 'sub_123',
    tier: 'professional',
    status: 'active',
    businessName: 'Salon Sano',
    monthlyPrice: 299,
    billingCycleEnd: '2026-02-11',
  });

  const [activeTab, setActiveTab] = useState<'overview' | 'calls' | 'bookings' | 'settings'>('overview');

  const kpis: KPICard[] = [
    {
      label: 'Calls Answered',
      value: '1,247',
      icon: <Phone className="h-6 w-6" />,
      trend: 12,
      color: 'cyan',
    },
    {
      label: 'Appointments Booked',
      value: '342',
      icon: <Calendar className="h-6 w-6" />,
      trend: 8,
      color: 'green',
    },
    {
      label: 'Revenue Captured',
      value: '$18,540',
      icon: <CreditCard className="h-6 w-6" />,
      trend: 15,
      color: 'blue',
    },
    {
      label: 'Team Members',
      value: '5',
      icon: <Users className="h-6 w-6" />,
      trend: 0,
      color: 'purple',
    },
  ];

  const recentCalls = [
    { id: 1, caller: 'John Smith', duration: '3:45', outcome: 'Booked', time: '2 hours ago' },
    { id: 2, caller: 'Sarah Johnson', duration: '2:12', outcome: 'Callback', time: '4 hours ago' },
    { id: 3, caller: 'Mike Chen', duration: '1:30', outcome: 'Transferred', time: '6 hours ago' },
  ];

  const tierFeatures: Record<string, string[]> = {
    free_trial: ['50 calls/month', 'Basic support', 'Standard greeting', 'Call transcripts'],
    starter: ['500 calls/month', 'Email support', 'Custom greeting', 'Call recordings', 'Basic integrations'],
    professional: ['2,000 calls/month', 'Priority support', 'Advanced routing', 'Full analytics', 'Multiple integrations', 'Team management'],
    enterprise: ['Unlimited calls', 'Dedicated support', 'Custom features', 'SLA guarantee', 'API access'],
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-800/50 backdrop-blur px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">{subscription.businessName}</h1>
            <p className="text-slate-400">
              {subscription.tier.charAt(0).toUpperCase() + subscription.tier.slice(1)} Plan • Active
            </p>
          </div>
          <Button className="bg-cyan-500 hover:bg-cyan-600 text-white">
            <Settings className="mr-2 h-5 w-5" />
            Settings
          </Button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-slate-700 bg-slate-800/30 backdrop-blur px-6">
        <div className="flex gap-8">
          {(['overview', 'calls', 'bookings', 'settings'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-4 px-1 border-b-2 font-medium transition-colors ${
                activeTab === tab
                  ? 'border-cyan-400 text-cyan-400'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-8">
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* KPI Cards */}
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
              {kpis.map((kpi, index) => (
                <div key={index} className="rounded-lg bg-slate-800/50 border border-slate-700 p-6 backdrop-blur">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">{kpi.label}</p>
                      <p className="mt-2 text-3xl font-bold text-white">{kpi.value}</p>
                      {kpi.trend !== undefined && kpi.trend > 0 && (
                        <p className="mt-2 text-sm text-green-400">↑ {kpi.trend}% from last month</p>
                      )}
                    </div>
                    <div className={`text-${kpi.color}-400`}>{kpi.icon}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Recent Activity */}
            <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-6 backdrop-blur">
              <h2 className="mb-6 text-xl font-bold text-white">Recent Calls</h2>
              <div className="space-y-4">
                {recentCalls.map((call) => (
                  <div key={call.id} className="flex items-center justify-between rounded-lg bg-slate-700/30 p-4">
                    <div>
                      <p className="font-medium text-white">{call.caller}</p>
                      <p className="text-sm text-slate-400">{call.time}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-medium text-slate-300">{call.duration}</p>
                        <p className="text-xs text-slate-400">{call.outcome}</p>
                      </div>
                      <ChevronRight className="h-5 w-5 text-slate-500" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Subscription Info */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-6 backdrop-blur">
                <h3 className="mb-4 text-lg font-bold text-white">Subscription Details</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Plan</span>
                    <span className="font-medium text-white capitalize">{subscription.tier}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Monthly Price</span>
                    <span className="font-medium text-white">${subscription.monthlyPrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Next Billing</span>
                    <span className="font-medium text-white">{subscription.billingCycleEnd}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Status</span>
                    <span className="inline-flex items-center gap-2 rounded-full bg-green-500/10 px-3 py-1 text-sm font-medium text-green-400">
                      <Zap className="h-3 w-3" />
                      Active
                    </span>
                  </div>
                </div>
                <div className="mt-6 flex gap-3">
                  <Button className="flex-1 bg-slate-700 hover:bg-slate-600 text-white">
                    Upgrade Plan
                  </Button>
                  <Button className="flex-1 bg-slate-700 hover:bg-slate-600 text-white">
                    Pause
                  </Button>
                </div>
              </div>

              <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-6 backdrop-blur">
                <h3 className="mb-4 text-lg font-bold text-white">Included Features</h3>
                <ul className="space-y-3">
                  {tierFeatures[subscription.tier].map((feature, index) => (
                    <li key={index} className="flex items-center gap-3 text-slate-300">
                      <div className="h-2 w-2 rounded-full bg-cyan-400" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'calls' && (
          <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-6 backdrop-blur">
            <h2 className="mb-6 text-xl font-bold text-white">Call History</h2>
            <div className="text-center py-12">
              <Phone className="mx-auto mb-4 h-12 w-12 text-slate-500" />
              <p className="text-slate-400">Call history and analytics coming soon</p>
            </div>
          </div>
        )}

        {activeTab === 'bookings' && (
          <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-6 backdrop-blur">
            <h2 className="mb-6 text-xl font-bold text-white">Bookings</h2>
            <div className="text-center py-12">
              <Calendar className="mx-auto mb-4 h-12 w-12 text-slate-500" />
              <p className="text-slate-400">Booking management coming soon</p>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-6 backdrop-blur">
            <h2 className="mb-6 text-xl font-bold text-white">Settings</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-white mb-2">Business Phone</label>
                <input
                  type="tel"
                  placeholder="+1 (555) 123-4567"
                  className="w-full rounded-lg bg-slate-700 px-4 py-2 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-white mb-2">Custom Greeting</label>
                <textarea
                  placeholder="Thank you for calling..."
                  rows={4}
                  className="w-full rounded-lg bg-slate-700 px-4 py-2 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
                />
              </div>
              <Button className="bg-cyan-500 hover:bg-cyan-600 text-white">
                Save Settings
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AveryDashboard;
