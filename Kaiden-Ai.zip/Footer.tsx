import { Link } from "wouter";

export function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-background border-t border-border/50">
      <div className="container py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-cyan-400 flex items-center justify-center">
                <span className="text-white font-bold text-sm">K</span>
              </div>
              <span className="font-bold text-lg">Kaiden</span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              AI-powered business consulting platform with 282+ capabilities to help you build, grow, and scale.
            </p>
          </div>

          {/* Platform */}
          <div>
            <h4 className="font-semibold mb-4">Platform</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/capabilities" className="hover:text-foreground transition-colors">Capabilities</Link></li>
              <li><Link href="/integrations" className="hover:text-foreground transition-colors">Integrations</Link></li>
              <li><Link href="/dashboard" className="hover:text-foreground transition-colors">Dashboard</Link></li>
              <li><Link href="/referrals" className="hover:text-foreground transition-colors">Referral Program</Link></li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="font-semibold mb-4">Resources</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/credit-repair" className="hover:text-foreground transition-colors">Credit Building</Link></li>
              <li><Link href="/business-formation" className="hover:text-foreground transition-colors">Business Formation</Link></li>
              <li><Link href="/real-estate" className="hover:text-foreground transition-colors">Real Estate</Link></li>
              <li><a href="mailto:support@synckaiden.com" className="hover:text-foreground transition-colors">Support</a></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/privacy" className="hover:text-foreground transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms" className="hover:text-foreground transition-colors">Terms of Service</Link></li>
              <li><Link href="/disclaimer" className="hover:text-foreground transition-colors">Disclaimer</Link></li>
              <li><Link href="/cookies" className="hover:text-foreground transition-colors">Cookie Policy</Link></li>
            </ul>
          </div>
        </div>

        {/* Legal Disclaimers */}
        <div className="border-t border-border/50 pt-8 mb-8">
          <div className="text-xs text-muted-foreground space-y-4">
            <p>
              <strong>IMPORTANT DISCLAIMER:</strong> Kaiden and SyncKaiden.com provide educational information and AI-assisted business tools only. We are NOT licensed attorneys, CPAs, financial advisors, real estate agents, or investment advisors. All information provided is for educational purposes only and should not be construed as legal, financial, tax, or investment advice. Always consult with qualified licensed professionals before making any financial, legal, or business decisions.
            </p>
            <p>
              <strong>NO GUARANTEES:</strong> Results vary based on individual circumstances. Past performance does not guarantee future results. Credit repair, business formation, and investment strategies carry inherent risks. We make no representations or warranties regarding the accuracy, completeness, or applicability of any information provided.
            </p>
            <p>
              <strong>AFFILIATE DISCLOSURE:</strong> Some links on this platform may be affiliate links. We may receive compensation if you make purchases through these links at no additional cost to you. This does not influence our recommendations.
            </p>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-border/50 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-muted-foreground text-center md:text-left">
              <p>Copyright {currentYear} SyncKaiden.com. All Rights Reserved.</p>
              <p className="mt-1">
                Kaiden, SyncKaiden, and all associated logos, designs, content, and intellectual property are protected under U.S. and international copyright, trademark, and intellectual property laws. Unauthorized reproduction, distribution, or use is strictly prohibited.
              </p>
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>Patent Pending</span>
              <span className="text-border">|</span>
              <span>Trademark Registered</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
