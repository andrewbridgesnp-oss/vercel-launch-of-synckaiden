import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface FilterOption {
  key: string;
  label: string;
  options: string[];
  type?: 'select' | 'multi';
}

interface FilterBarProps {
  filters: FilterOption[];
  onFilter: (filters: Record<string, string | string[]>) => void;
  className?: string;
}

export function FilterBar({ filters, onFilter, className = "" }: FilterBarProps) {
  const [activeFilters, setActiveFilters] = useState<Record<string, string | string[]>>({});

  const handleFilterChange = (key: string, value: string) => {
    const newFilters = { ...activeFilters };
    
    if (newFilters[key] === value) {
      delete newFilters[key];
    } else {
      newFilters[key] = value;
    }
    
    setActiveFilters(newFilters);
    onFilter(newFilters);
  };

  const clearFilters = () => {
    setActiveFilters({});
    onFilter({});
  };

  const hasActiveFilters = Object.keys(activeFilters).length > 0;

  return (
    <Card className={`border-slate-700 bg-slate-900/50 p-4 ${className}`}>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white">Filters</h3>
          {hasActiveFilters && (
            <Button 
              onClick={clearFilters}
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-white"
            >
              <X className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </div>

        <div className="space-y-3">
          {filters.map((filter) => (
            <div key={filter.key} className="space-y-2">
              <label className="text-xs font-medium text-slate-400 uppercase">
                {filter.label}
              </label>
              <div className="flex flex-wrap gap-2">
                {filter.options.map((option) => (
                  <Button
                    key={option}
                    onClick={() => handleFilterChange(filter.key, option)}
                    variant={activeFilters[filter.key] === option ? "default" : "outline"}
                    size="sm"
                    className={
                      activeFilters[filter.key] === option
                        ? "bg-blue-600 border-blue-600 hover:bg-blue-700"
                        : "border-slate-600 text-slate-300 hover:border-slate-500"
                    }
                  >
                    {option}
                  </Button>
                ))}
              </div>
            </div>
          ))}
        </div>

        {hasActiveFilters && (
          <div className="pt-2 border-t border-slate-700">
            <div className="text-xs text-slate-400">
              Active filters: {Object.keys(activeFilters).length}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}
