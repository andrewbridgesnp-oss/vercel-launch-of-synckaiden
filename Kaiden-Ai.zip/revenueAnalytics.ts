/**
 * Revenue Analytics Module
 * Tracks subscription revenue and financial metrics
 */

import { getDb } from '../db';
import { revenueMetrics } from '../../drizzle/analytics-schema';
import { eq, gte, lte, and } from 'drizzle-orm';

export interface RevenueMetric {
  tier: string;
  revenue: number;
  transactions: number;
  avgTransactionValue: number;
}

export interface MrrMetric {
  month: string;
  mrr: number;
  newSubscriptions: number;
  cancelledSubscriptions: number;
  churnRate: number;
}

export interface SubscriptionMetric {
  tier: string;
  activeSubscriptions: number;
  newThisMonth: number;
  cancelledThisMonth: number;
  mrr: number;
}

export class RevenueAnalyticsService {
  /**
   * Get revenue by subscription tier
   */
  async getRevenueByTier(startDate: Date, endDate: Date): Promise<RevenueMetric[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const data = await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, startDate),
          lte(revenueMetrics.createdAt, endDate),
          eq(revenueMetrics.status, 'completed')
        )
      );

    const tiers = new Map<string, { revenue: number; count: number }>();

    data.forEach((item) => {
      const tier = item.subscriptionTier;
      const amount = typeof item.amount === 'string' 
        ? parseFloat(item.amount) 
        : item.amount;

      if (!tiers.has(tier)) {
        tiers.set(tier, { revenue: 0, count: 0 });
      }

      const current = tiers.get(tier)!;
      current.revenue += amount;
      current.count += 1;
    });

    return Array.from(tiers.entries()).map(([tier, { revenue, count }]) => ({
      tier,
      revenue: Math.round(revenue * 100) / 100,
      transactions: count,
      avgTransactionValue: Math.round((revenue / count) * 100) / 100,
    }));
  }

  /**
   * Calculate Monthly Recurring Revenue (MRR)
   */
  async calculateMrr(month: Date): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const startOfMonth = new Date(month.getFullYear(), month.getMonth(), 1);
    const endOfMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0);

    const data = await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, startOfMonth),
          lte(revenueMetrics.createdAt, endOfMonth),
          eq(revenueMetrics.status, 'completed'),
          eq(revenueMetrics.billingPeriod, 'monthly')
        )
      );

    return data.reduce((sum, item) => {
      const amount = typeof item.amount === 'string' 
        ? parseFloat(item.amount) 
        : item.amount;
      return sum + amount;
    }, 0);
  }

  /**
   * Calculate Annual Recurring Revenue (ARR)
   */
  async calculateArr(month: Date): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const startOfMonth = new Date(month.getFullYear(), month.getMonth(), 1);
    const endOfMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0);

    const data = await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, startOfMonth),
          lte(revenueMetrics.createdAt, endOfMonth),
          eq(revenueMetrics.status, 'completed')
        )
      );

    let arr = 0;

    data.forEach((item) => {
      const amount = typeof item.amount === 'string' 
        ? parseFloat(item.amount) 
        : item.amount;

      if (item.billingPeriod === 'monthly') {
        arr += amount * 12;
      } else if (item.billingPeriod === 'yearly') {
        arr += amount;
      }
    });

    return Math.round(arr * 100) / 100;
  }

  /**
   * Get revenue trends over time
   */
  async getRevenueTrends(startDate: Date, endDate: Date) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const data = await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, startDate),
          lte(revenueMetrics.createdAt, endDate),
          eq(revenueMetrics.status, 'completed')
        )
      );

    // Group by date
    const trends = new Map<string, number>();

    data.forEach((item) => {
      const dateKey = item.createdAt
        ? new Date(item.createdAt).toISOString().split('T')[0]
        : new Date().toISOString().split('T')[0];

      const amount = typeof item.amount === 'string' 
        ? parseFloat(item.amount) 
        : item.amount;

      trends.set(dateKey, (trends.get(dateKey) || 0) + amount);
    });

    return Array.from(trends.entries())
      .map(([date, revenue]) => ({
        date,
        revenue: Math.round(revenue * 100) / 100,
      }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  /**
   * Get subscription metrics by tier
   */
  async getSubscriptionMetrics(month: Date): Promise<SubscriptionMetric[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const startOfMonth = new Date(month.getFullYear(), month.getMonth(), 1);
    const endOfMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0);

    const data = await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, startOfMonth),
          lte(revenueMetrics.createdAt, endOfMonth)
        )
      );

    const tiers = new Map<
      string,
      {
        active: number;
        new: number;
        cancelled: number;
        revenue: number;
      }
    >();

    data.forEach((item) => {
      const tier = item.subscriptionTier;
      const amount = typeof item.amount === 'string' 
        ? parseFloat(item.amount) 
        : item.amount;

      if (!tiers.has(tier)) {
        tiers.set(tier, { active: 0, new: 0, cancelled: 0, revenue: 0 });
      }

      const current = tiers.get(tier)!;

      if (item.status === 'completed') {
        current.active += 1;
        current.new += 1;
        current.revenue += amount;
      } else if (item.status === 'refunded') {
        current.cancelled += 1;
      }
    });

    return Array.from(tiers.entries()).map(([tier, metrics]) => ({
      tier,
      activeSubscriptions: metrics.active,
      newThisMonth: metrics.new,
      cancelledThisMonth: metrics.cancelled,
      mrr: Math.round(metrics.revenue * 100) / 100,
    }));
  }

  /**
   * Calculate churn rate
   */
  async calculateChurnRate(month: Date): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const startOfMonth = new Date(month.getFullYear(), month.getMonth(), 1);
    const endOfMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0);

    const allData = await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, startOfMonth),
          lte(revenueMetrics.createdAt, endOfMonth)
        )
      );

    const cancelled = allData.filter((item) => item.status === 'refunded').length;
    const total = allData.length;

    if (total === 0) return 0;

    return Math.round((cancelled / total) * 10000) / 100;
  }

  /**
   * Get customer lifetime value (CLV) estimate
   */
  async estimateClv(userId: string): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const data = await db
      .select()
      .from(revenueMetrics)
      .where(eq(revenueMetrics.userId, userId));

    if (data.length === 0) return 0;

    const totalRevenue = data.reduce((sum, item) => {
      const amount = typeof item.amount === 'string' 
        ? parseFloat(item.amount) 
        : item.amount;
      return sum + amount;
    }, 0);

    const avgMonthlyValue = totalRevenue / Math.max(data.length, 1);
    const estimatedMonths = 24; // Assume 24-month average customer lifetime

    return Math.round(avgMonthlyValue * estimatedMonths * 100) / 100;
  }

  /**
   * Get payment method distribution
   */
  async getPaymentMethodDistribution(startDate: Date, endDate: Date) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const data = await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, startDate),
          lte(revenueMetrics.createdAt, endDate),
          eq(revenueMetrics.status, 'completed')
        )
      );

    const methods = new Map<string, { count: number; revenue: number }>();

    data.forEach((item) => {
      const method = item.paymentMethod || 'Unknown';
      const amount = typeof item.amount === 'string' 
        ? parseFloat(item.amount) 
        : item.amount;

      if (!methods.has(method)) {
        methods.set(method, { count: 0, revenue: 0 });
      }

      const current = methods.get(method)!;
      current.count += 1;
      current.revenue += amount;
    });

    return Array.from(methods.entries()).map(([method, { count, revenue }]) => ({
      method,
      transactions: count,
      revenue: Math.round(revenue * 100) / 100,
      percentage: Math.round((count / data.length) * 10000) / 100,
    }));
  }

  /**
   * Get failed payment attempts
   */
  async getFailedPayments(startDate: Date, endDate: Date) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const data = await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, startDate),
          lte(revenueMetrics.createdAt, endDate),
          eq(revenueMetrics.status, 'failed')
        )
      );

    const totalAttempts = await db
      .select()
      .from(revenueMetrics)
      .where(
        and(
          gte(revenueMetrics.createdAt, startDate),
          lte(revenueMetrics.createdAt, endDate)
        )
      );

    return {
      failedCount: data.length,
      totalAttempts: totalAttempts.length,
      failureRate: Math.round((data.length / totalAttempts.length) * 10000) / 100,
    };
  }
}

export const revenueAnalytics = new RevenueAnalyticsService();
