import React, { useState } from 'react';
import { ChevronRight, ChevronLeft, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface OnboardingStep {
  id: number;
  title: string;
  description: string;
  fields: Array<{ name: string; label: string; type: string; placeholder: string; required?: boolean }>;
}

const AveryOnboarding: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    businessName: '',
    industry: '',
    businessPhone: '',
    serviceType: '',
    businessHours: '',
    bufferTime: '15',
    customGreeting: '',
    integrations: [] as string[],
  });

  const steps: OnboardingStep[] = [
    {
      id: 1,
      title: 'Business Profile',
      description: 'Tell us about your business',
      fields: [
        { name: 'businessName', label: 'Business Name', type: 'text', placeholder: 'Your Business Name', required: true },
        { name: 'industry', label: 'Industry', type: 'select', placeholder: 'Select Industry', required: true },
        { name: 'businessPhone', label: 'Business Phone', type: 'tel', placeholder: '+1 (555) 123-4567', required: true },
      ],
    },
    {
      id: 2,
      title: 'Services',
      description: 'What services do you offer?',
      fields: [
        { name: 'serviceType', label: 'Primary Service', type: 'select', placeholder: 'Select Service', required: true },
      ],
    },
    {
      id: 3,
      title: 'Booking Rules',
      description: 'Set your availability and preferences',
      fields: [
        { name: 'businessHours', label: 'Business Hours', type: 'text', placeholder: '9 AM - 5 PM', required: true },
        { name: 'bufferTime', label: 'Buffer Time Between Bookings (minutes)', type: 'number', placeholder: '15', required: true },
      ],
    },
    {
      id: 4,
      title: 'Greeting',
      description: 'Customize Avery\'s greeting',
      fields: [
        { name: 'customGreeting', label: 'Custom Greeting Message', type: 'textarea', placeholder: 'Thank you for calling...', required: true },
      ],
    },
    {
      id: 5,
      title: 'Integrations',
      description: 'Connect your tools',
      fields: [],
    },
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleIntegrationToggle = (integration: string) => {
    setFormData((prev) => ({
      ...prev,
      integrations: prev.integrations.includes(integration)
        ? prev.integrations.filter((i) => i !== integration)
        : [...prev.integrations, integration],
    }));
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Complete onboarding
      console.log('Onboarding complete:', formData);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const step = steps[currentStep];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4 py-12">
      <div className="mx-auto max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="mb-4 flex justify-between">
            <span className="text-sm font-medium text-slate-300">
              Step {currentStep + 1} of {steps.length}
            </span>
            <span className="text-sm font-medium text-slate-400">{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-700">
            <div
              className="h-2 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-300"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Indicator */}
        <div className="mb-8 flex gap-2">
          {steps.map((_, index) => (
            <div
              key={index}
              className={`h-10 w-10 rounded-full flex items-center justify-center font-semibold transition-all ${
                index < currentStep
                  ? 'bg-green-500 text-white'
                  : index === currentStep
                    ? 'bg-cyan-500 text-white'
                    : 'bg-slate-700 text-slate-400'
              }`}
            >
              {index < currentStep ? <Check className="h-5 w-5" /> : index + 1}
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-8 backdrop-blur">
          <h1 className="mb-2 text-3xl font-bold text-white">{step.title}</h1>
          <p className="mb-8 text-lg text-slate-400">{step.description}</p>

          {currentStep === 4 ? (
            // Integrations Step
            <div className="space-y-4">
              {['Twilio', 'Google Calendar', 'Zapier', 'Slack', 'HubSpot', 'Calendly'].map((integration) => (
                <label key={integration} className="flex items-center gap-3 rounded-lg bg-slate-700/30 p-4 cursor-pointer hover:bg-slate-700/50 transition-colors">
                  <input
                    type="checkbox"
                    checked={formData.integrations.includes(integration)}
                    onChange={() => handleIntegrationToggle(integration)}
                    className="h-5 w-5 rounded border-slate-600 bg-slate-700 text-cyan-500 focus:ring-cyan-500"
                  />
                  <span className="text-white">{integration}</span>
                </label>
              ))}
            </div>
          ) : (
            // Form Fields
            <form className="space-y-6">
              {step.fields.map((field) => (
                <div key={field.name}>
                  <label className="block text-sm font-medium text-white mb-2">{field.label}</label>
                  {field.type === 'textarea' ? (
                    <textarea
                      name={field.name}
                      value={formData[field.name as keyof typeof formData]}
                      onChange={handleInputChange}
                      placeholder={field.placeholder}
                      rows={4}
                      required={field.required}
                      className="w-full rounded-lg bg-slate-700 px-4 py-3 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
                    />
                  ) : field.type === 'select' ? (
                    <select
                      name={field.name}
                      value={formData[field.name as keyof typeof formData]}
                      onChange={handleInputChange}
                      required={field.required}
                      className="w-full rounded-lg bg-slate-700 px-4 py-3 text-white border border-slate-600 focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="">{field.placeholder}</option>
                      {field.name === 'industry' && (
                        <>
                          <option value="salon">Salon & Spa</option>
                          <option value="medical">Medical</option>
                          <option value="dental">Dental</option>
                          <option value="consulting">Consulting</option>
                          <option value="other">Other</option>
                        </>
                      )}
                      {field.name === 'serviceType' && (
                        <>
                          <option value="appointments">Appointments</option>
                          <option value="consultations">Consultations</option>
                          <option value="support">Support</option>
                          <option value="sales">Sales</option>
                        </>
                      )}
                    </select>
                  ) : (
                    <input
                      type={field.type}
                      name={field.name}
                      value={formData[field.name as keyof typeof formData]}
                      onChange={handleInputChange}
                      placeholder={field.placeholder}
                      required={field.required}
                      className="w-full rounded-lg bg-slate-700 px-4 py-3 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
                    />
                  )}
                </div>
              ))}
            </form>
          )}

          {/* Navigation */}
          <div className="mt-8 flex gap-4">
            <Button
              onClick={handlePrevious}
              disabled={currentStep === 0}
              className="flex-1 bg-slate-700 hover:bg-slate-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="mr-2 h-5 w-5" />
              Previous
            </Button>
            <Button
              onClick={handleNext}
              className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-white"
            >
              {currentStep === steps.length - 1 ? 'Complete' : 'Next'}
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Skip Option */}
        <div className="mt-4 text-center">
          <button className="text-sm text-slate-400 hover:text-slate-300">Skip setup and go to dashboard</button>
        </div>
      </div>
    </div>
  );
};

export default AveryOnboarding;
