/**
 * Approval Workflow System Schema (MySQL)
 * Manages approval workflows, tasks, and gating
 */

import {
  mysqlTable,
  int,
  varchar,
  text,
  timestamp,
  boolean,
  json,
  mysqlEnum,
  index,
} from 'drizzle-orm/mysql-core';
import { relations } from 'drizzle-orm';

// Workflows Table
export const workflows = mysqlTable(
  'workflows',
  {
    id: int('id').autoincrement().primaryKey(),
    userId: varchar('userId', { length: 64 }).notNull(),
    name: varchar('name', { length: 255 }).notNull(),
    description: text('description'),
    status: mysqlEnum('status', ['draft', 'active', 'paused', 'archived'])
      .default('draft')
      .notNull(),
    approvalLevels: int('approvalLevels').default(1).notNull(),
    requiresAllApprovals: boolean('requiresAllApprovals').default(true),
    autoApproveAfterDays: int('autoApproveAfterDays'),
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow().notNull(),
    updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index('workflow_userId_idx').on(table.userId),
  })
);

// Tasks Table
export const approvalTasks = mysqlTable(
  'approvalTasks',
  {
    id: int('id').autoincrement().primaryKey(),
    workflowId: int('workflowId').notNull(),
    userId: varchar('userId', { length: 64 }).notNull(),
    title: varchar('title', { length: 255 }).notNull(),
    description: text('description'),
    status: mysqlEnum('status', [
      'pending',
      'in_progress',
      'approved',
      'rejected',
      'cancelled',
    ])
      .default('pending')
      .notNull(),
    priority: mysqlEnum('priority', ['low', 'medium', 'high', 'critical'])
      .default('medium')
      .notNull(),
    assignedTo: varchar('assignedTo', { length: 64 }),
    dueDate: timestamp('dueDate'),
    completedAt: timestamp('completedAt'),
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow().notNull(),
    updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    workflowIdIdx: index('task_workflowId_idx').on(table.workflowId),
    userIdIdx: index('task_userId_idx').on(table.userId),
  })
);

// Approvals Table
export const approvals = mysqlTable(
  'approvals',
  {
    id: int('id').autoincrement().primaryKey(),
    taskId: int('taskId').notNull(),
    workflowId: int('workflowId').notNull(),
    approverUserId: varchar('approverUserId', { length: 64 }).notNull(),
    status: mysqlEnum('status', [
      'pending',
      'in_progress',
      'approved',
      'rejected',
      'cancelled',
    ])
      .default('pending')
      .notNull(),
    approvalLevel: mysqlEnum('approvalLevel', ['low', 'medium', 'high', 'critical'])
      .default('medium')
      .notNull(),
    comments: text('comments'),
    approvedAt: timestamp('approvedAt'),
    rejectedAt: timestamp('rejectedAt'),
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow().notNull(),
    updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    taskIdIdx: index('approval_taskId_idx').on(table.taskId),
    workflowIdIdx: index('approval_workflowId_idx').on(table.workflowId),
    approverUserIdIdx: index('approval_approverUserId_idx').on(table.approverUserId),
  })
);

// Approval Gates Table (for feature gating)
export const approvalGates = mysqlTable(
  'approvalGates',
  {
    id: int('id').autoincrement().primaryKey(),
    userId: varchar('userId', { length: 64 }).notNull(),
    featureName: varchar('featureName', { length: 255 }).notNull(),
    requiredApprovals: int('requiredApprovals').default(1).notNull(),
    currentApprovals: int('currentApprovals').default(0).notNull(),
    isGated: boolean('isGated').default(true).notNull(),
    expiresAt: timestamp('expiresAt'),
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow().notNull(),
    updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userIdIdx: index('gate_userId_idx').on(table.userId),
    featureNameIdx: index('gate_featureName_idx').on(table.featureName),
  })
);

// Approval History Table
export const approvalHistory = mysqlTable(
  'approvalHistory',
  {
    id: int('id').autoincrement().primaryKey(),
    approvalId: int('approvalId').notNull(),
    action: varchar('action', { length: 50 }).notNull(),
    performedBy: varchar('performedBy', { length: 64 }).notNull(),
    details: json('details'),
    createdAt: timestamp('createdAt').defaultNow().notNull(),
  },
  (table) => ({
    approvalIdIdx: index('history_approvalId_idx').on(table.approvalId),
  })
);

// Types
export type Workflow = typeof workflows.$inferSelect;
export type InsertWorkflow = typeof workflows.$inferInsert;

export type ApprovalTask = typeof approvalTasks.$inferSelect;
export type InsertApprovalTask = typeof approvalTasks.$inferInsert;

export type Approval = typeof approvals.$inferSelect;
export type InsertApproval = typeof approvals.$inferInsert;

export type ApprovalGate = typeof approvalGates.$inferSelect;
export type InsertApprovalGate = typeof approvalGates.$inferInsert;

export type ApprovalHistoryRecord = typeof approvalHistory.$inferSelect;
export type InsertApprovalHistory = typeof approvalHistory.$inferInsert;

// Relations
export const workflowsRelations = relations(workflows, ({ many }) => ({
  tasks: many(approvalTasks),
  approvals: many(approvals),
  gates: many(approvalGates),
}));

export const approvalTasksRelations = relations(approvalTasks, ({ one, many }) => ({
  workflow: one(workflows),
  approvals: many(approvals),
  history: many(approvalHistory),
}));

export const approvalsRelations = relations(approvals, ({ one, many }) => ({
  task: one(approvalTasks),
  workflow: one(workflows),
  history: many(approvalHistory),
}));

export const approvalGatesRelations = relations(approvalGates, ({ one }) => ({
  workflow: one(workflows),
}));

export const approvalHistoryRelations = relations(approvalHistory, ({ one }) => ({
  approval: one(approvals),
}));
