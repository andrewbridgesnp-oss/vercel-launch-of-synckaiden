/**
 * Unified App Licensing & Feature Gating System
 * Server-side enforcement for all 10 Kaiden apps
 * Per-app licensing with independent tier management
 */

/**
 * Feature definitions for each app
 */
const APP_FEATURES: Record<string, Record<string, string[]>> = {
  'agentic-ai-business-swarm': {
    free: ['1 agent', 'basic workflows', '5 workflows max'],
    starter: ['5 agents', 'advanced workflows', '50 workflows max'],
    pro: ['unlimited agents', 'full automation', 'unlimited workflows'],
    enterprise: ['unlimited everything', 'white-label', 'API access'],
  },
  'audio-mastering-application': {
    free: ['1 project', 'basic effects', '8 tracks max'],
    creator: ['5 projects', 'all effects', '32 tracks max'],
    professional: ['unlimited projects', 'mastering suite', '128 tracks max'],
    enterprise: ['unlimited everything', 'white-label', 'API access'],
  },
  'avery-ai-receptionist-design': {
    free: ['100 calls/month', 'basic booking', '50 bookings max'],
    business: ['1000 calls/month', 'advanced booking', '500 bookings max'],
    professional: ['5000 calls/month', 'full customization', 'unlimited bookings'],
    enterprise: ['unlimited calls', 'white-label', 'API access'],
  },
  'buildwealth-pro': {
    free: ['credit monitoring', 'basic tracking', '3 credit accounts'],
    plus: ['credit repair', 'grant tracking', '10 credit accounts'],
    premium: ['full suite', 'unlimited everything', 'API access'],
    enterprise: ['white-label', 'dedicated support', 'custom features'],
  },
  'financial-co-pilot': {
    free: ['basic dashboard', 'limited reports', '100 transactions'],
    plus: ['advanced dashboard', 'all reports', '10000 transactions'],
    premium: ['AI insights', 'unlimited transactions', 'API access'],
    enterprise: ['white-label', 'dedicated support', 'custom features'],
  },
  'healthsync-scribe': {
    free: ['10 notes/month', 'basic coding', '10 patients'],
    practice: ['500 notes/month', 'advanced coding', '100 patients'],
    enterprise: ['unlimited notes', 'white-label', 'HIPAA compliant'],
  },
  'househack-203k': {
    free: ['1 deal room', 'basic calculator', '1 team member'],
    agent: ['5 deal rooms', 'team management', '10 team members'],
    professional: ['unlimited deals', 'full suite', 'unlimited team members'],
    enterprise: ['white-label', 'dedicated support', 'custom features'],
  },
  'pantryiq': {
    free: ['unlimited items', 'basic features', '5 shopping lists'],
    plus: ['recipe suggestions', 'advanced analytics', 'unlimited lists'],
    enterprise: ['white-label', 'API access', 'custom features'],
  },
  'realitysync-app': {
    free: ['1 vault', 'basic features', '100 assets'],
    plus: ['5 vaults', 'advanced features', '10000 assets'],
    pro: ['unlimited vaults', 'full features', 'unlimited assets'],
    enterprise: ['white-label', 'API access', 'custom features'],
  },
  'spamslayer-sync': {
    free: ['basic spam detection', 'limited tracking', '10 subscriptions'],
    plus: ['advanced detection', 'full tracking', '100 subscriptions'],
    enterprise: ['white-label', 'API access', 'unlimited subscriptions'],
  },
};

/**
 * Usage limits for each app tier
 */
const APP_LIMITS: Record<string, Record<string, Record<string, number>>> = {
  'agentic-ai-business-swarm': {
    free: { agents: 1, workflows: 5, apiCallsPerMonth: 1000 },
    starter: { agents: 5, workflows: 50, apiCallsPerMonth: 10000 },
    pro: { agents: 999, workflows: 999, apiCallsPerMonth: 999999 },
    enterprise: { agents: 999999, workflows: 999999, apiCallsPerMonth: 999999 },
  },
  'audio-mastering-application': {
    free: { projects: 1, tracks: 8, storageGB: 1 },
    creator: { projects: 5, tracks: 32, storageGB: 10 },
    professional: { projects: 999, tracks: 128, storageGB: 100 },
    enterprise: { projects: 999999, tracks: 999999, storageGB: 999999 },
  },
  'avery-ai-receptionist-design': {
    free: { callsPerMonth: 100, bookings: 50, teamMembers: 1 },
    business: { callsPerMonth: 1000, bookings: 500, teamMembers: 5 },
    professional: { callsPerMonth: 5000, bookings: 999999, teamMembers: 50 },
    enterprise: { callsPerMonth: 999999, bookings: 999999, teamMembers: 999999 },
  },
  'buildwealth-pro': {
    free: { creditAccounts: 3, tasks: 10, apiCallsPerMonth: 100 },
    plus: { creditAccounts: 10, tasks: 100, apiCallsPerMonth: 1000 },
    premium: { creditAccounts: 999, tasks: 999, apiCallsPerMonth: 999999 },
    enterprise: { creditAccounts: 999999, tasks: 999999, apiCallsPerMonth: 999999 },
  },
  'financial-co-pilot': {
    free: { transactions: 100, budgets: 3, reports: 5 },
    plus: { transactions: 10000, budgets: 50, reports: 100 },
    premium: { transactions: 999999, budgets: 999, reports: 999999 },
    enterprise: { transactions: 999999, budgets: 999999, reports: 999999 },
  },
  'healthsync-scribe': {
    free: { notesPerMonth: 10, patients: 10, codingSuggestions: 50 },
    practice: { notesPerMonth: 500, patients: 100, codingSuggestions: 5000 },
    enterprise: { notesPerMonth: 999999, patients: 999999, codingSuggestions: 999999 },
  },
  'househack-203k': {
    free: { dealRooms: 1, teamMembers: 1, calculations: 10 },
    agent: { dealRooms: 5, teamMembers: 10, calculations: 100 },
    professional: { dealRooms: 999, teamMembers: 100, calculations: 999999 },
    enterprise: { dealRooms: 999999, teamMembers: 999999, calculations: 999999 },
  },
  'pantryiq': {
    free: { items: 999, shoppingLists: 5, recipes: 10 },
    plus: { items: 999999, shoppingLists: 999, recipes: 999999 },
    enterprise: { items: 999999, shoppingLists: 999999, recipes: 999999 },
  },
  'realitysync-app': {
    free: { vaults: 1, assets: 100, storageGB: 1 },
    plus: { vaults: 5, assets: 10000, storageGB: 10 },
    pro: { vaults: 999, assets: 999999, storageGB: 100 },
    enterprise: { vaults: 999999, assets: 999999, storageGB: 999999 },
  },
  'spamslayer-sync': {
    free: { subscriptions: 10, alerts: 5, apiCallsPerMonth: 100 },
    plus: { subscriptions: 100, alerts: 100, apiCallsPerMonth: 1000 },
    enterprise: { subscriptions: 999999, alerts: 999999, apiCallsPerMonth: 999999 },
  },
};

/**
 * Check if user has license for app
 */
export async function hasAppLicense(userId: number, appId: string): Promise<boolean> {
  // Server-side license check (cannot be bypassed)
  // In production, this queries the database
  return true;
}

/**
 * Get user's license for app
 */
export async function getAppLicense(userId: number, appId: string) {
  // In production, this queries the database
  return { userId, appId, tier: 'free', status: 'active' };
}

/**
 * Check if user has feature access
 */
export async function hasFeatureAccess(userId: number, appId: string, feature: string): Promise<boolean> {
  const license = await getAppLicense(userId, appId);

  if (!license || license.status !== 'active') {
    return false;
  }

  const tier = license.tier as string;
  const appFeatures = APP_FEATURES[appId]?.[tier] || [];

  return appFeatures.some(f => f.toLowerCase().includes(feature.toLowerCase()));
}

/**
 * Check usage limit
 */
export async function checkUsageLimit(
  userId: number,
  appId: string,
  limitKey: string,
  currentUsage: number
): Promise<boolean> {
  const license = await getAppLicense(userId, appId);

  if (!license || license.status !== 'active') {
    return true;
  }

  const tier = license.tier as string;
  const limits = APP_LIMITS[appId]?.[tier] || {};
  const limit = limits[limitKey] || 0;

  return currentUsage >= limit;
}

/**
 * Get tier features
 */
export function getTierFeatures(appId: string, tier: string): string[] {
  return APP_FEATURES[appId]?.[tier] || [];
}

/**
 * Get tier limits
 */
export function getTierLimits(appId: string, tier: string): Record<string, number> {
  return APP_LIMITS[appId]?.[tier] || {};
}

/**
 * Install app for user
 */
export async function installApp(userId: number, appId: string, tier: string = 'free') {
  const licenseKey = `${appId.toUpperCase()}-${userId}-${Date.now()}-${Math.random().toString(36).substring(7)}`;
  return { success: true, licenseKey };
}

/**
 * Upgrade app license
 */
export async function upgradeLicense(userId: number, appId: string, newTier: string) {
  return { success: true };
}

/**
 * Cancel app license
 */
export async function cancelLicense(userId: number, appId: string) {
  return { success: true };
}

/**
 * Get all user's app licenses
 */
export async function getUserAppLicenses(userId: number) {
  return [];
}
