/**
 * Bougie Boutique - Digital Storefront
 * Premium AI side hustles and digital products for $1 each
 * Liquid glass UI with anti-theft unique purchase codes
 */

import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ShoppingCart, 
  Star, 
  Download, 
  Shield, 
  Sparkles, 
  Zap, 
  Lock, 
  CheckCircle2,
  Search,
  Filter,
  TrendingUp,
  Gift,
  Crown,
  Eye,
  Heart
} from 'lucide-react';

// Product categories
const CATEGORIES = [
  { id: 'all', name: 'All Products', icon: Sparkles },
  { id: 'ai-hustle', name: 'AI Side Hustles', icon: Zap },
  { id: 'template', name: 'Templates', icon: Gift },
  { id: 'guide', name: 'Guides', icon: TrendingUp },
  { id: 'course', name: 'Courses', icon: Crown },
  { id: 'tool', name: 'Tools', icon: Shield },
];

// Sample products (will be fetched from API in production)
const SAMPLE_PRODUCTS = [
  {
    id: 1,
    name: 'AI Content Empire Blueprint',
    description: 'Complete system to generate $5K/month with AI content creation. Includes prompts, workflows, and monetization strategies.',
    category: 'ai-hustle',
    price: 100, // $1.00
    originalPrice: 4700, // $47.00
    imageUrl: '/products/ai-content-empire.png',
    features: ['50+ AI Prompts', 'Content Calendar', 'Monetization Guide', 'Video Tutorials'],
    rating: 4.9,
    reviewCount: 127,
    salesCount: 1543,
  },
  {
    id: 2,
    name: 'Faceless YouTube Automation',
    description: 'Build a faceless YouTube channel that generates passive income using AI tools and automation.',
    category: 'ai-hustle',
    price: 100,
    originalPrice: 9700,
    imageUrl: '/products/faceless-youtube.png',
    features: ['Channel Setup Guide', 'AI Script Templates', 'Thumbnail Templates', 'SEO Checklist'],
    rating: 4.8,
    reviewCount: 89,
    salesCount: 892,
  },
  {
    id: 3,
    name: 'AI Freelance Mastery',
    description: 'Land high-paying freelance clients using AI to 10x your productivity and deliver premium results.',
    category: 'ai-hustle',
    price: 100,
    originalPrice: 6700,
    imageUrl: '/products/ai-freelance.png',
    features: ['Client Acquisition', 'AI Workflow Setup', 'Pricing Strategy', 'Portfolio Templates'],
    rating: 4.7,
    reviewCount: 156,
    salesCount: 2341,
  },
  {
    id: 4,
    name: 'Notion Business Dashboard',
    description: 'Complete Notion template for managing your entire business - CRM, projects, finances, and more.',
    category: 'template',
    price: 100,
    originalPrice: 2900,
    imageUrl: '/products/notion-dashboard.png',
    features: ['CRM System', 'Project Tracker', 'Finance Dashboard', 'Team Wiki'],
    rating: 4.9,
    reviewCount: 234,
    salesCount: 3456,
  },
  {
    id: 5,
    name: 'Social Media Content Calendar',
    description: '365-day content calendar with AI-generated post ideas, hashtags, and optimal posting times.',
    category: 'template',
    price: 100,
    originalPrice: 1900,
    imageUrl: '/products/content-calendar.png',
    features: ['365 Post Ideas', 'Hashtag Database', 'Posting Schedule', 'Analytics Tracker'],
    rating: 4.6,
    reviewCount: 78,
    salesCount: 1234,
  },
  {
    id: 6,
    name: 'Credit Repair Masterclass',
    description: 'Step-by-step guide to repair your credit score from 500 to 750+ in 6 months or less.',
    category: 'guide',
    price: 100,
    originalPrice: 19700,
    imageUrl: '/products/credit-repair.png',
    features: ['Dispute Templates', 'Credit Stack Strategy', 'Secured Card Guide', 'Legal Resources'],
    rating: 4.9,
    reviewCount: 312,
    salesCount: 4567,
  },
  {
    id: 7,
    name: 'Real Estate Investing 101',
    description: 'Complete beginner guide to real estate investing - from house hacking to BRRRR strategy.',
    category: 'guide',
    price: 100,
    originalPrice: 14700,
    imageUrl: '/products/real-estate-guide.png',
    features: ['Deal Analysis', '203K Loan Guide', 'House Hacking', 'DSCR Loans'],
    rating: 4.8,
    reviewCount: 189,
    salesCount: 2890,
  },
  {
    id: 8,
    name: 'AI Automation Bootcamp',
    description: 'Learn to automate your business with AI - from chatbots to workflow automation.',
    category: 'course',
    price: 100,
    originalPrice: 29700,
    imageUrl: '/products/ai-automation.png',
    features: ['10+ Hours Video', 'Hands-on Projects', 'Certificate', 'Community Access'],
    rating: 4.9,
    reviewCount: 456,
    salesCount: 5678,
  },
  {
    id: 9,
    name: 'Prompt Engineering Pro',
    description: 'Master the art of prompt engineering to get 10x better results from ChatGPT and other AI tools.',
    category: 'course',
    price: 100,
    originalPrice: 9700,
    imageUrl: '/products/prompt-engineering.png',
    features: ['100+ Prompts', 'Advanced Techniques', 'Use Case Library', 'Updates Included'],
    rating: 4.7,
    reviewCount: 234,
    salesCount: 3456,
  },
  {
    id: 10,
    name: 'AI Business Toolkit',
    description: 'Collection of AI-powered tools for business - proposal generator, email writer, and more.',
    category: 'tool',
    price: 100,
    originalPrice: 7700,
    imageUrl: '/products/ai-toolkit.png',
    features: ['Proposal Generator', 'Email Templates', 'Contract Writer', 'Invoice Creator'],
    rating: 4.8,
    reviewCount: 167,
    salesCount: 2345,
  },
];

// Product Card Component
function ProductCard({ 
  product, 
  onPurchase,
  onPreview 
}: { 
  product: typeof SAMPLE_PRODUCTS[0];
  onPurchase: (product: typeof SAMPLE_PRODUCTS[0]) => void;
  onPreview: (product: typeof SAMPLE_PRODUCTS[0]) => void;
}) {
  const discount = Math.round((1 - product.price / product.originalPrice) * 100);
  
  return (
    <Card className="group relative overflow-hidden bg-slate-900/50 border-slate-800 backdrop-blur-xl hover:border-cyan-500/50 transition-all duration-300">
      {/* Liquid glass effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      {/* Discount badge */}
      <div className="absolute top-3 right-3 z-10">
        <Badge className="bg-gradient-to-r from-pink-500 to-rose-500 text-white border-0 shadow-lg">
          {discount}% OFF
        </Badge>
      </div>

      {/* Product image */}
      <div className="relative h-48 bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent z-10" />
        <Sparkles className="w-16 h-16 text-cyan-400/30" />
        <div className="absolute bottom-3 left-3 z-20 flex items-center gap-2">
          <Badge variant="secondary" className="bg-slate-800/80 text-slate-300 text-xs">
            {product.salesCount.toLocaleString()} sold
          </Badge>
        </div>
      </div>

      <CardHeader className="relative pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-lg text-white line-clamp-2 group-hover:text-cyan-400 transition-colors">
            {product.name}
          </CardTitle>
        </div>
        <CardDescription className="text-slate-400 line-clamp-2 text-sm">
          {product.description}
        </CardDescription>
      </CardHeader>

      <CardContent className="relative space-y-4">
        {/* Rating */}
        <div className="flex items-center gap-2">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-slate-600'}`} 
              />
            ))}
          </div>
          <span className="text-sm text-slate-400">
            {product.rating} ({product.reviewCount} reviews)
          </span>
        </div>

        {/* Features */}
        <div className="flex flex-wrap gap-1.5">
          {product.features.slice(0, 3).map((feature, i) => (
            <Badge key={i} variant="outline" className="text-xs border-slate-700 text-slate-400">
              {feature}
            </Badge>
          ))}
          {product.features.length > 3 && (
            <Badge variant="outline" className="text-xs border-slate-700 text-slate-400">
              +{product.features.length - 3} more
            </Badge>
          )}
        </div>

        {/* Pricing */}
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-bold text-white">${(product.price / 100).toFixed(2)}</span>
          <span className="text-lg text-slate-500 line-through">${(product.originalPrice / 100).toFixed(2)}</span>
        </div>
      </CardContent>

      <CardFooter className="relative flex gap-2">
        <Button 
          variant="outline" 
          size="sm"
          className="flex-1 border-slate-700 text-slate-300 hover:bg-slate-800"
          onClick={() => onPreview(product)}
        >
          <Eye className="w-4 h-4 mr-1" />
          Preview
        </Button>
        <Button 
          size="sm"
          className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white border-0"
          onClick={() => onPurchase(product)}
        >
          <ShoppingCart className="w-4 h-4 mr-1" />
          Buy Now
        </Button>
      </CardFooter>
    </Card>
  );
}

// Main Bougie Boutique Component
export default function BougieBoutique() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<typeof SAMPLE_PRODUCTS>([]);
  const [showCart, setShowCart] = useState(false);

  // Filter products
  const filteredProducts = SAMPLE_PRODUCTS.filter(product => {
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Handle purchase
  const handlePurchase = (product: typeof SAMPLE_PRODUCTS[0]) => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    // Add to cart or direct checkout
    setCart(prev => [...prev, product]);
    setShowCart(true);
  };

  // Handle preview
  const handlePreview = (product: typeof SAMPLE_PRODUCTS[0]) => {
    // Open preview modal (to be implemented)
    console.log('Preview:', product.name);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-500/10 via-transparent to-transparent" />
        <div className="absolute top-20 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center space-y-6">
            {/* Badge */}
            <Badge className="bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-400 border-cyan-500/30 px-4 py-1.5">
              <Crown className="w-4 h-4 mr-2" />
              Premium Digital Products
            </Badge>

            {/* Title with liquid glass effect */}
            <h1 className="text-5xl md:text-7xl font-bold">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-400 animate-gradient">
                Bougie Boutique
              </span>
            </h1>

            <p className="text-xl md:text-2xl text-slate-400 max-w-3xl mx-auto">
              Premium AI side hustles and digital products for just <span className="text-cyan-400 font-bold">$1</span> each.
              <br />
              No subscriptions. No hidden fees. Just pure value.
            </p>

            {/* Trust badges */}
            <div className="flex flex-wrap justify-center gap-6 pt-4">
              <div className="flex items-center gap-2 text-slate-400">
                <Shield className="w-5 h-5 text-green-400" />
                <span>Secure Checkout</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <Lock className="w-5 h-5 text-cyan-400" />
                <span>Unique Purchase Codes</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <Download className="w-5 h-5 text-blue-400" />
                <span>Instant Download</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <CheckCircle2 className="w-5 h-5 text-purple-400" />
                <span>No Tracking</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="px-4 pb-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input 
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-slate-900/50 border-slate-800 text-white placeholder:text-slate-500 focus:border-cyan-500"
              />
            </div>

            {/* Category tabs */}
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full md:w-auto">
              <TabsList className="bg-slate-900/50 border border-slate-800 p-1 flex-wrap h-auto">
                {CATEGORIES.map(cat => (
                  <TabsTrigger 
                    key={cat.id} 
                    value={cat.id}
                    className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500/20 data-[state=active]:to-blue-500/20 data-[state=active]:text-cyan-400"
                  >
                    <cat.icon className="w-4 h-4 mr-1.5" />
                    {cat.name}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="px-4 pb-20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map(product => (
              <ProductCard 
                key={product.id} 
                product={product}
                onPurchase={handlePurchase}
                onPreview={handlePreview}
              />
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-20">
              <Sparkles className="w-16 h-16 text-slate-600 mx-auto mb-4" />
              <h3 className="text-xl text-white mb-2">No products found</h3>
              <p className="text-slate-400">Try adjusting your search or filter</p>
            </div>
          )}
        </div>
      </section>

      {/* Security Section */}
      <section className="px-4 py-20 bg-slate-900/50">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl font-bold text-white">Air-Tight Security</h2>
          <p className="text-slate-400 text-lg">
            Your privacy is our priority. We never track, share, or sell your data.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="pt-6 text-center">
                <Lock className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Unique Purchase Codes</h3>
                <p className="text-sm text-slate-400">
                  Each purchase generates a unique code tied to your account. No sharing, no stealing.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="pt-6 text-center">
                <Shield className="w-12 h-12 text-green-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Zero Tracking</h3>
                <p className="text-sm text-slate-400">
                  No cookies, no analytics, no third-party trackers. Your browsing stays private.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="pt-6 text-center">
                <CheckCircle2 className="w-12 h-12 text-purple-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No Data Sharing</h3>
                <p className="text-sm text-slate-400">
                  Your information never leaves our servers. We never sell or share your data.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Cart Sidebar (simplified) */}
      {showCart && cart.length > 0 && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm" onClick={() => setShowCart(false)}>
          <div 
            className="absolute right-0 top-0 h-full w-full max-w-md bg-slate-900 border-l border-slate-800 p-6 overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Your Cart</h2>
              <Button variant="ghost" size="sm" onClick={() => setShowCart(false)}>
                Close
              </Button>
            </div>
            
            <div className="space-y-4">
              {cart.map((item, i) => (
                <div key={i} className="flex items-center gap-4 p-4 bg-slate-800/50 rounded-lg">
                  <div className="w-16 h-16 bg-slate-700 rounded-lg flex items-center justify-center">
                    <Sparkles className="w-8 h-8 text-cyan-400/50" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-white font-medium line-clamp-1">{item.name}</h3>
                    <p className="text-cyan-400 font-bold">${(item.price / 100).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 pt-6 border-t border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <span className="text-slate-400">Total</span>
                <span className="text-2xl font-bold text-white">
                  ${(cart.reduce((sum, item) => sum + item.price, 0) / 100).toFixed(2)}
                </span>
              </div>
              
              <Button 
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white"
                onClick={() => navigate('/checkout')}
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                Checkout
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
