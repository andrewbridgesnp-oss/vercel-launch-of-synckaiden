/**
 * Analytics Tracking Utility
 * 
 * Tracks user interactions for engagement metrics:
 * - Personality selection
 * - Button clicks
 * - Feature access
 * - Conversion events
 */

interface AnalyticsEvent {
  eventName: string;
  eventData?: Record<string, unknown>;
  timestamp: number;
  sessionId: string;
  userId?: string;
}

interface AnalyticsConfig {
  endpoint?: string;
  enabled: boolean;
  debug?: boolean;
}

class Analytics {
  private config: AnalyticsConfig;
  private sessionId: string;
  private eventQueue: AnalyticsEvent[] = [];
  private flushInterval: NodeJS.Timeout | null = null;

  constructor(config: Partial<AnalyticsConfig> = {}) {
    this.config = {
      enabled: true,
      debug: false,
      endpoint: typeof window !== 'undefined' && import.meta.env.VITE_ANALYTICS_ENDPOINT ? import.meta.env.VITE_ANALYTICS_ENDPOINT : '/api/analytics',
      ...config,
    };

    this.sessionId = this.generateSessionId();
    this.initializeSession();
    this.startFlushInterval();
  }

  /**
   * Generate unique session ID
   */
  private generateSessionId(): string {
    const stored = localStorage.getItem('analytics_session_id');
    if (stored) {
      return stored;
    }

    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem('analytics_session_id', sessionId);
    return sessionId;
  }

  /**
   * Initialize session tracking
   */
  private initializeSession(): void {
    if (!this.config.enabled) return;

    // Track page view
    this.trackEvent('page_view', {
      url: window.location.href,
      referrer: document.referrer,
      userAgent: navigator.userAgent,
    });

    // Track visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.trackEvent('session_pause');
      } else {
        this.trackEvent('session_resume');
      }
    });

    // Flush events on page unload
    if (typeof window !== 'undefined') {
      window.addEventListener('beforeunload', () => {
        this.flush();
      });
    }
  }

  /**
   * Start periodic flush interval
   */
  private startFlushInterval(): void {
    this.flushInterval = setInterval(() => {
      this.flush();
    }, 30000); // Flush every 30 seconds
  }

  /**
   * Track personality selection
   */
  trackPersonalitySelection(personalityId: string): void {
    this.trackEvent('personality_selected', {
      personalityId,
      timestamp: Date.now(),
    });
  }

  /**
   * Track button click
   */
  trackButtonClick(buttonName: string, metadata?: Record<string, unknown>): void {
    this.trackEvent('button_clicked', {
      buttonName,
      ...metadata,
    });
  }

  /**
   * Track feature access
   */
  trackFeatureAccess(featureName: string, metadata?: Record<string, unknown>): void {
    this.trackEvent('feature_accessed', {
      featureName,
      ...metadata,
    });
  }

  /**
   * Track conversion event
   */
  trackConversion(conversionType: string, metadata?: Record<string, unknown>): void {
    this.trackEvent('conversion', {
      conversionType,
      ...metadata,
    });
  }

  /**
   * Track custom event
   */
  trackEvent(eventName: string, eventData?: Record<string, unknown>): void {
    if (!this.config.enabled) return;

    const event: AnalyticsEvent = {
      eventName,
      eventData,
      timestamp: Date.now(),
      sessionId: this.sessionId,
      userId: this.getUserId(),
    };

    if (this.config.debug) {
      console.log('[Analytics]', event);
    }

    this.eventQueue.push(event);

    // Flush if queue is large
    if (this.eventQueue.length >= 10) {
      this.flush();
    }
  }

  /**
   * Get user ID from localStorage or auth
   */
  private getUserId(): string | undefined {
    try {
      const user = localStorage.getItem('user');
      if (user) {
        const parsed = JSON.parse(user);
        return parsed.id;
      }
    } catch (e) {
      // Ignore parsing errors
    }
    return undefined;
  }

  /**
   * Flush events to server
   */
  async flush(): Promise<void> {
    if (this.eventQueue.length === 0) return;

    const events = [...this.eventQueue];
    this.eventQueue = [];

    try {
      await fetch(this.config.endpoint!, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ events }),
        keepalive: true, // Important for beforeunload
      });
    } catch (error) {
      if (this.config.debug) {
        console.error('[Analytics] Flush failed:', error);
      }
      // Re-queue events on failure
      this.eventQueue.unshift(...events);
    }
  }

  /**
   * Cleanup
   */
  destroy(): void {
    if (this.flushInterval) {
      clearInterval(this.flushInterval);
    }
    this.flush();
  }
}

// Create singleton instance
let analyticsInstance: Analytics | null = null;

export function getAnalytics(): Analytics {
  if (!analyticsInstance) {
    analyticsInstance = new Analytics({
      enabled: true,
      debug: import.meta.env.DEV,
    });
  }
  return analyticsInstance;
}

export default Analytics;
