/**
 * KAI(DEN) TAX - Server-side Tax Operations
 * Privacy-first: Minimal data storage, field-level encryption
 */

import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { getDb } from "./db";
import { 
  taxReturns, taxpayerInfo, incomeRecords, taxDeductions, 
  taxCredits, scheduleC, taxDocuments, taxAuditTrail,
  taxHealth, taxScenarios, interviewProgress
} from "../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";
import crypto from "crypto";

// Encryption utilities for PII
const ENCRYPTION_KEY = process.env.TAX_ENCRYPTION_KEY || process.env.JWT_SECRET || 'default-key-change-in-production';

function encryptSSN(ssn: string): string {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-gcm', Buffer.from(ENCRYPTION_KEY.padEnd(32, '0').slice(0, 32)), iv);
  let encrypted = cipher.update(ssn, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag();
  return iv.toString('hex') + ':' + authTag.toString('hex') + ':' + encrypted;
}

function hashSSN(ssn: string): string {
  return crypto.createHash('sha256').update(ssn + ENCRYPTION_KEY).digest('hex');
}

// Input schemas
const filingStatusSchema = z.enum([
  'single', 
  'married_filing_jointly', 
  'married_filing_separately', 
  'head_of_household', 
  'qualifying_widow'
]);

const createReturnSchema = z.object({
  taxYear: z.number().min(2020).max(2030),
  filingStatus: filingStatusSchema,
  state: z.string().length(2).optional(),
});

const taxpayerInfoSchema = z.object({
  returnId: z.number(),
  type: z.enum(['primary', 'spouse', 'dependent']),
  firstName: z.string().min(1).max(100),
  lastName: z.string().min(1).max(100),
  ssn: z.string().optional(), // Will be encrypted
  dateOfBirth: z.string().optional(),
  occupation: z.string().optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().length(2).optional(),
  zipCode: z.string().optional(),
  relationship: z.string().optional(),
  monthsLivedWithYou: z.number().min(0).max(12).optional(),
});

const incomeRecordSchema = z.object({
  returnId: z.number(),
  type: z.enum(['w2', '1099_nec', '1099_int', '1099_div', '1099_b', '1099_r', '1099_g', 'k1', 'other']),
  payerName: z.string().optional(),
  payerEin: z.string().optional(),
  grossAmount: z.number(),
  federalWithheld: z.number().optional(),
  stateWithheld: z.number().optional(),
  socialSecurityWages: z.number().optional(),
  medicareWages: z.number().optional(),
  qualifiedDividends: z.number().optional(),
  ordinaryDividends: z.number().optional(),
  proceeds: z.number().optional(),
  costBasis: z.number().optional(),
  gainLoss: z.number().optional(),
  isLongTerm: z.boolean().optional(),
});

const deductionSchema = z.object({
  returnId: z.number(),
  category: z.enum(['medical', 'state_local_taxes', 'mortgage_interest', 'charitable', 'business', 'home_office', 'mileage', 'other']),
  subcategory: z.string().optional(),
  description: z.string().optional(),
  amount: z.number(),
  deductionDate: z.string().optional(),
  payee: z.string().optional(),
  aiSuggested: z.boolean().optional(),
});

const creditSchema = z.object({
  returnId: z.number(),
  type: z.enum(['child_tax_credit', 'earned_income', 'education', 'child_care', 'retirement_savings', 'ev_credit', 'energy_credit', 'other']),
  amount: z.number(),
  qualifyingPersonId: z.number().optional(),
  details: z.record(z.string(), z.any()).optional(),
});

const scenarioSchema = z.object({
  returnId: z.number(),
  name: z.string(),
  description: z.string().optional(),
  isBaseline: z.boolean().optional(),
  filingStatus: z.string().optional(),
  additionalIncome: z.number().optional(),
  additionalDeductions: z.number().optional(),
  retirementContribution: z.number().optional(),
  hsaContribution: z.number().optional(),
  itemizedVsStandard: z.string().optional(),
});

export const taxRouter = router({
  // ==================== TAX RETURNS ====================
  
  // Create new tax return
  createReturn: protectedProcedure
    .input(createReturnSchema)
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      const userId = ctx.user.id;
      
      const [result] = await db.insert(taxReturns).values({
        userId,
        taxYear: input.taxYear,
        filingStatus: input.filingStatus,
        state: input.state,
        status: 'draft',
        completionPercentage: 0,
      });
      
      const returnId = result.insertId;
      
      // Create initial interview progress records
      const sections = ['personal_info', 'income', 'deductions', 'credits', 'review'] as const;
      for (const section of sections) {
        await db.insert(interviewProgress).values({
          returnId: Number(returnId),
          section,
          status: 'not_started',
        });
      }
      
      // Log audit trail
      await db.insert(taxAuditTrail).values({
        returnId: Number(returnId),
        userId,
        action: 'created',
        entityType: 'return',
        entityId: Number(returnId),
        sourceType: 'manual',
      });
      
      return { id: returnId };
    }),

  // Get user's tax returns
  getReturns: protectedProcedure
    .query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      const returns = await db.select()
        .from(taxReturns)
        .where(eq(taxReturns.userId, ctx.user.id))
        .orderBy(desc(taxReturns.taxYear));
      return returns;
    }),

  // Get single return with all data
  getReturn: protectedProcedure
    .input(z.object({ returnId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      // Verify ownership
      const [taxReturn] = await db.select()
        .from(taxReturns)
        .where(and(
          eq(taxReturns.id, input.returnId),
          eq(taxReturns.userId, ctx.user.id)
        ));
      
      if (!taxReturn) {
        throw new TRPCError({ code: 'NOT_FOUND', message: 'Tax return not found' });
      }
      
      // Get all related data
      const [taxpayers, income, deductions, credits, progress] = await Promise.all([
        db.select().from(taxpayerInfo).where(eq(taxpayerInfo.returnId, input.returnId)),
        db.select().from(incomeRecords).where(eq(incomeRecords.returnId, input.returnId)),
        db.select().from(taxDeductions).where(eq(taxDeductions.returnId, input.returnId)),
        db.select().from(taxCredits).where(eq(taxCredits.returnId, input.returnId)),
        db.select().from(interviewProgress).where(eq(interviewProgress.returnId, input.returnId)),
      ]);
      
      return {
        ...taxReturn,
        taxpayers,
        income,
        deductions,
        credits,
        progress,
      };
    }),

  // Update return status
  updateReturnStatus: protectedProcedure
    .input(z.object({
      returnId: z.number(),
      status: z.enum(['draft', 'in_progress', 'review', 'submitted', 'accepted', 'rejected']),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      // Verify ownership
      const [taxReturn] = await db.select()
        .from(taxReturns)
        .where(and(
          eq(taxReturns.id, input.returnId),
          eq(taxReturns.userId, ctx.user.id)
        ));
      
      if (!taxReturn) {
        throw new TRPCError({ code: 'NOT_FOUND' });
      }
      
      await db.update(taxReturns)
        .set({ 
          status: input.status,
          ...(input.status === 'submitted' ? { submittedAt: new Date() } : {}),
          ...(input.status === 'accepted' ? { acceptedAt: new Date() } : {}),
        })
        .where(eq(taxReturns.id, input.returnId));
      
      // Log audit trail
      await db.insert(taxAuditTrail).values({
        returnId: input.returnId,
        userId: ctx.user.id,
        action: 'updated',
        entityType: 'return',
        entityId: input.returnId,
        fieldName: 'status',
        oldValue: taxReturn.status,
        newValue: input.status,
        sourceType: 'manual',
      });
      
      return { success: true };
    }),

  // ==================== TAXPAYER INFO ====================
  
  addTaxpayer: protectedProcedure
    .input(taxpayerInfoSchema)
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      // Verify return ownership
      const [taxReturn] = await db.select()
        .from(taxReturns)
        .where(and(
          eq(taxReturns.id, input.returnId),
          eq(taxReturns.userId, ctx.user.id)
        ));
      
      if (!taxReturn) {
        throw new TRPCError({ code: 'NOT_FOUND' });
      }
      
      // Encrypt SSN if provided
      const ssnEncrypted = input.ssn ? encryptSSN(input.ssn) : undefined;
      const ssnHash = input.ssn ? hashSSN(input.ssn) : undefined;
      
      const [result] = await db.insert(taxpayerInfo).values({
        returnId: input.returnId,
        type: input.type,
        firstName: input.firstName,
        lastName: input.lastName,
        ssnEncrypted,
        ssnHash,
        dateOfBirth: input.dateOfBirth,
        occupation: input.occupation,
        email: input.email,
        phone: input.phone,
        address: input.address,
        city: input.city,
        state: input.state,
        zipCode: input.zipCode,
        relationship: input.relationship,
        monthsLivedWithYou: input.monthsLivedWithYou,
      });
      
      // Log audit trail (without PII)
      await db.insert(taxAuditTrail).values({
        returnId: input.returnId,
        userId: ctx.user.id,
        action: 'created',
        entityType: 'taxpayer',
        entityId: Number(result.insertId),
        sourceType: 'manual',
      });
      
      return { id: result.insertId };
    }),

  // ==================== INCOME RECORDS ====================
  
  addIncome: protectedProcedure
    .input(incomeRecordSchema)
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      // Verify return ownership
      const [taxReturn] = await db.select()
        .from(taxReturns)
        .where(and(
          eq(taxReturns.id, input.returnId),
          eq(taxReturns.userId, ctx.user.id)
        ));
      
      if (!taxReturn) {
        throw new TRPCError({ code: 'NOT_FOUND' });
      }
      
      const [result] = await db.insert(incomeRecords).values({
        returnId: input.returnId,
        type: input.type,
        payerName: input.payerName,
        payerEin: input.payerEin,
        grossAmount: String(input.grossAmount),
        federalWithheld: input.federalWithheld ? String(input.federalWithheld) : '0',
        stateWithheld: input.stateWithheld ? String(input.stateWithheld) : '0',
        socialSecurityWages: input.socialSecurityWages ? String(input.socialSecurityWages) : undefined,
        medicareWages: input.medicareWages ? String(input.medicareWages) : undefined,
        qualifiedDividends: input.qualifiedDividends ? String(input.qualifiedDividends) : undefined,
        ordinaryDividends: input.ordinaryDividends ? String(input.ordinaryDividends) : undefined,
        proceeds: input.proceeds ? String(input.proceeds) : undefined,
        costBasis: input.costBasis ? String(input.costBasis) : undefined,
        gainLoss: input.gainLoss ? String(input.gainLoss) : undefined,
        isLongTerm: input.isLongTerm,
      });
      
      // Log audit trail
      await db.insert(taxAuditTrail).values({
        returnId: input.returnId,
        userId: ctx.user.id,
        action: 'created',
        entityType: 'income',
        entityId: Number(result.insertId),
        sourceType: 'manual',
        newValue: JSON.stringify({ type: input.type, amount: input.grossAmount }),
      });
      
      return { id: result.insertId };
    }),

  // ==================== DEDUCTIONS ====================
  
  addDeduction: protectedProcedure
    .input(deductionSchema)
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      // Verify return ownership
      const [taxReturn] = await db.select()
        .from(taxReturns)
        .where(and(
          eq(taxReturns.id, input.returnId),
          eq(taxReturns.userId, ctx.user.id)
        ));
      
      if (!taxReturn) {
        throw new TRPCError({ code: 'NOT_FOUND' });
      }
      
      const [result] = await db.insert(taxDeductions).values({
        returnId: input.returnId,
        category: input.category,
        subcategory: input.subcategory,
        description: input.description,
        amount: String(input.amount),
        deductionDate: input.deductionDate,
        payee: input.payee,
        aiSuggested: input.aiSuggested || false,
      });
      
      // Log audit trail
      await db.insert(taxAuditTrail).values({
        returnId: input.returnId,
        userId: ctx.user.id,
        action: 'created',
        entityType: 'deduction',
        entityId: Number(result.insertId),
        sourceType: input.aiSuggested ? 'ai_suggestion' : 'manual',
        newValue: JSON.stringify({ category: input.category, amount: input.amount }),
      });
      
      return { id: result.insertId };
    }),

  // ==================== CREDITS ====================
  
  addCredit: protectedProcedure
    .input(creditSchema)
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      // Verify return ownership
      const [taxReturn] = await db.select()
        .from(taxReturns)
        .where(and(
          eq(taxReturns.id, input.returnId),
          eq(taxReturns.userId, ctx.user.id)
        ));
      
      if (!taxReturn) {
        throw new TRPCError({ code: 'NOT_FOUND' });
      }
      
      const [result] = await db.insert(taxCredits).values({
        returnId: input.returnId,
        type: input.type,
        amount: String(input.amount),
        qualifyingPersonId: input.qualifyingPersonId,
        details: input.details,
      });
      
      return { id: result.insertId };
    }),

  // ==================== SCENARIOS ====================
  
  createScenario: protectedProcedure
    .input(scenarioSchema)
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      // Verify return ownership
      const [taxReturn] = await db.select()
        .from(taxReturns)
        .where(and(
          eq(taxReturns.id, input.returnId),
          eq(taxReturns.userId, ctx.user.id)
        ));
      
      if (!taxReturn) {
        throw new TRPCError({ code: 'NOT_FOUND' });
      }
      
      const [result] = await db.insert(taxScenarios).values({
        returnId: input.returnId,
        userId: ctx.user.id,
        name: input.name,
        description: input.description,
        isBaseline: input.isBaseline || false,
        filingStatus: input.filingStatus,
        additionalIncome: input.additionalIncome ? String(input.additionalIncome) : undefined,
        additionalDeductions: input.additionalDeductions ? String(input.additionalDeductions) : undefined,
        retirementContribution: input.retirementContribution ? String(input.retirementContribution) : undefined,
        hsaContribution: input.hsaContribution ? String(input.hsaContribution) : undefined,
        itemizedVsStandard: input.itemizedVsStandard,
      });
      
      return { id: result.insertId };
    }),

  getScenarios: protectedProcedure
    .input(z.object({ returnId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      const scenarios = await db.select()
        .from(taxScenarios)
        .where(and(
          eq(taxScenarios.returnId, input.returnId),
          eq(taxScenarios.userId, ctx.user.id)
        ));
      
      return scenarios;
    }),

  // ==================== AUDIT TRAIL ====================
  
  getAuditTrail: protectedProcedure
    .input(z.object({ returnId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      // Verify return ownership
      const [taxReturn] = await db.select()
        .from(taxReturns)
        .where(and(
          eq(taxReturns.id, input.returnId),
          eq(taxReturns.userId, ctx.user.id)
        ));
      
      if (!taxReturn) {
        throw new TRPCError({ code: 'NOT_FOUND' });
      }
      
      const trail = await db.select()
        .from(taxAuditTrail)
        .where(eq(taxAuditTrail.returnId, input.returnId))
        .orderBy(desc(taxAuditTrail.createdAt));
      
      return trail;
    }),

  // ==================== TAX HEALTH ====================
  
  getTaxHealth: protectedProcedure
    .input(z.object({ taxYear: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      const health = await db.select()
        .from(taxHealth)
        .where(and(
          eq(taxHealth.userId, ctx.user.id),
          eq(taxHealth.taxYear, input.taxYear)
        ))
        .orderBy(taxHealth.month);
      
      return health;
    }),

  updateTaxHealth: protectedProcedure
    .input(z.object({
      taxYear: z.number(),
      month: z.number().min(1).max(12),
      projectedIncome: z.number().optional(),
      actualIncome: z.number().optional(),
      projectedWithholding: z.number().optional(),
      actualWithholding: z.number().optional(),
      projectedDeductions: z.number().optional(),
      actualDeductions: z.number().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      // Check if record exists
      const [existing] = await db.select()
        .from(taxHealth)
        .where(and(
          eq(taxHealth.userId, ctx.user.id),
          eq(taxHealth.taxYear, input.taxYear),
          eq(taxHealth.month, input.month)
        ));
      
      if (existing) {
        await db.update(taxHealth)
          .set({
            projectedIncome: input.projectedIncome ? String(input.projectedIncome) : existing.projectedIncome,
            actualIncome: input.actualIncome ? String(input.actualIncome) : existing.actualIncome,
            projectedWithholding: input.projectedWithholding ? String(input.projectedWithholding) : existing.projectedWithholding,
            actualWithholding: input.actualWithholding ? String(input.actualWithholding) : existing.actualWithholding,
            projectedDeductions: input.projectedDeductions ? String(input.projectedDeductions) : existing.projectedDeductions,
            actualDeductions: input.actualDeductions ? String(input.actualDeductions) : existing.actualDeductions,
          })
          .where(eq(taxHealth.id, existing.id));
        return { id: existing.id };
      } else {
        const [result] = await db.insert(taxHealth).values({
          userId: ctx.user.id,
          taxYear: input.taxYear,
          month: input.month,
          projectedIncome: input.projectedIncome ? String(input.projectedIncome) : undefined,
          actualIncome: input.actualIncome ? String(input.actualIncome) : undefined,
          projectedWithholding: input.projectedWithholding ? String(input.projectedWithholding) : undefined,
          actualWithholding: input.actualWithholding ? String(input.actualWithholding) : undefined,
          projectedDeductions: input.projectedDeductions ? String(input.projectedDeductions) : undefined,
          actualDeductions: input.actualDeductions ? String(input.actualDeductions) : undefined,
        });
        return { id: result.insertId };
      }
    }),

  // ==================== INTERVIEW PROGRESS ====================
  
  updateInterviewProgress: protectedProcedure
    .input(z.object({
      returnId: z.number(),
      section: z.enum(['personal_info', 'income', 'deductions', 'credits', 'review']),
      status: z.enum(['not_started', 'in_progress', 'completed', 'skipped']),
      answers: z.record(z.string(), z.any()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
      
      // Verify return ownership
      const [taxReturn] = await db.select()
        .from(taxReturns)
        .where(and(
          eq(taxReturns.id, input.returnId),
          eq(taxReturns.userId, ctx.user.id)
        ));
      
      if (!taxReturn) {
        throw new TRPCError({ code: 'NOT_FOUND' });
      }
      
      await db.update(interviewProgress)
        .set({
          status: input.status,
          answers: input.answers,
          completedAt: input.status === 'completed' ? new Date() : undefined,
        })
        .where(and(
          eq(interviewProgress.returnId, input.returnId),
          eq(interviewProgress.section, input.section)
        ));
      
      // Update return completion percentage
      const allProgress = await db.select()
        .from(interviewProgress)
        .where(eq(interviewProgress.returnId, input.returnId));
      
      const completedSections = allProgress.filter(p => p.status === 'completed').length;
      const completionPercentage = Math.round((completedSections / allProgress.length) * 100);
      
      await db.update(taxReturns)
        .set({ completionPercentage })
        .where(eq(taxReturns.id, input.returnId));
      
      return { success: true, completionPercentage };
    }),
});
