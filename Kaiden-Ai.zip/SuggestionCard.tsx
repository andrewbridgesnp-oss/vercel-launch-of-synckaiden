import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LucideIcon } from "lucide-react";

interface SuggestionCardProps {
  title: string;
  description: string;
  icon?: LucideIcon;
  action?: () => void;
  actionLabel?: string;
  className?: string;
}

export function SuggestionCard({ 
  title, 
  description, 
  icon: Icon, 
  action, 
  actionLabel = "Learn More",
  className = ""
}: SuggestionCardProps) {
  return (
    <Card className={`hover:border-blue-500/50 transition-colors ${className}`}>
      <CardHeader>
        <div className="flex items-start gap-4">
          {Icon && (
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-500">
              <Icon className="h-5 w-5" />
            </div>
          )}
          <div className="flex-1">
            <CardTitle className="text-lg">{title}</CardTitle>
            <CardDescription className="mt-2">{description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      {action && (
        <CardContent>
          <Button onClick={action} variant="outline" size="sm">
            {actionLabel}
          </Button>
        </CardContent>
      )}
    </Card>
  );
}
