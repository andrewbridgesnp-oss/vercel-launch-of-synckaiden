import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";

interface LegalDisclaimerProps {
  type?: "tax" | "legal" | "financial" | "general";
  className?: string;
}

export function LegalDisclaimer({ type = "general", className = "" }: LegalDisclaimerProps) {
  const disclaimers = {
    tax: "This information is for educational purposes only and does not constitute tax advice. Kaiden is not a CPA, tax attorney, or enrolled agent. Consult a licensed tax professional for your specific situation.",
    legal: "This information is for educational purposes only and does not constitute legal advice. Kaiden is not a licensed attorney. Consult a licensed attorney for your specific legal matters.",
    financial: "This information is for educational purposes only and does not constitute financial advice. Kaiden is not a licensed financial advisor. Consult a licensed financial professional for your specific situation.",
    general: "This information is for educational purposes only. Kaiden provides tools and guidance but is not a substitute for professional advice. Consult licensed professionals for your specific needs."
  };

  return (
    <Alert className={`border-yellow-500/50 bg-yellow-500/10 ${className}`}>
      <AlertTriangle className="h-4 w-4 text-yellow-500" />
      <AlertDescription className="text-sm text-yellow-200/90">
        <strong>Legal Disclaimer:</strong> {disclaimers[type]}
      </AlertDescription>
    </Alert>
  );
}
