import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import type { Capability, Module, CapabilityState, CapabilityRegistry } from '@/types';

interface CapabilityStoreState {
  // Data
  registry: CapabilityRegistry | null;
  capabilities: Capability[];
  modules: Module[];
  
  // UI State
  selectedCapabilityId: string | null;
  selectedModuleId: string | null;
  expandedModules: Set<string>;
  searchQuery: string;
  filterStatus: 'ALL' | 'LIVE' | 'BETA' | 'COMING_SOON';
  filterPriority: 'ALL' | 'HIGH' | 'MEDIUM' | 'LOW';
  
  // Runtime State
  capabilityStates: Map<string, CapabilityState>;
  isLoading: boolean;
  error: Error | null;
  
  // Actions
  setRegistry: (registry: CapabilityRegistry) => void;
  setCapabilities: (capabilities: Capability[]) => void;
  setModules: (modules: Module[]) => void;
  
  selectCapability: (id: string) => void;
  selectModule: (id: string) => void;
  toggleModuleExpanded: (id: string) => void;
  
  setSearchQuery: (query: string) => void;
  setFilterStatus: (status: 'ALL' | 'LIVE' | 'BETA' | 'COMING_SOON') => void;
  setFilterPriority: (priority: 'ALL' | 'HIGH' | 'MEDIUM' | 'LOW') => void;
  
  updateCapabilityState: (id: string, state: Partial<CapabilityState>) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: Error | null) => void;
  
  // Computed
  getFilteredCapabilities: () => Capability[];
  getCapabilitiesByModule: (moduleId: string) => Capability[];
  getSelectedCapability: () => Capability | undefined;
  getSelectedModule: () => Module | undefined;
  
  // Reset
  reset: () => void;
}

const initialState = {
  registry: null,
  capabilities: [],
  modules: [],
  selectedCapabilityId: null,
  selectedModuleId: null,
  expandedModules: new Set<string>(),
  searchQuery: '',
  filterStatus: 'ALL' as const,
  filterPriority: 'ALL' as const,
  capabilityStates: new Map<string, CapabilityState>(),
  isLoading: false,
  error: null,
};

export const useCapabilityStore = create<CapabilityStoreState>()(
  devtools(
    persist(
      (set, get) => ({
        ...initialState,

        setRegistry: (registry) => {
          set({ registry });
          // Auto-organize capabilities into modules
          const moduleMap = new Map<string, Capability[]>();
          registry.capabilities.forEach((cap) => {
            if (!moduleMap.has(cap.module)) {
              moduleMap.set(cap.module, []);
            }
            moduleMap.get(cap.module)!.push(cap);
          });

          const modules: Module[] = Array.from(moduleMap.entries()).map(
            ([name, caps], index) => ({
              id: `module_${index}`,
              name,
              description: `${caps.length} capabilities`,
              capabilities: caps,
              order: index,
              isExpanded: index < 3, // Expand first 3 modules by default
            })
          );

          set({
            capabilities: registry.capabilities,
            modules,
          });
        },

        setCapabilities: (capabilities) => set({ capabilities }),
        setModules: (modules) => set({ modules }),

        selectCapability: (id) => set({ selectedCapabilityId: id }),
        selectModule: (id) => set({ selectedModuleId: id }),

        toggleModuleExpanded: (id) => {
          set((state) => {
            const expanded = new Set(state.expandedModules);
            if (expanded.has(id)) {
              expanded.delete(id);
            } else {
              expanded.add(id);
            }
            return { expandedModules: expanded };
          });
        },

        setSearchQuery: (query) => set({ searchQuery: query.toLowerCase() }),
        setFilterStatus: (status) => set({ filterStatus: status }),
        setFilterPriority: (priority) => set({ filterPriority: priority }),

        updateCapabilityState: (id, state) => {
          set((current) => {
            const states = new Map(current.capabilityStates);
            const existing = states.get(id) || {
              id,
              capabilityId: id,
              isLoading: false,
              isError: false,
            };
            states.set(id, { ...existing, ...state });
            return { capabilityStates: states };
          });
        },

        setLoading: (loading) => set({ isLoading: loading }),
        setError: (error) => set({ error }),

        getFilteredCapabilities: () => {
          const state = get();
          return state.capabilities.filter((cap) => {
            // Status filter
            if (state.filterStatus !== 'ALL' && cap.status !== state.filterStatus) {
              return false;
            }

            // Priority filter
            if (state.filterPriority !== 'ALL' && cap.priority !== state.filterPriority) {
              return false;
            }

            // Search filter
            if (state.searchQuery) {
              const query = state.searchQuery;
              return (
                cap.name.toLowerCase().includes(query) ||
                cap.description.toLowerCase().includes(query) ||
                cap.module.toLowerCase().includes(query)
              );
            }

            return true;
          });
        },

        getCapabilitiesByModule: (moduleId) => {
          const state = get();
          const module = state.modules.find((m) => m.id === moduleId);
          return module?.capabilities || [];
        },

        getSelectedCapability: () => {
          const state = get();
          return state.capabilities.find((c) => c.id === state.selectedCapabilityId);
        },

        getSelectedModule: () => {
          const state = get();
          return state.modules.find((m) => m.id === state.selectedModuleId);
        },

        reset: () => set(initialState),
      }),
      {
        name: 'capability-store',
        partialize: (state) => ({
          searchQuery: state.searchQuery,
          filterStatus: state.filterStatus,
          filterPriority: state.filterPriority,
          expandedModules: Array.from(state.expandedModules),
        }),
      }
    )
  )
);
