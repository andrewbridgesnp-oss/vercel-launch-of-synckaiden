/**
 * Unit tests for useContentGeneration hook
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useContentGeneration } from './useContentGeneration';

describe('useContentGeneration', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    global.fetch = vi.fn();
  });

  it('should initialize with correct default state', () => {
    const { result } = renderHook(() => useContentGeneration());

    expect(result.current.isGenerating).toBe(false);
    expect(result.current.error).toBe(null);
    expect(result.current.generatedContent).toEqual([]);
  });

  it('should generate text content', async () => {
    const mockResponse = {
      id: 'content-1',
      content: 'Generated text content',
      metadata: {},
    };

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockResponse,
    });

    const { result } = renderHook(() => useContentGeneration());

    await act(async () => {
      await result.current.generateText('Write a blog post');
    });

    expect(result.current.generatedContent).toHaveLength(1);
    expect(result.current.generatedContent[0].contentType).toBe('text');
    expect(result.current.isGenerating).toBe(false);
  });

  it('should generate image content', async () => {
    const mockResponse = {
      id: 'image-1',
      content: 'https://example.com/image.png',
      metadata: { width: 1024, height: 1024 },
    };

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockResponse,
    });

    const { result } = renderHook(() => useContentGeneration());

    await act(async () => {
      await result.current.generateImage('A beautiful sunset');
    });

    expect(result.current.generatedContent).toHaveLength(1);
    expect(result.current.generatedContent[0].contentType).toBe('image');
  });

  it('should generate code', async () => {
    const mockResponse = {
      id: 'code-1',
      content: 'function hello() { console.log("Hello"); }',
      metadata: { language: 'javascript' },
    };

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockResponse,
    });

    const { result } = renderHook(() => useContentGeneration());

    await act(async () => {
      await result.current.generateCode('A function that prints hello');
    });

    expect(result.current.generatedContent).toHaveLength(1);
    expect(result.current.generatedContent[0].contentType).toBe('code');
  });

  it('should handle generation errors', async () => {
    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: false,
      json: async () => ({ message: 'Generation failed' }),
    });

    const { result } = renderHook(() => useContentGeneration());

    await act(async () => {
      try {
        await result.current.generateText('Test');
      } catch (e) {
        // Expected error
      }
    });

    expect(result.current.error).toBeTruthy();
  });

  it('should support custom options', async () => {
    const mockResponse = {
      id: 'text-1',
      content: 'Generated content',
      metadata: {},
    };

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockResponse,
    });

    const { result } = renderHook(() => useContentGeneration());

    await act(async () => {
      await result.current.generateText('Write a poem', {
        tone: 'romantic',
        length: 'short',
      });
    });

    expect(global.fetch).toHaveBeenCalledWith(
      '/api/content/generate',
      expect.objectContaining({
        body: expect.stringContaining('romantic'),
      })
    );
  });

  it('should clear content history', () => {
    const { result } = renderHook(() => useContentGeneration());

    // Add mock content
    act(() => {
      result.current.generatedContent.push({
        id: 'test-1',
        content: 'Test',
        contentType: 'text',
        prompt: 'Test prompt',
        createdAt: new Date(),
      });
    });

    expect(result.current.generatedContent).toHaveLength(1);

    act(() => {
      result.current.clearHistory();
    });

    expect(result.current.generatedContent).toHaveLength(0);
  });

  it('should delete specific content', () => {
    const { result } = renderHook(() => useContentGeneration());

    act(() => {
      result.current.deleteContent('content-1');
    });

    expect(result.current.generatedContent).not.toContainEqual(
      expect.objectContaining({ id: 'content-1' })
    );
  });

  it('should maintain generation state', async () => {
    const mockResponse = {
      id: 'content-1',
      content: 'Generated content',
      metadata: {},
    };

    global.fetch = vi.fn().mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          setTimeout(
            () =>
              resolve({
                ok: true,
                json: async () => mockResponse,
              }),
            100
          );
        })
    );

    const { result } = renderHook(() => useContentGeneration());

    const promise = act(async () => {
      await result.current.generateText('Test');
    });

    expect(result.current.isGenerating).toBe(true);

    await promise;

    expect(result.current.isGenerating).toBe(false);
  });
});
