import { Phone, Mic, MicOff, Volume2, VolumeX, Play, Pause, SkipBack, SkipForward } from "lucide-react";
import { GlassmorphismCard } from "../components/avery/glassmorphism-card";
import { CallTimeline } from "../components/avery/call-timeline";
import { Button } from "../components/ui/button";

export function DemoPage() {
  const demoScript = [
    {
      speaker: "Avery",
      text: "Hi, this is Avery with Acme Services. How can I help you today?"
    },
    {
      speaker: "Customer",
      text: "Hi, I'd like to schedule a consultation."
    },
    {
      speaker: "Avery",
      text: "Perfect! I can help you book that. I have availability on January 15th at 2:00 PM, January 16th at 10:00 AM, or January 17th at 3:00 PM. Which works best for you?"
    },
    {
      speaker: "Customer",
      text: "January 15th at 2 PM sounds good."
    },
    {
      speaker: "Avery",
      text: "Great! I've got you scheduled for a consultation on January 15th at 2:00 PM. The session is 60 minutes and costs $150. A deposit is required to confirm. I'll send you a secure payment link via text right now. Can I confirm your phone number is +1 (555) 123-4567?"
    },
    {
      speaker: "Customer",
      text: "Yes, that's correct."
    },
    {
      speaker: "Avery",
      text: "Perfect! I've sent the payment link. Once the deposit is received, you'll get a confirmation email with all the details. Is there anything else I can help you with?"
    },
    {
      speaker: "Customer",
      text: "No, that's all. Thank you!"
    },
    {
      speaker: "Avery",
      text: "You're welcome! Have a great day, and we look forward to seeing you on January 15th. Goodbye!"
    }
  ];

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">Live Demo</h1>
        <p className="text-muted-foreground">Experience how Avery handles a real customer call</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Call Simulation */}
        <GlassmorphismCard className="p-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Call Simulation</h2>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon">
                  <SkipBack className="h-4 w-4" />
                </Button>
                <Button size="icon">
                  <Play className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <SkipForward className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Phone UI */}
            <div className="bg-gradient-to-b from-slate-900 to-slate-950 rounded-3xl p-6 mx-auto max-w-sm">
              <div className="text-center space-y-4">
                <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-accent to-accent/50 flex items-center justify-center">
                  <Phone className="h-10 w-10 text-white" />
                </div>
                <div>
                  <p className="text-lg font-medium text-white">Avery AI</p>
                  <p className="text-sm text-slate-400">00:45</p>
                </div>
                <div className="flex justify-center gap-4 pt-4">
                  <Button variant="outline" size="icon" className="rounded-full h-12 w-12">
                    <Mic className="h-5 w-5" />
                  </Button>
                  <Button variant="destructive" size="icon" className="rounded-full h-12 w-12">
                    <Phone className="h-5 w-5 rotate-[135deg]" />
                  </Button>
                  <Button variant="outline" size="icon" className="rounded-full h-12 w-12">
                    <Volume2 className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </GlassmorphismCard>

        {/* Transcript */}
        <GlassmorphismCard className="p-6">
          <h2 className="text-xl font-semibold mb-4">Live Transcript</h2>
          <div className="space-y-4 max-h-[400px] overflow-y-auto">
            {demoScript.map((line, i) => (
              <div
                key={i}
                className={`flex ${line.speaker === "Avery" ? "justify-start" : "justify-end"}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    line.speaker === "Avery"
                      ? "bg-accent/20 text-accent-foreground"
                      : "bg-muted"
                  }`}
                >
                  <p className="text-xs font-medium mb-1 opacity-70">{line.speaker}</p>
                  <p className="text-sm">{line.text}</p>
                </div>
              </div>
            ))}
          </div>
        </GlassmorphismCard>
      </div>

      {/* Call Timeline */}
      <GlassmorphismCard className="p-6">
        <h2 className="text-xl font-semibold mb-4">Call Flow Timeline</h2>
        <CallTimeline />
      </GlassmorphismCard>
    </div>
  );
}
