/**
 * Notifications Hook
 * Manages in-app notifications and alerts
 */

import { useState, useCallback, useRef } from 'react';

export type NotificationType = 'success' | 'error' | 'warning' | 'info';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  duration?: number; // milliseconds, 0 = persistent
  action?: {
    label: string;
    onClick: () => void;
  };
}

export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const idRef = useRef(0);

  /**
   * Add a notification
   */
  const addNotification = useCallback(
    (
      type: NotificationType,
      title: string,
      message: string,
      duration: number = 5000,
      action?: Notification['action']
    ): string => {
      const id = `notification-${++idRef.current}`;

      const notification: Notification = {
        id,
        type,
        title,
        message,
        duration,
        action,
      };

      setNotifications((prev) => [...prev, notification]);

      // Auto-remove if duration is set
      if (duration > 0) {
        setTimeout(() => {
          removeNotification(id);
        }, duration);
      }

      return id;
    },
    []
  );

  /**
   * Remove a notification
   */
  const removeNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  /**
   * Clear all notifications
   */
  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  /**
   * Convenience methods
   */
  const success = useCallback(
    (title: string, message: string, duration?: number, action?: Notification['action']) =>
      addNotification('success', title, message, duration, action),
    [addNotification]
  );

  const error = useCallback(
    (title: string, message: string, duration?: number, action?: Notification['action']) =>
      addNotification('error', title, message, duration || 7000, action),
    [addNotification]
  );

  const warning = useCallback(
    (title: string, message: string, duration?: number, action?: Notification['action']) =>
      addNotification('warning', title, message, duration || 6000, action),
    [addNotification]
  );

  const info = useCallback(
    (title: string, message: string, duration?: number, action?: Notification['action']) =>
      addNotification('info', title, message, duration || 5000, action),
    [addNotification]
  );

  return {
    notifications,
    addNotification,
    removeNotification,
    clearAll,
    success,
    error,
    warning,
    info,
  };
}
