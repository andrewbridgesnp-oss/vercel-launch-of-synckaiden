            size: 11,
            family: ""Inter", sans-serif",
            weight: "600" as const
          },
          padding: 16,