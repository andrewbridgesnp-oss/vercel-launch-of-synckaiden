/**
 * Advanced Analytics Dashboard
 * Comprehensive analytics and metrics visualization
 */

import React, { useState, useEffect } from 'react';
import { format, subDays } from 'date-fns';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import { Calendar, TrendingUp, Users, DollarSign, Activity, AlertCircle } from 'lucide-react';

interface KPISummary {
  totalActiveUsers: number;
  totalNewUsers: number;
  totalSessions: number;
  totalEvents: number;
  avgSessionDuration: number;
  avgBounceRate: number;
  totalRevenue: number;
  totalSubscriptions: number;
}

interface DateRange {
  startDate: Date;
  endDate: Date;
}

interface MetricCard {
  title: string;
  value: string | number;
  change?: number;
  icon: React.ReactNode;
  color: string;
}

export function AnalyticsDashboard() {
  const [dateRange, setDateRange] = useState<DateRange>({
    startDate: subDays(new Date(), 30),
    endDate: new Date(),
  });

  const [kpiData, setKpiData] = useState<KPISummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedMetric, setSelectedMetric] = useState<'users' | 'revenue' | 'engagement'>('users');

  // Mock data for visualization
  const mockDailyMetrics = Array.from({ length: 30 }, (_, i) => ({
    date: format(subDays(new Date(), 30 - i), 'MMM dd'),
    users: Math.floor(Math.random() * 500) + 100,
    sessions: Math.floor(Math.random() * 1000) + 200,
    revenue: Math.floor(Math.random() * 5000) + 1000,
  }));

  const mockRevenueByTier = [
    { tier: 'Free Trial', revenue: 0, transactions: 150 },
    { tier: 'Starter', revenue: 9900, transactions: 100 },
    { tier: 'Professional', revenue: 29700, transactions: 100 },
    { tier: 'Enterprise', revenue: 15000, transactions: 5 },
  ];

  const mockFeatureUsage = [
    { feature: 'Voice Sync', usage: 1250 },
    { feature: 'Analytics', usage: 980 },
    { feature: 'Content Gen', usage: 750 },
    { feature: 'Pricing', usage: 620 },
    { feature: 'Dashboard', usage: 540 },
  ];

  const mockFunnelData = [
    { step: 'Landing Page', total: 5000, completed: 5000, conversionRate: 100 },
    { step: 'Sign Up', total: 3500, completed: 3500, conversionRate: 70 },
    { step: 'Onboarding', total: 2800, completed: 2800, conversionRate: 80 },
    { step: 'First Action', total: 2100, completed: 2100, conversionRate: 75 },
    { step: 'Subscription', total: 315, completed: 315, conversionRate: 15 },
  ];

  const mockPerformanceData = [
    { endpoint: '/api/users', avgTime: 45, p95: 120, p99: 250 },
    { endpoint: '/api/analytics', avgTime: 120, p95: 350, p99: 800 },
    { endpoint: '/api/content', avgTime: 200, p95: 500, p99: 1200 },
    { endpoint: '/api/payments', avgTime: 80, p95: 200, p99: 450 },
  ];

  useEffect(() => {
    // Simulate loading analytics data
    setLoading(true);
    const timer = setTimeout(() => {
      setKpiData({
        totalActiveUsers: 2847,
        totalNewUsers: 342,
        totalSessions: 8932,
        totalEvents: 45230,
        avgSessionDuration: 12,
        avgBounceRate: 32.5,
        totalRevenue: 54600,
        totalSubscriptions: 205,
      });
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, [dateRange]);

  const handleDateRangeChange = (days: number) => {
    setDateRange({
      startDate: subDays(new Date(), days),
      endDate: new Date(),
    });
  };

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-slate-300">Loading analytics...</p>
        </div>
      </div>
    );
  }

  const metricCards: MetricCard[] = [
    {
      title: 'Active Users',
      value: kpiData?.totalActiveUsers || 0,
      change: 12.5,
      icon: <Users className="w-6 h-6" />,
      color: 'bg-blue-500',
    },
    {
      title: 'Total Revenue',
      value: `$${(kpiData?.totalRevenue || 0).toLocaleString()}`,
      change: 28.3,
      icon: <DollarSign className="w-6 h-6" />,
      color: 'bg-green-500',
    },
    {
      title: 'Total Sessions',
      value: kpiData?.totalSessions || 0,
      change: 8.2,
      icon: <Activity className="w-6 h-6" />,
      color: 'bg-purple-500',
    },
    {
      title: 'Subscriptions',
      value: kpiData?.totalSubscriptions || 0,
      change: 15.7,
      icon: <TrendingUp className="w-6 h-6" />,
      color: 'bg-orange-500',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-white mb-2">Analytics Dashboard</h1>
        <p className="text-slate-400">Real-time insights and performance metrics</p>
      </div>

      {/* Date Range Selector */}
      <div className="flex gap-4 mb-8">
        <button
          onClick={() => handleDateRangeChange(7)}
          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition"
        >
          7 Days
        </button>
        <button
          onClick={() => handleDateRangeChange(30)}
          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition"
        >
          30 Days
        </button>
        <button
          onClick={() => handleDateRangeChange(90)}
          className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition"
        >
          90 Days
        </button>
        <div className="ml-auto flex items-center gap-2 text-slate-400">
          <Calendar className="w-5 h-5" />
          <span>
            {format(dateRange.startDate, 'MMM dd')} - {format(dateRange.endDate, 'MMM dd')}
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {metricCards.map((card, index) => (
          <div
            key={index}
            className="bg-slate-800 border border-slate-700 rounded-lg p-6 hover:border-slate-600 transition"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-400 text-sm font-medium">{card.title}</h3>
              <div className={`${card.color} p-3 rounded-lg text-white`}>{card.icon}</div>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold text-white">{card.value}</span>
              {card.change !== undefined && (
                <span className="text-green-400 text-sm font-medium">+{card.change}%</span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Daily Metrics Chart */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
          <h2 className="text-xl font-bold text-white mb-6">Daily Active Users & Sessions</h2>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={mockDailyMetrics}>
              <defs>
                <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
              <XAxis dataKey="date" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Area
                type="monotone"
                dataKey="users"
                stroke="#3b82f6"
                fillOpacity={1}
                fill="url(#colorUsers)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Revenue Chart */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
          <h2 className="text-xl font-bold text-white mb-6">Revenue by Subscription Tier</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={mockRevenueByTier}>
              <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
              <XAxis dataKey="tier" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Bar dataKey="revenue" fill="#10b981" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Feature Usage */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
          <h2 className="text-xl font-bold text-white mb-6">Feature Usage</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={mockFeatureUsage} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
              <XAxis type="number" stroke="#94a3b8" />
              <YAxis dataKey="feature" type="category" stroke="#94a3b8" width={100} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Bar dataKey="usage" fill="#8b5cf6" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Conversion Funnel */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
          <h2 className="text-xl font-bold text-white mb-6">Conversion Funnel</h2>
          <div className="space-y-4">
            {mockFunnelData.map((step, index) => (
              <div key={index}>
                <div className="flex justify-between mb-2">
                  <span className="text-slate-300 font-medium">{step.step}</span>
                  <span className="text-slate-400 text-sm">
                    {step.completed.toLocaleString()} / {step.total.toLocaleString()}
                  </span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
                    style={{ width: `${step.conversionRate}%` }}
                  ></div>
                </div>
                <span className="text-slate-400 text-xs mt-1 block">
                  {step.conversionRate.toFixed(1)}% conversion
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="bg-slate-800 border border-slate-700 rounded-lg p-6 mb-8">
        <h2 className="text-xl font-bold text-white mb-6">API Performance</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left py-3 px-4 text-slate-400 font-medium">Endpoint</th>
                <th className="text-right py-3 px-4 text-slate-400 font-medium">Avg Time</th>
                <th className="text-right py-3 px-4 text-slate-400 font-medium">P95</th>
                <th className="text-right py-3 px-4 text-slate-400 font-medium">P99</th>
              </tr>
            </thead>
            <tbody>
              {mockPerformanceData.map((perf, index) => (
                <tr key={index} className="border-b border-slate-700 hover:bg-slate-700/50">
                  <td className="py-3 px-4 text-white">{perf.endpoint}</td>
                  <td className="text-right py-3 px-4 text-slate-300">{perf.avgTime}ms</td>
                  <td className="text-right py-3 px-4 text-slate-300">{perf.p95}ms</td>
                  <td className="text-right py-3 px-4 text-slate-300">{perf.p99}ms</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Alerts */}
      <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
        <div className="flex items-center gap-2 mb-4">
          <AlertCircle className="w-5 h-5 text-orange-400" />
          <h2 className="text-xl font-bold text-white">Alerts & Notifications</h2>
        </div>
        <div className="space-y-3">
          <div className="bg-orange-900/20 border border-orange-700/50 rounded p-3 flex items-start gap-3">
            <div className="w-2 h-2 bg-orange-400 rounded-full mt-1.5 flex-shrink-0"></div>
            <div>
              <p className="text-orange-200 font-medium">High bounce rate detected</p>
              <p className="text-orange-300 text-sm">Bounce rate increased to 32.5% (↑5.2%)</p>
            </div>
          </div>
          <div className="bg-green-900/20 border border-green-700/50 rounded p-3 flex items-start gap-3">
            <div className="w-2 h-2 bg-green-400 rounded-full mt-1.5 flex-shrink-0"></div>
            <div>
              <p className="text-green-200 font-medium">Revenue milestone reached</p>
              <p className="text-green-300 text-sm">Monthly revenue exceeded $50,000</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AnalyticsDashboard;
