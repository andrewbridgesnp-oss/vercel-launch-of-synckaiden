export type CapabilityStatus = 'LIVE' | 'BETA' | 'COMING_SOON';

export type RevenueRank = 'HIGH' | 'MEDIUM' | 'LONG_TERM';

export interface Capability {
  id: string;
  name: string;
  description: string;
  module: string; // e.g. "What's for Dinner", "Where's My Tribe", "Employees OS"
  status: CapabilityStatus;
  revenueRank: RevenueRank;
}

export const capabilities: Capability[] = [
  // --- Direct Revenue / Marketplace ---
  {
    id: 'dinner-weekly-menu',
    name: "Weekly Dinner Menu",
    description: 'Two affordable meal choices per service night with bulk pricing.',
    module: "What's for Dinner",
    status: 'BETA',
    revenueRank: 'HIGH',
  },
  {
    id: 'dinner-marketplace-restaurants',
    name: 'Restaurant Partner Sign-Up',
    description: 'Restaurants apply in-app to join the bulk dinner marketplace.',
    module: "What's for Dinner",
    status: 'LIVE',
    revenueRank: 'HIGH',
  },
  {
    id: 'dinner-marketplace-drivers',
    name: 'Driver Partner Sign-Up',
    description: 'Delivery drivers apply to pick up and route bulk dinner orders.',
    module: "What's for Dinner",
    status: 'LIVE',
    revenueRank: 'HIGH',
  },
  {
    id: 'dinner-marketplace-solvers',
    name: 'FWP Solver Network',
    description: 'First-World Problem solvers create service profiles for paid gigs.',
    module: 'First World Problems',
    status: 'LIVE',
    revenueRank: 'HIGH',
  },

  // --- CRM / Business OS ---
  {
    id: 'crm-contacts',
    name: 'Contacts CRM',
    description: 'Store and manage leads and contacts tied to a user account.',
    module: 'CRM',
    status: 'LIVE',
    revenueRank: 'HIGH',
  },
  {
    id: 'crm-deals',
    name: 'Deals Pipeline',
    description: 'Track deals by stage with simple probability logic.',
    module: 'CRM',
    status: 'LIVE',
    revenueRank: 'HIGH',
  },
  {
    id: 'agent-swarms-configs',
    name: 'Agent Swarm Configs',
    description: 'Define autonomous swarms focused on sales, ops, or finance.',
    module: 'Predictive Ops',
    status: 'LIVE',
    revenueRank: 'HIGH',
  },
  {
    id: 'agent-swarms-runs',
    name: 'Swarm Runs & Reports',
    description: 'Run swarms and receive summarized recommendations.',
    module: 'Predictive Ops',
    status: 'LIVE',
    revenueRank: 'HIGH',
  },

  // --- Where's My Tribe / Nexus ---
  {
    id: 'nexus-intake',
    name: "Where's My Tribe Intake",
    description: 'Conversation-style intake that captures vibe, energy, and group preferences.',
    module: "Where's My Tribe",
    status: 'LIVE',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'nexus-profile',
    name: 'Tribe Profile Vector',
    description: 'Backend profile vector (Big Five, values, social style) for future matching.',
    module: "Where's My Tribe",
    status: 'BETA',
    revenueRank: 'MEDIUM',
  },

  // --- Residential: Time, Tasks, FWPs ---
  {
    id: 'time-credits',
    name: "Where's My Time Going?",
    description: 'Time credit system to visualize how you spend your hours.',
    module: 'Time & Focus',
    status: 'COMING_SOON',
    revenueRank: 'HIGH',
  },
  {
    id: 'tasks-core',
    name: "Today's To-Do",
    description: 'Task list with AI-generated reminders and nudges.',
    module: 'Tasks',
    status: 'LIVE',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'fwp-top10',
    name: 'Weekly Top 10 FWPs',
    description: 'First-World Problem feed on the home screen with actionable links.',
    module: 'First World Problems',
    status: 'LIVE',
    revenueRank: 'MEDIUM',
  },

  // --- OS Modules (Employees, Sales, Ops, Marketing, Finance, Admin) ---
  {
    id: 'employees-payroll-benefits',
    name: 'Payroll & Benefits Module',
    description: 'Payroll processing, benefits tracking, and compliance mapping.',
    module: 'Employees OS',
    status: 'BETA',
    revenueRank: 'HIGH',
  },
  {
    id: 'employees-performance',
    name: 'Performance Management Module',
    description: 'Goals, reviews, and improvement plans overview.',
    module: 'Employees OS',
    status: 'BETA',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'employees-training',
    name: 'Training & Development Module',
    description: 'Courses, certifications, and training progress overview.',
    module: 'Employees OS',
    status: 'BETA',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'employees-hr-admin',
    name: 'HR Administration Module',
    description: 'Digital employee records and HR admin flows.',
    module: 'Employees OS',
    status: 'BETA',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'sales-automation',
    name: 'Sales Automation Module',
    description: 'Lead routing, workflows, and sales automations.',
    module: 'Sales OS',
    status: 'BETA',
    revenueRank: 'HIGH',
  },
  {
    id: 'sales-analytics',
    name: 'Sales Reporting & Analytics',
    description: 'Sales performance, forecasts, and dashboards.',
    module: 'Sales OS',
    status: 'BETA',
    revenueRank: 'HIGH',
  },
  {
    id: 'ops-projects',
    name: 'Projects & Workflows',
    description: 'Projects, sprints, and workflow visualizations.',
    module: 'Operations OS',
    status: 'BETA',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'ops-support-desk',
    name: 'Support & Service Desk',
    description: 'Ticket queues and SLA routing for support.',
    module: 'Operations OS',
    status: 'BETA',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'ops-assets',
    name: 'Assets & Facilities',
    description: 'Asset inventory and maintenance schedules.',
    module: 'Operations OS',
    status: 'BETA',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'marketing-campaigns',
    name: 'Campaigns & Journeys',
    description: 'Multi-step campaigns and journey builder.',
    module: 'Marketing OS',
    status: 'BETA',
    revenueRank: 'HIGH',
  },
  {
    id: 'marketing-social',
    name: 'Social & Content Studio',
    description: 'Content calendar and social publishing overview.',
    module: 'Marketing OS',
    status: 'BETA',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'marketing-seo',
    name: 'SEO & Web Intelligence',
    description: 'SEO monitoring and recommendations overview.',
    module: 'Marketing OS',
    status: 'BETA',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'finance-billing',
    name: 'Billing & Invoicing Module',
    description: 'Quotes, invoices, and payment status overview.',
    module: 'Finance OS',
    status: 'COMING_SOON',
    revenueRank: 'HIGH',
  },
  {
    id: 'finance-accounting',
    name: 'Accounting & Cashflow Module',
    description: 'High-level P&L and cashflow projections.',
    module: 'Finance OS',
    status: 'COMING_SOON',
    revenueRank: 'HIGH',
  },
  {
    id: 'finance-planning',
    name: 'Planning & KPIs Module',
    description: 'KPI and forecasting views for leadership.',
    module: 'Finance OS',
    status: 'COMING_SOON',
    revenueRank: 'HIGH',
  },
  {
    id: 'admin-governance',
    name: 'Governance & Compliance',
    description: 'Roles, permissions, and audit trails.',
    module: 'Admin OS',
    status: 'COMING_SOON',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'admin-workspace',
    name: 'Workspace & Configuration',
    description: 'Environment, brand, and layout configuration.',
    module: 'Admin OS',
    status: 'COMING_SOON',
    revenueRank: 'MEDIUM',
  },
  {
    id: 'admin-security',
    name: 'Security & Monitoring',
    description: 'Security controls and monitoring hooks.',
    module: 'Admin OS',
    status: 'COMING_SOON',
    revenueRank: 'MEDIUM',
  },

  // --- Lifestyle / Health / Mini Me ---
  {
    id: 'health-vitalsync',
    name: 'VitalSync Basics',
    description: 'Health overview and future wearable sync.',
    module: 'Health',
    status: 'COMING_SOON',
    revenueRank: 'LONG_TERM',
  },
  {
    id: 'mini-me-portal',
    name: 'Mini Me Portal',
    description: 'Kid-focused routines and micro-quests.',
    module: 'Mini Me',
    status: 'COMING_SOON',
    revenueRank: 'LONG_TERM',
  },
];
