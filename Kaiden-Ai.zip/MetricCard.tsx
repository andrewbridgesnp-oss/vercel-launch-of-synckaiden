/**
 * Metric Card Component
 * Reusable card for displaying KPI metrics
 */

import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  unit?: string;
  change?: {
    value: number;
    isPositive: boolean;
  };
  icon: React.ReactNode;
  color: 'blue' | 'green' | 'purple' | 'orange' | 'red' | 'pink';
  onClick?: () => void;
  loading?: boolean;
  trend?: 'up' | 'down' | 'neutral';
}

const colorMap = {
  blue: 'bg-blue-500',
  green: 'bg-green-500',
  purple: 'bg-purple-500',
  orange: 'bg-orange-500',
  red: 'bg-red-500',
  pink: 'bg-pink-500',
};

const borderColorMap = {
  blue: 'border-blue-500/30',
  green: 'border-green-500/30',
  purple: 'border-purple-500/30',
  orange: 'border-orange-500/30',
  red: 'border-red-500/30',
  pink: 'border-pink-500/30',
};

export function MetricCard({
  title,
  value,
  unit,
  change,
  icon,
  color,
  onClick,
  loading = false,
  trend,
}: MetricCardProps) {
  return (
    <div
      onClick={onClick}
      className={`bg-slate-800 border ${borderColorMap[color]} rounded-lg p-6 hover:border-${color}-500/50 transition cursor-pointer group`}
    >
      {loading ? (
        <div className="animate-pulse">
          <div className="h-4 bg-slate-700 rounded w-24 mb-4"></div>
          <div className="h-8 bg-slate-700 rounded w-32"></div>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-slate-400 text-sm font-medium">{title}</h3>
            <div className={`${colorMap[color]} p-3 rounded-lg text-white group-hover:scale-110 transition`}>
              {icon}
            </div>
          </div>

          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-3xl font-bold text-white">{value}</span>
            {unit && <span className="text-slate-400 text-sm">{unit}</span>}
          </div>

          {change && (
            <div className="flex items-center gap-1">
              {change.isPositive ? (
                <>
                  <TrendingUp className="w-4 h-4 text-green-400" />
                  <span className="text-green-400 text-sm font-medium">
                    +{change.value}%
                  </span>
                </>
              ) : (
                <>
                  <TrendingDown className="w-4 h-4 text-red-400" />
                  <span className="text-red-400 text-sm font-medium">
                    {change.value}%
                  </span>
                </>
              )}
              <span className="text-slate-500 text-xs ml-1">vs last period</span>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default MetricCard;
