import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Redirect } from "wouter";
import {
  CreditCard,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  FileText,
  Phone,
  Mail,
  Scale,
  Building2,
  DollarSign,
  Shield,
  ArrowRight,
  Star,
  Clock,
  Target,
  Zap,
  BookOpen,
  Lock,
} from "lucide-react";

// Credit Score Tiers
const creditTiers = [
  { range: "300-579", label: "Poor", color: "bg-red-500", description: "Start with secured cards" },
  { range: "580-629", label: "Fair", color: "bg-orange-500", description: "Credit One eligible" },
  { range: "630-649", label: "Good", color: "bg-yellow-500", description: "Capital One eligible" },
  { range: "650-699", label: "Very Good", color: "bg-green-500", description: "Major cards eligible" },
  { range: "700+", label: "Excellent", color: "bg-emerald-500", description: "Premium cards & loans" },
];

// Credit Building Resources
const creditResources = [
  { name: "CreditBanks.com", url: "https://creditbanks.com", description: "Credit building tools and resources" },
  { name: "BankNet.com", url: "https://banknet.com", description: "Banking and credit solutions" },
  { name: "HelpMeBuildCredit.com", url: "https://helpmebuildcredit.com", description: "Credit improvement strategies" },
  { name: "AnnualCreditReport.com", url: "https://annualcreditreport.com", description: "Free annual credit reports" },
];

// Credit Stack Strategy
const creditStackSteps = [
  {
    scoreRange: "Below 580",
    title: "Foundation Phase",
    cards: ["Discover It Secured"],
    strategy: "Use $500 to secure credit line. Pay one subscription monthly (like NAV Prime). Never exceed 30% utilization.",
    timeline: "3-6 months",
  },
  {
    scoreRange: "580-629",
    title: "Building Phase",
    cards: ["Credit One Bank"],
    strategy: "Apply for Credit One. Continue using secured card responsibly. Pay in full each month.",
    timeline: "3-6 months",
  },
  {
    scoreRange: "630-649",
    title: "Growth Phase",
    cards: ["Capital One (Any Card)"],
    strategy: "Apply for Capital One. At 650, retire Credit One. Discover will increase limit and refund deposit.",
    timeline: "3-6 months",
  },
  {
    scoreRange: "650-699",
    title: "Expansion Phase",
    cards: ["PenFed", "Request Cap One CLI"],
    strategy: "Apply for PenFed (top choice). Request Capital One credit limit increase if 90+ days since approval.",
    timeline: "3-6 months",
  },
  {
    scoreRange: "700+",
    title: "Premium Phase",
    cards: ["Amex", "Chase", "Bank of America"],
    strategy: "Apply for all three major banks at once. Score will temporarily drop but recover once all report. You'll have every major card you need.",
    timeline: "Ongoing",
  },
];

// Dispute Process Steps
const disputeSteps = [
  {
    step: 1,
    title: "Get Your Reports",
    description: "Purchase reports from AnnualCreditReport.com for all three bureaus (Equifax, Experian, TransUnion).",
    icon: FileText,
  },
  {
    step: 2,
    title: "Identify Negatives",
    description: "Review all negative items: late payments, collections, charge-offs, inquiries, and errors.",
    icon: Target,
  },
  {
    step: 3,
    title: "Written Disputes",
    description: "Dispute ALL negative items in writing. Send via CERTIFIED MAIL with return receipt requested.",
    icon: Mail,
  },
  {
    step: 4,
    title: "Phone Follow-Up",
    description: "TWO DAYS after mailing, call in your disputes to each bureau. Document everything.",
    icon: Phone,
  },
  {
    step: 5,
    title: "Wait 30 Days",
    description: "Bureaus have 30 days to investigate. If they verify, proceed to legal action.",
    icon: Clock,
  },
  {
    step: 6,
    title: "Legal Action (1681i)",
    description: "If they verify without proper investigation, sue under FCRA 1681i for insufficient investigations.",
    icon: Scale,
  },
];

// Big Money Banks
const bigMoneyBanks = [
  { name: "BlueVine", type: "Business Banking", loanRange: "$250K+", requirements: "Good business credit, 2+ years in business" },
  { name: "Bank of America", type: "Business Loans", loanRange: "$250K+", requirements: "Strong credit, established business" },
  { name: "KeyBank", type: "Commercial Loans", loanRange: "$500K+", requirements: "Solid financials, collateral" },
  { name: "Truist", type: "Business Credit", loanRange: "$250K+", requirements: "Good credit stack, business history" },
  { name: "US Bank", type: "Business Financing", loanRange: "$500K+", requirements: "Strong credit profile, revenue" },
];

export default function CreditRepair() {
  const { isAuthenticated, loading } = useAuth();
  const [currentScore, setCurrentScore] = useState(580);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
            <CreditCard className="h-8 w-8 text-primary" />
          </div>
          <p className="text-muted-foreground">Loading credit tools...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        {/* Legal Disclaimer Banner */}
        <Alert className="mb-8 border-yellow-500/50 bg-yellow-500/10">
          <AlertTriangle className="h-4 w-4 text-yellow-500" />
          <AlertTitle className="text-yellow-500">Important Legal Disclaimer</AlertTitle>
          <AlertDescription className="text-muted-foreground">
            <strong>I am NOT a CPA, attorney, or licensed financial advisor.</strong> The information provided is for educational purposes only and should not be considered legal, tax, or financial advice. Always consult with qualified professionals before making financial decisions. Results may vary. Past performance does not guarantee future results. You are solely responsible for your financial decisions.
          </AlertDescription>
        </Alert>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            <span className="gradient-text">Credit Repair & Building</span>
          </h1>
          <p className="text-muted-foreground">
            Your complete roadmap from any credit score to 700+ and beyond.
          </p>
        </div>

        {/* Credit Score Visualization */}
        <Card className="luxury-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Credit Score Tiers
            </CardTitle>
            <CardDescription>Where you are and where you're going</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2 mb-4">
              {creditTiers.map((tier) => (
                <div key={tier.range} className="flex-1 text-center">
                  <div className={`h-3 ${tier.color} rounded-full mb-2`} />
                  <div className="text-xs font-medium">{tier.label}</div>
                  <div className="text-xs text-muted-foreground">{tier.range}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="stack" className="space-y-8">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="stack">Credit Stack</TabsTrigger>
            <TabsTrigger value="dispute">Dispute Process</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
            <TabsTrigger value="bigmoney">Big Money</TabsTrigger>
            <TabsTrigger value="legal">Legal Info</TabsTrigger>
          </TabsList>

          {/* Credit Stack Strategy */}
          <TabsContent value="stack" className="space-y-6">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle>The Credit Stack Strategy</CardTitle>
                <CardDescription>
                  Follow this proven path to build your credit from any starting point
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {creditStackSteps.map((step, index) => (
                  <div key={step.scoreRange} className="relative">
                    {index < creditStackSteps.length - 1 && (
                      <div className="absolute left-6 top-16 bottom-0 w-0.5 bg-border" />
                    )}
                    <div className="flex gap-4">
                      <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 z-10">
                        <span className="text-primary font-bold">{index + 1}</span>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline">{step.scoreRange}</Badge>
                          <h3 className="font-semibold">{step.title}</h3>
                          <Badge variant="secondary" className="ml-auto">
                            <Clock className="h-3 w-3 mr-1" />
                            {step.timeline}
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-2 mb-2">
                          {step.cards.map((card) => (
                            <Badge key={card} className="bg-primary/20 text-primary">
                              <CreditCard className="h-3 w-3 mr-1" />
                              {card}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-sm text-muted-foreground">{step.strategy}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Pro Tips */}
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-yellow-500" />
                  Pro Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Never exceed 30% credit utilization on any card</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Pay statement balance in full every month</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Wait 90 days between credit limit increase requests</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>Use secured card for one subscription only (like NAV Prime)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>At 650+, apply for Amex, Chase, and BOA all at once for maximum impact</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Dispute Process */}
          <TabsContent value="dispute" className="space-y-6">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle>The Dispute Process</CardTitle>
                <CardDescription>
                  Step-by-step guide to removing negative items from your credit report
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {disputeSteps.map((step) => {
                    const Icon = step.icon;
                    return (
                      <div key={step.step} className="flex gap-4">
                        <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                          <Icon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline">Step {step.step}</Badge>
                            <h3 className="font-semibold">{step.title}</h3>
                          </div>
                          <p className="text-sm text-muted-foreground">{step.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* FCRA 1681i Information */}
            <Card className="luxury-card border-primary/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  FCRA Section 1681i - Your Legal Rights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Under the Fair Credit Reporting Act (FCRA), credit bureaus must conduct a <strong>reasonable investigation</strong> of disputed items within 30 days. If they fail to do so, you may have grounds for legal action.
                </p>
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>When to Consider Legal Action</AlertTitle>
                  <AlertDescription>
                    If the bureau "verifies" a disputed item without conducting a proper investigation (just rubber-stamping the creditor's response), you may sue under 15 U.S.C. § 1681i for insufficient investigation. Consult with a consumer rights attorney.
                  </AlertDescription>
                </Alert>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-secondary/50">
                    <h4 className="font-medium mb-2">Potential Damages</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Actual damages suffered</li>
                      <li>• Statutory damages up to $1,000</li>
                      <li>• Attorney's fees and costs</li>
                      <li>• Punitive damages (willful violations)</li>
                    </ul>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/50">
                    <h4 className="font-medium mb-2">Evidence to Gather</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Certified mail receipts</li>
                      <li>• Phone call logs and notes</li>
                      <li>• Bureau response letters</li>
                      <li>• Credit report copies (before/after)</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Resources */}
          <TabsContent value="resources" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
              {creditResources.map((resource) => (
                <Card key={resource.name} className="luxury-card card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold mb-1">{resource.name}</h3>
                        <p className="text-sm text-muted-foreground">{resource.description}</p>
                      </div>
                      <Button variant="ghost" size="icon" asChild>
                        <a href={resource.url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Business Credit Resources */}
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  Business Credit Resources
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-secondary/50">
                    <h4 className="font-medium mb-2">NAV & NAV Prime</h4>
                    <p className="text-sm text-muted-foreground mb-3">Business credit monitoring and tradeline recommendations</p>
                    <Badge variant="outline">Recommended</Badge>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/50">
                    <h4 className="font-medium mb-2">BlueVine</h4>
                    <p className="text-sm text-muted-foreground mb-3">Business banking and lines of credit</p>
                    <Badge variant="outline">Top Choice</Badge>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/50">
                    <h4 className="font-medium mb-2">GlowBal Voice Direct</h4>
                    <p className="text-sm text-muted-foreground mb-3">Professional business phone lines</p>
                    <Badge variant="outline">Business Lines</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tradelines */}
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle>Top Tradelines (Through NAV)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg border border-primary/30 bg-primary/5">
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      Quill
                    </h4>
                    <p className="text-sm text-muted-foreground">Office supplies tradeline - reports to business credit bureaus</p>
                  </div>
                  <div className="p-4 rounded-lg border border-primary/30 bg-primary/5">
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      Uline
                    </h4>
                    <p className="text-sm text-muted-foreground">Shipping and packaging tradeline - builds business credit</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Big Money */}
          <TabsContent value="bigmoney" className="space-y-6">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  $250K+ Loan Sources
                </CardTitle>
                <CardDescription>
                  Once your credit stack is complete, these banks offer the big money
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {bigMoneyBanks.map((bank) => (
                    <div key={bank.name} className="flex items-center justify-between p-4 rounded-lg bg-secondary/50">
                      <div>
                        <h4 className="font-medium">{bank.name}</h4>
                        <p className="text-sm text-muted-foreground">{bank.type}</p>
                      </div>
                      <div className="text-right">
                        <Badge className="bg-green-500/20 text-green-500">{bank.loanRange}</Badge>
                        <p className="text-xs text-muted-foreground mt-1">{bank.requirements}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* PenFed Recommendation */}
            <Card className="luxury-card border-yellow-500/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-yellow-500/20 flex items-center justify-center">
                    <Star className="h-8 w-8 text-yellow-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Personal Top Choice: PenFed</h3>
                    <p className="text-muted-foreground">Best personal credit card and personal loan once you hit 650+ score</p>
                    <Badge variant="outline" className="mt-2">Credit Union Benefits</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Legal Information */}
          <TabsContent value="legal" className="space-y-6">
            <Alert className="border-red-500/50 bg-red-500/10">
              <AlertTriangle className="h-4 w-4 text-red-500" />
              <AlertTitle className="text-red-500">Legal & Liability Disclaimer</AlertTitle>
              <AlertDescription className="text-muted-foreground space-y-2">
                <p><strong>I am NOT a Certified Public Accountant (CPA), attorney, or licensed financial advisor.</strong></p>
                <p>The information, strategies, and recommendations provided in this application are for <strong>educational and informational purposes only</strong>. They do not constitute legal, tax, financial, or professional advice.</p>
                <p>You should consult with qualified professionals (attorneys, CPAs, financial advisors) before making any financial, legal, or business decisions.</p>
                <p><strong>Results are not guaranteed.</strong> Individual results may vary based on your specific situation, credit history, and other factors.</p>
                <p>By using this application, you acknowledge that you are solely responsible for your financial decisions and their outcomes.</p>
              </AlertDescription>
            </Alert>

            <Card className="luxury-card">
              <CardHeader>
                <CardTitle>Your Rights Under Federal Law</CardTitle>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="fcra">
                    <AccordionTrigger>Fair Credit Reporting Act (FCRA)</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-sm text-muted-foreground">
                        The FCRA promotes accuracy, fairness, and privacy of information in consumer credit reports. Key rights include: access to your credit file, right to dispute inaccurate information, and right to sue for violations.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="fdcpa">
                    <AccordionTrigger>Fair Debt Collection Practices Act (FDCPA)</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-sm text-muted-foreground">
                        The FDCPA prohibits debt collectors from using abusive, unfair, or deceptive practices. You have the right to request debt validation and stop harassment.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="ecoa">
                    <AccordionTrigger>Equal Credit Opportunity Act (ECOA)</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-sm text-muted-foreground">
                        The ECOA prohibits credit discrimination based on race, color, religion, national origin, sex, marital status, age, or receipt of public assistance.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>

            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-primary" />
                  Information Verification
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  The strategies and information in this application are based on current practices and regulations. However, financial regulations, credit card terms, and bank policies change frequently.
                </p>
                <Alert>
                  <Shield className="h-4 w-4" />
                  <AlertTitle>Always Verify</AlertTitle>
                  <AlertDescription>
                    Before taking any action, verify current terms, rates, and requirements directly with the financial institution. This information is provided as a starting point for your research.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Premium Content Notice */}
        <Card className="luxury-card mt-8 border-primary/30">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Lock className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Premium Content</h3>
                  <p className="text-sm text-muted-foreground">This is paid content. Strategies are verified and updated regularly.</p>
                </div>
              </div>
              <Button className="btn-shine">
                <Zap className="h-4 w-4 mr-2" />
                Upgrade for Full Access
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
