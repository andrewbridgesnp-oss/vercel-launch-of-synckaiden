import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  GitMerge, 
  Check, 
  AlertTriangle, 
  FilePlus, 
  FileDiff, 
  ArrowRight, 
  ArrowLeft,
  CheckCircle,
  X,
  Loader2
} from "lucide-react";
import { useApp } from "../store/AppContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { ScrollArea } from "../components/ui/scroll-area";
import { cn } from "../components/ui/utils";
import { toast } from "sonner";

const DiffViewer = ({ oldCode, newCode }: { oldCode: string, newCode: string }) => {
  // Simple mock diff visualization
  const lines = [
    { type: "equal", content: 'import React from "react";' },
    { type: "equal", content: `import { Button } from "./ui/button";` },
    { type: "remove", content: "- import { OldComponent } from \"./old\";" },
    { type: "add", content: "+ import { NewComponent } from \"./new\";" },
    { type: "equal", content: "" },
    { type: "equal", content: "export const App = () => {" },
    { type: "equal", content: "  return (" },
    { type: "remove", content: "-   <OldComponent />" },
    { type: "add", content: '+   <NewComponent variant="primary" />' },
    { type: "equal", content: "  );" },
    { type: "equal", content: "};" },
  ];

  return (
    <div className="font-mono text-xs bg-slate-950 rounded-md overflow-hidden border border-white/10">
      {lines.map((line, i) => (
        <div 
          key={i} 
          className={cn(
            "flex",
            line.type === "add" && "bg-emerald-500/10",
            line.type === "remove" && "bg-rose-500/10"
          )}
        >
          <div className="w-8 flex-shrink-0 text-slate-500 border-r border-white/5 text-right pr-2 select-none">
            {i + 1}
          </div>
          <div className="w-6 flex-shrink-0 text-center select-none opacity-50">
            {line.type === "add" ? "+" : line.type === "remove" ? "-" : " "}
          </div>
          <div className={cn(
            "flex-1 pl-2",
            line.type === "add" && "text-emerald-400",
            line.type === "remove" && "text-rose-400 opacity-60 line-through decoration-rose-400/50"
          )}>
            {line.content}
          </div>
        </div>
      ))}
    </div>
  );
};

export const MergePlanPage = () => {
  const { generateMergePlan, mergePlan, resolveConflict, executeMerge, isLoading } = useApp();
  const [step, setStep] = useState(1);

  useEffect(() => {
    if (!mergePlan) {
      generateMergePlan();
    }
  }, []);

  if (!mergePlan && isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-[50vh] space-y-4">
        <div className="relative w-16 h-16">
          <div className="absolute inset-0 border-4 border-white/10 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin"></div>
        </div>
        <p className="text-lg font-medium animate-pulse">Analyzing dependency graph...</p>
      </div>
    );
  }

  if (!mergePlan) return null;

  const steps = [
    { id: 1, title: "Additions", icon: FilePlus },
    { id: 2, title: "Upgrades", icon: FileDiff },
    { id: 3, title: "Conflicts", icon: AlertTriangle },
    { id: 4, title: "Review", icon: CheckCircle },
  ];

  const handleNext = () => setStep(prev => Math.min(prev + 1, 4));
  const handlePrev = () => setStep(prev => Math.max(prev - 1, 1));

  return (
    <div className="max-w-5xl mx-auto space-y-8 h-full flex flex-col">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold">Merge Plan Builder</h1>
          <p className="text-muted-foreground">Review how ingested artifacts will be mapped to your existing project structure.</p>
        </div>
        <Badge variant="outline" className="px-3 py-1 border-white/10 bg-white/5">
          Plan ID: {mergePlan.id}
        </Badge>
      </div>

      {/* Stepper */}
      <div className="relative">
        <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-white/10 -translate-y-1/2 z-0" />
        <div className="relative z-10 flex justify-between">
          {steps.map((s) => (
            <div 
              key={s.id} 
              className={cn(
                "flex flex-col items-center gap-2 transition-colors duration-300",
                step >= s.id ? "text-primary" : "text-muted-foreground"
              )}
            >
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300 bg-background",
                step >= s.id ? "border-primary text-primary shadow-[0_0_15px_rgba(59,130,246,0.3)]" : "border-white/10"
              )}>
                <s.icon className="h-5 w-5" />
              </div>
              <span className="text-sm font-medium">{s.title}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <Card className="flex-1 bg-card/30 border-white/10 overflow-hidden flex flex-col">
        <CardContent className="flex-1 p-0 overflow-hidden flex flex-col">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div 
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1 p-6"
              >
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <FilePlus className="h-5 w-5 text-emerald-400" />
                  New Additions (2)
                </h2>
                <div className="space-y-3">
                  {[
                    { file: "components/NewFeature.tsx", dest: "/src/components/features" },
                    { file: "styles/new-theme.css", dest: "/src/styles" }
                  ].map((item) => (
                    <div key={item.file} className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/5">
                      <div className="flex items-center gap-3 flex-1">
                        <div className="h-8 w-8 rounded bg-emerald-500/10 flex items-center justify-center">
                          <FilePlus className="h-4 w-4 text-emerald-400" />
                        </div>
                        <div className="flex flex-col">
                          <span className="font-mono text-sm">{item.file}</span>
                          <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                            <ArrowRight className="h-3 w-3" />
                            <span className="text-emerald-400/80">{item.dest}</span>
                          </div>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-emerald-400 border-emerald-500/20 bg-emerald-500/10">Mapped</Badge>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div 
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1 p-6"
              >
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <FileDiff className="h-5 w-5 text-blue-400" />
                  Upgrades (1)
                </h2>
                <div className="space-y-4">
                  <div className="border border-white/10 rounded-lg overflow-hidden">
                    <div className="bg-white/5 p-3 flex items-center justify-between border-b border-white/5">
                      <span className="font-mono text-sm font-medium">src/utils/helpers.ts</span>
                      <Badge variant="outline" className="text-blue-400 border-blue-500/20 bg-blue-500/10">Modified</Badge>
                    </div>
                    <div className="p-4 bg-black/20">
                      <DiffViewer oldCode="" newCode="" />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div 
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1 p-6"
              >
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-400" />
                  Conflicts ({mergePlan.conflicts.filter(c => c.status === "Open").length})
                </h2>
                
                {mergePlan.conflicts.map((conflict) => (
                  <div key={conflict.id} className="border border-amber-500/30 rounded-lg overflow-hidden mb-6">
                    <div className="bg-amber-500/10 p-3 flex items-center justify-between border-b border-amber-500/20">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-amber-400" />
                        <span className="font-mono text-sm font-medium text-amber-100">{conflict.path}</span>
                      </div>
                      <Badge variant="destructive">Conflict</Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 border-b border-white/5 text-xs">
                      <div className="p-2 border-r border-white/5 bg-white/5 text-center text-muted-foreground">Current (Destination)</div>
                      <div className="p-2 bg-emerald-500/10 text-center text-emerald-400">Incoming (Source)</div>
                    </div>

                    <div className="p-4 bg-black/20">
                      <DiffViewer oldCode="" newCode="" />
                    </div>

                    <div className="p-3 bg-white/5 border-t border-white/5 flex justify-end gap-3">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => resolveConflict(conflict.id, "KeepExisting")}
                        className={conflict.resolution === "KeepExisting" ? "bg-white/20" : ""}
                      >
                        Keep Existing
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => resolveConflict(conflict.id, "Overwrite")}
                        className={conflict.resolution === "Overwrite" ? "bg-white/20" : ""}
                      >
                        Overwrite
                      </Button>
                      <Button 
                        size="sm" 
                        className="bg-primary hover:bg-primary/90"
                        onClick={() => resolveConflict(conflict.id, "Merge")}
                      >
                        Smart Merge
                      </Button>
                    </div>
                  </div>
                ))}
              </motion.div>
            )}

            {step === 4 && (
              <motion.div 
                key="step4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1 p-6 flex flex-col items-center justify-center text-center space-y-6"
              >
                <div className="h-20 w-20 rounded-full bg-emerald-500/20 flex items-center justify-center border border-emerald-500/50 shadow-[0_0_30px_rgba(16,185,129,0.3)]">
                  <Check className="h-10 w-10 text-emerald-400" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-2">Ready to Execute</h2>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    All conflicts have been resolved. The merge plan is ready to be applied to the registry.
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-8 w-full max-w-2xl mt-8">
                  <div className="text-center p-4 rounded-lg bg-white/5 border border-white/5">
                    <div className="text-2xl font-bold">2</div>
                    <div className="text-sm text-muted-foreground">Additions</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-white/5 border border-white/5">
                    <div className="text-2xl font-bold">1</div>
                    <div className="text-sm text-muted-foreground">Upgrades</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-white/5 border border-white/5">
                    <div className="text-2xl font-bold text-emerald-400">Fixed</div>
                    <div className="text-sm text-muted-foreground">Conflicts</div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>

        <div className="p-6 border-t border-white/10 flex justify-between bg-black/20">
          <Button 
            variant="ghost" 
            onClick={handlePrev} 
            disabled={step === 1}
            className="text-muted-foreground"
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> Previous
          </Button>

          {step < 4 ? (
            <Button onClick={handleNext} className="bg-primary text-primary-foreground">
              Next Step <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          ) : (
            <Button onClick={executeMerge} disabled={isLoading} className="bg-emerald-600 hover:bg-emerald-500 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]">
              {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <GitMerge className="mr-2 h-4 w-4" />}
              Execute Merge
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
};
