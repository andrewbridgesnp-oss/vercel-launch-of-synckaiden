import React, { useState, useEffect } from 'react';
import { Copy, Eye, EyeOff, Trash2, Plus, AlertCircle, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface APIKey {
  id: string;
  name: string;
  service: string;
  keyPrefix: string; // First 4 and last 4 characters
  isActive: boolean;
  createdAt: string;
  lastUsed?: string;
  masked: boolean;
}

const APIKeysSettings: React.FC = () => {
  const [apiKeys, setApiKeys] = useState<APIKey[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [newKey, setNewKey] = useState({
    name: '',
    service: '',
    keyValue: '',
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const services = [
    'Twilio',
    'SendGrid',
    'Stripe',
    'OpenAI',
    'Google',
    'GitHub',
    'Slack',
    'HubSpot',
    'Zapier',
    'Airtable',
    'Notion',
    'Other',
  ];

  // Load API keys from localStorage (in production, this would be from backend)
  useEffect(() => {
    const stored = localStorage.getItem('userApiKeys');
    if (stored) {
      try {
        setApiKeys(JSON.parse(stored));
      } catch (e) {
        console.error('Failed to load API keys:', e);
      }
    }
  }, []);

  const maskKey = (key: string): string => {
    if (key.length <= 8) return '••••••••';
    return `${key.substring(0, 4)}••••••••${key.substring(key.length - 4)}`;
  };

  const toggleKeyVisibility = (id: string) => {
    const newVisible = new Set(visibleKeys);
    if (newVisible.has(id)) {
      newVisible.delete(id);
    } else {
      newVisible.add(id);
    }
    setVisibleKeys(newVisible);
  };

  const copyToClipboard = (key: string, id: string) => {
    navigator.clipboard.writeText(key);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleAddKey = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newKey.name || !newKey.service || !newKey.keyValue) {
      setMessage({ type: 'error', text: 'Please fill in all fields' });
      return;
    }

    setLoading(true);

    try {
      // Simulate API call to save key
      await new Promise((resolve) => setTimeout(resolve, 500));

      const apiKey: APIKey = {
        id: `key_${Math.random().toString(36).substr(2, 9)}`,
        name: newKey.name,
        service: newKey.service,
        keyPrefix: maskKey(newKey.keyValue),
        isActive: true,
        createdAt: new Date().toISOString(),
        masked: true,
      };

      const updated = [...apiKeys, apiKey];
      setApiKeys(updated);
      localStorage.setItem('userApiKeys', JSON.stringify(updated));

      setMessage({ type: 'success', text: 'API key added successfully' });
      setNewKey({ name: '', service: '', keyValue: '' });
      setShowAddForm(false);

      setTimeout(() => setMessage(null), 3000);
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to add API key' });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteKey = async (id: string) => {
    if (!confirm('Are you sure you want to delete this API key?')) return;

    try {
      const updated = apiKeys.filter((key) => key.id !== id);
      setApiKeys(updated);
      localStorage.setItem('userApiKeys', JSON.stringify(updated));
      setMessage({ type: 'success', text: 'API key deleted' });
      setTimeout(() => setMessage(null), 3000);
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to delete API key' });
    }
  };

  const handleToggleActive = (id: string) => {
    const updated = apiKeys.map((key) =>
      key.id === id ? { ...key, isActive: !key.isActive } : key
    );
    setApiKeys(updated);
    localStorage.setItem('userApiKeys', JSON.stringify(updated));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">API Keys</h2>
          <p className="text-slate-400 mt-1">Manage your API credentials securely</p>
        </div>
        <Button
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-cyan-500 hover:bg-cyan-600 text-white"
        >
          <Plus className="mr-2 h-5 w-5" />
          Add API Key
        </Button>
      </div>

      {/* Messages */}
      {message && (
        <div
          className={`rounded-lg p-4 flex items-center gap-3 ${
            message.type === 'success'
              ? 'bg-green-500/10 border border-green-500/20'
              : 'bg-red-500/10 border border-red-500/20'
          }`}
        >
          {message.type === 'success' ? (
            <Check className="h-5 w-5 text-green-400" />
          ) : (
            <AlertCircle className="h-5 w-5 text-red-400" />
          )}
          <span className={message.type === 'success' ? 'text-green-400' : 'text-red-400'}>
            {message.text}
          </span>
        </div>
      )}

      {/* Add Key Form */}
      {showAddForm && (
        <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-6 backdrop-blur">
          <h3 className="text-lg font-semibold text-white mb-4">Add New API Key</h3>
          <form onSubmit={handleAddKey} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-white mb-2">Key Name</label>
              <input
                type="text"
                value={newKey.name}
                onChange={(e) => setNewKey({ ...newKey, name: e.target.value })}
                placeholder="e.g., Production Twilio"
                className="w-full rounded-lg bg-slate-700 px-4 py-2 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-2">Service</label>
              <select
                value={newKey.service}
                onChange={(e) => setNewKey({ ...newKey, service: e.target.value })}
                className="w-full rounded-lg bg-slate-700 px-4 py-2 text-white border border-slate-600 focus:border-cyan-500 focus:outline-none"
              >
                <option value="">Select a service</option>
                {services.map((service) => (
                  <option key={service} value={service}>
                    {service}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-2">API Key</label>
              <input
                type="password"
                value={newKey.keyValue}
                onChange={(e) => setNewKey({ ...newKey, keyValue: e.target.value })}
                placeholder="Paste your API key here"
                className="w-full rounded-lg bg-slate-700 px-4 py-2 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
              />
              <p className="text-xs text-slate-400 mt-2">
                Your key is encrypted and stored securely. Never shared with anyone.
              </p>
            </div>

            <div className="flex gap-3">
              <Button
                type="submit"
                disabled={loading}
                className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-white disabled:opacity-50"
              >
                {loading ? 'Saving...' : 'Save API Key'}
              </Button>
              <Button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="flex-1 bg-slate-700 hover:bg-slate-600 text-white"
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* API Keys List */}
      <div className="space-y-3">
        {apiKeys.length === 0 ? (
          <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-8 text-center backdrop-blur">
            <p className="text-slate-400">No API keys added yet</p>
            <p className="text-sm text-slate-500 mt-2">
              Add your first API key to enable integrations
            </p>
          </div>
        ) : (
          apiKeys.map((key) => (
            <div
              key={key.id}
              className="rounded-lg bg-slate-800/50 border border-slate-700 p-4 backdrop-blur flex items-center justify-between"
            >
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <div>
                    <h4 className="font-medium text-white">{key.name}</h4>
                    <p className="text-sm text-slate-400">{key.service}</p>
                  </div>
                  <span
                    className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      key.isActive
                        ? 'bg-green-500/10 text-green-400'
                        : 'bg-slate-700 text-slate-400'
                    }`}
                  >
                    {key.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  Created {new Date(key.createdAt).toLocaleDateString()}
                  {key.lastUsed && ` • Last used ${new Date(key.lastUsed).toLocaleDateString()}`}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <div className="bg-slate-700/50 px-3 py-2 rounded-lg flex items-center gap-2">
                  <span className="text-sm text-slate-300 font-mono">{key.keyPrefix}</span>
                  <button
                    onClick={() => toggleKeyVisibility(key.id)}
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {visibleKeys.has(key.id) ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>

                <button
                  onClick={() => copyToClipboard(key.keyPrefix, key.id)}
                  className="p-2 hover:bg-slate-700 rounded-lg transition-colors text-slate-400 hover:text-white"
                >
                  {copiedId === key.id ? (
                    <Check className="h-4 w-4 text-green-400" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </button>

                <button
                  onClick={() => handleToggleActive(key.id)}
                  className="px-3 py-2 rounded-lg text-sm font-medium transition-colors bg-slate-700 hover:bg-slate-600 text-white"
                >
                  {key.isActive ? 'Disable' : 'Enable'}
                </button>

                <button
                  onClick={() => handleDeleteKey(key.id)}
                  className="p-2 hover:bg-red-500/10 rounded-lg transition-colors text-slate-400 hover:text-red-400"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Info Box */}
      <div className="rounded-lg bg-blue-500/10 border border-blue-500/20 p-4">
        <h4 className="font-medium text-blue-400 mb-2">Security Best Practices</h4>
        <ul className="text-sm text-blue-300 space-y-1">
          <li>• Never share your API keys with anyone</li>
          <li>• Rotate your keys regularly for security</li>
          <li>• Use separate keys for development and production</li>
          <li>• Disable keys you no longer use</li>
          <li>• All keys are encrypted before storage</li>
        </ul>
      </div>
    </div>
  );
};

export default APIKeysSettings;
