import { router, publicProcedure, protectedProcedure } from '@/server/_core/trpc';
import { z } from 'zod';
import type { Capability, CapabilityRegistry, CapabilityState } from '@/shared/types';
import { capabilityRegistry } from '@/server/data/capabilities';

/**
 * Capability Router
 * Handles all capability-related API endpoints
 */

export const capabilityRouter = router({
  /**
   * Get the complete capability registry
   */
  getRegistry: publicProcedure.query(async (): Promise<CapabilityRegistry> => {
    return capabilityRegistry;
  }),

  /**
   * Get a single capability by ID
   */
  getById: publicProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      const capability = capabilityRegistry.capabilities.find((c) => c.id === input.id);
      if (!capability) {
        throw new Error(`Capability ${input.id} not found`);
      }
      return capability;
    }),

  /**
   * Get all capabilities for a specific module
   */
  getByModule: publicProcedure
    .input(z.object({ module: z.string() }))
    .query(async ({ input }) => {
      return capabilityRegistry.capabilities.filter((c) => c.module === input.module);
    }),

  /**
   * Search capabilities
   */
  search: publicProcedure
    .input(
      z.object({
        query: z.string(),
        status: z.enum(['LIVE', 'BETA', 'COMING_SOON']).optional(),
        priority: z.enum(['HIGH', 'MEDIUM', 'LOW']).optional(),
        limit: z.number().default(50),
      })
    )
    .query(async ({ input }) => {
      let results = capabilityRegistry.capabilities;

      // Filter by search query
      if (input.query) {
        const q = input.query.toLowerCase();
        results = results.filter(
          (c) =>
            c.name.toLowerCase().includes(q) ||
            c.description.toLowerCase().includes(q) ||
            c.module.toLowerCase().includes(q)
        );
      }

      // Filter by status
      if (input.status) {
        results = results.filter((c) => c.status === input.status);
      }

      // Filter by priority
      if (input.priority) {
        results = results.filter((c) => c.priority === input.priority);
      }

      return results.slice(0, input.limit);
    }),

  /**
   * Get capability statistics
   */
  getStats: publicProcedure.query(async () => {
    const capabilities = capabilityRegistry.capabilities;

    return {
      total: capabilities.length,
      byStatus: {
        LIVE: capabilities.filter((c) => c.status === 'LIVE').length,
        BETA: capabilities.filter((c) => c.status === 'BETA').length,
        COMING_SOON: capabilities.filter((c) => c.status === 'COMING_SOON').length,
      },
      byPriority: {
        HIGH: capabilities.filter((c) => c.priority === 'HIGH').length,
        MEDIUM: capabilities.filter((c) => c.priority === 'MEDIUM').length,
        LOW: capabilities.filter((c) => c.priority === 'LOW').length,
      },
      byComplexity: {
        SIMPLE: capabilities.filter((c) => c.complexity === 'SIMPLE').length,
        MEDIUM: capabilities.filter((c) => c.complexity === 'MEDIUM').length,
        COMPLEX: capabilities.filter((c) => c.complexity === 'COMPLEX').length,
      },
      modules: [...new Set(capabilities.map((c) => c.module))].length,
    };
  }),

  /**
   * Execute a capability (protected - requires authentication)
   */
  execute: protectedProcedure
    .input(
      z.object({
        capabilityId: z.string(),
        params: z.record(z.unknown()).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const capability = capabilityRegistry.capabilities.find((c) => c.id === input.capabilityId);

      if (!capability) {
        throw new Error(`Capability ${input.capabilityId} not found`);
      }

      // Check user permissions
      if (capability.requiredPermissions && capability.requiredPermissions.length > 0) {
        const hasPermission = capability.requiredPermissions.some((perm) =>
          ctx.user?.permissions?.includes(perm)
        );

        if (!hasPermission) {
          throw new Error('Insufficient permissions to execute this capability');
        }
      }

      // Execute capability based on type
      // This is a placeholder - actual implementation depends on capability type
      const result = {
        capabilityId: input.capabilityId,
        executedAt: new Date(),
        params: input.params,
        status: 'success',
        data: {
          message: `Capability ${capability.name} executed successfully`,
        },
      };

      return result;
    }),

  /**
   * Get user's capability preferences
   */
  getUserPreferences: protectedProcedure.query(async ({ ctx }) => {
    // TODO: Fetch from database
    return {
      userId: ctx.user?.id,
      favoriteCapabilities: [],
      recentlyUsed: [],
      preferences: {},
    };
  }),

  /**
   * Update capability preferences
   */
  updatePreferences: protectedProcedure
    .input(
      z.object({
        favoriteCapabilities: z.array(z.string()).optional(),
        preferences: z.record(z.unknown()).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // TODO: Save to database
      return {
        success: true,
        userId: ctx.user?.id,
        updated: input,
      };
    }),

  /**
   * Get capability usage analytics
   */
  getAnalytics: protectedProcedure
    .input(
      z.object({
        capabilityId: z.string().optional(),
        period: z.enum(['day', 'week', 'month']).default('week'),
      })
    )
    .query(async ({ input, ctx }) => {
      // TODO: Fetch from analytics database
      return {
        period: input.period,
        capabilityId: input.capabilityId,
        executions: 0,
        averageExecutionTime: 0,
        errorRate: 0,
        trends: [],
      };
    }),

  /**
   * Get capabilities by user subscription tier
   */
  getBySubscriptionTier: publicProcedure
    .input(
      z.object({
        tier: z.enum(['free', 'basic', 'pro', 'enterprise']),
      })
    )
    .query(async ({ input }) => {
      // Map subscription tiers to capability access
      const tierCapabilities: Record<string, string[]> = {
        free: ['LIVE'], // Only live capabilities
        basic: ['LIVE', 'BETA'], // Live and beta
        pro: ['LIVE', 'BETA'], // All capabilities
        enterprise: ['LIVE', 'BETA', 'COMING_SOON'], // All capabilities including coming soon
      };

      const allowedStatuses = tierCapabilities[input.tier];
      return capabilityRegistry.capabilities.filter((c) => allowedStatuses.includes(c.status));
    }),

  /**
   * Get capability dependencies
   */
  getDependencies: publicProcedure
    .input(z.object({ capabilityId: z.string() }))
    .query(async ({ input }) => {
      const capability = capabilityRegistry.capabilities.find((c) => c.id === input.capabilityId);

      if (!capability) {
        throw new Error(`Capability ${input.capabilityId} not found`);
      }

      if (!capability.dependencies || capability.dependencies.length === 0) {
        return [];
      }

      return capabilityRegistry.capabilities.filter((c) =>
        capability.dependencies?.includes(c.id)
      );
    }),

  /**
   * Get related capabilities
   */
  getRelated: publicProcedure
    .input(z.object({ capabilityId: z.string(), limit: z.number().default(5) }))
    .query(async ({ input }) => {
      const capability = capabilityRegistry.capabilities.find((c) => c.id === input.capabilityId);

      if (!capability) {
        throw new Error(`Capability ${input.capabilityId} not found`);
      }

      // Find related capabilities in the same module or subsection
      const related = capabilityRegistry.capabilities
        .filter(
          (c) =>
            c.id !== input.capabilityId &&
            (c.module === capability.module || c.subsection === capability.subsection)
        )
        .slice(0, input.limit);

      return related;
    }),
});

export type CapabilityRouter = typeof capabilityRouter;
