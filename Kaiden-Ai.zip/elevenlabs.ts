/**
 * ElevenLabs Text-to-Speech Integration
 * Provides voice synthesis capabilities using ElevenLabs API
 */

import { ENV } from './env';

export interface TTSOptions {
  text: string;
  voiceId?: string;
  modelId?: string;
  stability?: number;
  similarityBoost?: number;
}

export interface TTSResponse {
  audioUrl: string;
  duration: number;
  voiceId: string;
  modelId: string;
}

export interface Voice {
  voiceId: string;
  name: string;
  category: string;
  description: string;
  previewUrl: string;
}

class ElevenLabsService {
  private apiKey: string;
  private baseUrl = 'https://api.elevenlabs.io/v1';
  private defaultVoiceId = '21m00Tcm4TlvDq8ikWAM'; // Rachel voice
  private defaultModelId = 'eleven_monolingual_v1';

  constructor() {
    this.apiKey = process.env.ELEVENLABS_API_KEY || '';
  }

  /**
   * Check if ElevenLabs is configured
   */
  isConfigured(): boolean {
    return !!this.apiKey;
  }

  /**
   * Convert text to speech and return audio URL
   */
  async synthesize(options: TTSOptions): Promise<TTSResponse> {
    if (!this.isConfigured()) {
      throw new Error('ElevenLabs API key not configured');
    }

    const {
      text,
      voiceId = this.defaultVoiceId,
      modelId = this.defaultModelId,
      stability = 0.5,
      similarityBoost = 0.75,
    } = options;

    if (!text || text.trim().length === 0) {
      throw new Error('Text cannot be empty');
    }

    if (text.length > 5000) {
      throw new Error('Text exceeds maximum length of 5000 characters');
    }

    try {
      const response = await fetch(
        `${this.baseUrl}/text-to-speech/${voiceId}`,
        {
          method: 'POST',
          headers: {
            'xi-api-key': this.apiKey,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            text,
            model_id: modelId,
            voice_settings: {
              stability,
              similarity_boost: similarityBoost,
            },
          }),
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(`ElevenLabs API error: ${error.detail || response.statusText}`);
      }

      const audioBuffer = await response.arrayBuffer();
      const audioBlob = new Blob([audioBuffer], { type: 'audio/mpeg' });
      const audioUrl = URL.createObjectURL(audioBlob);

      // Estimate duration (rough calculation: 150 words per minute)
      const wordCount = text.split(/\s+/).length;
      const duration = (wordCount / 150) * 60;

      return {
        audioUrl,
        duration,
        voiceId,
        modelId,
      };
    } catch (error) {
      console.error('ElevenLabs synthesis error:', error);
      throw error;
    }
  }

  /**
   * Get available voices
   */
  async getVoices(): Promise<Voice[]> {
    if (!this.isConfigured()) {
      return this.getDefaultVoices();
    }

    try {
      const response = await fetch(`${this.baseUrl}/voices`, {
        headers: {
          'xi-api-key': this.apiKey,
        },
      });

      if (!response.ok) {
        console.warn('Failed to fetch voices from ElevenLabs, using defaults');
        return this.getDefaultVoices();
      }

      const data = await response.json();
      return data.voices || this.getDefaultVoices();
    } catch (error) {
      console.warn('Error fetching voices:', error);
      return this.getDefaultVoices();
    }
  }

  /**
   * Get default voices for fallback
   */
  private getDefaultVoices(): Voice[] {
    return [
      {
        voiceId: '21m00Tcm4TlvDq8ikWAM',
        name: 'Rachel',
        category: 'female',
        description: 'Young female voice, clear and pleasant',
        previewUrl: '',
      },
      {
        voiceId: 'AZnzlk1XvdvUBZXUNXHP',
        name: 'Domi',
        category: 'female',
        description: 'Warm female voice, professional',
        previewUrl: '',
      },
      {
        voiceId: 'EXAVITQu4vr4xnSDxMaL',
        name: 'Bella',
        category: 'female',
        description: 'Expressive female voice',
        previewUrl: '',
      },
      {
        voiceId: 'pNInz6obpgDQGcFmaJgB',
        name: 'Antoni',
        category: 'male',
        description: 'Deep male voice, professional',
        previewUrl: '',
      },
      {
        voiceId: 'nPczCjzI2devNBz1zQrb',
        name: 'Elli',
        category: 'female',
        description: 'Young female voice, energetic',
        previewUrl: '',
      },
    ];
  }

  /**
   * Check API quota and usage
   */
  async getUsage() {
    if (!this.isConfigured()) {
      return null;
    }

    try {
      const response = await fetch(`${this.baseUrl}/user/subscription`, {
        headers: {
          'xi-api-key': this.apiKey,
        },
      });

      if (!response.ok) {
        return null;
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching usage:', error);
      return null;
    }
  }
}

// Export singleton instance
export const elevenlabs = new ElevenLabsService();

// Export service class for testing
export { ElevenLabsService };
