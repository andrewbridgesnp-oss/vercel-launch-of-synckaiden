import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { Redirect } from "wouter";
import {
  Building2,
  FileText,
  Users,
  Phone,
  Mail,
  Globe,
  MapPin,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  BookOpen,
  Shield,
  Briefcase,
  Scale,
  Clock,
  DollarSign,
  ExternalLink,
} from "lucide-react";

// LLC Formation Checklist
const llcChecklist = [
  {
    id: "articles",
    title: "Articles of Incorporation/Organization",
    description: "File with your state's Secretary of State. This is the legal document that creates your LLC.",
    required: true,
    cost: "$50-$500 (varies by state)",
  },
  {
    id: "ein",
    title: "EIN (Employer Identification Number)",
    description: "Apply for free through IRS.gov. Required for business banking and taxes.",
    required: true,
    cost: "Free",
  },
  {
    id: "operating",
    title: "Operating Agreement",
    description: "Internal document outlining ownership, management, and profit distribution.",
    required: true,
    cost: "$0-$200 (DIY or attorney)",
  },
  {
    id: "recordbook",
    title: "Corporate Record Book with Resolutions",
    description: "Official binder containing all corporate documents, meeting minutes, and resolutions.",
    required: true,
    cost: "$50-$150",
  },
  {
    id: "agent",
    title: "Registered Agent",
    description: "Person or service that receives legal documents on behalf of your LLC.",
    required: true,
    cost: "$50-$300/year",
  },
  {
    id: "website",
    title: "Business Website",
    description: "Professional online presence. Domain + hosting + design.",
    required: true,
    cost: "$100-$500/year",
  },
  {
    id: "phone",
    title: "Business Phone Line",
    description: "Dedicated business number. GlowBal Voice Direct recommended.",
    required: true,
    cost: "$20-$50/month",
  },
  {
    id: "email",
    title: "Business Email",
    description: "Professional email with your domain (you@yourbusiness.com).",
    required: true,
    cost: "$5-$12/month",
  },
  {
    id: "mailbox",
    title: "Business Mailbox/Address",
    description: "Virtual mailbox or physical address for business correspondence.",
    required: true,
    cost: "$10-$50/month",
  },
  {
    id: "bank",
    title: "Business Bank Account",
    description: "Separate business checking account. BlueVine recommended.",
    required: true,
    cost: "Usually free",
  },
];

// Corporate Record Book Contents
const recordBookContents = [
  "Articles of Incorporation/Organization",
  "Operating Agreement",
  "EIN Confirmation Letter",
  "Initial Resolutions",
  "Meeting Minutes Template",
  "Member/Manager Certificates",
  "Membership Ledger",
  "Annual Meeting Minutes",
  "Banking Resolutions",
  "Amendment Records",
];

// Business Resolutions Needed
const resolutionsNeeded = [
  {
    title: "Initial Resolution",
    description: "Authorizes formation, appoints managers, adopts operating agreement",
    when: "At formation",
  },
  {
    title: "Banking Resolution",
    description: "Authorizes opening bank accounts and designates signers",
    when: "Before opening accounts",
  },
  {
    title: "Credit Application Resolution",
    description: "Authorizes applying for business credit",
    when: "Before credit applications",
  },
  {
    title: "Loan Authorization Resolution",
    description: "Authorizes borrowing money on behalf of the LLC",
    when: "Before taking loans",
  },
  {
    title: "Annual Meeting Resolution",
    description: "Documents annual meeting and any decisions made",
    when: "Annually",
  },
];

// Recommended Services
const recommendedServices = [
  {
    category: "Business Phone",
    name: "GlowBal Voice Direct",
    description: "Professional business phone lines with virtual receptionist",
    badge: "Recommended",
  },
  {
    category: "Business Banking",
    name: "BlueVine",
    description: "Free business checking with high yield and credit lines",
    badge: "Top Choice",
  },
  {
    category: "Business Credit",
    name: "NAV / NAV Prime",
    description: "Business credit monitoring and tradeline recommendations",
    badge: "Essential",
  },
  {
    category: "Tradelines",
    name: "Quill & Uline (via NAV)",
    description: "Office supplies and shipping tradelines that report to bureaus",
    badge: "Top Tradelines",
  },
];

export default function BusinessFormation() {
  const { isAuthenticated, loading } = useAuth();
  const [checkedItems, setCheckedItems] = useState<string[]>([]);

  const toggleItem = (id: string) => {
    setCheckedItems((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const progress = (checkedItems.length / llcChecklist.length) * 100;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
            <Building2 className="h-8 w-8 text-primary" />
          </div>
          <p className="text-muted-foreground">Loading business tools...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        {/* Legal Disclaimer */}
        <Alert className="mb-8 border-yellow-500/50 bg-yellow-500/10">
          <AlertTriangle className="h-4 w-4 text-yellow-500" />
          <AlertTitle className="text-yellow-500">Important Legal Disclaimer</AlertTitle>
          <AlertDescription className="text-muted-foreground">
            <strong>I am NOT an attorney or licensed business advisor.</strong> This information is for educational purposes only. Consult with a qualified attorney and CPA for your specific situation. State requirements vary significantly.
          </AlertDescription>
        </Alert>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            <span className="gradient-text">Business Formation</span>
          </h1>
          <p className="text-muted-foreground">
            Everything you need to properly structure and establish your LLC.
          </p>
        </div>

        {/* Progress Card */}
        <Card className="luxury-card mb-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold">Formation Progress</h3>
                <p className="text-sm text-muted-foreground">
                  {checkedItems.length} of {llcChecklist.length} items completed
                </p>
              </div>
              <Badge variant={progress === 100 ? "default" : "outline"} className={progress === 100 ? "bg-green-500" : ""}>
                {Math.round(progress)}% Complete
              </Badge>
            </div>
            <div className="w-full h-3 bg-secondary rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-cyan-400 transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="checklist" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="checklist">Formation Checklist</TabsTrigger>
            <TabsTrigger value="recordbook">Corporate Records</TabsTrigger>
            <TabsTrigger value="resolutions">Resolutions</TabsTrigger>
            <TabsTrigger value="services">Recommended Services</TabsTrigger>
          </TabsList>

          {/* Formation Checklist */}
          <TabsContent value="checklist" className="space-y-4">
            {llcChecklist.map((item) => (
              <Card key={item.id} className={`luxury-card transition-all ${checkedItems.includes(item.id) ? "border-green-500/50 bg-green-500/5" : ""}`}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <Checkbox
                      id={item.id}
                      checked={checkedItems.includes(item.id)}
                      onCheckedChange={() => toggleItem(item.id)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <label htmlFor={item.id} className="font-medium cursor-pointer">
                          {item.title}
                        </label>
                        {item.required && (
                          <Badge variant="destructive" className="text-xs">Required</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{item.description}</p>
                      <Badge variant="outline" className="text-xs">
                        <DollarSign className="h-3 w-3 mr-1" />
                        {item.cost}
                      </Badge>
                    </div>
                    {checkedItems.includes(item.id) && (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* Corporate Record Book */}
          <TabsContent value="recordbook" className="space-y-6">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  Corporate Record Book
                </CardTitle>
                <CardDescription>
                  Your official binder containing all corporate documents
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {recordBookContents.map((item, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-sm font-medium text-primary">
                        {index + 1}
                      </div>
                      <span className="text-sm">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Alert>
              <Shield className="h-4 w-4" />
              <AlertTitle>Why This Matters</AlertTitle>
              <AlertDescription>
                A properly maintained corporate record book helps protect your personal assets by demonstrating that your LLC is a legitimate, separate entity. This is crucial for maintaining the "corporate veil."
              </AlertDescription>
            </Alert>
          </TabsContent>

          {/* Resolutions */}
          <TabsContent value="resolutions" className="space-y-6">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-primary" />
                  Essential Resolutions
                </CardTitle>
                <CardDescription>
                  Formal decisions documented by the LLC members/managers
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {resolutionsNeeded.map((resolution, index) => (
                  <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-secondary/50">
                    <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium mb-1">{resolution.title}</h4>
                      <p className="text-sm text-muted-foreground mb-2">{resolution.description}</p>
                      <Badge variant="outline" className="text-xs">
                        <Clock className="h-3 w-3 mr-1" />
                        {resolution.when}
                      </Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Recommended Services */}
          <TabsContent value="services" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
              {recommendedServices.map((service, index) => (
                <Card key={index} className="luxury-card card-hover">
                  <CardContent className="p-6">
                    <Badge variant="outline" className="mb-3">{service.category}</Badge>
                    <h3 className="font-semibold text-lg mb-2">{service.name}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{service.description}</p>
                    <Badge className="bg-primary/20 text-primary">{service.badge}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Business Essentials Summary */}
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle>Business Essentials Checklist</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="flex items-center gap-3 p-4 rounded-lg bg-secondary/50">
                    <Globe className="h-5 w-5 text-primary" />
                    <span>Business Website</span>
                  </div>
                  <div className="flex items-center gap-3 p-4 rounded-lg bg-secondary/50">
                    <Phone className="h-5 w-5 text-primary" />
                    <span>Business Phone</span>
                  </div>
                  <div className="flex items-center gap-3 p-4 rounded-lg bg-secondary/50">
                    <Mail className="h-5 w-5 text-primary" />
                    <span>Business Email</span>
                  </div>
                  <div className="flex items-center gap-3 p-4 rounded-lg bg-secondary/50">
                    <MapPin className="h-5 w-5 text-primary" />
                    <span>Business Address</span>
                  </div>
                  <div className="flex items-center gap-3 p-4 rounded-lg bg-secondary/50">
                    <Users className="h-5 w-5 text-primary" />
                    <span>Registered Agent</span>
                  </div>
                  <div className="flex items-center gap-3 p-4 rounded-lg bg-secondary/50">
                    <Briefcase className="h-5 w-5 text-primary" />
                    <span>Business Banking</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
