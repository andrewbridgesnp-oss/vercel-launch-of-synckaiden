/**
 * App Loader - Loads isolated apps with shared auth and Stripe
 * Each app runs in its own context with access to Kaiden infrastructure
 */

import { useEffect, useState, Suspense, lazy, ComponentType } from 'react';
import { useParams, useLocation } from 'wouter';
import { KAIDEN_APPS, getAppById } from '@/lib/appRegistryConfig';
import { appRegistry, AppLicense } from '@/lib/appRegistry';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Lock, ArrowLeft, ShoppingCart, Star, Shield, Zap } from 'lucide-react';

// App component map - lazy loaded for performance
// Note: Apps are excluded from main tsconfig and loaded dynamically
// Each app has its own isolated environment
const APP_COMPONENTS: Record<string, () => Promise<{ default: ComponentType<any> }>> = {};

// Dynamic app loader that bypasses TypeScript checking for isolated apps
async function loadAppComponent(appId: string): Promise<ComponentType<any> | null> {
  const appPaths: Record<string, string> = {
    'agentic-ai-business-swarm': 'agenticaibusinessswarm/App',
    'audio-mastering-application': 'audiomasteringapplication/app/App',
    'avery-ai-receptionist-design': 'averyaireceptionistdesign/app/App',
    'buildwealth-pro': 'buildwealthproappprototype/app/App',
    'financial-co-pilot': 'financialco-pilotapp/app/App',
    'healthsync-scribe': 'healthsyncscribedesign/app/App',
    'househack-203k': 'kaidenhousehack203kapp/app/App',
    'pantryiq': 'pantryinventorymanagement/app/App',
    'realitysync-app': 'realitysyncappdesign/app/App',
    'spamslayer-sync': 'spamslayersyncfigmabuild/app/App',
    'syndica-ingestor': 'syndicaingestor-and-composer/app/App',
    'tax-preparer-pro': 'taxpreparer/app/App',
    'kaiden-tax': 'kaidenta/app/App',
  };

  const path = appPaths[appId];
  if (!path) return null;

  try {
    // Dynamic import with glob pattern to load isolated app
    const modules = import.meta.glob('../apps/**/App.tsx');
    const modulePath = `../apps/${path}.tsx`;
    
    if (modules[modulePath]) {
      const module = await modules[modulePath]() as { default: ComponentType<any> };
      return module.default;
    }
    return null;
  } catch (error) {
    console.error(`Failed to load app ${appId}:`, error);
    return null;
  }
}

// Loading component with Kaiden branding
function AppLoadingState({ appName }: { appName: string }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
      <div className="text-center space-y-6">
        <div className="relative">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 backdrop-blur-xl border border-cyan-500/30 flex items-center justify-center mx-auto">
            <Loader2 className="w-10 h-10 text-cyan-400 animate-spin" />
          </div>
          <div className="absolute inset-0 w-20 h-20 mx-auto rounded-2xl bg-cyan-500/20 blur-xl animate-pulse" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Loading {appName}</h2>
          <p className="text-slate-400">Initializing app environment...</p>
        </div>
      </div>
    </div>
  );
}

// License required component
function LicenseRequired({ 
  app, 
  onPurchase 
}: { 
  app: ReturnType<typeof getAppById>;
  onPurchase: () => void;
}) {
  const [, navigate] = useLocation();
  
  if (!app) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/app-store')}
          className="mb-8 text-slate-400 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to App Store
        </Button>

        <Card className="bg-slate-900/50 border-slate-800 backdrop-blur-xl overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-blue-500/5" />
          
          <CardHeader className="relative">
            <div className="flex items-start gap-6">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 flex items-center justify-center text-4xl">
                {app.icon}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <CardTitle className="text-2xl text-white">{app.name}</CardTitle>
                  <Badge variant="secondary" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                    {app.category}
                  </Badge>
                </div>
                <CardDescription className="text-slate-400 text-lg">
                  {app.description}
                </CardDescription>
              </div>
            </div>
          </CardHeader>

          <CardContent className="relative space-y-8">
            {/* Features */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Features</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {app.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-3 text-slate-300">
                    <Zap className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Pricing Tiers */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-4">Choose Your Plan</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Free Tier */}
                <Card className="bg-slate-800/50 border-slate-700 hover:border-cyan-500/50 transition-colors cursor-pointer" onClick={onPurchase}>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg text-white">Free</CardTitle>
                    <div className="text-3xl font-bold text-white">$0<span className="text-sm font-normal text-slate-400">/mo</span></div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm text-slate-400">
                      {app.pricing.free.features.map((f, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <Star className="w-3 h-3 text-cyan-400" />
                          {f}
                        </li>
                      ))}
                    </ul>
                    <Button className="w-full mt-4 bg-slate-700 hover:bg-slate-600 font-['SF_Pro_Rounded',_-apple-system,_system-ui]">
                      Start Free
                    </Button>
                  </CardContent>
                </Card>

                {/* Paid Tiers */}
                {app.pricing.tiers.map((tier, i) => (
                  <Card 
                    key={i} 
                    className={`border transition-colors cursor-pointer ${
                      i === 0 
                        ? 'bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border-cyan-500/50 hover:border-cyan-400' 
                        : 'bg-slate-800/50 border-slate-700 hover:border-cyan-500/50'
                    }`}
                    onClick={onPurchase}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg text-white">{tier.name}</CardTitle>
                        {i === 0 && (
                          <Badge className="bg-cyan-500 text-white">Popular</Badge>
                        )}
                      </div>
                      <div className="text-3xl font-bold text-white">
                        ${tier.price}<span className="text-sm font-normal text-slate-400">/mo</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-sm text-slate-400">
                        {tier.features.map((f, j) => (
                          <li key={j} className="flex items-center gap-2">
                            <Star className="w-3 h-3 text-cyan-400" />
                            {f}
                          </li>
                        ))}
                      </ul>
                      <Button className={`w-full mt-4 ${
                        i === 0 
                          ? 'bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400' 
                          : 'bg-slate-700 hover:bg-slate-600'
                      }`}>
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        Subscribe
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Security Note */}
            <div className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-lg border border-slate-700">
              <Shield className="w-6 h-6 text-green-400 flex-shrink-0" />
              <div>
                <p className="text-sm text-white font-medium">Enterprise-Grade Security</p>
                <p className="text-xs text-slate-400">
                  AES-256 encryption, GDPR/CCPA compliant, no tracking, no data sharing
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// Login required component
function LoginRequired() {
  const [, navigate] = useLocation();
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center px-4">
      <Card className="max-w-md w-full bg-slate-900/50 border-slate-800 backdrop-blur-xl">
        <CardHeader className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 flex items-center justify-center mx-auto mb-4">
            <Lock className="w-8 h-8 text-cyan-400" />
          </div>
          <CardTitle className="text-2xl text-white">Sign In Required</CardTitle>
          <CardDescription className="text-slate-400">
            Please sign in to access Kaiden apps
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button 
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400"
            onClick={() => navigate('/login')}
          >
            Sign In
          </Button>
          <Button 
            variant="outline" 
            className="w-full border-slate-700 text-slate-300 hover:bg-slate-800"
            onClick={() => navigate('/app-store')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to App Store
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// App not found component
function AppNotFound() {
  const [, navigate] = useLocation();
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center px-4">
      <Card className="max-w-md w-full bg-slate-900/50 border-slate-800 backdrop-blur-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-white">App Not Found</CardTitle>
          <CardDescription className="text-slate-400">
            The requested app does not exist or has been removed
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button 
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400"
            onClick={() => navigate('/app-store')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Browse App Store
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// Main App Loader component
export default function AppLoader() {
  const params = useParams<{ appId: string }>();
  const appId = params.appId || '';
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [license, setLicense] = useState<AppLicense | null>(null);
  const [isCheckingLicense, setIsCheckingLicense] = useState(true);
  const [AppComponent, setAppComponent] = useState<ComponentType<any> | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Get app metadata
  const app = getAppById(appId);

  // Check license status
  useEffect(() => {
    if (!app || authLoading) return;

    const checkLicense = async () => {
      setIsCheckingLicense(true);
      
      try {
        if (isAuthenticated && user) {
          // Check if user has license for this app
          const userLicense = appRegistry.getAppLicense(user.id, appId);
          
          if (userLicense && (userLicense.status === 'active' || userLicense.status === 'trial')) {
            setLicense(userLicense);
          } else {
            // Auto-install free tier for authenticated users
            const newLicense = appRegistry.installApp(appId, user.id, 'free');
            setLicense(newLicense);
          }
        }
      } catch (error) {
        console.error('License check failed:', error);
      } finally {
        setIsCheckingLicense(false);
      }
    };

    checkLicense();
  }, [appId, app, isAuthenticated, user, authLoading]);

  // Load app component when license is valid
  useEffect(() => {
    if (!license || !app) return;

    const loadApp = async () => {
      try {
        const component = await loadAppComponent(appId);
        
        if (!component) {
          setLoadError(`App component not found for ${appId}`);
          return;
        }

        setAppComponent(() => component);
      } catch (error) {
        console.error('Failed to load app:', error);
        setLoadError(`Failed to load ${app.name}`);
      }
    };

    loadApp();
  }, [license, app, appId]);

  // Handle purchase/subscription
  const handlePurchase = () => {
    // For now, auto-install free tier
    if (isAuthenticated && user && app) {
      const newLicense = appRegistry.installApp(appId, user.id, 'free');
      setLicense(newLicense);
    }
  };

  // Loading state
  if (authLoading || isCheckingLicense) {
    return <AppLoadingState appName={app?.name || 'App'} />;
  }

  // App not found
  if (!app) {
    return <AppNotFound />;
  }

  // Not authenticated
  if (!isAuthenticated) {
    return <LoginRequired />;
  }

  // No license - show purchase options
  if (!license) {
    return <LicenseRequired app={app} onPurchase={handlePurchase} />;
  }

  // Load error
  if (loadError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center px-4">
        <Card className="max-w-md w-full bg-slate-900/50 border-slate-800 backdrop-blur-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-white">Error Loading App</CardTitle>
            <CardDescription className="text-red-400">{loadError}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              className="w-full"
              onClick={() => window.location.reload()}
            >
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // App loading
  if (!AppComponent) {
    return <AppLoadingState appName={app.name} />;
  }

  // Render app with shared context
  return (
    <div className="app-container" data-app-id={appId} data-license-tier={license.tier}>
      <Suspense fallback={<AppLoadingState appName={app.name} />}>
        <AppComponent 
          license={license}
          user={user}
          appMetadata={app}
        />
      </Suspense>
    </div>
  );
}
