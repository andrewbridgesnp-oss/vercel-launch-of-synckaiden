/**
 * PRODUCTION AUTHENTICATION SYSTEM
 * 
 * Implements:
 * - JWT token generation (15-min expiry)
 * - Refresh tokens (7-day expiry)
 * - bcrypt password hashing (cost: 12)
 * - Role-based access control (user, admin, super_admin)
 * - Rate limiting (5 failed attempts = 15-min lockout)
 * - Brute-force detection
 * - Session management
 * - Automatic expiration
 */

import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import { z } from 'zod';

// Configuration
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-in-production';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'dev-refresh-secret';
const ACCESS_TOKEN_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY = '7d';
const BCRYPT_COST = 12;
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes

// Types
export type UserRole = 'user' | 'admin' | 'super_admin';

export interface JWTPayload {
  userId: string;
  email: string;
  role: UserRole;
  iat: number;
  exp: number;
}

export interface RefreshTokenPayload {
  userId: string;
  iat: number;
  exp: number;
}

// In-memory store for login attempts (use Redis in production)
const loginAttempts = new Map<string, { count: number; lockedUntil: number }>();

/**
 * Hash password with bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_COST);
}

/**
 * Verify password against hash
 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

/**
 * Generate access token (JWT)
 */
export function generateAccessToken(userId: string, email: string, role: UserRole): string {
  const payload: Omit<JWTPayload, 'iat' | 'exp'> = {
    userId,
    email,
    role,
  };

  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: ACCESS_TOKEN_EXPIRY,
    algorithm: 'HS256',
  });
}

/**
 * Generate refresh token
 */
export function generateRefreshToken(userId: string): string {
  const payload: Omit<RefreshTokenPayload, 'iat' | 'exp'> = {
    userId,
  };

  return jwt.sign(payload, JWT_REFRESH_SECRET, {
    expiresIn: REFRESH_TOKEN_EXPIRY,
    algorithm: 'HS256',
  });
}

/**
 * Verify access token
 */
export function verifyAccessToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET, {
      algorithms: ['HS256'],
    }) as JWTPayload;
  } catch (error) {
    console.error('[Auth] Invalid access token:', error instanceof Error ? error.message : error);
    return null;
  }
}

/**
 * Verify refresh token
 */
export function verifyRefreshToken(token: string): RefreshTokenPayload | null {
  try {
    return jwt.verify(token, JWT_REFRESH_SECRET, {
      algorithms: ['HS256'],
    }) as RefreshTokenPayload;
  } catch (error) {
    console.error('[Auth] Invalid refresh token:', error instanceof Error ? error.message : error);
    return null;
  }
}

/**
 * Check if user is locked out due to too many failed attempts
 */
export function isLockedOut(email: string): boolean {
  const attempt = loginAttempts.get(email);
  if (!attempt) return false;

  if (Date.now() > attempt.lockedUntil) {
    // Lockout expired, reset
    loginAttempts.delete(email);
    return false;
  }

  return true;
}

/**
 * Record failed login attempt
 */
export function recordFailedAttempt(email: string): void {
  const attempt = loginAttempts.get(email) || { count: 0, lockedUntil: 0 };

  attempt.count += 1;

  if (attempt.count >= MAX_LOGIN_ATTEMPTS) {
    attempt.lockedUntil = Date.now() + LOCKOUT_DURATION_MS;
    console.warn(`[Auth] User ${email} locked out due to ${attempt.count} failed attempts`);
  }

  loginAttempts.set(email, attempt);
}

/**
 * Clear failed login attempts
 */
export function clearFailedAttempts(email: string): void {
  loginAttempts.delete(email);
}

/**
 * Validate password strength
 */
export function validatePasswordStrength(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (password.length < 12) {
    errors.push('Password must be at least 12 characters');
  }

  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain uppercase letter');
  }

  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain lowercase letter');
  }

  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain number');
  }

  if (!/[!@#$%^&*]/.test(password)) {
    errors.push('Password must contain special character (!@#$%^&*)');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validate email format
 */
export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Extract user from JWT token
 */
export function extractUserFromToken(token: string): JWTPayload | null {
  const payload = verifyAccessToken(token);
  if (!payload) return null;

  return payload;
}

/**
 * Check if user has required role
 */
export function hasRole(userRole: UserRole, requiredRole: UserRole): boolean {
  const roleHierarchy: Record<UserRole, number> = {
    user: 1,
    admin: 2,
    super_admin: 3,
  };

  return roleHierarchy[userRole] >= roleHierarchy[requiredRole];
}

/**
 * Generate session ID (for tracking)
 */
export function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Validation schemas
 */
export const loginSchema = z.object({
  email: z.string().email('Invalid email format'),
  password: z.string().min(1, 'Password required'),
});

export const registerSchema = z.object({
  email: z.string().email('Invalid email format'),
  password: z.string().min(12, 'Password must be at least 12 characters'),
  name: z.string().min(2, 'Name must be at least 2 characters'),
});

export const refreshTokenSchema = z.object({
  refreshToken: z.string().min(1, 'Refresh token required'),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password required'),
  newPassword: z.string().min(12, 'Password must be at least 12 characters'),
});

/**
 * Audit log for authentication events
 */
export interface AuthAuditLog {
  timestamp: number;
  userId?: string;
  email: string;
  action: 'login_success' | 'login_failed' | 'login_lockout' | 'logout' | 'register' | 'password_change' | 'token_refresh';
  ipAddress: string;
  userAgent: string;
  details?: Record<string, unknown>;
}

export function createAuthAuditLog(
  email: string,
  action: AuthAuditLog['action'],
  ipAddress: string,
  userAgent: string,
  userId?: string,
  details?: Record<string, unknown>
): AuthAuditLog {
  return {
    timestamp: Date.now(),
    userId,
    email,
    action,
    ipAddress,
    userAgent,
    details,
  };
}

export default {
  hashPassword,
  verifyPassword,
  generateAccessToken,
  generateRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
  isLockedOut,
  recordFailedAttempt,
  clearFailedAttempts,
  validatePasswordStrength,
  validateEmail,
  extractUserFromToken,
  hasRole,
  generateSessionId,
  createAuthAuditLog,
};
