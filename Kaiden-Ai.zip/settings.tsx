                {[
                  { label: "New Call Notifications", description: "Get notified when Avery receives a call" },
                  { label: "Booking Confirmations", description: "Receive updates when appointments are booked" },
                  { label: "Payment Alerts", description: "Get notified of successful payments" },
                  { label: "Daily Summary", description: "Receive a daily summary of Avery's activity" }
                ].map((notif, i) => (
                  <div key={i} className="flex items-center justify-between p-4 border border-border/50 rounded-lg">
                    <div>
                      <p className="font-medium">{notif.label}</p>
                      <p className="text-sm text-muted-foreground">{notif.description}</p>
                    </div>
                    <Switch defaultChecked={i < 3} />
                  </div>
                ))}
              </div>