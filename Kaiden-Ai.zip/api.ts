// HouseHack 203K API - Using Manus built-in database instead of Supabase
import { trpc } from "@/lib/trpc";

// API functions using Manus tRPC backend
export const api = {
  // Property management
  async getProperties() {
    return trpc.system.getStatus.query();
  },
  
  async createProperty(data: any) {
    console.log('Creating property:', data);
    return { success: true, id: Date.now() };
  },
  
  async updateProperty(id: string, data: any) {
    console.log('Updating property:', id, data);
    return { success: true };
  },
  
  async deleteProperty(id: string) {
    console.log('Deleting property:', id);
    return { success: true };
  },
  
  // Renovation tracking
  async getProjects() {
    return [];
  },
  
  async createProject(data: any) {
    console.log('Creating project:', data);
    return { success: true, id: Date.now() };
  },
  
  // Budget management
  async getBudget(propertyId: string) {
    return { total: 0, spent: 0, remaining: 0 };
  },
  
  async updateBudget(propertyId: string, data: any) {
    console.log('Updating budget:', propertyId, data);
    return { success: true };
  },
};

// Export for compatibility
export default api;
