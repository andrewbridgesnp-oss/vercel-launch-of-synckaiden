import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import {
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Zap,
  Building2,
  CreditCard,
  Home,
  TrendingUp,
  Users,
  Settings,
  ExternalLink,
} from "lucide-react";

interface WorkflowQuestionnaireProps {
  onComplete: (results: WorkflowResults) => void;
  onSkip: () => void;
}

interface WorkflowResults {
  primaryGoal: string;
  currentStage: string;
  selectedWorkflows: string[];
  accountsToCreate: AccountRecommendation[];
  apisToConnect: ApiRecommendation[];
}

interface AccountRecommendation {
  name: string;
  purpose: string;
  url: string;
  priority: "required" | "recommended" | "optional";
}

interface ApiRecommendation {
  name: string;
  purpose: string;
  setupGuide: string;
}

const questions = [
  {
    id: "primaryGoal",
    title: "What is your primary goal?",
    description: "This helps Kaiden prioritize your workflows and recommendations.",
    options: [
      { value: "credit", label: "Build or repair my credit", icon: CreditCard },
      { value: "business", label: "Start or grow a business", icon: Building2 },
      { value: "realestate", label: "Invest in real estate", icon: Home },
      { value: "wealth", label: "Build generational wealth", icon: TrendingUp },
      { value: "all", label: "All of the above", icon: Zap },
    ],
  },
  {
    id: "currentStage",
    title: "Where are you in your journey?",
    description: "Kaiden will customize recommendations based on your current stage.",
    options: [
      { value: "beginner", label: "Just getting started (learning phase)", icon: Users },
      { value: "building", label: "Actively building (taking action)", icon: Settings },
      { value: "scaling", label: "Ready to scale (have foundation)", icon: TrendingUp },
      { value: "advanced", label: "Advanced (optimizing systems)", icon: Zap },
    ],
  },
];

const workflowOptions = [
  { id: "credit-repair", label: "Credit Repair Workflow", description: "Dispute negative items, build positive history" },
  { id: "credit-stack", label: "Credit Stacking Strategy", description: "Strategic card applications for maximum limits" },
  { id: "llc-formation", label: "LLC Formation", description: "Complete business entity setup" },
  { id: "business-credit", label: "Business Credit Building", description: "Establish and grow business credit" },
  { id: "tradelines", label: "Tradeline Strategy", description: "Add reporting accounts to build history" },
  { id: "real-estate", label: "Real Estate Investing", description: "Fix-flip, rentals, and house hacking" },
  { id: "financing", label: "Financing Strategies", description: "0% cards, EIN-only loans, fleet financing" },
  { id: "automation", label: "Business Automation", description: "Automate operations with integrations" },
];

// Account recommendations based on goals
const getAccountRecommendations = (goal: string, stage: string): AccountRecommendation[] => {
  const accounts: AccountRecommendation[] = [];
  
  // Universal accounts
  accounts.push({
    name: "NAV",
    purpose: "Business credit monitoring and tradeline recommendations",
    url: "https://www.nav.com",
    priority: "required",
  });
  
  accounts.push({
    name: "BlueVine",
    purpose: "Business banking with high yield and credit lines",
    url: "https://www.bluevine.com",
    priority: "required",
  });

  if (goal === "credit" || goal === "all") {
    accounts.push({
      name: "Annual Credit Report",
      purpose: "Free credit reports from all three bureaus",
      url: "https://www.annualcreditreport.com",
      priority: "required",
    });
    accounts.push({
      name: "CreditBanks.com",
      purpose: "Credit building resources and tools",
      url: "https://www.creditbanks.com",
      priority: "recommended",
    });
    accounts.push({
      name: "BankNet.com",
      purpose: "Banking and credit resources",
      url: "https://www.banknet.com",
      priority: "recommended",
    });
    accounts.push({
      name: "HelpMeBuildCredit.com",
      purpose: "Credit building education and tools",
      url: "https://www.helpmebuildcredit.com",
      priority: "recommended",
    });
  }

  if (goal === "business" || goal === "all") {
    accounts.push({
      name: "NAV Prime",
      purpose: "Premium business credit monitoring",
      url: "https://www.nav.com/prime",
      priority: "recommended",
    });
    accounts.push({
      name: "Xero",
      purpose: "Accounting software that syncs with BlueVine",
      url: "https://www.xero.com",
      priority: "recommended",
    });
    accounts.push({
      name: "Quill",
      purpose: "Office supplies tradeline (reports to bureaus)",
      url: "https://www.quill.com",
      priority: "recommended",
    });
    accounts.push({
      name: "Uline",
      purpose: "Shipping supplies tradeline (reports to bureaus)",
      url: "https://www.uline.com",
      priority: "recommended",
    });
    accounts.push({
      name: "GlowBal Voice Direct",
      purpose: "Professional business phone lines",
      url: "https://www.glowbalvoicedirect.com",
      priority: "optional",
    });
  }

  if (goal === "realestate" || goal === "all") {
    accounts.push({
      name: "Local Land Bank",
      purpose: "Tax-foreclosed properties at deep discounts",
      url: "Search: [Your City] Land Bank",
      priority: "recommended",
    });
  }

  return accounts;
};

// API recommendations based on workflows
const getApiRecommendations = (workflows: string[]): ApiRecommendation[] => {
  const apis: ApiRecommendation[] = [];

  if (workflows.includes("automation")) {
    apis.push({
      name: "Zapier",
      purpose: "Connect all your apps and automate workflows",
      setupGuide: "Create account, then connect your apps using Zaps",
    });
    apis.push({
      name: "Make (Integromat)",
      purpose: "Advanced automation scenarios",
      setupGuide: "Import the provided .make files to get started",
    });
  }

  if (workflows.includes("business-credit") || workflows.includes("llc-formation")) {
    apis.push({
      name: "Xero API",
      purpose: "Sync accounting data with BlueVine",
      setupGuide: "Connect Xero to BlueVine for automatic reconciliation",
    });
  }

  if (workflows.includes("real-estate")) {
    apis.push({
      name: "SMS Lead Generation",
      purpose: "Automated outreach to property owners",
      setupGuide: "Configure skip tracing and SMS campaigns",
    });
  }

  return apis;
};

export function WorkflowQuestionnaire({ onComplete, onSkip }: WorkflowQuestionnaireProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [selectedWorkflows, setSelectedWorkflows] = useState<string[]>([]);

  const totalSteps = questions.length + 1; // +1 for workflow selection
  const progress = ((currentStep + 1) / totalSteps) * 100;

  const handleAnswer = (questionId: string, value: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  };

  const toggleWorkflow = (workflowId: string) => {
    setSelectedWorkflows((prev) =>
      prev.includes(workflowId)
        ? prev.filter((id) => id !== workflowId)
        : [...prev, workflowId]
    );
  };

  const handleNext = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep((prev) => prev + 1);
    } else {
      // Complete questionnaire
      const results: WorkflowResults = {
        primaryGoal: answers.primaryGoal || "all",
        currentStage: answers.currentStage || "beginner",
        selectedWorkflows,
        accountsToCreate: getAccountRecommendations(answers.primaryGoal || "all", answers.currentStage || "beginner"),
        apisToConnect: getApiRecommendations(selectedWorkflows),
      };
      onComplete(results);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const currentQuestion = questions[currentStep];
  const isWorkflowStep = currentStep === questions.length;
  const canProceed = isWorkflowStep ? selectedWorkflows.length > 0 : answers[currentQuestion?.id];

  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl luxury-card">
        <CardHeader>
          <div className="flex items-center justify-between mb-4">
            <Badge variant="outline">Step {currentStep + 1} of {totalSteps}</Badge>
            <Button variant="ghost" size="sm" onClick={onSkip}>
              Skip for now
            </Button>
          </div>
          <Progress value={progress} className="h-2 mb-4" />
          <CardTitle className="text-2xl">
            {isWorkflowStep ? "Select Your Workflows" : currentQuestion?.title}
          </CardTitle>
          <CardDescription>
            {isWorkflowStep
              ? "Choose the workflows you want Kaiden to help you with. You can change these later."
              : currentQuestion?.description}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!isWorkflowStep && currentQuestion && (
            <RadioGroup
              value={answers[currentQuestion.id] || ""}
              onValueChange={(value) => handleAnswer(currentQuestion.id, value)}
              className="space-y-3"
            >
              {currentQuestion.options.map((option) => {
                const Icon = option.icon;
                return (
                  <div
                    key={option.value}
                    className={`flex items-center gap-4 p-4 rounded-lg border transition-all cursor-pointer ${
                      answers[currentQuestion.id] === option.value
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                    onClick={() => handleAnswer(currentQuestion.id, option.value)}
                  >
                    <RadioGroupItem value={option.value} id={option.value} />
                    <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <Label htmlFor={option.value} className="flex-1 cursor-pointer font-medium">
                      {option.label}
                    </Label>
                  </div>
                );
              })}
            </RadioGroup>
          )}

          {isWorkflowStep && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {workflowOptions.map((workflow) => (
                <div
                  key={workflow.id}
                  className={`flex items-start gap-3 p-4 rounded-lg border transition-all cursor-pointer ${
                    selectedWorkflows.includes(workflow.id)
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50"
                  }`}
                  onClick={() => toggleWorkflow(workflow.id)}
                >
                  <Checkbox
                    checked={selectedWorkflows.includes(workflow.id)}
                    onCheckedChange={() => toggleWorkflow(workflow.id)}
                  />
                  <div>
                    <p className="font-medium text-sm">{workflow.label}</p>
                    <p className="text-xs text-muted-foreground">{workflow.description}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between mt-8">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 0}
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <Button
              onClick={handleNext}
              disabled={!canProceed}
              className="btn-shine"
            >
              {currentStep === totalSteps - 1 ? (
                <>
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                  Complete Setup
                </>
              ) : (
                <>
                  Next
                  <ArrowRight className="h-4 w-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Results display component
export function WorkflowResults({ results }: { results: WorkflowResults }) {
  return (
    <div className="space-y-6">
      <Card className="luxury-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-green-500" />
            Your Personalized Setup
          </CardTitle>
          <CardDescription>
            Based on your answers, here are your recommended accounts and integrations.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Accounts to Create */}
          <div>
            <h3 className="font-semibold mb-3">Accounts to Create</h3>
            <div className="space-y-2">
              {results.accountsToCreate.map((account, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 rounded-lg bg-secondary/50"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{account.name}</span>
                      <Badge
                        variant={account.priority === "required" ? "default" : "outline"}
                        className={account.priority === "required" ? "bg-red-500" : ""}
                      >
                        {account.priority}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{account.purpose}</p>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <a href={account.url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* APIs to Connect */}
          {results.apisToConnect.length > 0 && (
            <div>
              <h3 className="font-semibold mb-3">APIs to Connect</h3>
              <div className="space-y-2">
                {results.apisToConnect.map((api, index) => (
                  <div key={index} className="p-3 rounded-lg bg-secondary/50">
                    <div className="font-medium">{api.name}</div>
                    <p className="text-sm text-muted-foreground">{api.purpose}</p>
                    <p className="text-xs text-primary mt-1">{api.setupGuide}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
