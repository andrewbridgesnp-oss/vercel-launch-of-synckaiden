import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Zap, Crown } from "lucide-react";

interface App {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: string;
  rating: number;
  reviews: number;
  image: string;
  tiers: {
    name: string;
    price: number;
    features: string[];
    popular?: boolean;
  }[];
}

const apps: App[] = [
  {
    id: "where-my-tribe",
    name: "Where's My Tribe",
    description: "Community building and networking platform",
    icon: "👥",
    category: "Community",
    rating: 4.8,
    reviews: 342,
    image: "/images/where-my-tribe.jpg",
    tiers: [
      {
        name: "Starter",
        price: 9.99,
        features: ["Up to 100 members", "Basic analytics", "Email support"],
      },
      {
        name: "Professional",
        price: 29.99,
        features: ["Unlimited members", "Advanced analytics", "Priority support", "Custom branding"],
        popular: true,
      },
      {
        name: "Enterprise",
        price: 99.99,
        features: ["Everything in Pro", "Dedicated account manager", "API access", "Custom integrations"],
      },
    ],
  },
  {
    id: "content-creation",
    name: "Content Creation Engine",
    description: "AI-powered content generation and management",
    icon: "✍️",
    category: "Content",
    rating: 4.9,
    reviews: 521,
    image: "/images/content-creation.jpg",
    tiers: [
      {
        name: "Starter",
        price: 14.99,
        features: ["50 posts/month", "Basic templates", "Email support"],
      },
      {
        name: "Professional",
        price: 49.99,
        features: ["500 posts/month", "Advanced templates", "Priority support", "Analytics"],
        popular: true,
      },
      {
        name: "Enterprise",
        price: 149.99,
        features: ["Unlimited posts", "Custom templates", "Dedicated support", "API access"],
      },
    ],
  },
  {
    id: "reality-sync",
    name: "Reality Sync",
    description: "Real estate management and virtual tours",
    icon: "🏠",
    category: "Real Estate",
    rating: 4.7,
    reviews: 289,
    image: "/images/reality-sync.jpg",
    tiers: [
      {
        name: "Starter",
        price: 19.99,
        features: ["10 listings", "Basic tours", "Email support"],
      },
      {
        name: "Professional",
        price: 59.99,
        features: ["Unlimited listings", "360° tours", "Priority support", "CRM"],
        popular: true,
      },
      {
        name: "Enterprise",
        price: 199.99,
        features: ["Everything in Pro", "Dedicated agent", "Custom branding", "API"],
      },
    ],
  },
  {
    id: "pal",
    name: "PAL - Personal Assistant Layer",
    description: "Your AI personal assistant for everything",
    icon: "🤖",
    category: "Productivity",
    rating: 4.9,
    reviews: 1203,
    image: "/images/pal.jpg",
    tiers: [
      {
        name: "Starter",
        price: 9.99,
        features: ["Basic tasks", "Email support", "1 device"],
      },
      {
        name: "Professional",
        price: 24.99,
        features: ["Advanced tasks", "Priority support", "5 devices", "Calendar sync"],
        popular: true,
      },
      {
        name: "Enterprise",
        price: 79.99,
        features: ["Everything in Pro", "Unlimited devices", "Dedicated support", "Custom workflows"],
      },
    ],
  },
  {
    id: "builder-sync",
    name: "Builder Sync",
    description: "Construction project management",
    icon: "🏗️",
    category: "Construction",
    rating: 4.6,
    reviews: 178,
    image: "/images/builder-sync.jpg",
    tiers: [
      {
        name: "Starter",
        price: 24.99,
        features: ["1 project", "Basic tracking", "Email support"],
      },
      {
        name: "Professional",
        price: 74.99,
        features: ["Unlimited projects", "Advanced tracking", "Team collaboration", "Reports"],
        popular: true,
      },
      {
        name: "Enterprise",
        price: 249.99,
        features: ["Everything in Pro", "Dedicated support", "Custom integrations", "API"],
      },
    ],
  },
  {
    id: "master-music",
    name: "Master Music Production",
    description: "Professional music production tools",
    icon: "🎵",
    category: "Music",
    rating: 4.8,
    reviews: 456,
    image: "/images/master-music.jpg",
    tiers: [
      {
        name: "Starter",
        price: 12.99,
        features: ["Basic tools", "100 MB storage", "Email support"],
      },
      {
        name: "Professional",
        price: 39.99,
        features: ["Pro tools", "1 TB storage", "Priority support", "Collaboration"],
        popular: true,
      },
      {
        name: "Enterprise",
        price: 129.99,
        features: ["Everything in Pro", "Unlimited storage", "Dedicated support", "API"],
      },
    ],
  },
];

export default function AppStore() {
  const [selectedApp, setSelectedApp] = useState<string | null>(null);
  const [selectedTier, setSelectedTier] = useState<{ appId: string; tierIndex: number } | null>(null);

  const handleSubscribe = (appId: string, tierIndex: number) => {
    setSelectedTier({ appId, tierIndex });
    // Trigger checkout flow
    console.log(`Subscribing to ${appId} tier ${tierIndex}`);
  };

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Kaiden <span className="gradient-text">App Store</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover and subscribe to powerful apps that integrate seamlessly with Kaiden.
            Cancel anytime. No refunds.
          </p>
        </div>

        {/* Apps Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {apps.map((app) => (
            <Card
              key={app.id}
              className="luxury-card cursor-pointer transition-all duration-300 hover:shadow-lg"
              onClick={() => setSelectedApp(selectedApp === app.id ? null : app.id)}
            >
              <CardHeader>
                <div className="flex items-start justify-between mb-4">
                  <div className="text-4xl">{app.icon}</div>
                  <Badge variant="secondary">{app.category}</Badge>
                </div>
                <CardTitle>{app.name}</CardTitle>
                <CardDescription>{app.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(app.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {app.rating} ({app.reviews} reviews)
                  </span>
                </div>

                {selectedApp === app.id && (
                  <div className="space-y-4 mt-6 pt-6 border-t">
                    {app.tiers.map((tier, idx) => (
                      <div
                        key={idx}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          tier.popular
                            ? "border-primary bg-primary/5"
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="font-semibold">{tier.name}</h3>
                            <p className="text-2xl font-bold text-primary">
                              ${tier.price}
                              <span className="text-sm text-muted-foreground">/month</span>
                            </p>
                          </div>
                          {tier.popular && (
                            <Badge className="bg-primary">Most Popular</Badge>
                          )}
                        </div>
                        <ul className="space-y-2 mb-4">
                          {tier.features.map((feature, fIdx) => (
                            <li key={fIdx} className="flex items-center gap-2 text-sm">
                              <Check className="h-4 w-4 text-primary" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                        <Button
                          className="w-full"
                          onClick={() => handleSubscribe(app.id, idx)}
                        >
                          Subscribe Now
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Pricing Info */}
        <div className="mt-16 bg-card rounded-lg p-8 border">
          <h2 className="text-2xl font-bold mb-4">Subscription Details</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-semibold mb-2">✅ No Refunds</h3>
              <p className="text-muted-foreground">
                All subscriptions are final. Choose wisely and upgrade anytime.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">⏸️ Cancel Anytime</h3>
              <p className="text-muted-foreground">
                Cancel your subscription anytime. You'll have access through the end of your billing period.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">🔄 Finish Your Month</h3>
              <p className="text-muted-foreground">
                Cancellations take effect at the end of your current billing cycle.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
