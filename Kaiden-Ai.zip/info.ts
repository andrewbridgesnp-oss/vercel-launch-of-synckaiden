// Supabase configuration placeholder
export const SUPABASE_URL = process.env.VITE_SUPABASE_URL || '';
export const SUPABASE_ANON_KEY = process.env.VITE_SUPABASE_ANON_KEY || '';

// Legacy exports for compatibility
export const projectId = SUPABASE_URL.replace('https://', '').split('.')[0] || 'placeholder';
export const publicAnonKey = SUPABASE_ANON_KEY;

export const supabaseConfig = {
  url: SUPABASE_URL,
  anonKey: SUPABASE_ANON_KEY,
};
