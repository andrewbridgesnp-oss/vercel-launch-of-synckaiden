/**
 * Hook for ElevenLabs Text-to-Speech functionality
 */

import { useState, useCallback, useRef } from 'react';

export interface UseTTSOptions {
  voiceId?: string;
  stability?: number;
  similarityBoost?: number;
}

export interface UseTTSState {
  isLoading: boolean;
  isPlaying: boolean;
  error: string | null;
  duration: number;
}

export function useElevenLabsTTS(options: UseTTSOptions = {}) {
  const [state, setState] = useState<UseTTSState>({
    isLoading: false,
    isPlaying: false,
    error: null,
    duration: 0,
  });

  const audioRef = useRef<HTMLAudioElement | null>(null);

  /**
   * Synthesize text to speech
   */
  const synthesize = useCallback(
    async (text: string) => {
      if (!text || text.trim().length === 0) {
        setState((prev) => ({ ...prev, error: 'Text cannot be empty' }));
        return;
      }

      setState((prev) => ({ ...prev, isLoading: true, error: null }));

      try {
        const response = await fetch('/api/tts/synthesize', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            text,
            voiceId: options.voiceId,
            stability: options.stability,
            similarityBoost: options.similarityBoost,
          }),
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.message || 'Failed to synthesize speech');
        }

        const data = await response.json();

        // Create audio element if it doesn't exist
        if (!audioRef.current) {
          audioRef.current = new Audio();
        }

        audioRef.current.src = data.audioUrl;
        setState((prev) => ({
          ...prev,
          isLoading: false,
          duration: data.duration,
        }));

        return data;
      } catch (error) {
        const errorMessage =
          error instanceof Error ? error.message : 'Unknown error';
        setState((prev) => ({ ...prev, isLoading: false, error: errorMessage }));
        throw error;
      }
    },
    [options]
  );

  /**
   * Play synthesized audio
   */
  const play = useCallback(async () => {
    if (!audioRef.current) {
      setState((prev) => ({
        ...prev,
        error: 'No audio to play. Synthesize text first.',
      }));
      return;
    }

    try {
      setState((prev) => ({ ...prev, isPlaying: true, error: null }));
      await audioRef.current.play();
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Failed to play audio';
      setState((prev) => ({ ...prev, isPlaying: false, error: errorMessage }));
    }
  }, []);

  /**
   * Pause audio playback
   */
  const pause = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      setState((prev) => ({ ...prev, isPlaying: false }));
    }
  }, []);

  /**
   * Stop audio and reset
   */
  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setState((prev) => ({ ...prev, isPlaying: false }));
    }
  }, []);

  /**
   * Synthesize and play in one call
   */
  const speakText = useCallback(
    async (text: string) => {
      await synthesize(text);
      // Small delay to ensure audio is ready
      setTimeout(() => play(), 100);
    },
    [synthesize, play]
  );

  return {
    ...state,
    synthesize,
    play,
    pause,
    stop,
    speakText,
    audioRef,
  };
}
