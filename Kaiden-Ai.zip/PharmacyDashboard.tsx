/**
 * Pharmacy Dashboard - HealthSync/MedScribe
 * 
 * Features:
 * - Prescription queue management
 * - Drug interaction checking
 * - Inventory management
 * - Patient medication history
 * - E-prescribing integration
 * - Controlled substance tracking
 */

import { useState } from "react";
import { 
  Pill, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Search, 
  Filter,
  Package,
  User,
  FileText,
  AlertCircle,
  RefreshCw,
  Send,
  Printer,
  MoreVertical,
  ChevronRight,
  Shield,
  Zap,
  TrendingUp,
  Bell
} from "lucide-react";

// Types
interface Prescription {
  id: string;
  patientName: string;
  patientId: string;
  medication: string;
  dosage: string;
  quantity: number;
  refills: number;
  prescriber: string;
  prescribedAt: string;
  status: 'pending' | 'processing' | 'ready' | 'picked_up' | 'cancelled';
  priority: 'normal' | 'urgent' | 'stat';
  isControlled: boolean;
  controlledSchedule?: 'II' | 'III' | 'IV' | 'V';
  interactions: DrugInteraction[];
  insurance?: {
    status: 'approved' | 'pending' | 'denied' | 'prior_auth';
    copay?: number;
  };
}

interface DrugInteraction {
  id: string;
  severity: 'minor' | 'moderate' | 'major' | 'contraindicated';
  drug1: string;
  drug2: string;
  description: string;
}

interface InventoryItem {
  id: string;
  name: string;
  ndc: string;
  quantity: number;
  reorderPoint: number;
  expirationDate: string;
  lotNumber: string;
  isControlled: boolean;
}

// Mock data
const mockPrescriptions: Prescription[] = [
  {
    id: 'RX-001',
    patientName: 'Sarah Johnson',
    patientId: 'PT-12345',
    medication: 'Metformin 500mg',
    dosage: '1 tablet twice daily',
    quantity: 60,
    refills: 3,
    prescriber: 'Dr. Michael Chen',
    prescribedAt: '2026-01-12T09:30:00',
    status: 'pending',
    priority: 'normal',
    isControlled: false,
    interactions: [],
    insurance: { status: 'approved', copay: 10 }
  },
  {
    id: 'RX-002',
    patientName: 'Robert Williams',
    patientId: 'PT-12346',
    medication: 'Oxycodone 5mg',
    dosage: '1 tablet every 6 hours as needed',
    quantity: 30,
    refills: 0,
    prescriber: 'Dr. Sarah Martinez',
    prescribedAt: '2026-01-12T10:15:00',
    status: 'processing',
    priority: 'urgent',
    isControlled: true,
    controlledSchedule: 'II',
    interactions: [
      {
        id: 'INT-001',
        severity: 'major',
        drug1: 'Oxycodone',
        drug2: 'Alprazolam',
        description: 'Concurrent use may result in profound sedation, respiratory depression, coma, and death.'
      }
    ],
    insurance: { status: 'prior_auth' }
  },
  {
    id: 'RX-003',
    patientName: 'Emily Chen',
    patientId: 'PT-12347',
    medication: 'Lisinopril 10mg',
    dosage: '1 tablet daily',
    quantity: 30,
    refills: 5,
    prescriber: 'Dr. James Wilson',
    prescribedAt: '2026-01-12T08:45:00',
    status: 'ready',
    priority: 'normal',
    isControlled: false,
    interactions: [],
    insurance: { status: 'approved', copay: 5 }
  },
  {
    id: 'RX-004',
    patientName: 'Marcus Thompson',
    patientId: 'PT-12348',
    medication: 'Amoxicillin 500mg',
    dosage: '1 capsule three times daily',
    quantity: 21,
    refills: 0,
    prescriber: 'Dr. Lisa Park',
    prescribedAt: '2026-01-12T11:00:00',
    status: 'pending',
    priority: 'stat',
    isControlled: false,
    interactions: [
      {
        id: 'INT-002',
        severity: 'moderate',
        drug1: 'Amoxicillin',
        drug2: 'Warfarin',
        description: 'May increase anticoagulant effect. Monitor INR closely.'
      }
    ],
    insurance: { status: 'approved', copay: 15 }
  },
];

// Components
function PrescriptionCard({ rx, onProcess, onReady, onPickup }: { 
  rx: Prescription; 
  onProcess: () => void;
  onReady: () => void;
  onPickup: () => void;
}) {
  const statusColors = {
    pending: 'bg-amber-100 text-amber-800 border-amber-200',
    processing: 'bg-blue-100 text-blue-800 border-blue-200',
    ready: 'bg-green-100 text-green-800 border-green-200',
    picked_up: 'bg-slate-100 text-slate-800 border-slate-200',
    cancelled: 'bg-red-100 text-red-800 border-red-200',
  };

  const priorityColors = {
    normal: '',
    urgent: 'border-l-4 border-l-amber-500',
    stat: 'border-l-4 border-l-red-500',
  };

  const hasInteractions = rx.interactions.length > 0;
  const hasMajorInteraction = rx.interactions.some(i => i.severity === 'major' || i.severity === 'contraindicated');

  return (
    <div className={`bg-white rounded-lg border shadow-sm p-4 ${priorityColors[rx.priority]}`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-navy-900">{rx.patientName}</span>
            {rx.priority === 'stat' && (
              <span className="px-2 py-0.5 bg-red-500 text-white text-xs font-bold rounded">STAT</span>
            )}
            {rx.priority === 'urgent' && (
              <span className="px-2 py-0.5 bg-amber-500 text-white text-xs font-bold rounded">URGENT</span>
            )}
          </div>
          <span className="text-sm text-slate-500">{rx.patientId}</span>
        </div>
        <span className={`px-2 py-1 text-xs font-medium rounded-full border ${statusColors[rx.status]}`}>
          {rx.status.replace('_', ' ').toUpperCase()}
        </span>
      </div>

      {/* Medication Info */}
      <div className="mb-3">
        <div className="flex items-center gap-2">
          <Pill className="w-4 h-4 text-navy-600" />
          <span className="font-medium text-navy-800">{rx.medication}</span>
          {rx.isControlled && (
            <span className="px-1.5 py-0.5 bg-purple-100 text-purple-800 text-xs font-medium rounded">
              C-{rx.controlledSchedule}
            </span>
          )}
        </div>
        <p className="text-sm text-slate-600 ml-6">{rx.dosage}</p>
        <p className="text-sm text-slate-500 ml-6">Qty: {rx.quantity} | Refills: {rx.refills}</p>
      </div>

      {/* Interactions Warning */}
      {hasInteractions && (
        <div className={`mb-3 p-2 rounded-lg ${hasMajorInteraction ? 'bg-red-50 border border-red-200' : 'bg-amber-50 border border-amber-200'}`}>
          <div className="flex items-center gap-2">
            <AlertTriangle className={`w-4 h-4 ${hasMajorInteraction ? 'text-red-600' : 'text-amber-600'}`} />
            <span className={`text-sm font-medium ${hasMajorInteraction ? 'text-red-800' : 'text-amber-800'}`}>
              {rx.interactions.length} Drug Interaction{rx.interactions.length > 1 ? 's' : ''} Detected
            </span>
          </div>
          {rx.interactions.map(interaction => (
            <p key={interaction.id} className="text-xs text-slate-600 mt-1 ml-6">
              {interaction.drug1} + {interaction.drug2}: {interaction.description}
            </p>
          ))}
        </div>
      )}

      {/* Insurance Status */}
      {rx.insurance && (
        <div className="mb-3 flex items-center gap-2">
          <Shield className="w-4 h-4 text-slate-400" />
          <span className={`text-sm ${
            rx.insurance.status === 'approved' ? 'text-green-600' :
            rx.insurance.status === 'denied' ? 'text-red-600' :
            rx.insurance.status === 'prior_auth' ? 'text-amber-600' :
            'text-slate-600'
          }`}>
            {rx.insurance.status === 'approved' && `Approved - Copay: $${rx.insurance.copay}`}
            {rx.insurance.status === 'denied' && 'Insurance Denied'}
            {rx.insurance.status === 'prior_auth' && 'Prior Authorization Required'}
            {rx.insurance.status === 'pending' && 'Insurance Pending'}
          </span>
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t">
        <div className="text-xs text-slate-500">
          <span>Prescribed by {rx.prescriber}</span>
          <span className="mx-2">•</span>
          <span>{new Date(rx.prescribedAt).toLocaleTimeString()}</span>
        </div>
        <div className="flex items-center gap-2">
          {rx.status === 'pending' && (
            <button 
              onClick={onProcess}
              className="px-3 py-1.5 bg-blue-500 text-white text-sm font-medium rounded-lg hover:bg-blue-600 transition-colors"
            >
              Process
            </button>
          )}
          {rx.status === 'processing' && (
            <button 
              onClick={onReady}
              className="px-3 py-1.5 bg-green-500 text-white text-sm font-medium rounded-lg hover:bg-green-600 transition-colors"
            >
              Mark Ready
            </button>
          )}
          {rx.status === 'ready' && (
            <button 
              onClick={onPickup}
              className="px-3 py-1.5 bg-navy-600 text-white text-sm font-medium rounded-lg hover:bg-navy-700 transition-colors"
            >
              Picked Up
            </button>
          )}
          <button className="p-1.5 text-slate-400 hover:text-slate-600">
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

function StatsCard({ icon: Icon, label, value, trend, color }: {
  icon: typeof Pill;
  label: string;
  value: string | number;
  trend?: string;
  color: string;
}) {
  return (
    <div className="bg-white rounded-lg border p-4">
      <div className="flex items-center justify-between mb-2">
        <div className={`w-10 h-10 rounded-lg ${color} flex items-center justify-center`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        {trend && (
          <span className="text-xs text-green-600 font-medium flex items-center">
            <TrendingUp className="w-3 h-3 mr-1" />
            {trend}
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-navy-900">{value}</p>
      <p className="text-sm text-slate-500">{label}</p>
    </div>
  );
}

// Main Component
export function PharmacyDashboard() {
  const [prescriptions, setPrescriptions] = useState(mockPrescriptions);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'queue' | 'inventory' | 'controlled'>('queue');

  // Filter prescriptions
  const filteredPrescriptions = prescriptions.filter(rx => {
    const matchesSearch = rx.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          rx.medication.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          rx.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || rx.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Stats
  const pendingCount = prescriptions.filter(rx => rx.status === 'pending').length;
  const processingCount = prescriptions.filter(rx => rx.status === 'processing').length;
  const readyCount = prescriptions.filter(rx => rx.status === 'ready').length;
  const controlledCount = prescriptions.filter(rx => rx.isControlled).length;

  // Actions
  const updateStatus = (id: string, newStatus: Prescription['status']) => {
    setPrescriptions(prev => prev.map(rx => 
      rx.id === id ? { ...rx, status: newStatus } : rx
    ));
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Pharmacy Dashboard</h1>
          <p className="text-slate-500">Manage prescriptions and inventory</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="p-2 text-slate-400 hover:text-slate-600 relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          <button className="px-4 py-2 bg-navy-600 text-white font-medium rounded-lg hover:bg-navy-700 transition-colors flex items-center gap-2">
            <RefreshCw className="w-4 h-4" />
            Sync E-Rx
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <StatsCard 
          icon={Clock} 
          label="Pending" 
          value={pendingCount} 
          color="bg-amber-500" 
        />
        <StatsCard 
          icon={Zap} 
          label="Processing" 
          value={processingCount} 
          color="bg-blue-500" 
        />
        <StatsCard 
          icon={CheckCircle2} 
          label="Ready for Pickup" 
          value={readyCount} 
          color="bg-green-500" 
        />
        <StatsCard 
          icon={Shield} 
          label="Controlled Substances" 
          value={controlledCount} 
          color="bg-purple-500" 
        />
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 mb-6 border-b">
        <button 
          onClick={() => setActiveTab('queue')}
          className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors ${
            activeTab === 'queue' 
              ? 'border-navy-600 text-navy-600' 
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          Prescription Queue
        </button>
        <button 
          onClick={() => setActiveTab('inventory')}
          className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors ${
            activeTab === 'inventory' 
              ? 'border-navy-600 text-navy-600' 
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          Inventory
        </button>
        <button 
          onClick={() => setActiveTab('controlled')}
          className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors ${
            activeTab === 'controlled' 
              ? 'border-navy-600 text-navy-600' 
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          Controlled Substances
        </button>
      </div>

      {/* Search and Filter */}
      <div className="flex items-center gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by patient, medication, or Rx ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-navy-500"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-navy-500"
        >
          <option value="all">All Status</option>
          <option value="pending">Pending</option>
          <option value="processing">Processing</option>
          <option value="ready">Ready</option>
          <option value="picked_up">Picked Up</option>
        </select>
        <button className="p-2 border rounded-lg text-slate-600 hover:bg-slate-50">
          <Filter className="w-5 h-5" />
        </button>
      </div>

      {/* Prescription Queue */}
      {activeTab === 'queue' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredPrescriptions.map(rx => (
            <PrescriptionCard 
              key={rx.id} 
              rx={rx}
              onProcess={() => updateStatus(rx.id, 'processing')}
              onReady={() => updateStatus(rx.id, 'ready')}
              onPickup={() => updateStatus(rx.id, 'picked_up')}
            />
          ))}
          {filteredPrescriptions.length === 0 && (
            <div className="col-span-2 text-center py-12 text-slate-500">
              <Pill className="w-12 h-12 mx-auto mb-4 text-slate-300" />
              <p>No prescriptions found</p>
            </div>
          )}
        </div>
      )}

      {/* Inventory Tab */}
      {activeTab === 'inventory' && (
        <div className="bg-white rounded-lg border p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-navy-900">Inventory Management</h2>
            <button className="px-4 py-2 bg-navy-600 text-white font-medium rounded-lg hover:bg-navy-700 transition-colors">
              Add Item
            </button>
          </div>
          <div className="text-center py-12 text-slate-500">
            <Package className="w-12 h-12 mx-auto mb-4 text-slate-300" />
            <p>Inventory management coming soon</p>
            <p className="text-sm">Track medications, manage stock levels, and set reorder alerts</p>
          </div>
        </div>
      )}

      {/* Controlled Substances Tab */}
      {activeTab === 'controlled' && (
        <div className="bg-white rounded-lg border p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-navy-900">Controlled Substance Tracking</h2>
            <button className="px-4 py-2 border border-navy-600 text-navy-600 font-medium rounded-lg hover:bg-navy-50 transition-colors">
              Generate DEA Report
            </button>
          </div>
          <div className="space-y-4">
            {prescriptions.filter(rx => rx.isControlled).map(rx => (
              <div key={rx.id} className="flex items-center justify-between p-4 bg-purple-50 rounded-lg border border-purple-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-navy-900">{rx.medication}</span>
                    <span className="px-1.5 py-0.5 bg-purple-200 text-purple-800 text-xs font-medium rounded">
                      Schedule {rx.controlledSchedule}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600">{rx.patientName} • {rx.id}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-navy-900">Qty: {rx.quantity}</p>
                  <p className="text-xs text-slate-500">Prescribed: {new Date(rx.prescribedAt).toLocaleDateString()}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default PharmacyDashboard;
