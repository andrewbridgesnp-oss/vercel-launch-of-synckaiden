/**
 * Unit tests for useNotifications hook
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useNotifications } from './useNotifications';

describe('useNotifications', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.runOnlyPendingTimers();
    vi.useRealTimers();
  });

  it('should initialize with empty notifications', () => {
    const { result } = renderHook(() => useNotifications());

    expect(result.current.notifications).toEqual([]);
  });

  it('should add a success notification', () => {
    const { result } = renderHook(() => useNotifications());

    act(() => {
      result.current.success('Success', 'Operation completed');
    });

    expect(result.current.notifications).toHaveLength(1);
    expect(result.current.notifications[0].type).toBe('success');
    expect(result.current.notifications[0].title).toBe('Success');
  });

  it('should add an error notification', () => {
    const { result } = renderHook(() => useNotifications());

    act(() => {
      result.current.error('Error', 'Something went wrong');
    });

    expect(result.current.notifications).toHaveLength(1);
    expect(result.current.notifications[0].type).toBe('error');
  });

  it('should add a warning notification', () => {
    const { result } = renderHook(() => useNotifications());

    act(() => {
      result.current.warning('Warning', 'Be careful');
    });

    expect(result.current.notifications).toHaveLength(1);
    expect(result.current.notifications[0].type).toBe('warning');
  });

  it('should add an info notification', () => {
    const { result } = renderHook(() => useNotifications());

    act(() => {
      result.current.info('Info', 'Here is some information');
    });

    expect(result.current.notifications).toHaveLength(1);
    expect(result.current.notifications[0].type).toBe('info');
  });

  it('should remove a notification by id', () => {
    const { result } = renderHook(() => useNotifications());

    let id: string;
    act(() => {
      id = result.current.success('Test', 'Message');
    });

    expect(result.current.notifications).toHaveLength(1);

    act(() => {
      result.current.removeNotification(id!);
    });

    expect(result.current.notifications).toHaveLength(0);
  });

  it('should auto-remove notification after duration', () => {
    const { result } = renderHook(() => useNotifications());

    act(() => {
      result.current.success('Test', 'Message', 3000);
    });

    expect(result.current.notifications).toHaveLength(1);

    act(() => {
      vi.advanceTimersByTime(3000);
    });

    expect(result.current.notifications).toHaveLength(0);
  });

  it('should not auto-remove notification with zero duration', () => {
    const { result } = renderHook(() => useNotifications());

    act(() => {
      result.current.success('Test', 'Message', 0);
    });

    expect(result.current.notifications).toHaveLength(1);

    act(() => {
      vi.advanceTimersByTime(10000);
    });

    expect(result.current.notifications).toHaveLength(1);
  });

  it('should clear all notifications', () => {
    const { result } = renderHook(() => useNotifications());

    act(() => {
      result.current.success('Test 1', 'Message 1');
      result.current.error('Test 2', 'Message 2');
      result.current.warning('Test 3', 'Message 3');
    });

    expect(result.current.notifications).toHaveLength(3);

    act(() => {
      result.current.clearAll();
    });

    expect(result.current.notifications).toHaveLength(0);
  });

  it('should support notification actions', () => {
    const { result } = renderHook(() => useNotifications());
    const mockAction = vi.fn();

    act(() => {
      result.current.success('Test', 'Message', 5000, {
        label: 'Undo',
        onClick: mockAction,
      });
    });

    expect(result.current.notifications[0].action).toBeDefined();
    expect(result.current.notifications[0].action?.label).toBe('Undo');
  });

  it('should generate unique ids for notifications', () => {
    const { result } = renderHook(() => useNotifications());

    let id1: string, id2: string;
    act(() => {
      id1 = result.current.success('Test 1', 'Message 1');
      id2 = result.current.success('Test 2', 'Message 2');
    });

    expect(id1).not.toBe(id2);
    expect(result.current.notifications[0].id).toBe(id1);
    expect(result.current.notifications[1].id).toBe(id2);
  });
});
