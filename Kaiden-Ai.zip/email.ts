/**
 * SendGrid Email Notification Service
 * Privacy-first email notifications for Kaiden platform
 */

import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";

// Email templates
const EMAIL_TEMPLATES = {
  PURCHASE_CONFIRMATION: 'purchase_confirmation',
  LICENSE_DELIVERY: 'license_delivery',
  WELCOME: 'welcome',
  PASSWORD_RESET: 'password_reset',
  SUBSCRIPTION_RENEWAL: 'subscription_renewal',
  SUBSCRIPTION_CANCELLED: 'subscription_cancelled',
  PAYMENT_FAILED: 'payment_failed',
  TAX_REMINDER: 'tax_reminder',
  DOCUMENT_UPLOADED: 'document_uploaded',
} as const;

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
  from?: string;
  replyTo?: string;
}

/**
 * Send email via SendGrid API
 */
async function sendEmail(options: EmailOptions): Promise<{ success: boolean; messageId?: string; error?: string }> {
  const apiKey = process.env.SENDGRID_API_KEY;
  
  if (!apiKey) {
    console.log('[Email] SendGrid API key not configured, logging email instead');
    console.log('[Email] Would send to:', options.to);
    console.log('[Email] Subject:', options.subject);
    return { success: true, messageId: 'mock-' + Date.now() };
  }

  try {
    const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: options.to }] }],
        from: { email: options.from || 'noreply@synckaiden.com', name: 'Kaiden' },
        reply_to: options.replyTo ? { email: options.replyTo } : undefined,
        subject: options.subject,
        content: [
          { type: 'text/plain', value: options.text || options.html.replace(/<[^>]*>/g, '') },
          { type: 'text/html', value: options.html },
        ],
      }),
    });

    if (response.ok) {
      const messageId = response.headers.get('X-Message-Id') || 'sent-' + Date.now();
      console.log('[Email] Sent successfully:', messageId);
      return { success: true, messageId };
    } else {
      const error = await response.text();
      console.error('[Email] SendGrid error:', error);
      return { success: false, error };
    }
  } catch (error) {
    console.error('[Email] Failed to send:', error);
    return { success: false, error: String(error) };
  }
}

/**
 * Generate HTML email template with Kaiden branding
 */
function generateEmailTemplate(
  title: string,
  content: string,
  ctaText?: string,
  ctaUrl?: string
): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #0a1628; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #0a1628; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #1a2744 0%, #0f1d32 100%); border-radius: 16px; border: 1px solid rgba(192, 192, 192, 0.2);">
          <!-- Header -->
          <tr>
            <td style="padding: 32px 40px; border-bottom: 1px solid rgba(192, 192, 192, 0.1);">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td>
                    <div style="display: inline-block; width: 40px; height: 40px; background: linear-gradient(135deg, #c0c0c0 0%, #e8e8e8 100%); border-radius: 10px; text-align: center; line-height: 40px; font-weight: bold; color: #0a1628; font-size: 18px;">K</div>
                    <span style="color: #c0c0c0; font-size: 20px; font-weight: bold; margin-left: 12px; vertical-align: middle;">Kaiden</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 40px;">
              <h1 style="color: #ffffff; font-size: 24px; font-weight: 600; margin: 0 0 24px 0;">${title}</h1>
              <div style="color: rgba(192, 192, 192, 0.8); font-size: 16px; line-height: 1.6;">
                ${content}
              </div>
              ${ctaText && ctaUrl ? `
              <div style="margin-top: 32px;">
                <a href="${ctaUrl}" style="display: inline-block; padding: 14px 28px; background: linear-gradient(135deg, #c0c0c0 0%, #e8e8e8 100%); color: #0a1628; text-decoration: none; font-weight: 600; border-radius: 8px; font-size: 14px;">${ctaText}</a>
              </div>
              ` : ''}
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="padding: 24px 40px; border-top: 1px solid rgba(192, 192, 192, 0.1);">
              <p style="color: rgba(192, 192, 192, 0.5); font-size: 12px; margin: 0; line-height: 1.6;">
                This email was sent by Kaiden. We respect your privacy and never share your data.
                <br>
                <a href="https://synckaiden.com/unsubscribe" style="color: rgba(192, 192, 192, 0.5);">Unsubscribe</a> | 
                <a href="https://synckaiden.com/privacy" style="color: rgba(192, 192, 192, 0.5);">Privacy Policy</a>
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}

// Email notification functions
export async function sendPurchaseConfirmation(
  email: string,
  productName: string,
  amount: number,
  purchaseCode: string
) {
  const html = generateEmailTemplate(
    'Purchase Confirmed',
    `
      <p>Thank you for your purchase!</p>
      <div style="background: rgba(255, 255, 255, 0.05); border-radius: 8px; padding: 20px; margin: 20px 0;">
        <p style="margin: 0 0 12px 0;"><strong style="color: #ffffff;">Product:</strong> ${productName}</p>
        <p style="margin: 0 0 12px 0;"><strong style="color: #ffffff;">Amount:</strong> $${amount.toFixed(2)}</p>
        <p style="margin: 0;"><strong style="color: #ffffff;">Purchase Code:</strong></p>
        <div style="background: rgba(192, 192, 192, 0.1); border: 1px solid rgba(192, 192, 192, 0.3); border-radius: 6px; padding: 12px; margin-top: 8px; font-family: monospace; font-size: 14px; color: #c0c0c0; word-break: break-all;">
          ${purchaseCode}
        </div>
      </div>
      <p style="color: rgba(192, 192, 192, 0.6); font-size: 14px;">
        Keep this code safe - it's your unique license key for this product.
      </p>
    `,
    'Access Your Purchase',
    'https://synckaiden.com/dashboard/purchases'
  );

  return sendEmail({
    to: email,
    subject: `Purchase Confirmed: ${productName}`,
    html,
  });
}

export async function sendLicenseDelivery(
  email: string,
  productName: string,
  licenseKey: string,
  downloadUrl?: string
) {
  const html = generateEmailTemplate(
    'Your License Key',
    `
      <p>Here's your license key for <strong style="color: #ffffff;">${productName}</strong>:</p>
      <div style="background: rgba(192, 192, 192, 0.1); border: 1px solid rgba(192, 192, 192, 0.3); border-radius: 8px; padding: 16px; margin: 20px 0; font-family: monospace; font-size: 16px; color: #c0c0c0; text-align: center; word-break: break-all;">
        ${licenseKey}
      </div>
      ${downloadUrl ? `
      <p>You can also download your product directly:</p>
      <p><a href="${downloadUrl}" style="color: #c0c0c0;">Download Now</a></p>
      ` : ''}
      <p style="color: rgba(192, 192, 192, 0.6); font-size: 14px;">
        This license is tied to your account and cannot be transferred or shared.
      </p>
    `,
    'Activate License',
    'https://synckaiden.com/dashboard/licenses'
  );

  return sendEmail({
    to: email,
    subject: `Your License Key for ${productName}`,
    html,
  });
}

export async function sendWelcomeEmail(email: string, name: string) {
  const html = generateEmailTemplate(
    `Welcome to Kaiden, ${name}!`,
    `
      <p>We're thrilled to have you join the Kaiden family.</p>
      <p>Kaiden is your AI-powered business consultant, designed to help you:</p>
      <ul style="color: rgba(192, 192, 192, 0.8); padding-left: 20px;">
        <li>Automate repetitive tasks</li>
        <li>Build and manage your business</li>
        <li>Prepare taxes with confidence</li>
        <li>Track your financial health</li>
      </ul>
      <p>Get started by exploring our app store or syncing with Kaiden.</p>
    `,
    'Get Started',
    'https://synckaiden.com/dashboard'
  );

  return sendEmail({
    to: email,
    subject: 'Welcome to Kaiden - Restore Your Time',
    html,
  });
}

export async function sendTaxReminder(
  email: string,
  reminderType: 'quarterly' | 'deadline' | 'document',
  details: string
) {
  const titles = {
    quarterly: 'Quarterly Tax Payment Reminder',
    deadline: 'Tax Deadline Approaching',
    document: 'Missing Tax Document',
  };

  const html = generateEmailTemplate(
    titles[reminderType],
    `
      <p>${details}</p>
      <p>Log in to KAI(DEN) TAX to take action.</p>
    `,
    'View Tax Dashboard',
    'https://synckaiden.com/apps/kaidenta'
  );

  return sendEmail({
    to: email,
    subject: titles[reminderType],
    html,
  });
}

export async function sendPaymentFailedNotification(
  email: string,
  productName: string,
  amount: number
) {
  const html = generateEmailTemplate(
    'Payment Failed',
    `
      <p>We were unable to process your payment for <strong style="color: #ffffff;">${productName}</strong>.</p>
      <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; padding: 16px; margin: 20px 0;">
        <p style="margin: 0; color: #ef4444;"><strong>Amount:</strong> $${amount.toFixed(2)}</p>
      </div>
      <p>Please update your payment method to continue using this service.</p>
    `,
    'Update Payment Method',
    'https://synckaiden.com/dashboard/billing'
  );

  return sendEmail({
    to: email,
    subject: 'Payment Failed - Action Required',
    html,
  });
}

// tRPC router for email operations
export const emailRouter = router({
  // Send test email (for development)
  sendTestEmail: protectedProcedure
    .input(z.object({
      to: z.string().email(),
      template: z.enum(['welcome', 'purchase', 'license', 'tax_reminder']),
    }))
    .mutation(async ({ input }) => {
      switch (input.template) {
        case 'welcome':
          return sendWelcomeEmail(input.to, 'Test User');
        case 'purchase':
          return sendPurchaseConfirmation(input.to, 'Test Product', 9.99, 'TEST-CODE-12345');
        case 'license':
          return sendLicenseDelivery(input.to, 'Test Product', 'LICENSE-KEY-ABCDE');
        case 'tax_reminder':
          return sendTaxReminder(input.to, 'quarterly', 'Your Q2 estimated tax payment is due in 14 days.');
        default:
          return { success: false, error: 'Unknown template' };
      }
    }),

  // Get email preferences
  getPreferences: protectedProcedure.query(async ({ ctx }) => {
    // In production, fetch from database
    return {
      marketing: false,
      transactional: true,
      taxReminders: true,
      paymentAlerts: true,
    };
  }),

  // Update email preferences
  updatePreferences: protectedProcedure
    .input(z.object({
      marketing: z.boolean().optional(),
      transactional: z.boolean().optional(),
      taxReminders: z.boolean().optional(),
      paymentAlerts: z.boolean().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      // In production, save to database
      console.log('[Email] Updated preferences for user:', ctx.user.id, input);
      return { success: true };
    }),
});

export type EmailRouter = typeof emailRouter;
