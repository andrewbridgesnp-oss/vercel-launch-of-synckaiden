/**
 * User Behavior Tracking Module
 * Tracks user interactions and engagement
 */

import { getDb } from '../db';
import { userBehavior, customEvents, funnelAnalysis } from '../../drizzle/analytics-schema';
import { eq, gte, lt, and } from 'drizzle-orm';

export interface BehaviorEvent {
  userId: string;
  eventType: string;
  eventName: string;
  eventValue?: string;
  pageUrl?: string;
  referrer?: string;
  sessionId?: string;
  duration?: number;
  metadata?: any;
}

export interface FunnelStep {
  userId: string;
  funnelName: string;
  step: number;
  stepName: string;
  completed: boolean;
}

export class UserBehaviorTracker {
  /**
   * Track a user behavior event
   */
  async trackEvent(event: BehaviorEvent) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db.insert(userBehavior).values({
      userId: event.userId,
      eventType: event.eventType,
      eventName: event.eventName,
      eventValue: event.eventValue,
      pageUrl: event.pageUrl,
      referrer: event.referrer,
      sessionId: event.sessionId,
      duration: event.duration,
      metadata: event.metadata,
    });
  }

  /**
   * Track a custom event
   */
  async trackCustomEvent(
    userId: string,
    eventCategory: string,
    eventAction: string,
    eventLabel?: string,
    eventValue?: string,
    metadata?: any
  ) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db.insert(customEvents).values({
      userId,
      eventCategory,
      eventAction,
      eventLabel,
      eventValue,
      metadata,
    });
  }

  /**
   * Track funnel step completion
   */
  async trackFunnelStep(step: FunnelStep) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db.insert(funnelAnalysis).values({
      userId: step.userId,
      funnelName: step.funnelName,
      step: step.step,
      stepName: step.stepName,
      completed: step.completed,
      completedAt: step.completed ? new Date() : undefined,
    });
  }

  /**
   * Get user engagement score (0-100)
   */
  async getUserEngagementScore(userId: string): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const events = await db
      .select()
      .from(userBehavior)
      .where(eq(userBehavior.userId, userId));

    if (events.length === 0) return 0;

    // Calculate engagement based on event frequency and types
    const eventTypes = new Set(events.map((e) => e.eventType));
    const eventFrequency = events.length;
    const uniqueEventTypes = eventTypes.size;

    // Score calculation: 0-100
    const frequencyScore = Math.min((eventFrequency / 100) * 50, 50);
    const diversityScore = Math.min((uniqueEventTypes / 10) * 50, 50);

    return Math.round(frequencyScore + diversityScore);
  }

  /**
   * Get user session duration average
   */
  async getUserAvgSessionDuration(userId: string): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const events = await db
      .select()
      .from(userBehavior)
      .where(eq(userBehavior.userId, userId));

    if (events.length === 0) return 0;

    const totalDuration = events.reduce((sum, e) => sum + (e.duration || 0), 0);
    return Math.round(totalDuration / events.length);
  }

  /**
   * Get user retention cohort
   */
  async getUserRetentionCohort(userId: string, days: number = 30): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);

    const recentEvents = await db
      .select()
      .from(userBehavior)
      .where(and(eq(userBehavior.userId, userId), gte(userBehavior.createdAt, cutoffDate)));

    // Retention score based on activity in the period
    const eventCount = recentEvents.length;
    return Math.min(Math.round((eventCount / 10) * 100), 100);
  }

  /**
   * Get most common user paths
   */
  async getUserCommonPaths(userId: string, limit: number = 10) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const events = await db
      .select()
      .from(userBehavior)
      .where(eq(userBehavior.userId, userId))
      .orderBy(userBehavior.createdAt);

    // Build paths from events
    const paths: string[] = [];
    let currentPath = '';

    events.forEach((event, index) => {
      currentPath += `${event.eventName}`;

      if (index > 0 && index % 5 === 0) {
        paths.push(currentPath);
        currentPath = '';
      } else if (index < events.length - 1) {
        currentPath += ' -> ';
      }
    });

    if (currentPath) paths.push(currentPath);

    return paths.slice(0, limit);
  }

  /**
   * Get user feature adoption
   */
  async getUserFeatureAdoption(userId: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const events = await db
      .select()
      .from(customEvents)
      .where(eq(customEvents.userId, userId));

    const adoption = new Map<string, number>();

    events.forEach((event) => {
      const feature = event.eventAction;
      adoption.set(feature, (adoption.get(feature) || 0) + 1);
    });

    return Array.from(adoption.entries())
      .map(([feature, count]) => ({
        feature,
        adoptionScore: Math.min(count * 10, 100),
      }))
      .sort((a, b) => b.adoptionScore - a.adoptionScore);
  }

  /**
   * Get user churn risk score
   */
  async getUserChurnRisk(userId: string): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Get events from last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const recentEvents = await db
      .select()
      .from(userBehavior)
      .where(and(eq(userBehavior.userId, userId), gte(userBehavior.createdAt, thirtyDaysAgo)));

    if (recentEvents.length === 0) return 100; // High churn risk if no recent activity

    // Get events from 30-60 days ago
    const sixtyDaysAgo = new Date();
    sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);

    const previousEvents = await db
      .select()
      .from(userBehavior)
      .where(and(
        eq(userBehavior.userId, userId),
        gte(userBehavior.createdAt, sixtyDaysAgo),
        lt(userBehavior.createdAt, thirtyDaysAgo)
      ));

    if (previousEvents.length === 0) return 50; // Medium risk if no previous activity

    // Calculate trend
    const trend = recentEvents.length / previousEvents.length;

    if (trend > 0.8) return 10; // Low risk - stable/growing
    if (trend > 0.5) return 30; // Medium-low risk
    if (trend > 0.2) return 60; // Medium-high risk
    return 85; // High risk - significant decline
  }

  /**
   * Get cohort analysis data
   */
  async getCohortAnalysis(cohortName: string, retentionDays: number[] = [0, 7, 14, 30]) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // This would typically aggregate data from cohortAnalysis table
    // For now, returning structure
    return {
      cohortName,
      retentionDays,
      data: [], // Would be populated from database
    };
  }
}

export const userBehaviorTracker = new UserBehaviorTracker();
