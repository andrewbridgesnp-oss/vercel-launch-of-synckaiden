import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Building2, ArrowLeft, ArrowRight, CheckCircle2, AlertTriangle, 
  Download, ExternalLink, Search, FileText, Scale, Copy, Printer
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

// State Secretary of State websites for name search
const STATE_SOS_LINKS: Record<string, { search: string; file: string; fee: number }> = {
  "Alabama": { search: "https://arc-sos.state.al.us/cgi/corpname.mbr/output", file: "https://www.sos.alabama.gov/business-entities", fee: 200 },
  "Alaska": { search: "https://www.commerce.alaska.gov/cbp/main/search/entities", file: "https://www.commerce.alaska.gov/web/cbpl/corporations", fee: 250 },
  "Arizona": { search: "https://ecorp.azcc.gov/EntitySearch/Index", file: "https://azcc.gov/corporations", fee: 50 },
  "Arkansas": { search: "https://www.sos.arkansas.gov/corps/search_all.php", file: "https://www.sos.arkansas.gov/business-commercial-services-bcs", fee: 50 },
  "California": { search: "https://bizfileonline.sos.ca.gov/search/business", file: "https://www.sos.ca.gov/business-programs/business-entities/forms", fee: 70 },
  "Colorado": { search: "https://www.sos.state.co.us/biz/BusinessEntityCriteriaExt.do", file: "https://www.sos.state.co.us/pubs/business/main.html", fee: 50 },
  "Connecticut": { search: "https://service.ct.gov/business/s/onlinebusinesssearch", file: "https://portal.ct.gov/SOTS/Business-Services", fee: 120 },
  "Delaware": { search: "https://icis.corp.delaware.gov/ecorp/entitysearch/namesearch.aspx", file: "https://corp.delaware.gov/howtoform/", fee: 90 },
  "Florida": { search: "https://search.sunbiz.org/Inquiry/CorporationSearch/ByName", file: "https://dos.myflorida.com/sunbiz/start-business/efile/fl-llc/", fee: 125 },
  "Georgia": { search: "https://ecorp.sos.ga.gov/BusinessSearch", file: "https://sos.ga.gov/corporations-division", fee: 100 },
  "Hawaii": { search: "https://hbe.ehawaii.gov/documents/search.html", file: "https://cca.hawaii.gov/breg/", fee: 50 },
  "Idaho": { search: "https://sosbiz.idaho.gov/search/business", file: "https://sos.idaho.gov/business-services/", fee: 100 },
  "Illinois": { search: "https://apps.ilsos.gov/corporatellc/", file: "https://www.ilsos.gov/departments/business_services/llc.html", fee: 150 },
  "Indiana": { search: "https://bsd.sos.in.gov/publicbusinesssearch", file: "https://www.in.gov/sos/business/start-a-business/", fee: 95 },
  "Iowa": { search: "https://sos.iowa.gov/search/business/search.aspx", file: "https://sos.iowa.gov/business/FormsAndFees.html", fee: 50 },
  "Kansas": { search: "https://www.kansas.gov/bess/flow/main?execution=e1s1", file: "https://sos.ks.gov/business/business.html", fee: 165 },
  "Kentucky": { search: "https://web.sos.ky.gov/ftshow/(S(...))/default.aspx", file: "https://www.sos.ky.gov/bus/business-filings/Pages/default.aspx", fee: 40 },
  "Louisiana": { search: "https://coraweb.sos.la.gov/commercialsearch/commercialsearch.aspx", file: "https://www.sos.la.gov/BusinessServices/Pages/default.aspx", fee: 100 },
  "Maine": { search: "https://icrs.informe.org/nei-sos-icrs/ICRS", file: "https://www.maine.gov/sos/cec/corp/", fee: 175 },
  "Maryland": { search: "https://egov.maryland.gov/BusinessExpress/EntitySearch", file: "https://dat.maryland.gov/businesses", fee: 100 },
  "Massachusetts": { search: "https://corp.sec.state.ma.us/corpweb/CorpSearch/CorpSearch.aspx", file: "https://www.sec.state.ma.us/cor/coridx.htm", fee: 500 },
  "Michigan": { search: "https://cofs.lara.state.mi.us/corpweb/CorpSearch/CorpSearch.aspx", file: "https://www.michigan.gov/lara/bureau-list/cscl/corps", fee: 50 },
  "Minnesota": { search: "https://mblsportal.sos.state.mn.us/Business/Search", file: "https://www.sos.state.mn.us/business-liens/start-a-business/", fee: 155 },
  "Mississippi": { search: "https://corp.sos.ms.gov/corp/portal/c/page/corpBusinessIdSearch/portal.aspx", file: "https://www.sos.ms.gov/business-services", fee: 50 },
  "Missouri": { search: "https://bsd.sos.mo.gov/BusinessEntity/BESearch.aspx", file: "https://www.sos.mo.gov/business", fee: 50 },
  "Montana": { search: "https://biz.sosmt.gov/search", file: "https://sosmt.gov/business/", fee: 70 },
  "Nebraska": { search: "https://www.nebraska.gov/sos/corp/corpsearch.cgi", file: "https://sos.nebraska.gov/business-services", fee: 105 },
  "Nevada": { search: "https://esos.nv.gov/EntitySearch/OnlineEntitySearch", file: "https://www.nvsos.gov/sos/businesses", fee: 425 },
  "New Hampshire": { search: "https://quickstart.sos.nh.gov/online/BusinessInquire", file: "https://www.sos.nh.gov/corporation-division", fee: 100 },
  "New Jersey": { search: "https://www.njportal.com/DOR/BusinessNameSearch/", file: "https://www.nj.gov/treasury/revenue/dcr/geninfo/nj_llc.shtml", fee: 125 },
  "New Mexico": { search: "https://portal.sos.state.nm.us/BFS/online/CorporationBusinessSearch", file: "https://www.sos.state.nm.us/business-services/", fee: 50 },
  "New York": { search: "https://apps.dos.ny.gov/publicInquiry/", file: "https://dos.ny.gov/forming-limited-liability-company-llc", fee: 200 },
  "North Carolina": { search: "https://www.sosnc.gov/online_services/search/by_title/_Business_Registration", file: "https://www.sosnc.gov/divisions/business_registration", fee: 125 },
  "North Dakota": { search: "https://firststop.sos.nd.gov/search/business", file: "https://sos.nd.gov/business/business-services", fee: 135 },
  "Ohio": { search: "https://businesssearch.ohiosos.gov/", file: "https://www.ohiosos.gov/businesses/", fee: 99 },
  "Oklahoma": { search: "https://www.sos.ok.gov/corp/corpInquiryFind.aspx", file: "https://www.sos.ok.gov/business/", fee: 100 },
  "Oregon": { search: "https://egov.sos.state.or.us/br/pkg_web_name_srch_inq.login", file: "https://sos.oregon.gov/business/Pages/register.aspx", fee: 100 },
  "Pennsylvania": { search: "https://www.corporations.pa.gov/search/corpsearch", file: "https://www.dos.pa.gov/BusinessCharities/Business/Pages/default.aspx", fee: 125 },
  "Rhode Island": { search: "https://business.sos.ri.gov/CorpWeb/CorpSearch/CorpSearch.aspx", file: "https://www.sos.ri.gov/divisions/business-services", fee: 150 },
  "South Carolina": { search: "https://businessfilings.sc.gov/BusinessFiling/Entity/Search", file: "https://sos.sc.gov/online-filings", fee: 110 },
  "South Dakota": { search: "https://sosenterprise.sd.gov/BusinessServices/Business/FilingSearch.aspx", file: "https://sdsos.gov/business-services/", fee: 150 },
  "Tennessee": { search: "https://tnbear.tn.gov/Ecommerce/FilingSearch.aspx", file: "https://sos.tn.gov/business-services", fee: 300 },
  "Texas": { search: "https://mycpa.cpa.state.tx.us/coa/", file: "https://www.sos.texas.gov/corp/forms_702.shtml", fee: 300 },
  "Utah": { search: "https://secure.utah.gov/bes/", file: "https://corporations.utah.gov/", fee: 54 },
  "Vermont": { search: "https://bizfilings.vermont.gov/online/BusinessInquire", file: "https://sos.vermont.gov/corporations/", fee: 125 },
  "Virginia": { search: "https://cis.scc.virginia.gov/", file: "https://www.scc.virginia.gov/pages/Virginia-Limited-Liability-Company", fee: 100 },
  "Washington": { search: "https://ccfs.sos.wa.gov/#/BusinessSearch", file: "https://www.sos.wa.gov/corps/", fee: 200 },
  "West Virginia": { search: "https://apps.wv.gov/SOS/BusinessEntitySearch/", file: "https://sos.wv.gov/business/Pages/default.aspx", fee: 100 },
  "Wisconsin": { search: "https://www.wdfi.org/apps/CorpSearch/Search.aspx", file: "https://www.wdfi.org/corporations/", fee: 130 },
  "Wyoming": { search: "https://wyobiz.wyo.gov/Business/FilingSearch.aspx", file: "https://sos.wyo.gov/Business/", fee: 100 },
};

const US_STATES = Object.keys(STATE_SOS_LINKS);

export default function LLCFormation() {
  const [step, setStep] = useState(1);
  const [nameAvailable, setNameAvailable] = useState<boolean | null>(null);
  const [generatedDocs, setGeneratedDocs] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  
  const [formData, setFormData] = useState({
    // Step 1 - Basic Info
    businessName: "",
    state: "",
    // Step 2 - Business Details
    businessPurpose: "",
    businessType: "",
    // Step 3 - Members
    members: [] as { name: string; address: string; ownership: string }[],
    managementType: "member-managed",
    // Step 4 - Registered Agent
    agentType: "self",
    agentName: "",
    agentAddress: "",
    agentCity: "",
    agentState: "",
    agentZip: "",
    // Step 5 - Principal Office
    principalAddress: "",
    principalCity: "",
    principalState: "",
    principalZip: "",
    // Step 6 - Additional
    effectiveDate: "immediate",
    duration: "perpetual",
    organizer: "",
  });

  const chatMutation = trpc.chat.sendMessage.useMutation();
  const generateArticlesPDF = trpc.pdf.generateLLCDocument.useMutation();

  const handleNameSearch = () => {
    if (!formData.state || !formData.businessName) {
      toast.error("Enter business name and select state first");
      return;
    }
    const stateInfo = STATE_SOS_LINKS[formData.state];
    if (stateInfo) {
      window.open(stateInfo.search, "_blank");
      toast.info("Name Search Opened", {
        description: "Check if your business name is available in the state database",
      });
    }
  };

  const handleAddMember = () => {
    setFormData({
      ...formData,
      members: [...formData.members, { name: "", address: "", ownership: "" }],
    });
  };

  const handleRemoveMember = (index: number) => {
    setFormData({
      ...formData,
      members: formData.members.filter((_, i) => i !== index),
    });
  };

  const handleUpdateMember = (index: number, field: string, value: string) => {
    const newMembers = [...formData.members];
    newMembers[index] = { ...newMembers[index], [field]: value };
    setFormData({ ...formData, members: newMembers });
  };

  const generateArticlesOfOrganization = async () => {
    setIsGenerating(true);
    try {
      const prompt = `Generate a complete Articles of Organization document for an LLC with the following details:

Business Name: ${formData.businessName}
State of Formation: ${formData.state}
Business Purpose: ${formData.businessPurpose || "Any lawful business purpose"}
Management Type: ${formData.managementType}
Duration: ${formData.duration}
Effective Date: ${formData.effectiveDate}

Registered Agent:
Name: ${formData.agentType === "self" ? formData.members[0]?.name || formData.organizer : formData.agentName}
Address: ${formData.agentType === "self" ? formData.principalAddress : formData.agentAddress}
City: ${formData.agentType === "self" ? formData.principalCity : formData.agentCity}
State: ${formData.agentType === "self" ? formData.principalState : formData.agentState}
ZIP: ${formData.agentType === "self" ? formData.principalZip : formData.agentZip}

Principal Office:
${formData.principalAddress}
${formData.principalCity}, ${formData.principalState} ${formData.principalZip}

Members/Organizers:
${formData.members.map((m, i) => `${i + 1}. ${m.name} - ${m.ownership}% ownership - ${m.address}`).join("\n")}

Organizer: ${formData.organizer}

Format this as a professional legal document with proper sections, numbered articles, and signature blocks. Include all required elements for ${formData.state} LLC formation. Add a disclaimer that this is for educational purposes and should be reviewed by an attorney.`;

      const response = await chatMutation.mutateAsync({
        conversationId: 1,
        content: prompt,
      });

      setGeneratedDocs({
        articlesOfOrganization: response.assistantMessage.content,
        state: formData.state,
        businessName: formData.businessName,
      });
      
      toast.success("Documents Generated!", {
        description: "Your Articles of Organization have been drafted",
      });
    } catch (error) {
      toast.error("Generation failed", {
        description: "Please try again or contact support",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const generateOperatingAgreement = async () => {
    setIsGenerating(true);
    try {
      const prompt = `Generate a comprehensive Operating Agreement for ${formData.businessName}, a ${formData.state} LLC with the following structure:

Management Type: ${formData.managementType}
Members:
${formData.members.map((m, i) => `${i + 1}. ${m.name} - ${m.ownership}% ownership interest`).join("\n")}

Include these sections:
1. Formation and Name
2. Purpose
3. Principal Place of Business
4. Term/Duration
5. Capital Contributions
6. Allocations of Profits and Losses
7. Distributions
8. Management and Voting
9. Meetings
10. Transfer of Membership Interests
11. Dissolution
12. Miscellaneous Provisions
13. Signature Blocks

Make it comprehensive but readable. Add a disclaimer that this is for educational purposes and should be reviewed by an attorney before use.`;

      const response = await chatMutation.mutateAsync({
        conversationId: 1,
        content: prompt,
      });

      setGeneratedDocs((prev: any) => ({
        ...prev,
        operatingAgreement: response.assistantMessage.content,
      }));
      
      toast.success("Operating Agreement Generated!", {
        description: "Your Operating Agreement has been drafted",
      });
    } catch (error) {
      toast.error("Generation failed", {
        description: "Please try again",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text: string, docName: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${docName} copied to clipboard`);
  };

  const stateInfo = formData.state ? STATE_SOS_LINKS[formData.state] : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/business-tools">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <Building2 className="h-8 w-8 text-primary" />
              LLC Formation Wizard
            </h1>
            <p className="text-muted-foreground">Complete guide to forming your Limited Liability Company</p>
          </div>
        </div>

        {/* Legal Disclaimer */}
        <Card className="mb-6 border-amber-500/30 bg-amber-500/5">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-semibold text-amber-600">Educational Tool - Not Legal Advice</p>
                <p className="text-muted-foreground">
                  This tool provides general information and document templates for educational purposes only. 
                  LLC requirements vary by state. Always consult a licensed attorney before filing. 
                  Kayden AI is not a law firm and does not provide legal advice.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress Steps */}
        <div className="flex items-center gap-2 mb-8 overflow-x-auto pb-2">
          {["Basic Info", "Business Details", "Members", "Registered Agent", "Principal Office", "Review & Generate"].map((label, i) => (
            <div key={i} className="flex items-center">
              <div 
(Content truncated due to size limit. Use page ranges or line ranges to read remaining content)