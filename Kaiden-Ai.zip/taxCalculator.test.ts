/**
 * KAI(DEN) TAX - Tax Calculator Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  calculateFederalTax,
  TAX_BRACKETS_2025,
  STANDARD_DEDUCTIONS_2025,
  formatCurrency,
  formatPercent,
  TaxInput,
} from './taxCalculator';

describe('Tax Calculator', () => {
  // Default test input
  const defaultInput: TaxInput = {
    filingStatus: 'single',
    wages: 75000,
    selfEmploymentIncome: 0,
    interestIncome: 0,
    dividendIncome: 0,
    qualifiedDividends: 0,
    shortTermGains: 0,
    longTermGains: 0,
    otherIncome: 0,
    federalWithholding: 10000,
    stateWithholding: 3000,
    itemizedDeductions: 0,
    useItemized: false,
    traditionalIraContribution: 0,
    hsaContribution: 0,
    studentLoanInterest: 0,
    selfEmploymentHealthInsurance: 0,
    numDependentsUnder17: 0,
    numDependents17Plus: 0,
    educationExpenses: 0,
    childCareExpenses: 0,
    retirementContributions: 0,
    isOver65: false,
    isBlind: false,
  };

  describe('Basic Tax Calculation', () => {
    it('should calculate tax for single filer with W-2 income', () => {
      const result = calculateFederalTax(defaultInput);
      
      expect(result.grossIncome).toBe(75000);
      expect(result.adjustedGrossIncome).toBe(75000);
      expect(result.taxableIncome).toBe(75000 - STANDARD_DEDUCTIONS_2025.single);
      expect(result.totalTax).toBeGreaterThan(0);
      expect(result.effectiveRate).toBeGreaterThan(0);
      expect(result.effectiveRate).toBeLessThan(25); // Reasonable effective rate
    });

    it('should calculate correct standard deduction for each filing status', () => {
      const filingStatuses: Array<keyof typeof STANDARD_DEDUCTIONS_2025> = [
        'single',
        'married_filing_jointly',
        'married_filing_separately',
        'head_of_household',
        'qualifying_widow',
      ];

      for (const status of filingStatuses) {
        const input = { ...defaultInput, filingStatus: status };
        const result = calculateFederalTax(input);
        expect(result.taxableIncome).toBe(75000 - STANDARD_DEDUCTIONS_2025[status]);
      }
    });

    it('should use itemized deductions when higher than standard', () => {
      const input = {
        ...defaultInput,
        itemizedDeductions: 20000,
        useItemized: true,
      };
      const result = calculateFederalTax(input);
      
      // Itemized ($20,000) > Standard ($14,600 for single)
      expect(result.taxableIncome).toBe(75000 - 20000);
    });

    it('should use standard deduction when itemized is lower', () => {
      const input = {
        ...defaultInput,
        itemizedDeductions: 10000,
        useItemized: true,
      };
      const result = calculateFederalTax(input);
      
      // Standard ($14,600) > Itemized ($10,000)
      expect(result.taxableIncome).toBe(75000 - STANDARD_DEDUCTIONS_2025.single);
    });
  });

  describe('Self-Employment Tax', () => {
    it('should calculate self-employment tax correctly', () => {
      const input = {
        ...defaultInput,
        wages: 0,
        selfEmploymentIncome: 50000,
      };
      const result = calculateFederalTax(input);
      
      // SE tax should be approximately 15.3% of 92.35% of SE income
      const expectedSETax = 50000 * 0.9235 * 0.153;
      expect(result.selfEmploymentTax).toBeCloseTo(expectedSETax, -2); // Within $100
    });

    it('should deduct half of SE tax from AGI', () => {
      const input = {
        ...defaultInput,
        wages: 0,
        selfEmploymentIncome: 50000,
      };
      const result = calculateFederalTax(input);
      
      // AGI should be reduced by half of SE tax
      expect(result.adjustedGrossIncome).toBeLessThan(50000);
    });
  });

  describe('Adjustments (Above-the-line Deductions)', () => {
    it('should deduct Traditional IRA contributions', () => {
      const input = {
        ...defaultInput,
        traditionalIraContribution: 7000,
      };
      const result = calculateFederalTax(input);
      
      expect(result.adjustedGrossIncome).toBe(75000 - 7000);
    });

    it('should cap IRA deduction at limit', () => {
      const input = {
        ...defaultInput,
        traditionalIraContribution: 10000, // Over limit
      };
      const result = calculateFederalTax(input);
      
      // Should only deduct $7,000 (2025 limit)
      expect(result.adjustedGrossIncome).toBe(75000 - 7000);
    });

    it('should deduct HSA contributions', () => {
      const input = {
        ...defaultInput,
        hsaContribution: 4300,
      };
      const result = calculateFederalTax(input);
      
      expect(result.adjustedGrossIncome).toBe(75000 - 4300);
    });

    it('should deduct student loan interest up to $2,500', () => {
      const input = {
        ...defaultInput,
        studentLoanInterest: 3000,
      };
      const result = calculateFederalTax(input);
      
      // Should only deduct $2,500 (limit)
      expect(result.adjustedGrossIncome).toBe(75000 - 2500);
    });
  });

  describe('Tax Credits', () => {
    it('should calculate Child Tax Credit', () => {
      const input = {
        ...defaultInput,
        numDependentsUnder17: 2,
      };
      const result = calculateFederalTax(input);
      
      // $2,000 per child
      expect(result.childTaxCredit).toBe(4000);
    });

    it('should phase out Child Tax Credit for high earners', () => {
      const input = {
        ...defaultInput,
        wages: 250000,
        numDependentsUnder17: 2,
        federalWithholding: 50000,
      };
      const result = calculateFederalTax(input);
      
      // Should be reduced due to income over $200,000
      expect(result.childTaxCredit).toBeLessThan(4000);
    });

    it('should calculate Education Credit', () => {
      const input = {
        ...defaultInput,
        educationExpenses: 4000,
      };
      const result = calculateFederalTax(input);
      
      // American Opportunity Credit: 100% of first $2,000 + 25% of next $2,000
      expect(result.educationCredit).toBe(2500);
    });

    it('should calculate Retirement Savings Credit', () => {
      const input = {
        ...defaultInput,
        wages: 20000,
        retirementContributions: 2000,
        federalWithholding: 2000,
      };
      const result = calculateFederalTax(input);
      
      // Should get 50% credit for low income
      expect(result.retirementSavingsCredit).toBe(1000);
    });
  });

  describe('Capital Gains', () => {
    it('should apply preferential rates to long-term gains', () => {
      const inputWithLTCG = {
        ...defaultInput,
        wages: 50000,
        longTermGains: 10000,
      };
      const inputWithSTCG = {
        ...defaultInput,
        wages: 50000,
        shortTermGains: 10000,
      };
      
      const resultLTCG = calculateFederalTax(inputWithLTCG);
      const resultSTCG = calculateFederalTax(inputWithSTCG);
      
      // Long-term gains should result in lower tax
      expect(resultLTCG.totalTax).toBeLessThan(resultSTCG.totalTax);
    });

    it('should apply 0% rate for low-income long-term gains', () => {
      const input = {
        ...defaultInput,
        wages: 30000,
        longTermGains: 5000,
        federalWithholding: 3000,
      };
      const result = calculateFederalTax(input);
      
      // Capital gains tax should be 0 for income under threshold
      expect(result.capitalGainsTax).toBe(0);
    });
  });

  describe('Refund/Owed Calculation', () => {
    it('should calculate refund when withholding exceeds tax', () => {
      const input = {
        ...defaultInput,
        federalWithholding: 15000, // High withholding
      };
      const result = calculateFederalTax(input);
      
      expect(result.refundOrOwed).toBeGreaterThan(0);
    });

    it('should calculate amount owed when tax exceeds withholding', () => {
      const input = {
        ...defaultInput,
        federalWithholding: 5000, // Low withholding
      };
      const result = calculateFederalTax(input);
      
      expect(result.refundOrOwed).toBeLessThan(0);
    });
  });

  describe('Tax Rates', () => {
    it('should calculate correct effective tax rate', () => {
      const result = calculateFederalTax(defaultInput);
      
      // Effective rate = tax / gross income * 100
      const expectedRate = (result.taxAfterCredits / result.grossIncome) * 100;
      expect(result.effectiveRate).toBeCloseTo(expectedRate, 1);
    });

    it('should identify correct marginal rate', () => {
      const input = {
        ...defaultInput,
        wages: 100000,
      };
      const result = calculateFederalTax(input);
      
      // $100k single filer should be in 22% bracket
      expect(result.marginalRate).toBe(22);
    });
  });

  describe('Breakdown Generation', () => {
    it('should generate breakdown items', () => {
      const result = calculateFederalTax(defaultInput);
      
      expect(result.breakdown).toBeDefined();
      expect(result.breakdown.length).toBeGreaterThan(0);
      
      // Should have income, deduction, tax, and payment items
      const types = result.breakdown.map(b => b.type);
      expect(types).toContain('income');
      expect(types).toContain('deduction');
      expect(types).toContain('tax');
      expect(types).toContain('payment');
    });
  });

  describe('Formatting Functions', () => {
    it('should format currency correctly', () => {
      expect(formatCurrency(1234)).toBe('$1,234');
      expect(formatCurrency(1234567)).toBe('$1,234,567');
      expect(formatCurrency(0)).toBe('$0');
    });

    it('should format percentage correctly', () => {
      expect(formatPercent(12.5)).toBe('12.5%');
      expect(formatPercent(0)).toBe('0.0%');
      expect(formatPercent(100)).toBe('100.0%');
    });
  });

  describe('Edge Cases', () => {
    it('should handle zero income', () => {
      const input = {
        ...defaultInput,
        wages: 0,
        federalWithholding: 0,
      };
      const result = calculateFederalTax(input);
      
      expect(result.grossIncome).toBe(0);
      expect(result.totalTax).toBe(0);
      expect(result.effectiveRate).toBe(0);
    });

    it('should handle very high income', () => {
      const input = {
        ...defaultInput,
        wages: 1000000,
        federalWithholding: 300000,
      };
      const result = calculateFederalTax(input);
      
      // Should be in top bracket (37%)
      expect(result.marginalRate).toBe(37);
      expect(result.totalTax).toBeGreaterThan(200000);
    });

    it('should handle additional standard deduction for 65+', () => {
      const input = {
        ...defaultInput,
        isOver65: true,
      };
      const result = calculateFederalTax(input);
      
      // Should have higher deduction
      const standardDeduction = STANDARD_DEDUCTIONS_2025.single + 1950; // Additional for 65+
      expect(result.taxableIncome).toBe(75000 - standardDeduction);
    });
  });
});
