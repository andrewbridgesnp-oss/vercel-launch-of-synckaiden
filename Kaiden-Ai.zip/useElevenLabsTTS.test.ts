/**
 * Unit tests for ElevenLabs TTS hook
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { renderHook, act, waitFor } from '@testing-library/react';
import { useElevenLabsTTS } from './useElevenLabsTTS';

describe('useElevenLabsTTS', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    global.fetch = vi.fn();
  });

  it('should initialize with correct default state', () => {
    const { result } = renderHook(() => useElevenLabsTTS());

    expect(result.current.isLoading).toBe(false);
    expect(result.current.isPlaying).toBe(false);
    expect(result.current.error).toBe(null);
    expect(result.current.duration).toBe(0);
  });

  it('should synthesize text successfully', async () => {
    const mockAudioUrl = 'blob:audio/mpeg;base64,test';
    const mockResponse = {
      audioUrl: mockAudioUrl,
      duration: 5,
      voiceId: 'test-voice',
      modelId: 'test-model',
    };

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockResponse,
    });

    const { result } = renderHook(() => useElevenLabsTTS());

    await act(async () => {
      await result.current.synthesize('Hello world');
    });

    expect(result.current.isLoading).toBe(false);
    expect(result.current.error).toBe(null);
    expect(result.current.duration).toBe(5);
  });

  it('should handle synthesis errors', async () => {
    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: false,
      json: async () => ({ message: 'API Error' }),
    });

    const { result } = renderHook(() => useElevenLabsTTS());

    await act(async () => {
      try {
        await result.current.synthesize('Test');
      } catch (e) {
        // Expected error
      }
    });

    expect(result.current.error).toBeTruthy();
  });

  it('should reject empty text', async () => {
    const { result } = renderHook(() => useElevenLabsTTS());

    await act(async () => {
      try {
        await result.current.synthesize('');
      } catch (e) {
        // Expected error
      }
    });

    expect(result.current.error).toBe('Text cannot be empty');
  });

  it('should manage audio playback state', async () => {
    const { result } = renderHook(() => useElevenLabsTTS());

    // Mock audio element
    const mockAudio = {
      play: vi.fn().mockResolvedValue(undefined),
      pause: vi.fn(),
      currentTime: 0,
      src: '',
    };

    // Set up audio
    await act(async () => {
      result.current.audioRef.current = mockAudio as any;
    });

    // Test play
    await act(async () => {
      await result.current.play();
    });

    expect(result.current.isPlaying).toBe(true);

    // Test pause
    act(() => {
      result.current.pause();
    });

    expect(result.current.isPlaying).toBe(false);
  });

  it('should support custom voice options', async () => {
    const customOptions = {
      voiceId: 'custom-voice-123',
      stability: 0.8,
      similarityBoost: 0.9,
    };

    const mockResponse = {
      audioUrl: 'blob:test',
      duration: 3,
      voiceId: customOptions.voiceId,
      modelId: 'test-model',
    };

    global.fetch = vi.fn().mockResolvedValueOnce({
      ok: true,
      json: async () => mockResponse,
    });

    const { result } = renderHook(() => useElevenLabsTTS(customOptions));

    await act(async () => {
      await result.current.synthesize('Test with custom voice');
    });

    expect(global.fetch).toHaveBeenCalledWith(
      '/api/tts/synthesize',
      expect.objectContaining({
        body: expect.stringContaining(customOptions.voiceId),
      })
    );
  });
});
