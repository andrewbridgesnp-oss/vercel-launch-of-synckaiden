/**
 * App Registry & License Management
 * Manages app registration, licensing, and independent scaling
 */

export interface AppLicense {
  appId: string;
  userId: number;
  tier: 'free' | 'starter' | 'pro' | 'enterprise';
  status: 'trial' | 'active' | 'paused' | 'expired';
  licenseKey?: string;
  installedAt: Date;
  expiresAt?: Date;
  config: Record<string, any>;
}

export interface AppMetadata {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'finance' | 'real-estate' | 'data' | 'productivity' | 'ai' | 'other';
  version: string;
  author: string;
  website?: string;
  
  // App-specific pricing tiers
  pricing: {
    free: {
      price: 0;
      features: string[];
      limits: Record<string, number>;
    };
    tiers: {
      name: string;
      price: number;
      features: string[];
      limits: Record<string, number>;
    }[];
  };
  
  // App-specific features
  features: string[];
  
  // App-specific scaling rules
  scaling: {
    minInstances: number;
    maxInstances: number;
    cpuThreshold: number;
    memoryThreshold: number;
  };
  
  status: 'active' | 'beta' | 'coming-soon';
  integrations: string[];
  route: string;
  requiredPermissions?: string[];
}

export interface AppRegistry {
  [appId: string]: AppMetadata;
}

export interface AppInstance {
  appId: string;
  userId: number;
  license: AppLicense;
  isActive: boolean;
  lastUsed?: Date;
}

class AppRegistryManager {
  private registry: AppRegistry = {};
  private userLicenses: Map<string, AppLicense[]> = new Map();

  /**
   * Register a new app in the platform
   */
  registerApp(metadata: AppMetadata): void {
    if (this.registry[metadata.id]) {
      console.warn(`App ${metadata.id} already registered, updating...`);
    }
    this.registry[metadata.id] = metadata;
  }

  /**
   * Get all registered apps
   */
  getApps(): AppMetadata[] {
    return Object.values(this.registry);
  }

  /**
   * Get app by ID
   */
  getApp(appId: string): AppMetadata | undefined {
    return this.registry[appId];
  }

  /**
   * Get apps by category
   */
  getAppsByCategory(category: string): AppMetadata[] {
    return Object.values(this.registry).filter(app => app.category === category);
  }

  /**
   * Install app for user (creates license)
   */
  installApp(
    appId: string,
    userId: number,
    tier: 'free' | 'starter' | 'pro' | 'enterprise' = 'free',
    config?: Record<string, any>
  ): AppLicense {
    const app = this.registry[appId];
    if (!app) {
      throw new Error(`App ${appId} not found in registry`);
    }

    const license: AppLicense = {
      appId,
      userId,
      tier,
      status: tier === 'free' ? 'active' : 'trial',
      licenseKey: this.generateLicenseKey(appId, userId),
      installedAt: new Date(),
      expiresAt: tier === 'free' ? undefined : new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14 day trial
      config: config || {},
    };

    const key = `${userId}`;
    if (!this.userLicenses.has(key)) {
      this.userLicenses.set(key, []);
    }
    this.userLicenses.get(key)!.push(license);

    return license;
  }

  /**
   * Get user's app licenses
   */
  getUserLicenses(userId: number): AppLicense[] {
    return this.userLicenses.get(`${userId}`) || [];
  }

  /**
   * Get specific app license for user
   */
  getAppLicense(userId: number, appId: string): AppLicense | undefined {
    const licenses = this.userLicenses.get(`${userId}`) || [];
    return licenses.find(l => l.appId === appId);
  }

  /**
   * Check if user has access to app feature
   */
  hasFeatureAccess(userId: number, appId: string, feature: string): boolean {
    const license = this.getAppLicense(userId, appId);
    if (!license) return false;

    const app = this.registry[appId];
    if (!app) return false;

    // Check if license is active
    if (license.status !== 'active' && license.status !== 'trial') {
      return false;
    }

    // Check if tier has feature
    if (license.tier === 'free') {
      return app.pricing.free.features.includes(feature);
    }

    const tierConfig = app.pricing.tiers.find(t => t.name.toLowerCase() === license.tier);
    return tierConfig?.features.includes(feature) || false;
  }

  /**
   * Check if user has exceeded usage limit
   */
  checkUsageLimit(
    userId: number,
    appId: string,
    limitKey: string,
    currentUsage: number
  ): boolean {
    const license = this.getAppLicense(userId, appId);
    if (!license) return false;

    const app = this.registry[appId];
    if (!app) return false;

    let limit = 0;

    if (license.tier === 'free') {
      limit = app.pricing.free.limits[limitKey] || 0;
    } else {
      const tierConfig = app.pricing.tiers.find(t => t.name.toLowerCase() === license.tier);
      limit = tierConfig?.limits[limitKey] || 0;
    }

    return currentUsage >= limit;
  }

  /**
   * Upgrade app license
   */
  upgradeLicense(
    userId: number,
    appId: string,
    newTier: 'starter' | 'pro' | 'enterprise'
  ): AppLicense | undefined {
    const license = this.getAppLicense(userId, appId);
    if (!license) return undefined;

    license.tier = newTier;
    license.status = 'active';
    license.expiresAt = undefined; // Paid licenses don't expire
    return license;
  }

  /**
   * Downgrade app license
   */
  downgradeLicense(userId: number, appId: string): AppLicense | undefined {
    const license = this.getAppLicense(userId, appId);
    if (!license) return undefined;

    license.tier = 'free';
    license.status = 'active';
    license.expiresAt = undefined;
    return license;
  }

  /**
   * Cancel app license
   */
  cancelLicense(userId: number, appId: string): boolean {
    const licenses = this.userLicenses.get(`${userId}`);
    if (!licenses) return false;

    const index = licenses.findIndex(l => l.appId === appId);
    if (index === -1) return false;

    licenses[index].status = 'expired';
    return true;
  }

  /**
   * Get app scaling rules
   */
  getScalingRules(appId: string) {
    const app = this.registry[appId];
    if (!app) return undefined;

    return app.scaling;
  }

  /**
   * Get featured apps
   */
  getFeaturedApps(): AppMetadata[] {
    return Object.values(this.registry)
      .filter(app => app.status === 'active')
      .slice(0, 6);
  }

  /**
   * Search apps
   */
  searchApps(query: string): AppMetadata[] {
    const lowerQuery = query.toLowerCase();
    return Object.values(this.registry).filter(app =>
      app.name.toLowerCase().includes(lowerQuery) ||
      app.description.toLowerCase().includes(lowerQuery) ||
      app.features.some(f => f.toLowerCase().includes(lowerQuery))
    );
  }

  /**
   * Generate license key
   */
  private generateLicenseKey(appId: string, userId: number): string {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `${appId.toUpperCase()}-${userId}-${timestamp}-${random}`;
  }

  /**
   * Validate license key
   * Format: APPID-USERID-TIMESTAMP-RANDOM (e.g., BUILDWEALTH-PRO-3-1768208500000-ABC123)
   */
  validateLicenseKey(licenseKey: string): boolean {
    // Match format: uppercase letters/hyphens, number, number, alphanumeric
    return /^[A-Z-]+-\d+-\d+-[A-Z0-9]+$/.test(licenseKey);
  }
}

// Export singleton instance
export const appRegistry = new AppRegistryManager();

// Export manager class for testing
export default AppRegistryManager;
