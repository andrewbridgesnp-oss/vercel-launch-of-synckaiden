/**
 * Mobile-Optimized Personality Card Carousel
 * 
 * Features:
 * - Touch swipe support
 * - Keyboard navigation
 * - Responsive design
 * - Smooth animations
 * - Accessibility support
 */

import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PersonalityCard {
  id: string;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  tagline: string;
  description: string;
  color: string;
  traits: string[];
  recommended: string[];
}

interface PersonalityCarouselProps {
  items: PersonalityCard[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  renderCard: (item: PersonalityCard, isSelected: boolean) => React.ReactNode;
}

export function PersonalityCarousel({
  items,
  selectedId,
  onSelect,
  renderCard,
}: PersonalityCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const carouselRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Get number of visible cards based on screen size
  const getVisibleCards = () => {
    if (typeof window === 'undefined') return 3;
    const width = window.innerWidth;
    if (width < 640) return 1; // Mobile
    if (width < 1024) return 2; // Tablet
    return 3; // Desktop
  };

  const [visibleCards, setVisibleCards] = useState(getVisibleCards());

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setVisibleCards(getVisibleCards());
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Handle touch swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
    setIsDragging(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    setIsDragging(false);

    if (!touchStart || !touchEnd) return;

    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe) {
      handleNext();
    }
    if (isRightSwipe) {
      handlePrev();
    }
  };

  // Navigation handlers
  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? Math.max(0, items.length - visibleCards) : prev - 1));
  };

  const handleNext = () => {
    const maxIndex = Math.max(0, items.length - visibleCards);
    setCurrentIndex((prev) => (prev >= maxIndex ? 0 : prev + 1));
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        handlePrev();
      } else if (e.key === 'ArrowRight') {
        handleNext();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [visibleCards]);

  const visibleItems = items.slice(currentIndex, currentIndex + visibleCards);
  const maxIndex = Math.max(0, items.length - visibleCards);
  const showPrevButton = currentIndex > 0;
  const showNextButton = currentIndex < maxIndex;

  return (
    <div className="relative w-full">
      {/* Main Carousel Container */}
      <div
        ref={containerRef}
        className="relative overflow-hidden"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Carousel Track */}
        <div
          ref={carouselRef}
          className="flex gap-6 md:gap-8 transition-transform duration-300 ease-out"
          style={{
            transform: `translateX(-${currentIndex * (100 / visibleCards)}%)`,
            width: `${(items.length / visibleCards) * 100}%`,
          }}
        >
          {items.map((item) => (
            <div
              key={item.id}
              className="flex-shrink-0"
              style={{ width: `${100 / items.length}%` }}
              onClick={() => onSelect(item.id)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  onSelect(item.id);
                }
              }}
            >
              {renderCard(item, selectedId === item.id)}
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Buttons - Desktop */}
      {visibleCards > 1 && (
        <>
          {showPrevButton && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-12 md:-translate-x-16 z-10 hidden md:flex"
              onClick={handlePrev}
              aria-label="Previous personality"
            >
              <ChevronLeft className="h-6 w-6" />
            </Button>
          )}

          {showNextButton && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-12 md:translate-x-16 z-10 hidden md:flex"
              onClick={handleNext}
              aria-label="Next personality"
            >
              <ChevronRight className="h-6 w-6" />
            </Button>
          )}
        </>
      )}

      {/* Dot Indicators - Mobile */}
      {visibleCards === 1 && items.length > 1 && (
        <div className="flex justify-center gap-2 mt-6 md:hidden">
          {items.map((_, index) => (
            <button
              key={index}
              className={`h-2 rounded-full transition-all ${
                index === currentIndex ? 'bg-primary w-6' : 'bg-muted-foreground/30 w-2'
              }`}
              onClick={() => setCurrentIndex(index)}
              aria-label={`Go to personality ${index + 1}`}
            />
          ))}
        </div>
      )}

      {/* Swipe Hint - Mobile */}
      {visibleCards === 1 && items.length > 1 && !isDragging && (
        <div className="text-center mt-4 md:hidden">
          <p className="text-xs text-muted-foreground">Swipe to explore personalities</p>
        </div>
      )}
    </div>
  );
}

export default PersonalityCarousel;
