import React, { createContext, useContext, useState, useEffect } from "react";
import { Artifact, DetectedApp, MergePlan, KpiStats, IngestSource, ArtifactType } from "../types";
import { toast } from "sonner";

export interface IngestRule {
  id: string;
  pattern: string;
  destination: string;
  description: string;
  active: boolean;
}

interface AppState {
  artifacts: Artifact[];
  apps: DetectedApp[];
  mergePlan: MergePlan | null;
  stats: KpiStats;
  rules: IngestRule[];
  isLoading: boolean;
  processingStage: string | null;
}

interface AppContextType extends AppState {
  ingestZip: (files: File[]) => Promise<void>;
  connectGithub: (repo: string, branch: string) => Promise<void>;
  scanDomain: (domain: string) => Promise<void>;
  generateMergePlan: () => Promise<void>;
  resolveConflict: (conflictId: string, resolution: "KeepExisting" | "Overwrite" | "Merge") => void;
  executeMerge: () => Promise<void>;
  addRule: (rule: Omit<IngestRule, "id">) => void;
  toggleRule: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>({
    artifacts: [],
    apps: [],
    mergePlan: null,
    stats: {
      artifactsIngested: 124,
      appsDetected: 8,
      modulesDetected: 32,
      conflictsPending: 0,
      lastSyncTime: new Date().toISOString(),
    },
    rules: [
      { id: "r1", pattern: "**/*.tsx", destination: "/src/components", description: "React Components", active: true },
      { id: "r2", pattern: "**/*.test.ts", destination: "/tests", description: "Test Files", active: true },
      { id: "r3", pattern: "**/assets/**/*", destination: "/public/assets", description: "Static Assets", active: true },
    ],
    isLoading: false,
    processingStage: null
  });

  // Load initial mock data
  useEffect(() => {
    // Simulate loading existing registry
    setTimeout(() => {
      setState(prev => ({
        ...prev,
        apps: [
          {
            id: "app-1",
            name: "Syndica Core",
            description: "Main ingestion engine",
            framework: "React + Vite",
            version: "1.0.2",
            modules: ["mod-1", "mod-2"],
            artifacts: ["art-1", "art-2"],
            status: "Active",
            lastSync: new Date(Date.now() - 86400000).toISOString(),
          },
          {
            id: "app-2",
            name: "Auth Service",
            description: "Centralized authentication provider",
            framework: "Node.js",
            version: "2.1.0",
            modules: [],
            artifacts: [],
            status: "Active",
            lastSync: new Date(Date.now() - 172800000).toISOString(),
          }
        ],
        artifacts: [
          { id: "art-1", name: "App.tsx", type: "App", source: "GitHub", sourceDetails: "syndica/core", path: "/src/App.tsx", lastUpdated: new Date().toISOString(), status: "Complete", tags: ["react", "core"] },
          { id: "art-2", name: "utils.ts", type: "Module", source: "GitHub", sourceDetails: "syndica/core", path: "/src/utils.ts", lastUpdated: new Date().toISOString(), status: "Complete", tags: ["utility"] },
        ]
      }));
    }, 1000);
  }, []);

  const ingestZip = async (files: File[]) => {
    setState(prev => ({ ...prev, isLoading: true, processingStage: "Uploading bundles..." }));
    
    // Simulate complex processing stages
    await new Promise(resolve => setTimeout(resolve, 1500));
    setState(prev => ({ ...prev, processingStage: "Extracting archives..." }));
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    setState(prev => ({ ...prev, processingStage: "Analyzing file structure..." }));
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    setState(prev => ({ ...prev, processingStage: "Applying organization rules..." }));
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newArtifacts: Artifact[] = files.map((f, i) => ({
      id: `new-zip-${Date.now()}-${i}`,
      name: f.name,
      type: "App",
      source: "ZIP",
      sourceDetails: f.name,
      path: `/src/imports/${f.name.replace(".zip", "")}`,
      size: f.size,
      lastUpdated: new Date().toISOString(),
      status: "Complete",
      tags: ["uploaded", "zip", "auto-organized"]
    }));

    setState(prev => ({
      ...prev,
      isLoading: false,
      processingStage: null,
      artifacts: [...prev.artifacts, ...newArtifacts],
      stats: {
        ...prev.stats,
        artifactsIngested: prev.stats.artifactsIngested + files.length,
        conflictsPending: prev.stats.conflictsPending + 1 
      }
    }));
    toast.success(`Successfully ingested and organized ${files.length} bundles`);
  };

  const addRule = (rule: Omit<IngestRule, "id">) => {
    setState(prev => ({
      ...prev,
      rules: [...prev.rules, { ...rule, id: `rule-${Date.now()}` }]
    }));
    toast.success("Organization rule added");
  };

  const toggleRule = (id: string) => {
    setState(prev => ({
      ...prev,
      rules: prev.rules.map(r => r.id === id ? { ...r, active: !r.active } : r)
    }));
  };

  const connectGithub = async (repo: string, branch: string) => {
    setState(prev => ({ ...prev, isLoading: true }));
    toast.info(`Connecting to ${repo} on branch ${branch}...`);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    toast.success("GitHub repository synced");
    setState(prev => ({ ...prev, isLoading: false }));
  };

  const scanDomain = async (domain: string) => {
    setState(prev => ({ ...prev, isLoading: true }));
    toast.info(`Scanning ${domain}...`);
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    toast.success("Domain scan complete. 14 pages found.");
    setState(prev => ({ ...prev, isLoading: false }));
  };

  const generateMergePlan = async () => {
    setState(prev => ({ ...prev, isLoading: true }));
    toast.info("Analyzing conflicts and dependencies...");
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const plan: MergePlan = {
      id: `plan-${Date.now()}`,
      timestamp: new Date().toISOString(),
      additions: [],
      upgrades: [],
      conflicts: [
        {
          id: "conf-1",
          artifactId: "art-1",
          path: "/src/App.tsx",
          diff: `@@ -1,5 +1,5 @@\n- import { Old } from "./old";\n+ import { New } from "./new";`,
          status: "Open"
        }
      ],
      status: "Draft"
    };
    
    setState(prev => ({ ...prev, isLoading: false, mergePlan: plan }));
    toast.success("Merge plan generated");
  };

  const resolveConflict = (conflictId: string, resolution: "KeepExisting" | "Overwrite" | "Merge") => {
    setState(prev => {
      if (!prev.mergePlan) return prev;
      return {
        ...prev,
        mergePlan: {
          ...prev.mergePlan,
          conflicts: prev.mergePlan.conflicts.map(c => 
            c.id === conflictId ? { ...c, resolution, status: "Resolved" } : c
          )
        }
      };
    });
    toast.success("Conflict resolved");
  };

  const executeMerge = async () => {
    setState(prev => ({ ...prev, isLoading: true }));
    await new Promise(resolve => setTimeout(resolve, 2000));
    setState(prev => ({ ...prev, isLoading: false, mergePlan: null }));
    toast.success("Merge executed successfully. Registry updated.");
  };

  return (
    <AppContext.Provider value={{ 
      ...state, 
      ingestZip, 
      connectGithub, 
      scanDomain, 
      generateMergePlan,
      resolveConflict,
      executeMerge,
      addRule,
      toggleRule
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
};
