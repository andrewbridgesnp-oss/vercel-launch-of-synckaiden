interface RealisticLogoProps {
  className?: string;
  variant?: "full" | "icon";
}

export function RealisticLogo({ className = "", variant = "full" }: RealisticLogoProps) {
  if (variant === "icon") {
    return (
      <svg className={className} viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Shield Background with Metallic Effect */}
        <defs>
          <linearGradient id="shieldGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: "#1a2942", stopOpacity: 1 }} />
            <stop offset="50%" style={{ stopColor: "#0a1628", stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: "#050d18", stopOpacity: 1 }} />
          </linearGradient>
          <linearGradient id="silverGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: "#e8e8e8", stopOpacity: 1 }} />
            <stop offset="30%" style={{ stopColor: "#c0c0c0", stopOpacity: 1 }} />
            <stop offset="70%" style={{ stopColor: "#a0a0a0", stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: "#c0c0c0", stopOpacity: 1 }} />
          </linearGradient>
          <linearGradient id="goldGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: "#f4e4b8", stopOpacity: 1 }} />
            <stop offset="30%" style={{ stopColor: "#d4af37", stopOpacity: 1 }} />
            <stop offset="70%" style={{ stopColor: "#b8941f", stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: "#d4af37", stopOpacity: 1 }} />
          </linearGradient>
          <linearGradient id="leatherGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: "#8b6f47", stopOpacity: 1 }} />
            <stop offset="50%" style={{ stopColor: "#6b5535", stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: "#4a3821", stopOpacity: 1 }} />
          </linearGradient>
          <filter id="shadow">
            <feDropShadow dx="0" dy="4" stdDeviation="3" floodOpacity="0.5"/>
          </filter>
          <filter id="innerShadow">
            <feGaussianBlur in="SourceAlpha" stdDeviation="2"/>
            <feOffset dx="0" dy="2" result="offsetblur"/>
            <feComponentTransfer>
              <feFuncA type="linear" slope="0.5"/>
            </feComponentTransfer>
            <feMerge>
              <feMergeNode/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        {/* Shield Shape */}
        <path 
          d="M100 20 L160 45 L160 110 C160 145 135 170 100 180 C65 170 40 145 40 110 L40 45 Z" 
          fill="url(#shieldGradient)" 
          filter="url(#shadow)"
          stroke="url(#silverGradient)"
          strokeWidth="3"
        />

        {/* Tool Belt wrapped around shield */}
        <path 
          d="M45 90 Q50 95 100 100 Q150 95 155 90 L155 115 Q150 120 100 125 Q50 120 45 115 Z" 
          fill="url(#leatherGradient)" 
          filter="url(#innerShadow)"
        />
        
        {/* Belt Buckle - Gold */}
        <rect x="90" y="95" width="20" height="15" rx="2" fill="url(#goldGradient)" stroke="#b8941f" strokeWidth="1"/>
        <circle cx="100" cy="102.5" r="3" fill="#8b6f47"/>

        {/* Belt Stitching Details */}
        <line x1="50" y1="92" x2="55" y2="92" stroke="#4a3821" strokeWidth="1" strokeDasharray="2,2"/>
        <line x1="145" y1="92" x2="150" y2="92" stroke="#4a3821" strokeWidth="1" strokeDasharray="2,2"/>
        <line x1="50" y1="113" x2="55" y2="113" stroke="#4a3821" strokeWidth="1" strokeDasharray="2,2"/>
        <line x1="145" y1="113" x2="150" y2="113" stroke="#4a3821" strokeWidth="1" strokeDasharray="2,2"/>

        {/* Tape Measure on Left */}
        <ellipse cx="70" cy="102" rx="12" ry="13" fill="#ffd700" filter="url(#shadow)"/>
        <ellipse cx="70" cy="102" rx="10" ry="11" fill="#1a1a1a"/>
        <circle cx="70" cy="102" r="3" fill="url(#goldGradient)"/>
        {/* Tape measure markings */}
        <line x1="62" y1="102" x2="64" y2="102" stroke="#ffd700" strokeWidth="0.5"/>
        <line x1="76" y1="102" x2="78" y2="102" stroke="#ffd700" strokeWidth="0.5"/>
        <line x1="70" y1="95" x2="70" y2="97" stroke="#ffd700" strokeWidth="0.5"/>
        
        {/* Tape extending out with realistic markings */}
        <rect x="55" y="100" width="8" height="4" fill="#f4f4f4" stroke="#333" strokeWidth="0.5"/>
        <line x1="56" y1="100" x2="56" y2="104" stroke="#dc2626" strokeWidth="0.3"/>
        <line x1="57.5" y1="101" x2="57.5" y2="103" stroke="#333" strokeWidth="0.2"/>
        <line x1="59" y1="100" x2="59" y2="104" stroke="#dc2626" strokeWidth="0.3"/>
        <line x1="60.5" y1="101" x2="60.5" y2="103" stroke="#333" strokeWidth="0.2"/>
        <line x1="62" y1="100" x2="62" y2="104" stroke="#dc2626" strokeWidth="0.3"/>

        {/* Hammer on Right Side */}
        <rect x="125" y="96" width="6" height="16" rx="1" fill="url(#leatherGradient)"/>
        <path d="M124 96 L126 92 L134 92 L136 96 Z" fill="#4a4a4a" stroke="#2a2a2a" strokeWidth="0.5"/>
        <rect x="126" y="90" width="6" height="4" fill="#6b6b6b" stroke="#2a2a2a" strokeWidth="0.5"/>
        <ellipse cx="129" cy="90" rx="3" ry="1.5" fill="#8a8a8a"/>

        {/* C Letter - Metallic Silver with 3D depth */}
        <path 
          d="M100 50 C85 50 75 60 75 75 C75 90 85 100 100 100 L100 90 C90 90 85 85 85 75 C85 65 90 60 100 60 Z" 
          fill="url(#silverGradient)" 
          filter="url(#shadow)"
          stroke="#a0a0a0"
          strokeWidth="2"
        />
        
        {/* Highlight on C for metallic effect */}
        <path 
          d="M77 65 C77 62 79 58 82 56" 
          stroke="#f0f0f0" 
          strokeWidth="2" 
          strokeLinecap="round"
          opacity="0.6"
        />
      </svg>
    );
  }

  // Full Logo
  return (
    <svg className={className} viewBox="0 0 600 300" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Definitions */}
      <defs>
        <linearGradient id="fullShieldGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" style={{ stopColor: "#1a2942", stopOpacity: 1 }} />
          <stop offset="50%" style={{ stopColor: "#0a1628", stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: "#050d18", stopOpacity: 1 }} />
        </linearGradient>
        <linearGradient id="fullSilverGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" style={{ stopColor: "#e8e8e8", stopOpacity: 1 }} />
          <stop offset="30%" style={{ stopColor: "#c0c0c0", stopOpacity: 1 }} />
          <stop offset="70%" style={{ stopColor: "#a0a0a0", stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: "#c0c0c0", stopOpacity: 1 }} />
        </linearGradient>
        <linearGradient id="fullGoldGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" style={{ stopColor: "#f4e4b8", stopOpacity: 1 }} />
          <stop offset="30%" style={{ stopColor: "#d4af37", stopOpacity: 1 }} />
          <stop offset="70%" style={{ stopColor: "#b8941f", stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: "#d4af37", stopOpacity: 1 }} />
        </linearGradient>
        <linearGradient id="fullLeatherGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" style={{ stopColor: "#8b6f47", stopOpacity: 1 }} />
          <stop offset="50%" style={{ stopColor: "#6b5535", stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: "#4a3821", stopOpacity: 1 }} />
        </linearGradient>
        <filter id="fullShadow">
          <feDropShadow dx="0" dy="6" stdDeviation="4" floodOpacity="0.6"/>
        </filter>
        <filter id="textShadow">
          <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity="0.4"/>
        </filter>
      </defs>

      {/* Shield Icon */}
      <path 
        d="M80 60 L140 85 L140 150 C140 185 115 210 80 220 C45 210 20 185 20 150 L20 85 Z" 
        fill="url(#fullShieldGradient)" 
        filter="url(#fullShadow)"
        stroke="url(#fullSilverGradient)"
        strokeWidth="3"
      />

      {/* Tool Belt on Shield */}
      <path 
        d="M25 130 Q30 135 80 140 Q130 135 135 130 L135 155 Q130 160 80 165 Q30 160 25 155 Z" 
        fill="url(#fullLeatherGradient)"
      />
      <rect x="70" y="135" width="20" height="15" rx="2" fill="url(#fullGoldGradient)" stroke="#b8941f" strokeWidth="1"/>
      <circle cx="80" cy="142.5" r="3" fill="#8b6f47"/>

      {/* Tape Measure */}
      <ellipse cx="50" cy="142" rx="12" ry="13" fill="#ffd700" filter="url(#fullShadow)"/>
      <ellipse cx="50" cy="142" rx="10" ry="11" fill="#1a1a1a"/>
      <circle cx="50" cy="142" r="3" fill="url(#fullGoldGradient)"/>
      <rect x="35" y="140" width="8" height="4" fill="#f4f4f4" stroke="#333" strokeWidth="0.5"/>
      <line x1="36" y1="140" x2="36" y2="144" stroke="#dc2626" strokeWidth="0.3"/>
      <line x1="38" y1="140" x2="38" y2="144" stroke="#dc2626" strokeWidth="0.3"/>
      <line x1="40" y1="140" x2="40" y2="144" stroke="#dc2626" strokeWidth="0.3"/>

      {/* Hammer */}
      <rect x="105" y="136" width="6" height="16" rx="1" fill="url(#fullLeatherGradient)"/>
      <path d="M104 136 L106 132 L114 132 L116 136 Z" fill="#4a4a4a" stroke="#2a2a2a" strokeWidth="0.5"/>
      <rect x="106" y="130" width="6" height="4" fill="#6b6b6b" stroke="#2a2a2a" strokeWidth="0.5"/>

      {/* C Letter */}
      <path 
        d="M80 90 C65 90 55 100 55 115 C55 130 65 140 80 140 L80 130 C70 130 65 125 65 115 C65 105 70 100 80 100 Z" 
        fill="url(#fullSilverGradient)" 
        filter="url(#fullShadow)"
        stroke="#a0a0a0"
        strokeWidth="2"
      />

      {/* Company Name - COX */}
      <text x="170" y="100" fontFamily="Arial Black,sans-serif" fontSize="56" fontWeight="900" fill="url(#fullSilverGradient)" filter="url(#textShadow)">
        COX
      </text>
      
      {/* Ampersand - Gold */}
      <text x="310" y="100" fontFamily="Georgia,serif" fontSize="56" fontWeight="bold" fill="url(#fullGoldGradient)" filter="url(#textShadow)" fontStyle="italic">
        &amp;
      </text>
      
      {/* CO. */}
      <text x="370" y="100" fontFamily="Arial Black,sans-serif" fontSize="56" fontWeight="900" fill="url(#fullSilverGradient)" filter="url(#textShadow)">
        CO.
      </text>

      {/* PROFESSIONAL SERVICES */}
      <text x="170" y="140" fontFamily="Arial,sans-serif" fontSize="22" fontWeight="600" fill="#c0c0c0" letterSpacing="4">
        PROFESSIONAL SERVICES
      </text>

      {/* LLC */}
      <text x="170" y="170" fontFamily="Arial,sans-serif" fontSize="18" fontWeight="600" fill="#a0a0a0" letterSpacing="3">
        LLC
      </text>

      {/* Tagline */}
      <g opacity="0.8">
        <text x="170" y="200" fontFamily="Arial,sans-serif" fontSize="14" fontWeight="500" fill="#d4af37" fontStyle="italic">
          Licensed
        </text>
        <circle cx="245" cy="196" r="2" fill="#d4af37"/>
        <text x="255" y="200" fontFamily="Arial,sans-serif" fontSize="14" fontWeight="500" fill="#d4af37" fontStyle="italic">
          Bonded
        </text>
        <circle cx="320" cy="196" r="2" fill="#d4af37"/>
        <text x="330" y="200" fontFamily="Arial,sans-serif" fontSize="14" fontWeight="500" fill="#d4af37" fontStyle="italic">
          Insured
        </text>
      </g>

      {/* Construction Icon Details */}
      <line x1="30" y1="132" x2="35" y2="132" stroke="#4a3821" strokeWidth="1" strokeDasharray="2,2"/>
      <line x1="125" y1="132" x2="130" y2="132" stroke="#4a3821" strokeWidth="1" strokeDasharray="2,2"/>
    </svg>
  );
}
