import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  Building2,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Download,
  ExternalLink,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

// State Secretary of State websites
const STATE_SOS_LINKS: Record<
  string,
  { search: string; file: string; fee: number }
> = {
  Alabama: {
    search: "https://arc-sos.state.al.us/cgi/corpname.mbr/output",
    file: "https://www.sos.alabama.gov/business-entities",
    fee: 200,
  },
  Alaska: {
    search: "https://www.commerce.alaska.gov/cbp/main/search/entities",
    file: "https://www.commerce.alaska.gov/web/cbpl/corporations",
    fee: 250,
  },
  Arizona: {
    search: "https://ecorp.azcc.gov/EntitySearch/Index",
    file: "https://azcc.gov/corporations",
    fee: 50,
  },
  California: {
    search: "https://bizfileonline.sos.ca.gov/search/business",
    file: "https://www.sos.ca.gov/business-programs/business-entities/forms",
    fee: 70,
  },
  Colorado: {
    search: "https://www.sos.state.co.us/biz/BusinessEntityCriteriaExt.do",
    file: "https://www.sos.state.co.us/pubs/business/main.html",
    fee: 50,
  },
  Delaware: {
    search: "https://icis.corp.delaware.gov/ecorp/entitysearch/namesearch.aspx",
    file: "https://corp.delaware.gov/howtoform/",
    fee: 90,
  },
  Florida: {
    search: "https://search.sunbiz.org/Inquiry/CorporationSearch/ByName",
    file: "https://dos.myflorida.com/sunbiz/start-business/efile/fl-llc/",
    fee: 125,
  },
  Texas: {
    search: "https://mycpa.cpa.state.tx.us/coa/",
    file: "https://www.sos.texas.gov/corp/forms_702.shtml",
    fee: 300,
  },
  Nevada: {
    search: "https://esos.nv.gov/EntitySearch/OnlineEntitySearch",
    file: "https://www.nvsos.gov/sos/businesses",
    fee: 425,
  },
  NewYork: {
    search: "https://apps.dos.ny.gov/publicInquiry/",
    file: "https://dos.ny.gov/forming-limited-liability-company-llc",
    fee: 200,
  },
};

const US_STATES = Object.keys(STATE_SOS_LINKS);

export default function LLCFormationWizard() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    businessName: "",
    state: "",
    businessPurpose: "",
    businessType: "",
    members: [] as { name: string; address: string; ownership: string }[],
    managementType: "member-managed",
    agentType: "self",
    agentName: "",
    agentAddress: "",
    principalAddress: "",
    principalCity: "",
    principalState: "",
    principalZip: "",
    effectiveDate: "immediate",
    duration: "perpetual",
    organizer: "",
  });

  const generateArticlesPDF = trpc.pdf.generateLLCDocument.useMutation();

  const handleNameSearch = () => {
    if (!formData.state || !formData.businessName) {
      toast.error("Enter business name and select state first");
      return;
    }
    const stateInfo = STATE_SOS_LINKS[formData.state];
    if (stateInfo) {
      window.open(stateInfo.search, "_blank");
      toast.info("Name Search Opened", {
        description: "Check if your business name is available in the state database",
      });
    }
  };

  const handleAddMember = () => {
    setFormData({
      ...formData,
      members: [...formData.members, { name: "", address: "", ownership: "" }],
    });
  };

  const handleRemoveMember = (index: number) => {
    setFormData({
      ...formData,
      members: formData.members.filter((_, i) => i !== index),
    });
  };

  const handleUpdateMember = (index: number, field: string, value: string) => {
    const newMembers = [...formData.members];
    newMembers[index] = { ...newMembers[index], [field]: value };
    setFormData({ ...formData, members: newMembers });
  };

  const generateDocuments = async () => {
    try {
      const result = await generateArticlesPDF.mutateAsync({
        businessName: formData.businessName,
        state: formData.state,
        businessPurpose: formData.businessPurpose || "Any lawful business purpose",
        managementType: formData.managementType,
        duration: formData.duration,
        effectiveDate: formData.effectiveDate,
        members: formData.members,
        principalAddress: formData.principalAddress,
        agentName: formData.agentType === "self" ? formData.members[0]?.name : formData.agentName,
        agentAddress: formData.agentType === "self" ? formData.principalAddress : formData.agentAddress,
      });

      toast.success("Documents Generated!", {
        description: "Your LLC formation documents are ready to download.",
      });

      // Trigger download
      const link = document.createElement("a");
      link.href = result.pdfUrl;
      link.download = `${formData.businessName}-LLC-Formation.pdf`;
      link.click();
    } catch (error) {
      toast.error("Error generating documents");
      console.error(error);
    }
  };

  const stateInfo = formData.state ? STATE_SOS_LINKS[formData.state] : null;

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Building2 className="w-12 h-12 text-cyan-400" />
        </div>
        <h2 className="text-4xl font-bold mb-2" style={{
          background: "linear-gradient(135deg, #e0e0e8 0%, #ffffff 50%, #c0c0d0 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}>
          LLC Formation Wizard
        </h2>
        <p className="text-gray-400">
          Step-by-step guide to forming your Limited Liability Company
        </p>
      </div>

      {/* Progress Indicator */}
      <div className="flex items-center justify-between mb-8">
        {[1, 2, 3, 4, 5, 6].map((s) => (
          <div key={s} className="flex items-center">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                s <= step
                  ? "bg-cyan-500 text-white"
                  : "bg-gray-700 text-gray-400"
              }`}
            >
              {s}
            </div>
            {s < 6 && (
              <div
                className={`w-12 h-1 mx-2 ${
                  s < step ? "bg-cyan-500" : "bg-gray-700"
                }`}
              />
            )}
          </div>
        ))}
      </div>

      {/* Step 1: Basic Info */}
      {step === 1 && (
        <Card className="glass border-border/50">
          <CardHeader>
            <CardTitle>Step 1: Business Name & State</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-300">Business Name</Label>
              <Input
                placeholder="Enter your LLC name"
                value={formData.businessName}
                onChange={(e) =>
                  setFormData({ ...formData, businessName: e.target.value })
                }
                className="bg-background/50 border-border/50 text-gray-200 mt-2"
              />
            </div>

            <div>
              <Label className="text-gray-300">State of Formation</Label>
              <Select value={formData.state} onValueChange={(value) =>
                setFormData({ ...formData, state: value })
              }>
                <SelectTrigger className="bg-background/50 border-border/50 text-gray-200 mt-2">
                  <SelectValue placeholder="Select a state" />
                </SelectTrigger>
                <SelectContent>
                  {US_STATES.map((state) => (
                    <SelectItem key={state} value={state}>
                      {state}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {stateInfo && (
              <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                <p className="text-sm text-gray-300 mb-3">
                  <strong>Filing Fee:</strong> ${stateInfo.fee}
                </p>
                <Button
                  onClick={handleNameSearch}
                  variant="outline"
                  className="w-full border-blue-500/50"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Search Name Availability
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 2: Business Details */}
      {step === 2 && (
        <Card className="glass border-border/50">
          <CardHeader>
            <CardTitle>Step 2: Business Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-300">Business Purpose</Label>
              <Textarea
                placeholder="Describe the purpose of your LLC"
                value={formData.businessPurpose}
                onChange={(e) =>
                  setFormData({ ...formData, businessPurpose: e.target.value })
                }
                className="bg-background/50 border-border/50 text-gray-200 mt-2"
              />
            </div>

            <div>
              <Label className="text-gray-300">Business Type</Label>
              <Select value={formData.businessType} onValueChange={(value) =>
                setFormData({ ...formData, businessType: value })
              }>
                <SelectTrigger className="bg-background/50 border-border/50 text-gray-200 mt-2">
                  <SelectValue placeholder="Select business type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="service">Service Business</SelectItem>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="ecommerce">E-Commerce</SelectItem>
                  <SelectItem value="consulting">Consulting</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-gray-300">Management Type</Label>
              <Select value={formData.managementType} onValueChange={(value) =>
                setFormData({ ...formData, managementType: value })
              }>
                <SelectTrigger className="bg-background/50 border-border/50 text-gray-200 mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="member-managed">Member-Managed</SelectItem>
                  <SelectItem value="manager-managed">Manager-Managed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Members */}
      {step === 3 && (
        <Card className="glass border-border/50">
          <CardHeader>
            <CardTitle>Step 3: LLC Members</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {formData.members.map((member, index) => (
              <div key={index} className="p-4 bg-background/50 rounded-lg space-y-3">
                <div className="flex justify-between items-center">
                  <span className="font-medium text-gray-300">Member {index + 1}</span>
                  <Button
                    onClick={() => handleRemoveMember(index)}
                    variant="ghost"
                    className="text-red-400 hover:text-red-300"
                  >
                    Remove
                  </Button>
                </div>

                <Input
                  placeholder="Member name"
                  value={member.name}
                  onChange={(e) =>
                    handleUpdateMember(index, "name", e.target.value)
                  }
                  className="bg-background/50 border-border/50 text-gray-200"
                />

                <Input
                  placeholder="Member address"
                  value={member.address}
                  onChange={(e) =>
                    handleUpdateMember(index, "address", e.target.value)
                  }
                  className="bg-background/50 border-border/50 text-gray-200"
                />

                <Input
                  placeholder="Ownership percentage"
                  value={member.ownership}
                  onChange={(e) =>
                    handleUpdateMember(index, "ownership", e.target.value)
                  }
                  className="bg-background/50 border-border/50 text-gray-200"
                />
              </div>
            ))}

            <Button
              onClick={handleAddMember}
              variant="outline"
              className="w-full border-border/50"
            >
              + Add Member
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Step 4: Principal Address */}
      {step === 4 && (
        <Card className="glass border-border/50">
          <CardHeader>
            <CardTitle>Step 4: Principal Office Address</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input
              placeholder="Street address"
              value={formData.principalAddress}
              onChange={(e) =>
                setFormData({ ...formData, principalAddress: e.target.value })
              }
              className="bg-background/50 border-border/50 text-gray-200"
            />

            <Input
              placeholder="City"
              value={formData.principalCity}
              onChange={(e) =>
                setFormData({ ...formData, principalCity: e.target.value })
              }
              className="bg-background/50 border-border/50 text-gray-200"
            />

            <Input
              placeholder="State"
              value={formData.principalState}
              onChange={(e) =>
                setFormData({ ...formData, principalState: e.target.value })
              }
              className="bg-background/50 border-border/50 text-gray-200"
            />

            <Input
              placeholder="ZIP code"
              value={formData.principalZip}
              onChange={(e) =>
                setFormData({ ...formData, principalZip: e.target.value })
              }
              className="bg-background/50 border-border/50 text-gray-200"
            />
          </CardContent>
        </Card>
      )}

      {/* Step 5: Registered Agent */}
      {step === 5 && (
        <Card className="glass border-border/50">
          <CardHeader>
            <CardTitle>Step 5: Registered Agent</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-300">Agent Type</Label>
              <Select value={formData.agentType} onValueChange={(value) =>
                setFormData({ ...formData, agentType: value })
              }>
                <SelectTrigger className="bg-background/50 border-border/50 text-gray-200 mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="self">Self (Member)</SelectItem>
                  <SelectItem value="professional">Professional Agent</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.agentType === "professional" && (
              <>
                <Input
                  placeholder="Agent name"
                  value={formData.agentName}
                  onChange={(e) =>
                    setFormData({ ...formData, agentName: e.target.value })
                  }
                  className="bg-background/50 border-border/50 text-gray-200"
                />

                <Input
                  placeholder="Agent address"
                  value={formData.agentAddress}
                  onChange={(e) =>
                    setFormData({ ...formData, agentAddress: e.target.value })
                  }
                  className="bg-background/50 border-border/50 text-gray-200"
                />
              </>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 6: Review & Generate */}
      {step === 6 && (
        <Card className="glass border-border/50">
          <CardHeader>
            <CardTitle>Step 6: Review & Generate Documents</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
              <div className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-green-300">Ready to Generate</p>
                  <p className="text-sm text-gray-300 mt-1">
                    Your LLC formation documents are ready. Click the button below to generate your Articles of Organization.
                  </p>
                </div>
              </div>
            </div>

            <Button
              onClick={generateDocuments}
              disabled={generateArticlesPDF.isPending}
              className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:opacity-90"
            >
              <Download className="w-4 h-4 mr-2" />
              {generateArticlesPDF.isPending ? "Generating..." : "Generate Documents"}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Navigation Buttons */}
      <div className="flex gap-4 justify-between">
        <Button
          onClick={() => setStep(Math.max(1, step - 1))}
          disabled={step === 1}
          variant="outline"
          className="border-border/50"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <Button
          onClick={() => setStep(Math.min(6, step + 1))}
          disabled={step === 6}
          className="bg-cyan-500 hover:bg-cyan-600"
        >
          Next
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}
