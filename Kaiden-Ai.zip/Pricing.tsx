import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Check, Star, Users, Zap, Crown, Building2, 
  CreditCard, ArrowRight, Shield, Gift
} from "lucide-react";
import { useState } from "react";

// Payment processors
const paymentProcessors = [
  { id: 'stripe', name: 'Stripe', description: 'Credit/Debit Cards' },
  { id: 'gumroad', name: 'Gumroad', description: 'Digital Payments' },
  { id: 'square', name: 'Square', description: 'Business Payments' },
];

// Pricing tiers
const pricingTiers = [
  {
    id: 'starter',
    name: 'Starter',
    description: 'Perfect for individuals getting started',
    monthlyPrice: 29,
    yearlyPrice: 290,
    features: [
      '1 User Session',
      '3 Signature Apps',
      'Basic AI Assistance',
      'Email Support',
      'Community Access',
    ],
    appLimit: 3,
    popular: false,
  },
  {
    id: 'professional',
    name: 'Professional',
    description: 'For growing businesses and teams',
    monthlyPrice: 79,
    yearlyPrice: 790,
    features: [
      '1 User Session',
      '10 Signature Apps',
      'Advanced AI Assistance',
      'Priority Support',
      'API Access',
      'Custom Integrations',
      'Analytics Dashboard',
    ],
    appLimit: 10,
    popular: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    description: 'For organizations requiring full access',
    monthlyPrice: 199,
    yearlyPrice: 1990,
    features: [
      '1 User Session (Team Access Available)',
      'All Signature Apps',
      'Unlimited AI Assistance',
      'Dedicated Account Manager',
      'Custom Development',
      'White-Label Options',
      'SLA Guarantee',
      'On-Premise Deployment',
    ],
    appLimit: -1, // unlimited
    popular: false,
  },
];

// App bundles
const appBundles = [
  { apps: 1, discount: 0, price: 9.99 },
  { apps: 3, discount: 10, price: 26.97 },
  { apps: 5, discount: 15, price: 42.45 },
  { apps: 7, discount: 20, price: 55.93 },
  { apps: 10, discount: 25, price: 74.92 },
];

// Standalone apps
const standaloneApps = [
  { id: 'wheres-my-tribe', name: "Where's My Tribe", price: 9.99, category: 'Social' },
  { id: 'vitalsync', name: 'VitalSync', price: 14.99, category: 'Health' },
  { id: 'financial-copilot', name: 'Financial Co-Pilot', price: 19.99, category: 'Finance' },
  { id: 'content-engine', name: 'Content Creation Engine', price: 14.99, category: 'Creative' },
  { id: 'reality-sync', name: 'Reality Sync', price: 12.99, category: 'Productivity' },
  { id: 'pal', name: 'PAL', price: 9.99, category: 'Assistant' },
  { id: 'builder-sync', name: 'Builder Sync', price: 14.99, category: 'Development' },
  { id: 'master-music', name: 'Master Music Production', price: 24.99, category: 'Audio' },
  { id: 'pantry-manager', name: 'Pantry Inventory', price: 7.99, category: 'Home' },
];

export default function Pricing() {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [selectedProcessor, setSelectedProcessor] = useState('stripe');

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-radial from-primary/10 via-transparent to-transparent" />
        <div className="container relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="gradient-text">Pricing</span> for Everyone
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Affordable tiers designed so anyone can run a piece of the future. 
              One user per session - team access available for Enterprise.
            </p>
            
            {/* Billing Toggle */}
            <div className="flex items-center justify-center gap-4 mb-8">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-4 py-2 rounded-lg transition-all ${
                  billingCycle === 'monthly' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-secondary text-muted-foreground'
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingCycle('yearly')}
                className={`px-4 py-2 rounded-lg transition-all ${
                  billingCycle === 'yearly' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-secondary text-muted-foreground'
                }`}
              >
                Yearly <Badge variant="secondary" className="ml-2">Save 17%</Badge>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Tiers */}
      <section className="py-16">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-8">
            {pricingTiers.map((tier) => (
              <Card 
                key={tier.id} 
                className={`luxury-card relative ${tier.popular ? 'ring-2 ring-primary' : ''}`}
              >
                {tier.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground">
                      <Star className="h-3 w-3 mr-1" />
                      Most Popular
                    </Badge>
                  </div>
                )}
                <CardHeader className="text-center pb-4">
                  <CardTitle className="text-2xl">{tier.name}</CardTitle>
                  <CardDescription>{tier.description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold">
                      ${billingCycle === 'monthly' ? tier.monthlyPrice : tier.yearlyPrice}
                    </span>
                    <span className="text-muted-foreground">
                      /{billingCycle === 'monthly' ? 'mo' : 'yr'}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {tier.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className={`w-full ${tier.popular ? 'btn-shine glow-blue' : ''}`}
                    variant={tier.popular ? 'default' : 'outline'}
                  >
                    Get Started
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Team Pricing Notice */}
      <section className="py-12 bg-secondary/30">
        <div className="container">
          <div className="luxury-card p-8 text-center">
            <Building2 className="h-12 w-12 mx-auto mb-4 text-primary" />
            <h3 className="text-2xl font-bold mb-2">Team Access</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              One user per session. Business owners can purchase team licenses to give 
              their entire organization access. Contact us for custom team pricing.
            </p>
            <Button variant="outline" className="mt-4">
              Contact Sales
            </Button>
          </div>
        </div>
      </section>

      {/* Standalone Apps */}
      <section className="py-16">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">
              Standalone <span className="gradient-text">Apps</span>
            </h2>
            <p className="text-muted-foreground">
              Purchase individual apps at reduced monthly costs
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {standaloneApps.map((app) => (
              <Card key={app.id} className="luxury-card card-hover">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{app.name}</CardTitle>
                      <Badge variant="secondary" className="mt-1">{app.category}</Badge>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl font-bold">${app.price}</span>
                      <span className="text-muted-foreground text-sm">/mo</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full">
                    Add to Cart
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* App Bundles */}
      <section className="py-16 bg-secondary/30">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">
              App <span className="gradient-text">Bundles</span>
            </h2>
            <p className="text-muted-foreground">
              Save more when you bundle apps together
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {appBundles.map((bundle) => (
              <Card key={bundle.apps} className="luxury-card text-center card-hover">
                <CardContent className="pt-6">
                  <div className="text-4xl font-bold text-primary mb-2">
                    {bundle.apps}
                  </div>
                  <div className="text-sm text-muted-foreground mb-2">
                    {bundle.apps === 1 ? 'App' : 'Apps'}
                  </div>
                  {bundle.discount > 0 && (
                    <Badge variant="secondary" className="mb-2">
                      {bundle.discount}% OFF
                    </Badge>
                  )}
                  <div className="text-xl font-bold">
                    ${bundle.price.toFixed(2)}/mo
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Discounts Section */}
      <section className="py-16">
        <div className="container">
          <div className="text-center mb-12">
            <Gift className="h-12 w-12 mx-auto mb-4 text-primary" />
            <h2 className="text-3xl font-bold mb-4">
              Special <span className="gradient-text">Discounts</span>
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-yellow-500" />
                  Honest Google Review
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-primary mb-2">10% OFF</div>
                <p className="text-muted-foreground">
                  Leave an honest review on Google and receive 10% off your subscription.
                  We value genuine feedback from our community.
                </p>
              </CardContent>
            </Card>
            
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-green-500" />
                  Issue Resolution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-primary mb-2">15% OFF</div>
                <p className="text-muted-foreground">
                  If you experience an issue and give us a chance to resolve it before 
                  posting a negative review, receive 15% off your next billing cycle.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Payment Processors */}
      <section className="py-16 bg-secondary/30">
        <div className="container">
          <div className="text-center mb-12">
            <CreditCard className="h-12 w-12 mx-auto mb-4 text-primary" />
            <h2 className="text-3xl font-bold mb-4">
              Payment <span className="gradient-text">Options</span>
            </h2>
            <p className="text-muted-foreground">
              Choose your preferred payment processor
            </p>
          </div>
          
          <div className="flex justify-center gap-6">
            {paymentProcessors.map((processor) => (
              <button
                key={processor.id}
                onClick={() => setSelectedProcessor(processor.id)}
                className={`luxury-card p-6 text-center transition-all ${
                  selectedProcessor === processor.id 
                    ? 'ring-2 ring-primary' 
                    : 'opacity-70 hover:opacity-100'
                }`}
              >
                <div className="text-xl font-bold mb-1">{processor.name}</div>
                <div className="text-sm text-muted-foreground">{processor.description}</div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16">
        <div className="container max-w-3xl">
          <h2 className="text-3xl font-bold text-center mb-12">
            Frequently Asked <span className="gradient-text">Questions</span>
          </h2>
          
          <div className="space-y-6">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle>Can my team use one subscription?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Each subscription is for one user per session. Business owners who want 
                  their team to have access should contact us for team licensing options.
                </p>
              </CardContent>
            </Card>
            
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle>Can I switch plans later?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Yes, you can upgrade or downgrade your plan at any time. Changes take 
                  effect at the start of your next billing cycle.
                </p>
              </CardContent>
            </Card>
            
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle>What payment methods do you accept?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  We accept payments through Stripe (credit/debit cards), Gumroad (digital payments), 
                  and Square (business payments). Choose whichever works best for you.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
