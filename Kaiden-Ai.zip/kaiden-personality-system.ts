/**
 * Kaiden Personality Sync System
 * Three personality choices for users to become
 */

export enum PersonalityType {
  VISIONARY = 'visionary',
  STRATEGIST = 'strategist',
  EXECUTOR = 'executor',
}

export interface PersonalityProfile {
  id: PersonalityType;
  name: string;
  description: string;
  tagline: string;
  icon: string;
  color: string;
  traits: string[];
  capabilities: string[];
  focusAreas: string[];
  communicationStyle: string;
  decisionMaking: string;
  strengths: string[];
  growthAreas: string[];
  recommendedCapabilities: string[];
}

export const PersonalityProfiles: Record<PersonalityType, PersonalityProfile> = {
  [PersonalityType.VISIONARY]: {
    id: PersonalityType.VISIONARY,
    name: 'The Visionary',
    description:
      'You see the big picture and inspire others with your compelling vision for the future. You excel at identifying opportunities, setting ambitious goals, and motivating teams to achieve extraordinary results.',
    tagline: 'See Tomorrow, Build Today',
    icon: '🚀',
    color: '#7c3aed', // Purple
    traits: [
      'Forward-thinking',
      'Inspirational',
      'Creative',
      'Ambitious',
      'Strategic',
      'Optimistic',
      'Innovative',
      'Charismatic',
    ],
    capabilities: [
      'Strategic Planning',
      'Market Analysis',
      'Innovation Lab',
      'Vision Mapping',
      'Trend Forecasting',
      'Goal Setting',
      'Leadership Development',
      'Team Inspiration',
    ],
    focusAreas: [
      'Long-term strategy',
      'Market opportunities',
      'Innovation',
      'Leadership',
      'Growth',
      'Transformation',
    ],
    communicationStyle:
      'Inspirational and big-picture focused. You communicate through compelling narratives and future possibilities.',
    decisionMaking:
      'You make decisions based on long-term vision and potential impact. You balance data with intuition.',
    strengths: [
      'Strategic thinking',
      'Innovation',
      'Leadership',
      'Motivation',
      'Big-picture perspective',
      'Adaptability',
    ],
    growthAreas: [
      'Attention to detail',
      'Execution focus',
      'Patience with process',
      'Delegation',
      'Risk management',
    ],
    recommendedCapabilities: [
      'cap_strategic_planning',
      'cap_market_analysis',
      'cap_innovation_lab',
      'cap_vision_mapping',
      'cap_trend_forecasting',
      'cap_goal_setting',
      'cap_leadership_development',
      'cap_team_inspiration',
      'cap_business_model_canvas',
      'cap_competitive_analysis',
      'cap_market_research',
      'cap_scenario_planning',
    ],
  },

  [PersonalityType.STRATEGIST]: {
    id: PersonalityType.STRATEGIST,
    name: 'The Strategist',
    description:
      'You are the master planner who turns vision into actionable strategy. You excel at analyzing complex situations, developing comprehensive plans, and ensuring alignment across teams and resources.',
    tagline: 'Plan with Precision, Execute with Purpose',
    icon: '🎯',
    color: '#5b7fff', // Primary Blue
    traits: [
      'Analytical',
      'Methodical',
      'Detail-oriented',
      'Logical',
      'Organized',
      'Disciplined',
      'Systematic',
      'Collaborative',
    ],
    capabilities: [
      'Business Planning',
      'Process Optimization',
      'Resource Allocation',
      'Risk Management',
      'Performance Metrics',
      'Team Coordination',
      'Project Management',
      'Financial Planning',
    ],
    focusAreas: [
      'Strategic alignment',
      'Process efficiency',
      'Resource optimization',
      'Risk mitigation',
      'Performance tracking',
      'Coordination',
    ],
    communicationStyle:
      'Clear, structured, and data-driven. You communicate through frameworks, metrics, and logical progression.',
    decisionMaking:
      'You make decisions through systematic analysis, weighing pros and cons, and considering multiple scenarios.',
    strengths: [
      'Strategic planning',
      'Analysis',
      'Organization',
      'Process design',
      'Risk assessment',
      'Team coordination',
    ],
    growthAreas: [
      'Flexibility',
      'Rapid decision-making',
      'Intuition',
      'Innovation',
      'Emotional intelligence',
    ],
    recommendedCapabilities: [
      'cap_business_planning',
      'cap_process_optimization',
      'cap_resource_allocation',
      'cap_risk_management',
      'cap_performance_metrics',
      'cap_team_coordination',
      'cap_project_management',
      'cap_financial_planning',
      'cap_swot_analysis',
      'cap_operational_planning',
      'cap_capacity_planning',
      'cap_stakeholder_management',
    ],
  },

  [PersonalityType.EXECUTOR]: {
    id: PersonalityType.EXECUTOR,
    name: 'The Executor',
    description:
      'You are the action-oriented leader who gets things done. You excel at implementation, problem-solving, and driving results through focus, determination, and hands-on involvement.',
    tagline: 'Do It Better, Do It Faster',
    icon: '⚡',
    color: '#10b981', // Green
    traits: [
      'Action-oriented',
      'Results-focused',
      'Pragmatic',
      'Decisive',
      'Resilient',
      'Hands-on',
      'Energetic',
      'Problem-solver',
    ],
    capabilities: [
      'Implementation',
      'Problem Solving',
      'Quality Control',
      'Workflow Automation',
      'Performance Optimization',
      'Crisis Management',
      'Rapid Prototyping',
      'Continuous Improvement',
    ],
    focusAreas: [
      'Execution',
      'Results',
      'Efficiency',
      'Quality',
      'Problem-solving',
      'Continuous improvement',
    ],
    communicationStyle:
      'Direct, concise, and action-focused. You communicate through results, timelines, and next steps.',
    decisionMaking:
      'You make decisions quickly based on available information, focusing on what works and what delivers results.',
    strengths: [
      'Execution',
      'Problem-solving',
      'Decisiveness',
      'Resilience',
      'Efficiency',
      'Results orientation',
    ],
    growthAreas: [
      'Strategic patience',
      'Long-term planning',
      'Delegation',
      'Communication',
      'Stakeholder management',
    ],
    recommendedCapabilities: [
      'cap_implementation',
      'cap_problem_solving',
      'cap_quality_control',
      'cap_workflow_automation',
      'cap_performance_optimization',
      'cap_crisis_management',
      'cap_rapid_prototyping',
      'cap_continuous_improvement',
      'cap_task_management',
      'cap_issue_tracking',
      'cap_bug_tracking',
      'cap_performance_monitoring',
    ],
  },
};

/**
 * User Personality Sync
 */
export interface UserPersonality {
  userId: number;
  personalityType: PersonalityType;
  syncedAt: Date;
  preferences: PersonalityPreferences;
  stats: PersonalityStats;
}

export interface PersonalityPreferences {
  focusArea: string;
  communicationFrequency: 'daily' | 'weekly' | 'monthly';
  notificationStyle: 'detailed' | 'summary' | 'minimal';
  capabilityRecommendations: boolean;
  personalizedInsights: boolean;
  teamAlignment: boolean;
}

export interface PersonalityStats {
  capabilitiesUsed: number;
  tasksCompleted: number;
  goalsAchieved: number;
  teamMembersInvited: number;
  averageCompletionTime: number; // in hours
  personalityAlignment: number; // 0-100%
}

/**
 * Personality Sync Script
 */
export class PersonalitySyncEngine {
  /**
   * Sync user with Kaiden personality system
   */
  static async syncUserWithKaiden(
    userId: number,
    answers: Record<string, number>
  ): Promise<PersonalityType> {
    // Calculate personality scores based on answers
    const scores = this.calculatePersonalityScores(answers);

    // Determine dominant personality
    const dominantPersonality = this.determineDominantPersonality(scores);

    return dominantPersonality;
  }

  /**
   * Calculate personality scores from assessment answers
   */
  private static calculatePersonalityScores(answers: Record<string, number>): Record<
    PersonalityType,
    number
  > {
    const scores: Record<PersonalityType, number> = {
      [PersonalityType.VISIONARY]: 0,
      [PersonalityType.STRATEGIST]: 0,
      [PersonalityType.EXECUTOR]: 0,
    };

    // Question mapping to personality types
    const questionMapping: Record<string, PersonalityType[]> = {
      q1: [PersonalityType.VISIONARY, PersonalityType.VISIONARY, PersonalityType.STRATEGIST],
      q2: [PersonalityType.STRATEGIST, PersonalityType.STRATEGIST, PersonalityType.EXECUTOR],
      q3: [PersonalityType.VISIONARY, PersonalityType.STRATEGIST, PersonalityType.EXECUTOR],
      q4: [PersonalityType.EXECUTOR, PersonalityType.STRATEGIST, PersonalityType.VISIONARY],
      q5: [PersonalityType.VISIONARY, PersonalityType.EXECUTOR, PersonalityType.STRATEGIST],
      q6: [PersonalityType.STRATEGIST, PersonalityType.VISIONARY, PersonalityType.EXECUTOR],
      q7: [PersonalityType.EXECUTOR, PersonalityType.EXECUTOR, PersonalityType.STRATEGIST],
      q8: [PersonalityType.VISIONARY, PersonalityType.STRATEGIST, PersonalityType.EXECUTOR],
    };

    // Calculate scores
    Object.entries(answers).forEach(([question, score]) => {
      const mapping = questionMapping[question];
      if (mapping) {
        mapping.forEach((personality, index) => {
          if (index === score - 1) {
            scores[personality]++;
          }
        });
      }
    });

    return scores;
  }

  /**
   * Determine dominant personality type
   */
  private static determineDominantPersonality(
    scores: Record<PersonalityType, number>
  ): PersonalityType {
    let maxScore = 0;
    let dominantPersonality = PersonalityType.STRATEGIST; // Default

    Object.entries(scores).forEach(([personality, score]) => {
      if (score > maxScore) {
        maxScore = score;
        dominantPersonality = personality as PersonalityType;
      }
    });

    return dominantPersonality;
  }

  /**
   * Get personality assessment questions
   */
  static getAssessmentQuestions(): Array<{
    id: string;
    question: string;
    options: Array<{ label: string; personality: PersonalityType }>;
  }> {
    return [
      {
        id: 'q1',
        question: 'When facing a new opportunity, you typically:',
        options: [
          { label: 'Envision the long-term potential and possibilities', personality: PersonalityType.VISIONARY },
          { label: 'Analyze how it fits into the overall strategy', personality: PersonalityType.STRATEGIST },
          { label: 'Focus on how to implement it quickly', personality: PersonalityType.EXECUTOR },
        ],
      },
      {
        id: 'q2',
        question: 'Your ideal work environment is:',
        options: [
          { label: 'Collaborative and inspiring with big ideas', personality: PersonalityType.VISIONARY },
          { label: 'Organized and structured with clear processes', personality: PersonalityType.STRATEGIST },
          { label: 'Dynamic and fast-paced with tangible results', personality: PersonalityType.EXECUTOR },
        ],
      },
      {
        id: 'q3',
        question: 'When leading a team, you focus on:',
        options: [
          { label: 'Inspiring them with a compelling vision', personality: PersonalityType.VISIONARY },
          { label: 'Ensuring alignment and coordination', personality: PersonalityType.STRATEGIST },
          { label: 'Getting results and solving problems', personality: PersonalityType.EXECUTOR },
        ],
      },
      {
        id: 'q4',
        question: 'In decision-making, you prioritize:',
        options: [
          { label: 'Long-term impact and innovation', personality: PersonalityType.VISIONARY },
          { label: 'Comprehensive analysis and risk assessment', personality: PersonalityType.STRATEGIST },
          { label: 'Speed and practical results', personality: PersonalityType.EXECUTOR },
        ],
      },
      {
        id: 'q5',
        question: 'Your biggest strength is:',
        options: [
          { label: 'Seeing possibilities and inspiring others', personality: PersonalityType.VISIONARY },
          { label: 'Planning and organizing complex initiatives', personality: PersonalityType.STRATEGIST },
          { label: 'Executing and delivering results', personality: PersonalityType.EXECUTOR },
        ],
      },
      {
        id: 'q6',
        question: 'When a project faces obstacles, you:',
        options: [
          { label: 'Reframe the challenge as an opportunity', personality: PersonalityType.VISIONARY },
          { label: 'Analyze the problem systematically', personality: PersonalityType.STRATEGIST },
          { label: 'Take immediate action to solve it', personality: PersonalityType.EXECUTOR },
        ],
      },
      {
        id: 'q7',
        question: 'Your communication style is:',
        options: [
          { label: 'Inspirational and narrative-driven', personality: PersonalityType.VISIONARY },
          { label: 'Structured and data-driven', personality: PersonalityType.STRATEGIST },
          { label: 'Direct and action-focused', personality: PersonalityType.EXECUTOR },
        ],
      },
      {
        id: 'q8',
        question: 'You measure success by:',
        options: [
          { label: 'Transformational impact and growth', personality: PersonalityType.VISIONARY },
          { label: 'Strategic goals achieved and efficiency', personality: PersonalityType.STRATEGIST },
          { label: 'Results delivered and problems solved', personality: PersonalityType.EXECUTOR },
        ],
      },
    ];
  }

  /**
   * Get personalized recommendations based on personality
   */
  static getPersonalizedRecommendations(personality: PersonalityType): {
    capabilities: string[];
    focusAreas: string[];
    growthOpportunities: string[];
    suggestedActions: string[];
  } {
    const profile = PersonalityProfiles[personality];

    return {
      capabilities: profile.recommendedCapabilities,
      focusAreas: profile.focusAreas,
      growthOpportunities: profile.growthAreas,
      suggestedActions: [
        `Focus on ${profile.focusAreas[0]} this week`,
        `Leverage your strength in ${profile.strengths[0]}`,
        `Work on developing ${profile.growthAreas[0]}`,
        `Use the ${profile.name} dashboard for personalized insights`,
        `Connect with other ${personality}s in your network`,
      ],
    };
  }

  /**
   * Get personality-specific dashboard
   */
  static getPersonalityDashboard(personality: PersonalityType): {
    widgets: Array<{ id: string; title: string; type: string; config: any }>;
    layout: string;
    theme: string;
  } {
    const profile = PersonalityProfiles[personality];

    return {
      widgets: [
        {
          id: 'personality_profile',
          title: `Your ${profile.name} Profile`,
          type: 'profile_card',
          config: { personality },
        },
        {
          id: 'recommended_capabilities',
          title: 'Recommended Capabilities',
          type: 'capability_grid',
          config: { capabilities: profile.recommendedCapabilities.slice(0, 6) },
        },
        {
          id: 'focus_areas',
          title: 'Your Focus Areas',
          type: 'focus_list',
          config: { areas: profile.focusAreas },
        },
        {
          id: 'personality_stats',
          title: 'Your Stats',
          type: 'stats_card',
          config: { personality },
        },
        {
          id: 'growth_opportunities',
          title: 'Growth Opportunities',
          type: 'growth_list',
          config: { areas: profile.growthAreas },
        },
        {
          id: 'team_alignment',
          title: 'Team Alignment',
          type: 'team_grid',
          config: { personality },
        },
      ],
      layout: 'grid',
      theme: profile.color,
    };
  }
}

export default PersonalitySyncEngine;
