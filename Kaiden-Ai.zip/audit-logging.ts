/**
 * PRODUCTION AUDIT LOGGING SYSTEM
 * 
 * Implements:
 * - Tamper-resistant audit logs
 * - Timestamped events
 * - User attribution
 * - Admin-only access
 * - Immutable records
 * - Log retention policies
 * - Suspicious behavior detection
 */

import crypto from 'crypto';
import { z } from 'zod';

/**
 * Audit log entry
 */
export interface AuditLogEntry {
  id: string;
  timestamp: number;
  userId?: string;
  email?: string;
  action: string;
  resourceType: string;
  resourceId: string;
  status: 'success' | 'failure';
  ipAddress: string;
  userAgent: string;
  changes?: Record<string, { before: unknown; after: unknown }>;
  metadata?: Record<string, unknown>;
  hash?: string;
  previousHash?: string;
}

/**
 * Audit log actions
 */
export enum AuditAction {
  // Authentication
  LOGIN_SUCCESS = 'LOGIN_SUCCESS',
  LOGIN_FAILED = 'LOGIN_FAILED',
  LOGOUT = 'LOGOUT',
  REGISTER = 'REGISTER',
  PASSWORD_CHANGE = 'PASSWORD_CHANGE',
  PASSWORD_RESET = 'PASSWORD_RESET',
  
  // Payments
  PAYMENT_INITIATED = 'PAYMENT_INITIATED',
  PAYMENT_SUCCESS = 'PAYMENT_SUCCESS',
  PAYMENT_FAILED = 'PAYMENT_FAILED',
  SUBSCRIPTION_CREATED = 'SUBSCRIPTION_CREATED',
  SUBSCRIPTION_UPDATED = 'SUBSCRIPTION_UPDATED',
  SUBSCRIPTION_CANCELED = 'SUBSCRIPTION_CANCELED',
  REFUND_ISSUED = 'REFUND_ISSUED',
  
  // License
  LICENSE_GRANTED = 'LICENSE_GRANTED',
  LICENSE_REVOKED = 'LICENSE_REVOKED',
  LICENSE_UPGRADED = 'LICENSE_UPGRADED',
  LICENSE_DOWNGRADED = 'LICENSE_DOWNGRADED',
  
  // Feature Access
  FEATURE_ACCESSED = 'FEATURE_ACCESSED',
  FEATURE_DENIED = 'FEATURE_DENIED',
  
  // Data
  DATA_CREATED = 'DATA_CREATED',
  DATA_UPDATED = 'DATA_UPDATED',
  DATA_DELETED = 'DATA_DELETED',
  DATA_EXPORTED = 'DATA_EXPORTED',
  
  // Admin
  ADMIN_ACTION = 'ADMIN_ACTION',
  ADMIN_OVERRIDE = 'ADMIN_OVERRIDE',
  
  // Security
  SUSPICIOUS_ACTIVITY = 'SUSPICIOUS_ACTIVITY',
  BRUTE_FORCE_ATTEMPT = 'BRUTE_FORCE_ATTEMPT',
  UNAUTHORIZED_ACCESS = 'UNAUTHORIZED_ACCESS',
}

/**
 * Generate hash for tamper detection
 */
function generateHash(entry: Partial<AuditLogEntry>, previousHash?: string): string {
  const data = JSON.stringify({
    ...entry,
    previousHash,
  });

  return crypto.createHash('sha256').update(data).digest('hex');
}

/**
 * Create audit log entry
 */
export function createAuditLogEntry(
  action: AuditAction | string,
  resourceType: string,
  resourceId: string,
  status: 'success' | 'failure',
  ipAddress: string,
  userAgent: string,
  userId?: string,
  email?: string,
  changes?: Record<string, { before: unknown; after: unknown }>,
  metadata?: Record<string, unknown>,
  previousHash?: string
): AuditLogEntry {
  const entry: AuditLogEntry = {
    id: generateLogId(),
    timestamp: Date.now(),
    userId,
    email,
    action,
    resourceType,
    resourceId,
    status,
    ipAddress,
    userAgent,
    changes,
    metadata,
    previousHash,
  };

  // Generate hash for tamper detection
  entry.hash = generateHash(entry, previousHash);

  return entry;
}

/**
 * Generate unique log ID
 */
function generateLogId(): string {
  return `audit_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;
}

/**
 * Verify log integrity
 */
export function verifyLogIntegrity(entry: AuditLogEntry, previousHash?: string): boolean {
  if (!entry.hash) return false;

  // Create a copy without the hash field for verification
  const { hash, ...entryWithoutHash } = entry;
  const expectedHash = generateHash(entryWithoutHash, previousHash);
  return entry.hash === expectedHash;
}

/**
 * Log authentication event
 */
export function logAuthenticationEvent(
  action: 'LOGIN_SUCCESS' | 'LOGIN_FAILED' | 'LOGOUT' | 'REGISTER' | 'PASSWORD_CHANGE',
  userId: string | undefined,
  email: string,
  ipAddress: string,
  userAgent: string,
  metadata?: Record<string, unknown>
): AuditLogEntry {
  return createAuditLogEntry(
    action,
    'authentication',
    email,
    'success',
    ipAddress,
    userAgent,
    userId,
    email,
    undefined,
    metadata
  );
}

/**
 * Log payment event
 */
export function logPaymentEvent(
  action: 'PAYMENT_INITIATED' | 'PAYMENT_SUCCESS' | 'PAYMENT_FAILED' | 'REFUND_ISSUED',
  userId: string,
  paymentId: string,
  amount: number,
  currency: string,
  ipAddress: string,
  userAgent: string,
  metadata?: Record<string, unknown>
): AuditLogEntry {
  return createAuditLogEntry(
    action,
    'payment',
    paymentId,
    action.includes('SUCCESS') || action === 'REFUND_ISSUED' ? 'success' : 'failure',
    ipAddress,
    userAgent,
    userId,
    undefined,
    undefined,
    {
      amount,
      currency,
      ...metadata,
    }
  );
}

/**
 * Log license event
 */
export function logLicenseEvent(
  action: 'LICENSE_GRANTED' | 'LICENSE_REVOKED' | 'LICENSE_UPGRADED' | 'LICENSE_DOWNGRADED',
  userId: string,
  appId: string,
  tier: string,
  ipAddress: string,
  userAgent: string,
  reason?: string
): AuditLogEntry {
  return createAuditLogEntry(
    action,
    'license',
    `${userId}-${appId}`,
    'success',
    ipAddress,
    userAgent,
    userId,
    undefined,
    undefined,
    {
      appId,
      tier,
      reason,
    }
  );
}

/**
 * Log feature access
 */
export function logFeatureAccess(
  action: 'FEATURE_ACCESSED' | 'FEATURE_DENIED',
  userId: string,
  featureName: string,
  appId: string,
  ipAddress: string,
  userAgent: string,
  reason?: string
): AuditLogEntry {
  return createAuditLogEntry(
    action,
    'feature',
    featureName,
    action === 'FEATURE_ACCESSED' ? 'success' : 'failure',
    ipAddress,
    userAgent,
    userId,
    undefined,
    undefined,
    {
      appId,
      reason,
    }
  );
}

/**
 * Log data event
 */
export function logDataEvent(
  action: 'DATA_CREATED' | 'DATA_UPDATED' | 'DATA_DELETED' | 'DATA_EXPORTED',
  userId: string,
  dataType: string,
  dataId: string,
  ipAddress: string,
  userAgent: string,
  changes?: Record<string, { before: unknown; after: unknown }>
): AuditLogEntry {
  return createAuditLogEntry(
    action,
    'data',
    dataId,
    'success',
    ipAddress,
    userAgent,
    userId,
    undefined,
    changes
  );
}

/**
 * Log security event
 */
export function logSecurityEvent(
  action: 'SUSPICIOUS_ACTIVITY' | 'BRUTE_FORCE_ATTEMPT' | 'UNAUTHORIZED_ACCESS',
  email: string,
  ipAddress: string,
  userAgent: string,
  details: Record<string, unknown>
): AuditLogEntry {
  return createAuditLogEntry(
    action,
    'security',
    email,
    'failure',
    ipAddress,
    userAgent,
    undefined,
    email,
    undefined,
    details
  );
}

/**
 * Log admin action
 */
export function logAdminAction(
  action: 'ADMIN_ACTION' | 'ADMIN_OVERRIDE',
  adminId: string,
  targetUserId: string,
  actionDescription: string,
  ipAddress: string,
  userAgent: string,
  changes?: Record<string, { before: unknown; after: unknown }>
): AuditLogEntry {
  return createAuditLogEntry(
    action,
    'admin',
    targetUserId,
    'success',
    ipAddress,
    userAgent,
    adminId,
    undefined,
    changes,
    {
      actionDescription,
      targetUserId,
    }
  );
}

/**
 * Query audit logs (admin only)
 */
export interface AuditLogQuery {
  userId?: string;
  action?: string;
  resourceType?: string;
  startTime?: number;
  endTime?: number;
  limit?: number;
  offset?: number;
}

/**
 * Detect suspicious behavior
 */
export function detectSuspiciousBehavior(
  logs: AuditLogEntry[],
  timeWindow: number = 5 * 60 * 1000 // 5 minutes
): AuditLogEntry[] {
  const suspicious: AuditLogEntry[] = [];

  // Check for multiple failed logins
  const failedLogins = logs.filter(
    (log) => log.action === AuditAction.LOGIN_FAILED
  );

  if (failedLogins.length >= 5) {
    suspicious.push(...failedLogins);
  }

  // Check for rapid data access
  const dataAccess = logs.filter(
    (log) => log.action === AuditAction.FEATURE_ACCESSED
  );

  const accessCounts: Record<string, number> = {};
  dataAccess.forEach((log) => {
    const key = `${log.userId}-${log.resourceType}`;
    accessCounts[key] = (accessCounts[key] || 0) + 1;
  });

  Object.entries(accessCounts).forEach(([key, count]) => {
    if (count > 100) {
      // More than 100 accesses in time window
      suspicious.push(
        ...dataAccess.filter((log) => `${log.userId}-${log.resourceType}` === key)
      );
    }
  });

  // Check for unauthorized access attempts
  const unauthorized = logs.filter(
    (log) => log.action === AuditAction.UNAUTHORIZED_ACCESS
  );

  if (unauthorized.length > 0) {
    suspicious.push(...unauthorized);
  }

  return suspicious;
}

/**
 * Validation schemas
 */
export const auditLogQuerySchema = z.object({
  userId: z.string().optional(),
  action: z.string().optional(),
  resourceType: z.string().optional(),
  startTime: z.number().optional(),
  endTime: z.number().optional(),
  limit: z.number().min(1).max(1000).optional(),
  offset: z.number().min(0).optional(),
});

export default {
  createAuditLogEntry,
  verifyLogIntegrity,
  logAuthenticationEvent,
  logPaymentEvent,
  logLicenseEvent,
  logFeatureAccess,
  logDataEvent,
  logSecurityEvent,
  logAdminAction,
  detectSuspiciousBehavior,
  AuditAction,
};
