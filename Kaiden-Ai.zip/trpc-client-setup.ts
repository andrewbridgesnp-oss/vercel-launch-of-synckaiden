/**
 * tRPC Client Setup for synckaiden.com Integration
 * 
 * This file sets up the tRPC client to communicate with the Kayden AI backend.
 * Place this in your client/src/lib directory.
 */

import { createTRPCReact } from "@trpc/react-query";
import { httpBatchLink, loggerLink } from "@trpc/client";
import { QueryClient } from "@tanstack/react-query";
import superjson from "superjson";
import type { AppRouter } from "../../../server/routers";

/**
 * Create a tRPC React client
 */
export const trpc = createTRPCReact<AppRouter>();

/**
 * Create a query client for React Query
 */
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      gcTime: 1000 * 60 * 10, // 10 minutes (formerly cacheTime)
    },
  },
});

/**
 * Create tRPC client
 */
export function createTRPCClient() {
  return trpc.createClient({
    links: [
      loggerLink({
        enabled: (opts) =>
          process.env.NODE_ENV === "development" ||
          (opts.direction === "down" && opts.result instanceof Error),
      }),
      httpBatchLink({
        url: `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/trpc`,
        // Send cookies with requests for authentication
        credentials: "include",
        // Use superjson for serialization
        transformer: superjson,
        // Custom headers
        headers: () => ({
          "Content-Type": "application/json",
        }),
        // Handle errors
        async fetch(url, options) {
          const response = await fetch(url, {
            ...options,
            credentials: "include",
          });

          if (!response.ok) {
            if (response.status === 401) {
              // Handle unauthorized - redirect to login
              window.location.href = "/login";
            }
          }

          return response;
        },
      }),
    ],
  });
}

/**
 * Export types for use in components
 */
export type { AppRouter };
