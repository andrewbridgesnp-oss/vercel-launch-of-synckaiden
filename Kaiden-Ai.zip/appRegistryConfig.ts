/**
 * Master App Registry Configuration
 * All 10 apps configured for Kaiden platform
 * Generated for 1-hour launch with 20k concurrent users
 */

import { AppMetadata } from './appRegistry';

export const KAIDEN_APPS: AppMetadata[] = [
  {
    id: 'agentic-ai-business-swarm',
    name: 'Agentic AI Business Swarm',
    description: 'AI agent swarm management and workflow automation',
    icon: '🤖',
    category: 'ai',
    version: '1.0.0',
    author: 'Kaiden Team',
    pricing: {
      free: {
        price: 0,
        features: ['1 agent', 'basic workflows'],
        limits: { agents: 1, workflows: 5 },
      },
      tiers: [
        {
          name: 'Starter',
          price: 29,
          features: ['5 agents', 'advanced workflows'],
          limits: { agents: 5, workflows: 50 },
        },
        {
          name: 'Pro',
          price: 99,
          features: ['unlimited agents', 'full automation'],
          limits: { agents: 999, workflows: 999 },
        },
      ],
    },
    features: ['Agent Swarm Management', 'Workflow Automation', 'n8n Integration', 'Predictive Analytics', 'AI Insights Feed'],
    scaling: { minInstances: 3, maxInstances: 50, cpuThreshold: 70, memoryThreshold: 80 },
    status: 'active',
    integrations: ['n8n', 'Kayden AI'],
    route: '/apps/agentic-ai-business-swarm',
  },
  {
    id: 'audio-mastering-application',
    name: 'All-In-One Music Production Studio',
    description: 'Professional audio mastering and music production',
    icon: '🎵',
    category: 'productivity',
    version: '1.0.0',
    author: 'Audio Team',
    pricing: {
      free: {
        price: 0,
        features: ['1 project', 'basic effects'],
        limits: { projects: 1, tracks: 8 },
      },
      tiers: [
        {
          name: 'Creator',
          price: 19,
          features: ['5 projects', 'all effects'],
          limits: { projects: 5, tracks: 32 },
        },
        {
          name: 'Professional',
          price: 79,
          features: ['unlimited projects', 'mastering suite'],
          limits: { projects: 999, tracks: 128 },
        },
      ],
    },
    features: ['Multi-Track Editor', 'Effects Rack', 'Virtual Instruments', 'Mastering Suite', 'Distribution Panel'],
    scaling: { minInstances: 2, maxInstances: 20, cpuThreshold: 75, memoryThreshold: 85 },
    status: 'active',
    integrations: ['Spotify', 'Apple Music', 'YouTube'],
    route: '/apps/audio-mastering-application',
  },
  {
    id: 'avery-ai-receptionist-design',
    name: 'Avery AI Receptionist',
    description: 'AI-powered call handling and appointment booking',
    icon: '📞',
    category: 'ai',
    version: '1.0.0',
    author: 'Avery Team',
    pricing: {
      free: {
        price: 0,
        features: ['100 calls/month', 'basic booking'],
        limits: { callsPerMonth: 100, bookings: 50 },
      },
      tiers: [
        {
          name: 'Business',
          price: 49,
          features: ['1000 calls/month', 'advanced booking'],
          limits: { callsPerMonth: 1000, bookings: 500 },
        },
        {
          name: 'Enterprise',
          price: 199,
          features: ['unlimited calls', 'full customization'],
          limits: { callsPerMonth: 999999, bookings: 999999 },
        },
      ],
    },
    features: ['AI-powered call handling', 'Appointment booking', 'Customer interaction management', 'Performance analytics', 'Customizable workflows'],
    scaling: { minInstances: 3, maxInstances: 50, cpuThreshold: 70, memoryThreshold: 80 },
    status: 'active',
    integrations: ['Twilio', 'Google Calendar', 'Stripe'],
    route: '/apps/avery-ai-receptionist-design',
  },
  {
    id: 'buildwealth-pro',
    name: 'BuildWealth Pro',
    description: 'Credit repair, grants, and business operations',
    icon: '💰',
    category: 'finance',
    version: '1.0.0',
    author: 'BuildWealth Team',
    pricing: {
      free: {
        price: 0,
        features: ['credit monitoring', 'basic tracking'],
        limits: { creditAccounts: 3, tasks: 10 },
      },
      tiers: [
        {
          name: 'Plus',
          price: 29,
          features: ['credit repair', 'grant tracking'],
          limits: { creditAccounts: 10, tasks: 100 },
        },
        {
          name: 'Premium',
          price: 99,
          features: ['full suite', 'unlimited everything'],
          limits: { creditAccounts: 999, tasks: 999 },
        },
      ],
    },
    features: ['Personal & Business Credit Repair', 'Grant & Loan Applications', 'Trail Boss Truck Finder', 'Business Operations', 'Gamification'],
    scaling: { minInstances: 3, maxInstances: 50, cpuThreshold: 70, memoryThreshold: 80 },
    status: 'active',
    integrations: ['Stripe', 'Plaid', 'Government APIs'],
    route: '/apps/buildwealth-pro',
  },
  {
    id: 'financial-co-pilot',
    name: 'Financial Co-Pilot',
    description: 'AI-powered financial management and insights',
    icon: '📊',
    category: 'finance',
    version: '1.0.0',
    author: 'Financial Team',
    pricing: {
      free: {
        price: 0,
        features: ['basic dashboard', 'limited reports'],
        limits: { transactions: 100, budgets: 3 },
      },
      tiers: [
        {
          name: 'Plus',
          price: 9,
          features: ['advanced dashboard', 'all reports'],
          limits: { transactions: 10000, budgets: 50 },
        },
        {
          name: 'Premium',
          price: 29,
          features: ['AI insights', 'unlimited everything'],
          limits: { transactions: 999999, budgets: 999 },
        },
      ],
    },
    features: ['AI-powered Financial Health Scoring', 'Advanced Data Visualization', 'Complete Financial Management', 'Enterprise Security', 'Fully Responsive'],
    scaling: { minInstances: 3, maxInstances: 50, cpuThreshold: 70, memoryThreshold: 80 },
    status: 'active',
    integrations: ['Plaid', 'Stripe', 'Bank APIs'],
    route: '/apps/financial-co-pilot',
  },
  {
    id: 'healthsync-scribe',
    name: 'HealthSync Scribe',
    description: 'AI medical scribe and smart coding',
    icon: '⚕️',
    category: 'productivity',
    version: '1.0.0',
    author: 'HealthSync Team',
    pricing: {
      free: {
        price: 0,
        features: ['10 notes/month', 'basic coding'],
        limits: { notesPerMonth: 10, patients: 10 },
      },
      tiers: [
        {
          name: 'Practice',
          price: 99,
          features: ['500 notes/month', 'advanced coding'],
          limits: { notesPerMonth: 500, patients: 100 },
        },
        {
          name: 'Enterprise',
          price: 499,
          features: ['unlimited notes', 'white-label'],
          limits: { notesPerMonth: 999999, patients: 999999 },
        },
      ],
    },
    features: ['AI Scribe', 'Smart Coding', 'White-Label', 'Multi-Tenant', 'Mobile Portal'],
    scaling: { minInstances: 2, maxInstances: 20, cpuThreshold: 75, memoryThreshold: 85 },
    status: 'active',
    integrations: ['EHR Systems', 'HIPAA Compliant'],
    route: '/apps/healthsync-scribe',
  },
  {
    id: 'househack-203k',
    name: 'KAIDEN HouseHack 203K',
    description: 'Real estate FHA 203(k) loan management',
    icon: '🏠',
    category: 'real-estate',
    version: '1.0.0',
    author: 'HouseHack Team',
    pricing: {
      free: {
        price: 0,
        features: ['1 deal room', 'basic calculator'],
        limits: { dealRooms: 1, teamMembers: 1 },
      },
      tiers: [
        {
          name: 'Agent',
          price: 49,
          features: ['5 deal rooms', 'team management'],
          limits: { dealRooms: 5, teamMembers: 10 },
        },
        {
          name: 'Professional',
          price: 199,
          features: ['unlimited deals', 'full suite'],
          limits: { dealRooms: 999, teamMembers: 100 },
        },
      ],
    },
    features: ['Eligibility Wizard', 'Deal Room Management', 'Financial Calculator', '203(k) Fit Score', 'Agent Commission System'],
    scaling: { minInstances: 3, maxInstances: 50, cpuThreshold: 70, memoryThreshold: 80 },
    status: 'active',
    integrations: ['Stripe', 'Supabase'],
    route: '/apps/househack-203k',
  },
  {
    id: 'pantryiq',
    name: 'Pantry Inventory Management',
    description: 'Smart pantry and shopping list management',
    icon: '🛒',
    category: 'productivity',
    version: '1.0.0',
    author: 'PantryIQ Team',
    pricing: {
      free: {
        price: 0,
        features: ['unlimited items', 'basic features'],
        limits: { items: 999, shoppingLists: 5 },
      },
      tiers: [
        {
          name: 'Plus',
          price: 4,
          features: ['recipe suggestions', 'advanced analytics'],
          limits: { items: 999, shoppingLists: 999 },
        },
      ],
    },
    features: ['Pantry Item Management', 'Shopping List Management', 'User Statistics', 'Notification Preferences', 'Recipe Suggestions'],
    scaling: { minInstances: 1, maxInstances: 10, cpuThreshold: 80, memoryThreshold: 90 },
    status: 'active',
    integrations: ['Recipe APIs'],
    route: '/apps/pantryiq',
  },
  {
    id: 'realitysync-app',
    name: 'Reality Sync',
    description: 'Asset management and vault organization',
    icon: '🔐',
    category: 'productivity',
    version: '1.0.0',
    author: 'RealitySync Team',
    pricing: {
      free: {
        price: 0,
        features: ['1 vault', 'basic features'],
        limits: { vaults: 1, assets: 100 },
      },
      tiers: [
        {
          name: 'Plus',
          price: 9,
          features: ['5 vaults', 'advanced features'],
          limits: { vaults: 5, assets: 10000 },
        },
        {
          name: 'Pro',
          price: 29,
          features: ['unlimited vaults', 'full features'],
          limits: { vaults: 999, assets: 999999 },
        },
      ],
    },
    features: ['Multiple Vaults', 'Photo Capture', 'Asset Management', 'Export Reports', 'PIN Protection'],
    scaling: { minInstances: 1, maxInstances: 10, cpuThreshold: 80, memoryThreshold: 90 },
    status: 'active',
    integrations: ['Cloud Storage'],
    route: '/apps/realitysync-app',
  },
  {
    id: 'spamslayer-sync',
    name: 'SpamSlayer Sync',
    description: 'Spam detection and subscription management',
    icon: '🛡️',
    category: 'productivity',
    version: '1.0.0',
    author: 'SpamSlayer Team',
    pricing: {
      free: {
        price: 0,
        features: ['basic spam detection', 'limited tracking'],
        limits: { subscriptions: 10, alerts: 5 },
      },
      tiers: [
        {
          name: 'Plus',
          price: 7,
          features: ['advanced detection', 'full tracking'],
          limits: { subscriptions: 100, alerts: 100 },
        },
      ],
    },
    features: ['Spam Detection/Management', 'Subscription Overview', 'Price Alerts', 'Savings Tracker', 'Dashboard'],
    scaling: { minInstances: 2, maxInstances: 20, cpuThreshold: 75, memoryThreshold: 85 },
    status: 'active',
    integrations: ['Email APIs'],
    route: '/apps/spamslayer-sync',
  },
  {
    id: 'tax-preparer-pro',
    name: 'Tax Preparer Pro',
    description: 'AI-powered tax preparation and e-filing platform',
    icon: '📊',
    category: 'finance',
    version: '1.0.0',
    author: 'Kaiden Finance Team',
    pricing: {
      free: {
        price: 0,
        features: ['5 clients', 'basic returns'],
        limits: { clients: 5, returns: 10 },
      },
      tiers: [
        {
          name: 'Professional',
          price: 49,
          features: ['50 clients', 'all forms', 'e-file'],
          limits: { clients: 50, returns: 200 },
        },
        {
          name: 'Enterprise',
          price: 199,
          features: ['unlimited clients', 'full suite', 'priority support'],
          limits: { clients: 999, returns: 9999 },
        },
      ],
    },
    features: ['Client Management', 'Document OCR', 'AI Deduction Finder', 'E-Filing', 'Audit Risk Assessment', 'Multi-Year Comparison'],
    scaling: { minInstances: 2, maxInstances: 30, cpuThreshold: 70, memoryThreshold: 80 },
    status: 'active',
    integrations: ['IRS E-File', 'QuickBooks', 'Xero'],
    route: '/apps/tax-preparer-pro',
  },
  {
    id: 'kaiden-tax',
    name: 'KAI(DEN) TAX™',
    description: 'Luxury-grade, privacy-first tax preparation with Year-Round Tax Autopilot, Audit-Proof Vault, and Decision Engine',
    icon: '💰',
    category: 'finance',
    version: '1.0.0',
    author: 'Kaiden Finance Team',
    pricing: {
      free: {
        price: 0,
        features: ['Basic 1040', 'Standard deduction', 'W-2 import'],
        limits: { returns: 1, scenarios: 2 },
      },
      tiers: [
        {
          name: 'Premium',
          price: 49,
          features: ['All forms', 'Itemized deductions', 'State returns', 'Audit Vault'],
          limits: { returns: 3, scenarios: 10 },
        },
        {
          name: 'Pro',
          price: 149,
          features: ['Unlimited returns', 'Tax Autopilot', 'Decision Engine', 'Priority support'],
          limits: { returns: 999, scenarios: 999 },
        },
      ],
    },
    features: ['Tax Interview Workflow', 'Year-Round Tax Autopilot', 'Audit-Proof Vault', 'Decision Engine Simulator', 'Document OCR', 'Real-Time Refund Estimator'],
    scaling: { minInstances: 3, maxInstances: 50, cpuThreshold: 70, memoryThreshold: 80 },
    status: 'active',
    integrations: ['IRS E-File', 'Bank Import', 'Crypto Import'],
    route: '/apps/kaiden-tax',
  },
  {
    id: 'syndica-ingestor',
    name: 'Syndica Ingestor & Composer',
    description: 'Content ingestion, merge planning, and syndication workflow automation',
    icon: '🔄',
    category: 'productivity',
    version: '1.0.0',
    author: 'Syndica Solutions',
    pricing: {
      free: {
        price: 0,
        features: ['5 ingests/month', 'basic merging'],
        limits: { ingestsPerMonth: 5, projects: 2 },
      },
      tiers: [
        {
          name: 'Professional',
          price: 29,
          features: ['100 ingests/month', 'advanced merging', 'automation'],
          limits: { ingestsPerMonth: 100, projects: 10 },
        },
        {
          name: 'Enterprise',
          price: 99,
          features: ['unlimited ingests', 'full automation', 'API access'],
          limits: { ingestsPerMonth: 999999, projects: 999 },
        },
      ],
    },
    features: ['Content Ingestion', 'Merge Planning', 'Diff Viewer', 'Workflow Automation', 'Version Control'],
    scaling: { minInstances: 2, maxInstances: 20, cpuThreshold: 75, memoryThreshold: 85 },
    status: 'active',
    integrations: ['GitHub', 'GitLab', 'Bitbucket'],
    route: '/apps/syndica-ingestor',
  },
];

/**
 * Initialize all apps in registry
 */
export function initializeAppRegistry() {
  return KAIDEN_APPS;
}

/**
 * Get app by ID
 */
export function getAppById(appId: string): AppMetadata | undefined {
  return KAIDEN_APPS.find(app => app.id === appId);
}

/**
 * Get all apps by category
 */
export function getAppsByCategory(category: string): AppMetadata[] {
  return KAIDEN_APPS.filter(app => app.category === category);
}

/**
 * Get featured apps
 */
export function getFeaturedApps(): AppMetadata[] {
  return KAIDEN_APPS.slice(0, 6);
}

/**
 * Search apps
 */
export function searchApps(query: string): AppMetadata[] {
  const lowerQuery = query.toLowerCase();
  return KAIDEN_APPS.filter(app =>
    app.name.toLowerCase().includes(lowerQuery) ||
    app.description.toLowerCase().includes(lowerQuery) ||
    app.features.some(f => f.toLowerCase().includes(lowerQuery))
  );
}
