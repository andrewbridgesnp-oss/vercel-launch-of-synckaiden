/**
 * App Scaling Configuration & Management
 * Each app scales independently based on its own rules
 */

export interface ScalingRules {
  appId: string;
  minInstances: number;
  maxInstances: number;
  cpuThreshold: number; // 0-100
  memoryThreshold: number; // 0-100
  scaleUpThreshold: number; // Percentage to trigger scale up
  scaleDownThreshold: number; // Percentage to trigger scale down
  cooldownPeriod: number; // Seconds before next scaling action
}

export interface AppMetrics {
  appId: string;
  currentInstances: number;
  avgCpuUsage: number;
  avgMemoryUsage: number;
  requestsPerSecond: number;
  errorRate: number;
  avgResponseTime: number; // milliseconds
  activeUsers: number;
}

export interface ScalingAction {
  appId: string;
  action: 'scale-up' | 'scale-down' | 'maintain';
  currentInstances: number;
  targetInstances: number;
  reason: string;
  timestamp: Date;
}

class AppScalingManager {
  private scalingRules: Map<string, ScalingRules> = new Map();
  private lastScalingAction: Map<string, Date> = new Map();
  private scalingHistory: ScalingAction[] = [];

  /**
   * Register scaling rules for an app
   */
  registerScalingRules(rules: ScalingRules): void {
    this.scalingRules.set(rules.appId, rules);
  }

  /**
   * Get scaling rules for an app
   */
  getScalingRules(appId: string): ScalingRules | undefined {
    return this.scalingRules.get(appId);
  }

  /**
   * Evaluate if app should scale based on metrics
   */
  evaluateScaling(appId: string, metrics: AppMetrics): ScalingAction | null {
    const rules = this.scalingRules.get(appId);
    if (!rules) {
      return null;
    }

    // Check cooldown period
    const lastAction = this.lastScalingAction.get(appId);
    if (lastAction) {
      const timeSinceLastAction = (Date.now() - lastAction.getTime()) / 1000;
      if (timeSinceLastAction < rules.cooldownPeriod) {
        return null; // Still in cooldown
      }
    }

    const action: ScalingAction = {
      appId,
      action: 'maintain',
      currentInstances: metrics.currentInstances,
      targetInstances: metrics.currentInstances,
      reason: '',
      timestamp: new Date(),
    };

    // Check if we should scale up
    if (
      metrics.avgCpuUsage > rules.cpuThreshold ||
      metrics.avgMemoryUsage > rules.memoryThreshold ||
      metrics.errorRate > 5 // More than 5% error rate
    ) {
      if (metrics.currentInstances < rules.maxInstances) {
        const scaleUpAmount = Math.ceil(metrics.currentInstances * 0.5); // Scale up by 50%
        action.action = 'scale-up';
        action.targetInstances = Math.min(
          metrics.currentInstances + scaleUpAmount,
          rules.maxInstances
        );
        action.reason = `High resource usage: CPU=${metrics.avgCpuUsage}%, Memory=${metrics.avgMemoryUsage}%, ErrorRate=${metrics.errorRate}%`;
      }
    }

    // Check if we should scale down
    if (
      metrics.avgCpuUsage < rules.scaleDownThreshold &&
      metrics.avgMemoryUsage < rules.scaleDownThreshold &&
      metrics.errorRate < 1 &&
      metrics.requestsPerSecond < 10
    ) {
      if (metrics.currentInstances > rules.minInstances) {
        const scaleDownAmount = Math.floor(metrics.currentInstances * 0.25); // Scale down by 25%
        action.action = 'scale-down';
        action.targetInstances = Math.max(
          metrics.currentInstances - scaleDownAmount,
          rules.minInstances
        );
        action.reason = `Low resource usage: CPU=${metrics.avgCpuUsage}%, Memory=${metrics.avgMemoryUsage}%`;
      }
    }

    if (action.action !== 'maintain') {
      this.lastScalingAction.set(appId, new Date());
      this.scalingHistory.push(action);
      return action;
    }

    return null;
  }

  /**
   * Get scaling history for an app
   */
  getScalingHistory(appId: string, limit: number = 100): ScalingAction[] {
    return this.scalingHistory
      .filter(a => a.appId === appId)
      .slice(-limit)
      .reverse();
  }

  /**
   * Get all scaling history
   */
  getAllScalingHistory(limit: number = 100): ScalingAction[] {
    return this.scalingHistory.slice(-limit).reverse();
  }

  /**
   * Get current scaling status for all apps
   */
  getScalingStatus(): Array<{ appId: string; rules: ScalingRules; lastAction?: Date }> {
    const status: Array<{ appId: string; rules: ScalingRules; lastAction?: Date }> = [];
    this.scalingRules.forEach((rules, appId) => {
      status.push({
        appId,
        rules,
        lastAction: this.lastScalingAction.get(appId),
      });
    });
    return status;
  }

  /**
   * Reset scaling cooldown for an app (for manual scaling)
   */
  resetCooldown(appId: string): void {
    this.lastScalingAction.delete(appId);
  }
}

// Export singleton instance
export const appScalingManager = new AppScalingManager();

/**
 * Pre-configured scaling rules for common app types
 */
export const defaultScalingRules = {
  // High-traffic apps (e.g., HouseHack with 10k+ users)
  highTraffic: {
    minInstances: 3,
    maxInstances: 50,
    cpuThreshold: 70,
    memoryThreshold: 80,
    scaleUpThreshold: 30,
    scaleDownThreshold: 20,
    cooldownPeriod: 300, // 5 minutes
  },

  // Medium-traffic apps (e.g., Syndica with 1k-5k users)
  mediumTraffic: {
    minInstances: 2,
    maxInstances: 20,
    cpuThreshold: 75,
    memoryThreshold: 85,
    scaleUpThreshold: 40,
    scaleDownThreshold: 25,
    cooldownPeriod: 600, // 10 minutes
  },

  // Low-traffic apps (e.g., new apps with <1k users)
  lowTraffic: {
    minInstances: 1,
    maxInstances: 10,
    cpuThreshold: 80,
    memoryThreshold: 90,
    scaleUpThreshold: 50,
    scaleDownThreshold: 30,
    cooldownPeriod: 900, // 15 minutes
  },

  // Always-on apps (e.g., critical infrastructure)
  alwaysOn: {
    minInstances: 5,
    maxInstances: 100,
    cpuThreshold: 60,
    memoryThreshold: 70,
    scaleUpThreshold: 20,
    scaleDownThreshold: 10,
    cooldownPeriod: 180, // 3 minutes
  },
};

/**
 * Example usage:
 *
 * // Register HouseHack with high-traffic scaling rules
 * appScalingManager.registerScalingRules({
 *   appId: 'househack-203k',
 *   ...defaultScalingRules.highTraffic,
 * });
 *
 * // Register Syndica with medium-traffic scaling rules
 * appScalingManager.registerScalingRules({
 *   appId: 'syndica',
 *   ...defaultScalingRules.mediumTraffic,
 * });
 *
 * // Evaluate scaling based on current metrics
 * const metrics: AppMetrics = {
 *   appId: 'househack-203k',
 *   currentInstances: 5,
 *   avgCpuUsage: 85,
 *   avgMemoryUsage: 88,
 *   requestsPerSecond: 150,
 *   errorRate: 0.5,
 *   avgResponseTime: 250,
 *   activeUsers: 8500,
 * };
 *
 * const scalingAction = appScalingManager.evaluateScaling('househack-203k', metrics);
 * if (scalingAction && scalingAction.action === 'scale-up') {
 *   // Execute scaling up: spawn 2-3 more instances
 *   console.log(`Scaling up ${scalingAction.appId} from ${scalingAction.currentInstances} to ${scalingAction.targetInstances}`);
 * }
 */

export default AppScalingManager;
