/**
 * Mock Mode Service
 * Simulates API responses without making real external API calls
 * Useful for development and testing without burning API credits
 */

export interface MockModeConfig {
  enabled: boolean;
  delay: number; // milliseconds to simulate network delay
  failureRate: number; // 0-1, probability of simulated failures
}

let mockConfig: MockModeConfig = {
  enabled: true, // Enabled by default for development
  delay: 500,
  failureRate: 0,
};

export const getMockConfig = (): MockModeConfig => mockConfig;

export const setMockConfig = (config: Partial<MockModeConfig>) => {
  mockConfig = { ...mockConfig, ...config };
};

export const toggleMockMode = (enabled: boolean) => {
  mockConfig.enabled = enabled;
};

// Simulate network delay
const simulateDelay = (ms: number = mockConfig.delay): Promise<void> => {
  return new Promise((resolve) => setTimeout(resolve, ms));
};

// Simulate random failure
const shouldFail = (): boolean => {
  return Math.random() < mockConfig.failureRate;
};

// Mock Data Generators
export const mockData = {
  // Call data
  generateCall: () => ({
    id: `call_${Math.random().toString(36).substr(2, 9)}`,
    fromNumber: `+1${Math.floor(Math.random() * 9000000000 + 1000000000)}`,
    toNumber: '+1-555-123-4567',
    duration: Math.floor(Math.random() * 600) + 30,
    outcome: ['booked', 'missed', 'transferred', 'voicemail', 'callback'][Math.floor(Math.random() * 5)],
    transcript: 'This is a mock transcript of the call conversation...',
    sentiment: ['positive', 'neutral', 'negative'][Math.floor(Math.random() * 3)],
    startedAt: new Date(Date.now() - Math.random() * 86400000),
    endedAt: new Date(),
  }),

  generateCalls: (count: number = 10) => {
    return Array.from({ length: count }, () => mockData.generateCall());
  },

  // Booking data
  generateBooking: () => ({
    id: `booking_${Math.random().toString(36).substr(2, 9)}`,
    clientName: ['John Smith', 'Sarah Johnson', 'Mike Chen', 'Jessica Martinez', 'David Lee'][
      Math.floor(Math.random() * 5)
    ],
    clientPhone: `+1${Math.floor(Math.random() * 9000000000 + 1000000000)}`,
    clientEmail: 'client@example.com',
    appointmentTime: new Date(Date.now() + Math.random() * 604800000),
    status: ['confirmed', 'completed', 'cancelled'][Math.floor(Math.random() * 3)],
    duration: [30, 60, 90][Math.floor(Math.random() * 3)],
  }),

  generateBookings: (count: number = 5) => {
    return Array.from({ length: count }, () => mockData.generateBooking());
  },

  // Payment data
  generatePayment: () => ({
    id: `payment_${Math.random().toString(36).substr(2, 9)}`,
    amount: (Math.random() * 1000 + 50).toFixed(2),
    currency: 'USD',
    status: ['succeeded', 'pending', 'failed'][Math.floor(Math.random() * 3)],
    description: 'Service payment',
    paidAt: new Date(),
  }),

  generatePayments: (count: number = 3) => {
    return Array.from({ length: count }, () => mockData.generatePayment());
  },

  // KPI data
  generateKPIs: () => ({
    callsAnswered: Math.floor(Math.random() * 5000) + 100,
    appointmentsBooked: Math.floor(Math.random() * 2000) + 50,
    revenueGenerated: (Math.random() * 100000 + 5000).toFixed(2),
    teamMembers: Math.floor(Math.random() * 20) + 1,
    averageCallDuration: Math.floor(Math.random() * 600) + 60,
    conversionRate: (Math.random() * 100).toFixed(1),
  }),

  // User data
  generateUser: () => ({
    id: `user_${Math.random().toString(36).substr(2, 9)}`,
    name: 'Test User',
    email: 'test@example.com',
    businessName: 'Test Business',
    tier: ['free_trial', 'starter', 'professional', 'enterprise'][Math.floor(Math.random() * 4)],
    createdAt: new Date(),
  }),

  // Message/Notification data
  generateNotification: () => ({
    id: `notif_${Math.random().toString(36).substr(2, 9)}`,
    type: ['call', 'booking', 'payment', 'alert'][Math.floor(Math.random() * 4)],
    message: 'New notification received',
    timestamp: new Date(),
    read: Math.random() > 0.5,
  }),

  generateNotifications: (count: number = 5) => {
    return Array.from({ length: count }, () => mockData.generateNotification());
  },
};

// Mock API Handlers
export const mockAPI = {
  // Calls
  async getCalls(limit: number = 10) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to fetch calls');
    return mockData.generateCalls(limit);
  },

  async logCall(callData: any) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to log call');
    return { success: true, callId: `call_${Math.random().toString(36).substr(2, 9)}` };
  },

  // Bookings
  async getBookings(limit: number = 10) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to fetch bookings');
    return mockData.generateBookings(limit);
  },

  async createBooking(bookingData: any) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to create booking');
    return { success: true, bookingId: `booking_${Math.random().toString(36).substr(2, 9)}` };
  },

  // Payments
  async getPayments(limit: number = 10) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to fetch payments');
    return mockData.generatePayments(limit);
  },

  async processPayment(paymentData: any) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to process payment');
    return { success: true, paymentId: `payment_${Math.random().toString(36).substr(2, 9)}` };
  },

  // KPIs
  async getKPIs() {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to fetch KPIs');
    return mockData.generateKPIs();
  },

  // Messages
  async sendMessage(message: string, recipient: string) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to send message');
    return { success: true, messageId: `msg_${Math.random().toString(36).substr(2, 9)}` };
  },

  // Notifications
  async getNotifications(limit: number = 10) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to fetch notifications');
    return mockData.generateNotifications(limit);
  },

  // Email
  async sendEmail(to: string, subject: string, body: string) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to send email');
    return { success: true, emailId: `email_${Math.random().toString(36).substr(2, 9)}` };
  },

  // SMS
  async sendSMS(to: string, message: string) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to send SMS');
    return { success: true, smsId: `sms_${Math.random().toString(36).substr(2, 9)}` };
  },

  // Analytics
  async trackEvent(eventName: string, eventData: any) {
    await simulateDelay();
    if (shouldFail()) throw new Error('Failed to track event');
    return { success: true };
  },

  // Integrations
  async testIntegration(integrationType: string, credentials: any) {
    await simulateDelay();
    if (shouldFail()) throw new Error(`Failed to test ${integrationType} integration`);
    return { success: true, message: `${integrationType} integration is working` };
  },
};

// API Call Wrapper - uses mock mode if enabled, otherwise makes real calls
export const apiCall = async (
  endpoint: string,
  method: string = 'GET',
  data?: any,
  useMock: boolean = mockConfig.enabled
) => {
  if (useMock) {
    // Route to appropriate mock handler
    const [resource, action] = endpoint.split('/').filter(Boolean);

    if (resource === 'calls' && action === 'log') {
      return mockAPI.logCall(data);
    } else if (resource === 'calls') {
      return mockAPI.getCalls();
    } else if (resource === 'bookings' && method === 'POST') {
      return mockAPI.createBooking(data);
    } else if (resource === 'bookings') {
      return mockAPI.getBookings();
    } else if (resource === 'payments' && method === 'POST') {
      return mockAPI.processPayment(data);
    } else if (resource === 'payments') {
      return mockAPI.getPayments();
    } else if (resource === 'kpis') {
      return mockAPI.getKPIs();
    } else if (resource === 'notifications') {
      return mockAPI.getNotifications();
    } else if (resource === 'email') {
      return mockAPI.sendEmail(data.to, data.subject, data.body);
    } else if (resource === 'sms') {
      return mockAPI.sendSMS(data.to, data.message);
    } else if (resource === 'analytics') {
      return mockAPI.trackEvent(data.eventName, data.eventData);
    } else if (resource === 'integrations') {
      return mockAPI.testIntegration(data.type, data.credentials);
    }

    return { success: true, data: {} };
  } else {
    // Make real API call
    const response = await fetch(endpoint, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: data ? JSON.stringify(data) : undefined,
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }

    return response.json();
  }
};

export default {
  getMockConfig,
  setMockConfig,
  toggleMockMode,
  mockData,
  mockAPI,
  apiCall,
};
