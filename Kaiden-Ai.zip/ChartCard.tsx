/**
 * Chart Card Component
 * Wrapper for chart visualizations
 */

import React from 'react';
import { Download, Settings } from 'lucide-react';

interface ChartCardProps {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  onExport?: () => void;
  onSettings?: () => void;
  loading?: boolean;
  height?: number;
}

export function ChartCard({
  title,
  subtitle,
  children,
  onExport,
  onSettings,
  loading = false,
  height = 300,
}: ChartCardProps) {
  return (
    <div className="bg-slate-800 border border-slate-700 rounded-lg p-6 hover:border-slate-600 transition">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-white">{title}</h2>
          {subtitle && <p className="text-slate-400 text-sm mt-1">{subtitle}</p>}
        </div>
        <div className="flex items-center gap-2">
          {onExport && (
            <button
              onClick={onExport}
              className="p-2 hover:bg-slate-700 rounded-lg transition text-slate-400 hover:text-white"
              title="Export data"
            >
              <Download className="w-5 h-5" />
            </button>
          )}
          {onSettings && (
            <button
              onClick={onSettings}
              className="p-2 hover:bg-slate-700 rounded-lg transition text-slate-400 hover:text-white"
              title="Chart settings"
            >
              <Settings className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {loading ? (
        <div
          className="bg-slate-700/30 rounded animate-pulse"
          style={{ height: `${height}px` }}
        ></div>
      ) : (
        <div style={{ height: `${height}px` }}>{children}</div>
      )}
    </div>
  );
}

export default ChartCard;
