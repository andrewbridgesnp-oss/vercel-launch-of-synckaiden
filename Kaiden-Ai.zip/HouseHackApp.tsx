import React, { Suspense, lazy } from 'react';
import { AppMetadata } from '@/lib/appIntegration';

// Lazy load HouseHack app
const HouseHackApp = lazy(() => import('./househack/src/App').catch(() => ({
  default: () => <div className="p-8 text-center">HouseHack app loading...</div>
})));

export const HouseHackAppMetadata: AppMetadata = {
  id: 'househack-203k',
  name: 'HouseHack 203K',
  description: 'Production-ready SaaS for real estate buyers navigating FHA 203(k) renovation loans with agent referral commission system',
  icon: '🏠',
  category: 'real-estate',
  version: '1.0.0',
  author: 'HouseHack Team',
  website: 'https://househack.app',
  pricing: {
    free: true,
    plans: [
      {
        name: 'Free',
        price: 0,
        features: ['1 Deal Room', 'Basic calculators', 'Community support']
      },
      {
        name: 'Pro',
        price: 29,
        features: ['Unlimited deals', 'Team features', 'Priority support', '20% agent commission']
      },
      {
        name: 'Team',
        price: 99,
        features: ['Partner workspace', 'White-label', 'API access', '20% agent commission']
      }
    ]
  },
  features: [
    'FHA 203(k) Eligibility Wizard',
    'Deal Room Management',
    'Financial Calculator',
    '203(k) Fit Score',
    'Scope Builder',
    'Partner Marketplace',
    'Document Vault',
    'Timeline Tracker',
    'Team Collaboration',
    'Agent Referral Commission',
    '50-State Coverage',
    'Mobile App Ready'
  ],
  status: 'active',
  integrations: ['Stripe', 'Twilio', 'Google Maps', 'HubSpot'],
  route: '/apps/househack',
  component: () => (
    <Suspense fallback={<div className="p-8 text-center">Loading HouseHack...</div>}>
      <HouseHackApp />
    </Suspense>
  ),
  requiredPermissions: ['read:deals', 'write:deals', 'read:users'],
  installDate: new Date()
};

export default HouseHackAppMetadata;
