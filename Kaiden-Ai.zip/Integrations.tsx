import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Redirect } from "wouter";
import {
  Search,
  ExternalLink,
  Check,
  Plus,
  Settings,
  Zap,
  CreditCard,
  MessageSquare,
  Mail,
  Github,
  Database,
  FileSpreadsheet,
  Calendar,
  Video,
  Cloud,
  Music,
  Building,
  Webhook,
  Key,
  Shield,
} from "lucide-react";

// Top 19 integrations
const integrations = [
  {
    id: 'gumroad',
    name: 'Gumroad',
    description: 'Accept payments without holds. Instant payouts to your bank.',
    icon: CreditCard,
    category: 'Payments',
    status: 'available',
    popular: true,
  },
  {
    id: 'xero',
    name: 'Xero',
    description: 'Cloud accounting that syncs with BlueVine and NAV.',
    icon: CreditCard,
    category: 'Accounting',
    status: 'available',
    popular: true,
  },
  {
    id: 'bluevine',
    name: 'BlueVine',
    description: 'Business banking with high-yield checking and credit lines up to $250K.',
    icon: Building,
    category: 'Banking',
    status: 'available',
    popular: true,
  },
  {
    id: 'nav',
    name: 'NAV',
    description: 'Business credit monitoring and tradeline recommendations.',
    icon: Building,
    category: 'Credit',
    status: 'available',
    popular: true,
  },
  {
    id: 'twilio',
    name: 'Twilio',
    description: 'SMS, voice calls, and communication APIs',
    icon: MessageSquare,
    category: 'Communication',
    status: 'available',
    popular: true,
  },
  {
    id: 'sendgrid',
    name: 'SendGrid',
    description: 'Transactional and marketing email delivery',
    icon: Mail,
    category: 'Email',
    status: 'connected',
    popular: true,
  },
  {
    id: 'slack',
    name: 'Slack',
    description: 'Team messaging and notifications',
    icon: MessageSquare,
    category: 'Messaging',
    status: 'available',
    popular: true,
  },
  {
    id: 'github',
    name: 'GitHub',
    description: 'Code repositories and version control',
    icon: Github,
    category: 'Development',
    status: 'connected',
    popular: true,
  },
  {
    id: 'hubspot',
    name: 'HubSpot',
    description: 'CRM, marketing, and sales automation',
    icon: Building,
    category: 'CRM',
    status: 'available',
    popular: true,
  },
  {
    id: 'google-sheets',
    name: 'Google Sheets',
    description: 'Spreadsheet data sync and automation',
    icon: FileSpreadsheet,
    category: 'Data',
    status: 'connected',
    popular: true,
  },
  {
    id: 'airtable',
    name: 'Airtable',
    description: 'Flexible database and project management',
    icon: Database,
    category: 'Database',
    status: 'available',
    popular: false,
  },
  {
    id: 'notion',
    name: 'Notion',
    description: 'Documentation and knowledge management',
    icon: FileSpreadsheet,
    category: 'Docs',
    status: 'available',
    popular: true,
  },
  {
    id: 'zapier',
    name: 'Zapier',
    description: 'Connect with 5000+ apps through workflows',
    icon: Zap,
    category: 'Automation',
    status: 'connected',
    popular: true,
  },
  {
    id: 'openai',
    name: 'OpenAI',
    description: 'GPT models and AI capabilities',
    icon: Zap,
    category: 'AI',
    status: 'connected',
    popular: true,
  },
  {
    id: 'spotify',
    name: 'Spotify',
    description: 'Music streaming and playback control',
    icon: Music,
    category: 'Music',
    status: 'available',
    popular: true,
  },
  {
    id: 'plaid',
    name: 'Plaid',
    description: 'Bank account connections and financial data',
    icon: Building,
    category: 'Banking',
    status: 'available',
    popular: true,
  },
  {
    id: 'calendly',
    name: 'Calendly',
    description: 'Scheduling and appointment booking',
    icon: Calendar,
    category: 'Scheduling',
    status: 'available',
    popular: false,
  },
  {
    id: 'docusign',
    name: 'DocuSign',
    description: 'Electronic signatures and agreements',
    icon: FileSpreadsheet,
    category: 'Signatures',
    status: 'available',
    popular: false,
  },
  {
    id: 'zoom',
    name: 'Zoom',
    description: 'Video conferencing and meetings',
    icon: Video,
    category: 'Video',
    status: 'available',
    popular: true,
  },
  {
    id: 'salesforce',
    name: 'Salesforce',
    description: 'Enterprise CRM and sales platform',
    icon: Cloud,
    category: 'CRM',
    status: 'available',
    popular: false,
  },
  {
    id: 'quickbooks',
    name: 'QuickBooks',
    description: 'Accounting and bookkeeping',
    icon: CreditCard,
    category: 'Accounting',
    status: 'available',
    popular: true,
  },
  {
    id: 'mailchimp',
    name: 'Mailchimp',
    description: 'Email marketing and automation',
    icon: Mail,
    category: 'Marketing',
    status: 'available',
    popular: false,
  },
];

const categories = [
  'All',
  'Payments',
  'Communication',
  'Email',
  'CRM',
  'Data',
  'Automation',
  'AI',
  'Banking',
  'Credit',
  'Accounting',
];

export default function Integrations() {
  const { isAuthenticated, loading } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [showConnectedOnly, setShowConnectedOnly] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
            <Webhook className="h-8 w-8 text-primary" />
          </div>
          <p className="text-muted-foreground">Loading integrations...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  const filteredIntegrations = integrations.filter((integration) => {
    const matchesSearch = integration.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         integration.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || integration.category === selectedCategory;
    const matchesConnected = !showConnectedOnly || integration.status === 'connected';
    return matchesSearch && matchesCategory && matchesConnected;
  });

  const connectedCount = integrations.filter(i => i.status === 'connected').length;

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold mb-2">
                <span className="gradient-text">Integrations</span>
              </h1>
              <p className="text-muted-foreground">
                Connect your favorite tools and services to supercharge your workflow.
              </p>
            </div>
            <Button className="btn-shine gap-2">
              <Key className="h-4 w-4" />
              API Keys
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            <Card className="luxury-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                    <Webhook className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">19</div>
                    <div className="text-sm text-muted-foreground">Available</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="luxury-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                    <Check className="h-5 w-5 text-green-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{connectedCount}</div>
                    <div className="text-sm text-muted-foreground">Connected</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="luxury-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                    <Shield className="h-5 w-5 text-blue-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">100%</div>
                    <div className="text-sm text-muted-foreground">Secure</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search integrations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Switch
                checked={showConnectedOnly}
                onCheckedChange={setShowConnectedOnly}
              />
              <span className="text-sm">Connected only</span>
            </div>
          </div>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Integrations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredIntegrations.map((integration) => {
            const Icon = integration.icon;
            const isConnected = integration.status === 'connected';
            
            return (
              <Card key={integration.id} className="luxury-card card-hover">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        isConnected ? 'bg-green-500/20' : 'bg-primary/20'
                      }`}>
                        <Icon className={`h-6 w-6 ${isConnected ? 'text-green-500' : 'text-primary'}`} />
                      </div>
                      <div>
                        <CardTitle className="text-lg flex items-center gap-2">
                          {integration.name}
                          {integration.popular && (
                            <Badge variant="secondary" className="text-xs">Popular</Badge>
                          )}
                        </CardTitle>
                        <Badge variant="outline" className="text-xs mt-1">
                          {integration.category}
                        </Badge>
                      </div>
                    </div>
                    {isConnected && (
                      <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
                        <Check className="h-4 w-4 text-white" />
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    {integration.description}
                  </CardDescription>
                  <div className="flex gap-2">
                    {isConnected ? (
                      <>
                        <Button variant="outline" size="sm" className="flex-1 gap-1">
                          <Settings className="h-3 w-3" />
                          Configure
                        </Button>
                        <Button variant="ghost" size="sm">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </>
                    ) : (
                      <Button size="sm" className="flex-1 gap-1 btn-shine">
                        <Plus className="h-3 w-3" />
                        Connect
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Empty State */}
        {filteredIntegrations.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
              <Search className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No integrations found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search or filter criteria.
            </p>
          </div>
        )}

        {/* Request Integration */}
        <Card className="luxury-card mt-12">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center">
              <Plus className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Need a different integration?</h3>
            <p className="text-muted-foreground mb-4 max-w-md mx-auto">
              We're always adding new integrations. Let us know what you need and we'll prioritize it.
            </p>
            <Button variant="outline" className="gap-2">
              <MessageSquare className="h-4 w-4" />
              Request Integration
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
