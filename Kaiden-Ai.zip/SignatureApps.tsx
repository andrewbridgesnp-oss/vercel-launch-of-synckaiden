import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Users, Heart, DollarSign, Palette, Eye, Bot,
  Hammer, Music, UtensilsCrossed, ArrowRight, Play
} from "lucide-react";
import { Link } from "wouter";

// Signature apps with full details
const signatureApps = [
  {
    id: 'wheres-my-tribe',
    name: "Where's My Tribe",
    tagline: 'Find Your Community',
    description: 'Connect with like-minded individuals who share your passions, goals, and values. Build meaningful relationships and grow together.',
    icon: Users,
    color: 'from-blue-500 to-cyan-500',
    features: ['Smart Matching', 'Community Events', 'Group Chats', 'Interest-Based Discovery'],
    price: 9.99,
    category: 'Social',
    status: 'live',
    image: '/images/community-app.png',
  },
  {
    id: 'vitalsync',
    name: 'VitalSync',
    tagline: 'Your Health, Synchronized',
    description: 'Comprehensive telehealth and wellness tracking. Monitor vitals, schedule appointments, and get AI-powered health insights.',
    icon: Heart,
    color: 'from-red-500 to-pink-500',
    features: ['Telehealth Visits', 'Vital Tracking', 'AI Health Insights', 'Medication Reminders'],
    price: 14.99,
    category: 'Health',
    status: 'live',
    image: '/images/health-app.png',
  },
  {
    id: 'financial-copilot',
    name: 'Financial Co-Pilot',
    tagline: 'Navigate Your Finances',
    description: 'AI-powered financial guidance. Budget tracking, investment insights, and personalized wealth-building strategies.',
    icon: DollarSign,
    color: 'from-green-500 to-emerald-500',
    features: ['Budget Tracking', 'Investment Analysis', 'Debt Payoff Plans', 'Wealth Building'],
    price: 19.99,
    category: 'Finance',
    status: 'live',
    image: '/images/finance-dashboard.png',
  },
  {
    id: 'content-engine',
    name: 'Content Creation Engine',
    tagline: 'Create Without Limits',
    description: 'AI-assisted content creation for social media, blogs, and marketing. Generate, edit, and schedule content effortlessly.',
    icon: Palette,
    color: 'from-purple-500 to-violet-500',
    features: ['AI Writing', 'Image Generation', 'Social Scheduling', 'Analytics'],
    price: 14.99,
    category: 'Creative',
    status: 'live',
    image: '/images/content-creation.png',
  },
  {
    id: 'reality-sync',
    name: 'Reality Sync',
    tagline: 'Align Your Reality',
    description: 'Goal setting and manifestation tool. Track habits, visualize success, and align your daily actions with your dreams.',
    icon: Eye,
    color: 'from-indigo-500 to-blue-500',
    features: ['Goal Tracking', 'Vision Boards', 'Habit Streaks', 'Progress Analytics'],
    price: 12.99,
    category: 'Productivity',
    status: 'live',
    image: '/images/ai-dashboard.jpg',
  },
  {
    id: 'pal',
    name: 'PAL',
    tagline: 'Personal AI Liaison',
    description: 'Your personal AI assistant that learns your preferences and helps manage your daily life with intelligent automation.',
    icon: Bot,
    color: 'from-cyan-500 to-teal-500',
    features: ['Smart Scheduling', 'Task Automation', 'Voice Commands', 'Learning AI'],
    price: 9.99,
    category: 'Assistant',
    status: 'live',
    image: '/images/marketing-dashboard.jpg',
  },
  {
    id: 'builder-sync',
    name: 'Builder Sync',
    tagline: 'Build Your Vision',
    description: 'Project management and development toolkit. From idea to execution, manage your builds with precision.',
    icon: Hammer,
    color: 'from-orange-500 to-amber-500',
    features: ['Project Management', 'Code Collaboration', 'Deployment Tools', 'Team Sync'],
    price: 14.99,
    category: 'Development',
    status: 'live',
    image: '/images/futuristic-interface.jpg',
  },
  {
    id: 'master-music',
    name: 'Master Music Production',
    tagline: 'Professional Audio Mastering',
    description: 'AI-powered audio mastering and production tools. Create professional-quality music with intelligent processing.',
    icon: Music,
    color: 'from-pink-500 to-rose-500',
    features: ['AI Mastering', 'Mix Analysis', 'Sound Design', 'Distribution'],
    price: 24.99,
    category: 'Audio',
    status: 'live',
    image: '/images/music-production.jpg',
  },
  {
    id: 'pantry-manager',
    name: 'Pantry Inventory',
    tagline: 'Smart Kitchen Management',
    description: 'Track your pantry, reduce waste, and get recipe suggestions based on what you have. Never wonder what is for dinner again.',
    icon: UtensilsCrossed,
    color: 'from-yellow-500 to-orange-500',
    features: ['Inventory Tracking', 'Recipe Suggestions', 'Expiry Alerts', 'Shopping Lists'],
    price: 7.99,
    category: 'Home',
    status: 'live',
    image: '/images/health-activities.jpg',
  },
];

export default function SignatureApps() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-radial from-primary/10 via-transparent to-transparent" />
        <div className="container relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <Badge className="mb-4">Signature Collection</Badge>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="gradient-text">Signature</span> Apps
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Premium applications designed to transform every aspect of your life and business. 
              Each app is crafted with precision and powered by advanced AI.
            </p>
          </div>
        </div>
      </section>

      {/* Apps Grid */}
      <section className="py-16">
        <div className="container">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {signatureApps.map((app) => {
              const IconComponent = app.icon;
              return (
                <Card key={app.id} className="luxury-card overflow-hidden card-hover group">
                  {/* Image Header with Gradient Overlay */}
                  <div className={`h-40 relative overflow-hidden`}>
                    <img 
                      src={app.image} 
                      alt={app.name}
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                    <div className={`absolute inset-0 bg-gradient-to-br ${app.color} opacity-60`} />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
                      <div className="w-14 h-14 rounded-xl bg-background/90 backdrop-blur flex items-center justify-center">
                        <IconComponent className="h-7 w-7 text-foreground" />
                      </div>
                      <Badge variant="secondary" className="bg-background/90 backdrop-blur">
                        {app.category}
                      </Badge>
                    </div>
                  </div>
                  
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-xl">{app.name}</CardTitle>
                        <CardDescription className="text-primary">{app.tagline}</CardDescription>
                      </div>
                      <div className="text-right">
                        <span className="text-2xl font-bold">${app.price}</span>
                        <span className="text-muted-foreground text-sm">/mo</span>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <p className="text-muted-foreground text-sm mb-4">
                      {app.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {app.features.map((feature, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex gap-2">
                      <Button className="flex-1" variant="outline">
                        <Play className="h-4 w-4 mr-2" />
                        Demo
                      </Button>
                      <Button className="flex-1">
                        Get App
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Bundle CTA */}
      <section className="py-16 bg-secondary/30">
        <div className="container">
          <div className="luxury-card p-12 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20" />
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Get All Apps with <span className="gradient-text">Enterprise</span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
                Access every signature app with an Enterprise subscription. 
                Save over 60% compared to purchasing individually.
              </p>
              <Link href="/pricing">
                <Button size="lg" className="btn-shine glow-blue">
                  View Pricing
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
