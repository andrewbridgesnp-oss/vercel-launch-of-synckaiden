import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { 
  Phone, Calendar, MessageSquare, CreditCard, QrCode, 
  Package, TrendingDown, Users, Clock, Music, Coffee,
  Mic, Send, Shield, ArrowRight, Check, Star, Building2
} from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

// AI Receptionist Features
const features = [
  {
    icon: Phone,
    title: 'Answer Phones 24/7',
    description: 'AI answers calls professionally, handles inquiries, and routes urgent matters to staff.',
  },
  {
    icon: Calendar,
    title: 'Smart Scheduling',
    description: 'Books appointments based on your criteria - service type, staff availability, client preferences.',
  },
  {
    icon: MessageSquare,
    title: 'Follow-up Communications',
    description: 'Automated texts, calls, and coupons to keep clients engaged and returning.',
  },
  {
    icon: CreditCard,
    title: 'Secure Payment Links',
    description: 'Generate and send secure payment links via text or email. No direct payment handling.',
  },
  {
    icon: QrCode,
    title: 'Employee QR Codes',
    description: 'Unique QR codes per employee for in-person payments and tip tracking.',
  },
  {
    icon: Package,
    title: 'Inventory Management',
    description: 'Monitor stock levels, auto-reorder, and track product usage patterns.',
  },
  {
    icon: TrendingDown,
    title: 'Vendor Deal Finder',
    description: 'AI finds better deals and alternative vendors to reduce costs.',
  },
  {
    icon: Users,
    title: 'Team Unity Tools',
    description: 'Staff scheduling, performance tracking, and team communication features.',
  },
  {
    icon: Clock,
    title: 'Always Active',
    description: '24-hour availability ensures no missed opportunities, even after hours.',
  },
  {
    icon: Music,
    title: 'Ambient Music',
    description: 'Spotify integration for waiting areas. Play user-specific playlists.',
  },
  {
    icon: Coffee,
    title: 'Voice Commands',
    description: 'Order coffee, adjust settings, and control features via voice with approval.',
  },
  {
    icon: Mic,
    title: 'Visitor QR Code',
    description: 'Give in-person visitors a QR code to try the web app while they wait.',
  },
];

// VIP Businesses
const vipBusinesses = [
  {
    name: 'Salon Sano',
    location: 'Augusta, GA',
    type: 'Hair Salon',
    subdomain: 'salonsano.synckaiden.com',
    status: 'active',
  },
  {
    name: 'Bougie Boutique',
    location: 'Atlanta, GA',
    type: 'Retail',
    subdomain: 'bougie.synckaiden.com',
    status: 'active',
  },
  {
    name: 'Cox & Co',
    location: 'Nationwide',
    type: 'Consulting',
    subdomain: 'coxandco.synckaiden.com',
    status: 'pending',
  },
];

export default function AIReceptionist() {
  const [businessName, setBusinessName] = useState('');
  const [businessPhone, setBusinessPhone] = useState('');
  const [businessType, setBusinessType] = useState('');
  const [enabledFeatures, setEnabledFeatures] = useState({
    phoneAnswering: true,
    scheduling: true,
    followUps: true,
    payments: false,
    inventory: false,
    music: true,
  });

  const toggleFeature = (feature: keyof typeof enabledFeatures) => {
    setEnabledFeatures(prev => ({ ...prev, [feature]: !prev[feature] }));
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 hero-gradient opacity-50" />
        <div className="container relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <Badge className="mb-4 bg-primary/20 text-primary border-primary/30">
              AI-Powered Business Management
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 tracking-tight">
              <span className="gradient-text">AI Receptionist</span>
              <br />
              <span className="text-foreground">Your 24/7 Business Partner</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Never miss a call, appointment, or opportunity. Kaiden AI handles phones, 
              scheduling, payments, inventory, and more - so you can focus on what matters.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="btn-shine glow-blue text-lg px-8 py-6">
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-6 glass">
                Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Complete Business Automation</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Everything you need to run your business efficiently, all powered by AI.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <Card key={idx} className="luxury-card card-hover">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center mb-4">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Setup Form */}
      <section className="py-16 bg-muted/30">
        <div className="container">
          <div className="max-w-2xl mx-auto">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="text-2xl">Setup Your AI Receptionist</CardTitle>
                <CardDescription>
                  Configure your AI receptionist to match your business needs.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="businessName">Business Name</Label>
                    <Input 
                      id="businessName"
                      placeholder="Enter your business name"
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="businessPhone">Business Phone</Label>
                    <Input 
                      id="businessPhone"
                      placeholder="(555) 123-4567"
                      value={businessPhone}
                      onChange={(e) => setBusinessPhone(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="businessType">Business Type</Label>
                    <Input 
                      id="businessType"
                      placeholder="e.g., Salon, Restaurant, Consulting"
                      value={businessType}
                      onChange={(e) => setBusinessType(e.target.value)}
                    />
                  </div>
                </div>

                <div className="border-t border-border pt-6">
                  <h4 className="font-semibold mb-4">Enable Features</h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Phone Answering</Label>
                        <p className="text-sm text-muted-foreground">AI answers calls 24/7</p>
                      </div>
                      <Switch 
                        checked={enabledFeatures.phoneAnswering}
                        onCheckedChange={() => toggleFeature('phoneAnswering')}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Smart Scheduling</Label>
                        <p className="text-sm text-muted-foreground">Automated appointment booking</p>
                      </div>
                      <Switch 
                        checked={enabledFeatures.scheduling}
                        onCheckedChange={() => toggleFeature('scheduling')}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Follow-up Communications</Label>
                        <p className="text-sm text-muted-foreground">Automated texts and reminders</p>
                      </div>
                      <Switch 
                        checked={enabledFeatures.followUps}
                        onCheckedChange={() => toggleFeature('followUps')}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Payment Links</Label>
                        <p className="text-sm text-muted-foreground">Secure payment link generation</p>
                      </div>
                      <Switch 
                        checked={enabledFeatures.payments}
                        onCheckedChange={() => toggleFeature('payments')}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Inventory Management</Label>
                        <p className="text-sm text-muted-foreground">Stock monitoring and reordering</p>
                      </div>
                      <Switch 
                        checked={enabledFeatures.inventory}
                        onCheckedChange={() => toggleFeature('inventory')}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Ambient Music</Label>
                        <p className="text-sm text-muted-foreground">Spotify integration for waiting areas</p>
                      </div>
                      <Switch 
                        checked={enabledFeatures.music}
                        onCheckedChange={() => toggleFeature('music')}
                      />
                    </div>
                  </div>
                </div>

                <Button className="w-full btn-shine glow-blue">
                  Activate AI Receptionist
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* VIP Businesses */}
      <section className="py-16">
        <div className="container">
          <div className="text-center mb-12">
            <Badge className="mb-4">VIP Partners</Badge>
            <h2 className="text-3xl font-bold mb-4">Businesses Using AI Receptionist</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Join these forward-thinking businesses already leveraging Kaiden AI.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {vipBusinesses.map((business, idx) => (
              <Card key={idx} className="luxury-card card-hover">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center">
                      <Building2 className="h-6 w-6 text-primary" />
                    </div>
                    <Badge variant={business.status === 'active' ? 'default' : 'secondary'}>
                      {business.status === 'active' ? 'Active' : 'Pending'}
                    </Badge>
                  </div>
                  <h3 className="font-semibold text-lg mb-1">{business.name}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{business.location}</p>
                  <Badge variant="outline" className="mb-3">{business.type}</Badge>
                  <p className="text-xs text-primary font-mono">{business.subdomain}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* QR Code Demo */}
      <section className="py-16 bg-muted/30">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <Card className="luxury-card overflow-hidden">
              <div className="grid md:grid-cols-2">
                <div className="p-8">
                  <h2 className="text-2xl font-bold mb-4">Employee QR Codes</h2>
                  <p className="text-muted-foreground mb-6">
                    Each employee gets a unique QR code for in-person payments and tips. 
                    Customers simply scan to pay - no cash handling required.
                  </p>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500" />
                      <span>Unique code per employee</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500" />
                      <span>Instant payment confirmation</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500" />
                      <span>Tip tracking and reporting</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500" />
                      <span>Connected to Stripe/BlueVine</span>
                    </li>
                  </ul>
                  <Button>
                    Generate QR Codes
                    <QrCode className="ml-2 h-4 w-4" />
                  </Button>
                </div>
                <div className="bg-gradient-to-br from-primary/20 to-accent/20 p-8 flex items-center justify-center">
                  <div className="w-48 h-48 bg-white rounded-xl flex items-center justify-center">
                    <QrCode className="h-32 w-32 text-navy-900" />
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-16">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Simple, Transparent Pricing</h2>
            <p className="text-muted-foreground">Start free, scale as you grow.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle>Starter</CardTitle>
                <CardDescription>For small businesses</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">$49</span>
                  <span className="text-muted-foreground">/month</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Phone answering (100 calls/mo)
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Basic scheduling
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    SMS follow-ups (500/mo)
                  </li>
                </ul>
                <Button variant="outline" className="w-full">Get Started</Button>
              </CardContent>
            </Card>
            <Card className="luxury-card border-primary">
              <CardHeader>
                <Badge className="w-fit mb-2">Most Popular</Badge>
                <CardTitle>Professional</CardTitle>
                <CardDescription>For growing businesses</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">$149</span>
                  <span className="text-muted-foreground">/month</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Unlimited phone answering
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Advanced scheduling
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Payment link generation
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Inventory management
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Employee QR codes
                  </li>
                </ul>
                <Button className="w-full btn-shine glow-blue">Get Started</Button>
              </CardContent>
            </Card>
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle>Enterprise</CardTitle>
                <CardDescription>For large operations</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">Custom</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Everything in Professional
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Multi-location support
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Custom integrations
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    Dedicated account manager
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <Check className="h-4 w-4 text-green-500" />
                    White-label option
                  </li>
                </ul>
                <Button variant="outline" className="w-full">Contact Sales</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Automate Your Business?</h2>
            <p className="text-muted-foreground mb-8">
              Join hundreds of businesses already using Kaiden AI Receptionist to save time, 
              increase revenue, and provide better customer experiences.
            </p>
            <Button size="lg" className="btn-shine glow-blue text-lg px-8 py-6">
              Start Free Trial
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
