import React from 'react';
import { ChevronRight, Star, Users, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AppTemplateProps {
  appName: string;
  appIcon: React.ReactNode;
  tagline: string;
  description: string;
  features: Array<{ icon: React.ReactNode; title: string; description: string }>;
  pricingTiers: Array<{
    name: string;
    price: number | null;
    period: string;
    features: string[];
    cta: string;
    highlighted?: boolean;
  }>;
  testimonials?: Array<{
    name: string;
    title: string;
    quote: string;
    rating: number;
    image: string;
  }>;
  stats?: Array<{ value: string; label: string }>;
  onGetStarted?: () => void;
  onViewDemo?: () => void;
}

const AppTemplate: React.FC<AppTemplateProps> = ({
  appName,
  appIcon,
  tagline,
  description,
  features,
  pricingTiers,
  testimonials,
  stats,
  onGetStarted,
  onViewDemo,
}) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <div className="mb-6 inline-flex items-center justify-center h-16 w-16 rounded-full bg-cyan-500/10">
              {appIcon}
            </div>
            <h1 className="mb-6 text-5xl font-bold tracking-tight text-white sm:text-6xl">
              {appName}
            </h1>
            <p className="mb-4 text-xl text-cyan-400 font-semibold">{tagline}</p>
            <p className="mb-8 text-xl text-slate-300">{description}</p>
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
              <Button
                onClick={onGetStarted}
                size="lg"
                className="bg-cyan-500 hover:bg-cyan-600 text-white"
              >
                Get Started <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                onClick={onViewDemo}
                size="lg"
                variant="outline"
                className="border-slate-600 text-white hover:bg-slate-800"
              >
                View Demo
              </Button>
            </div>
          </div>

          {/* Stats */}
          {stats && stats.length > 0 && (
            <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
              {stats.map((stat, index) => (
                <div
                  key={index}
                  className="rounded-lg bg-slate-800/50 p-6 text-center backdrop-blur"
                >
                  <div className="text-4xl font-bold text-cyan-400">{stat.value}</div>
                  <div className="mt-2 text-slate-300">{stat.label}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Features Section */}
      <div className="px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <h2 className="mb-4 text-center text-4xl font-bold text-white">
            Everything You Need
          </h2>
          <p className="mb-12 text-center text-xl text-slate-400">
            Powerful features to help you succeed
          </p>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <div key={index} className="rounded-lg bg-slate-800/50 p-6 backdrop-blur">
                <div className="mb-4 text-cyan-400">{feature.icon}</div>
                <h3 className="mb-2 text-lg font-semibold text-white">{feature.title}</h3>
                <p className="text-slate-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pricing Section */}
      <div className="px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <h2 className="mb-4 text-center text-4xl font-bold text-white">
            Simple, Transparent Pricing
          </h2>
          <p className="mb-12 text-center text-xl text-slate-400">
            Choose the plan that fits your needs
          </p>

          <div className={`grid grid-cols-1 gap-8 ${
            pricingTiers.length === 4 ? 'lg:grid-cols-4' : 'lg:grid-cols-3'
          }`}>
            {pricingTiers.map((tier, index) => (
              <div
                key={index}
                className={`relative rounded-lg backdrop-blur transition-all ${
                  tier.highlighted
                    ? 'border-2 border-cyan-400 bg-slate-800/80 ring-2 ring-cyan-400/20'
                    : 'border border-slate-700 bg-slate-800/50'
                }`}
              >
                {tier.highlighted && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 transform">
                    <span className="rounded-full bg-cyan-500 px-4 py-1 text-sm font-semibold text-white">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="p-6">
                  <h3 className="text-xl font-bold text-white">{tier.name}</h3>

                  <div className="mt-6">
                    {tier.price !== null ? (
                      <>
                        <span className="text-4xl font-bold text-white">${tier.price}</span>
                        <span className="text-slate-400">{tier.period}</span>
                      </>
                    ) : (
                      <span className="text-2xl font-bold text-cyan-400">Custom Pricing</span>
                    )}
                  </div>

                  <Button
                    className={`mt-6 w-full ${
                      tier.highlighted
                        ? 'bg-cyan-500 hover:bg-cyan-600 text-white'
                        : 'bg-slate-700 hover:bg-slate-600 text-white'
                    }`}
                  >
                    {tier.cta}
                  </Button>

                  <div className="mt-6 space-y-3">
                    {tier.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-start gap-3">
                        <div className="mt-1 h-5 w-5 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                          <div className="h-2 w-2 rounded-full bg-cyan-400" />
                        </div>
                        <span className="text-sm text-slate-300">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Testimonials Section */}
      {testimonials && testimonials.length > 0 && (
        <div className="px-4 py-20 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-6xl">
            <h2 className="mb-4 text-center text-4xl font-bold text-white">
              Loved by Users
            </h2>
            <p className="mb-12 text-center text-xl text-slate-400">
              See what people are saying
            </p>

            <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
              {testimonials.map((testimonial, index) => (
                <div key={index} className="rounded-lg bg-slate-800/50 p-6 backdrop-blur">
                  <div className="mb-4 flex gap-1">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star
                        key={i}
                        className="h-5 w-5 fill-yellow-400 text-yellow-400"
                      />
                    ))}
                  </div>
                  <p className="mb-6 text-slate-300">"{testimonial.quote}"</p>
                  <div className="flex items-center gap-3">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="h-12 w-12 rounded-full object-cover"
                    />
                    <div>
                      <div className="font-semibold text-white">{testimonial.name}</div>
                      <div className="text-sm text-slate-400">{testimonial.title}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <div className="px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl rounded-lg bg-gradient-to-r from-cyan-500/20 to-blue-500/20 p-12 text-center backdrop-blur">
          <h2 className="mb-4 text-3xl font-bold text-white">
            Ready to Get Started?
          </h2>
          <p className="mb-8 text-lg text-slate-300">
            Join thousands of users already using {appName}
          </p>
          <Button
            onClick={onGetStarted}
            size="lg"
            className="bg-cyan-500 hover:bg-cyan-600 text-white"
          >
            Start Now <ChevronRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AppTemplate;
