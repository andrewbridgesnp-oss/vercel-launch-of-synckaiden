import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Onboarding } from "@/components/Onboarding";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";
import { Heart } from "lucide-react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const { data: profile, refetch: refetchProfile } = trpc.profile.getProfile.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const [showContent, setShowContent] = useState(false);
  const [showButtons, setShowButtons] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  // Add CSS for gradient animation
  const styleSheet = document.createElement('style');
  if (!document.querySelector('style[data-gradient-animation]')) {
    styleSheet.setAttribute('data-gradient-animation', 'true');
    styleSheet.textContent = `
      @keyframes gradient {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
      }
    `;
    document.head.appendChild(styleSheet);
  }



  // Show onboarding for authenticated users without completed profile
  if (isAuthenticated && profile !== undefined && !profile?.onboardingCompleted) {
    return <Onboarding onComplete={() => refetchProfile()} />;
  }

  // Elegant reveal sequence - video plays for 3 seconds, then fade
  useEffect(() => {
    // Show content (fade video) after 3 seconds
    const contentTimer = setTimeout(() => {
      setShowContent(true);
    }, 3000);

    // Show buttons after content fades (3s video + 1s fade + 0.5s delay)
    const buttonTimer = setTimeout(() => {
      setShowButtons(true);
    }, 4500);



    return () => {
      clearTimeout(contentTimer);
      clearTimeout(buttonTimer);
    };
  }, []);

  // Speed up video to 3 seconds total, then fade
  useEffect(() => {
    if (videoRef.current) {
      // Calculate playback rate to finish video in 3 seconds
      // Assuming video is ~6-8 seconds, 2x speed gets us to ~3 seconds
      videoRef.current.playbackRate = 2.0; // 200% speed for 3-second play
      
      // After 3 seconds, fade to 5D homepage
      const fadeTimer = setTimeout(() => {
        setShowContent(true); // Start fading video out
      }, 3000);
      
      return () => clearTimeout(fadeTimer);
    }
  }, []);

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-black">
      {/* Single Video - User's uploaded video with fade transition */}
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover transition-opacity duration-1000"
        style={{ 
          opacity: showContent ? 0 : 0.9,
          filter: 'brightness(0.8) contrast(1.1)',
        }}
        autoPlay
        loop={false}
        muted
        playsInline
      >
        <source src="/kayden-hero-video.mp4" type="video/mp4" />
      </video>
      
      {/* 5D Background - Appears after video fades */}
      <div 
        className="absolute inset-0 w-full h-full transition-opacity duration-1000"
        style={{
          opacity: showContent ? 1 : 0,
          background: 'linear-gradient(135deg, #0a0e27 0%, #1a1f3a 25%, #0f1428 50%, #1a1f3a 75%, #0a0e27 100%)',
          backgroundSize: '400% 400%',
          animation: showContent ? 'gradient 15s ease infinite' : 'none',
        }}
      />

      {/* Luxury gradient overlay - fades with video */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60 transition-opacity duration-1000" style={{ opacity: showContent ? 0.3 : 1 }} />
      
      {/* Subtle vignette effect */}
      <div className="absolute inset-0" style={{
        background: 'radial-gradient(ellipse at center, transparent 0%, rgba(0,0,0,0.4) 100%)',
        opacity: showContent ? 0.2 : 1,
        transition: 'opacity 1s ease-out',
      }} />



      {/* Main Content - Top branding area */}
      <div className="relative z-20 flex flex-col items-center justify-start min-h-screen px-4 pt-20">
        
        {/* Large Kayden/Kaiden Name - appears first */}
        <h2 className="sr-only">Restore Your Time with Safe Automation</h2>
        <h1
          className="text-6xl md:text-8xl font-bold tracking-tighter mb-4"
          style={{
            opacity: showContent ? 1 : 0,
            transform: showContent ? 'translateY(0)' : 'translateY(-30px)',
            transition: 'all 1.5s ease-out',
            fontFamily: "'Playfair Display', serif",
            background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(200,200,220,0.7) 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            textShadow: '0 0 30px rgba(100,150,255,0.3)',
            letterSpacing: '-0.02em',
          }}
        >
          KAYDEN
        </h1>
        
        {/* Subtle tagline */}
        <p
          className="text-base md:text-lg font-light tracking-widest mb-32"
          style={{
            opacity: showContent ? 0.7 : 0,
            transform: showContent ? 'translateY(0)' : 'translateY(20px)',
            transition: 'all 1.2s ease-out 0.3s',
            fontFamily: "'Inter', sans-serif",
            color: "rgba(200, 200, 220, 0.8)",
            letterSpacing: "0.3em",
          }}
        >
          YOUR BUSINESS OPERATOR
        </p>
        <h2 className="sr-only">Approval-Gated Automation for Human Agency</h2>

      </div>

      {/* Bottom CTA Buttons - All buttons at bottom for better visibility */}
      <div 
        className="absolute bottom-0 left-0 right-0 z-20 flex flex-col items-center justify-end pb-20 px-4"
        style={{
          opacity: showButtons ? 1 : 0,
          transform: showButtons ? 'translateY(0)' : 'translateY(20px)',
          transition: 'all 1s ease-out',
        }}
      >
        {/* Main action buttons */}
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          {isAuthenticated ? (
            <>
              <Link href="/dashboard">
                <Button
                  size="lg"
                  className="px-16 py-7 text-lg font-medium rounded-full transition-all duration-500 hover:scale-105"
                  style={{
                    background: "linear-gradient(135deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 100%)",
                    backdropFilter: "blur(20px)",
                    border: "1px solid rgba(255,255,255,0.2)",
                    color: "rgba(255,255,255,0.9)",
                    boxShadow: "0 8px 32px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1)",
                  }}
                >
                  Enter
                </Button>
              </Link>

              <Link href="/pricing">
                <Button
                  size="lg"
                  className="px-12 py-7 text-lg font-medium rounded-full transition-all duration-500 hover:scale-105"
                  style={{
                    background: "transparent",
                    border: "1px solid rgba(255,255,255,0.15)",
                    color: "rgba(255,255,255,0.7)",
                  }}
                >
                  View Plans
                </Button>
              </Link>
            </>
          ) : (
            <>
              <a href={getLoginUrl()}>
                <Button
                  size="lg"
                  className="px-16 py-7 text-lg font-medium rounded-full transition-all duration-500 hover:scale-105"
                  style={{
                    background: "linear-gradient(135deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 100%)",
                    backdropFilter: "blur(20px)",
                    border: "1px solid rgba(255,255,255,0.2)",
                    color: "rgba(255,255,255,0.9)",
                    boxShadow: "0 8px 32px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.1)",
                  }}
                >
                  Enter
                </Button>
              </a>

              <Link href="/pricing">
                <Button
                  size="lg"
                  className="px-12 py-7 text-lg font-medium rounded-full transition-all duration-500 hover:scale-105"
                  style={{
                    background: "transparent",
                    border: "1px solid rgba(255,255,255,0.15)",
                    color: "rgba(255,255,255,0.7)",
                  }}
                >
                  View Plans
                </Button>
              </Link>
            </>
          )}
        </div>

        {/* CTA Buttons Section */}
        <h2 className="sr-only">Get Started with Kayden</h2>
        
        {/* Bougie Boutique Button - Birthday Edition */}
        <Link href="/bougie-boutique">
          <Button
            size="lg"
            className="px-8 py-6 text-base font-medium rounded-full transition-all duration-500 hover:scale-110 flex items-center gap-3 relative overflow-hidden"
            style={{
              background: "linear-gradient(135deg, rgba(236,72,153,0.3) 0%, rgba(168,85,247,0.3) 50%, rgba(236,72,153,0.3) 100%)",
              backgroundSize: "200% 200%",
              animation: "gradient 3s ease infinite",
              backdropFilter: "blur(20px)",
              border: "2px solid rgba(236,72,153,0.5)",
              color: "rgba(255,255,255,0.95)",
              boxShadow: "0 0 20px rgba(236,72,153,0.4), 0 0 40px rgba(168,85,247,0.2)",
            }}
          >
            <img 
              src="/bougie-boutique-logo.png" 
              alt="Bougie Boutique" 
              className="w-6 h-6 rounded-full object-cover"
            />
            <span className="font-semibold">Bougie Boutique</span>
          </Button>
        </Link>

        {/* Trust indicators - subtle */}
        <h2 className="sr-only">Why Teams Choose Kayden</h2>
        <div 
          className="flex flex-wrap items-center justify-center gap-6 mt-6"
          style={{
            opacity: showButtons ? 0.5 : 0,
            transition: 'opacity 1s ease-out 0.3s',
          }}
        >
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <svg className="w-3.5 h-3.5 text-green-500/70" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span>Encrypted</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <svg className="w-3.5 h-3.5 text-blue-500/70" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span>Professionally Reviewed</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <svg className="w-3.5 h-3.5 text-purple-500/70" fill="currentColor" viewBox="0 0 20 20">
              <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
            </svg>
            <span>1,000+ Served</span>
          </div>
        </div>
      </div>

      {/* Bottom branding - minimal */}
      <h2 className="sr-only">Offline-First, Privacy-Respecting Automation</h2>
      <div 
        className="absolute bottom-4 left-0 right-0 z-20 flex flex-col items-center"
        style={{
          opacity: showButtons ? 0.4 : 0,
          transition: 'opacity 1s ease-out 0.5s',
        }}
      >
        <p 
          className="text-xs tracking-widest mb-2"
          style={{
            fontFamily: "'Inter', sans-serif",
            color: "rgba(180, 180, 200, 0.6)",
            letterSpacing: "0.2em",
          }}
        >
          SYNDICA SOLUTIONS
        </p>
        <div className="flex gap-4">
          <Link href="/terms" className="text-xs text-gray-500/50 hover:text-gray-400 transition-colors">Terms</Link>
          <span className="text-xs text-gray-600/30">•</span>
          <Link href="/privacy" className="text-xs text-gray-500/50 hover:text-gray-400 transition-colors">Privacy</Link>
        </div>
      </div>
    </div>
  );
}
