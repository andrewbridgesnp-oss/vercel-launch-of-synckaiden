  const { data: campaigns, isLoading } = trpc.campaigns.list.useQuery();
  const { data: templates = [] } = trpc.templates.list.useQuery();
  
  const [showSendDialog, setShowSendDialog] = useState);
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [recipients, setRecipients] = useState("");
  const [campaignName, setCampaignName] = useState("");

  const executeCampaign = trpc.campaigns.execute.useMutation({
    onSuccess: () => {