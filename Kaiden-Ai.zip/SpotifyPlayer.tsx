import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Music,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Shuffle,
  Repeat,
  ExternalLink,
} from 'lucide-react';

interface Track {
  id: string;
  name: string;
  artist: string;
  albumArt: string;
  duration: number;
}

// Placeholder tracks for demo (Spotify integration would replace this)
const demoTracks: Track[] = [
  { id: '1', name: 'Focus Flow', artist: 'Productivity Beats', albumArt: '', duration: 180 },
  { id: '2', name: 'Deep Work', artist: 'Concentration Music', albumArt: '', duration: 240 },
  { id: '3', name: 'Creative Energy', artist: 'Inspiration Sounds', albumArt: '', duration: 200 },
];

export function SpotifyPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<Track>(demoTracks[0]);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(70);
  const [isMuted, setIsMuted] = useState(false);
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState<'off' | 'all' | 'one'>('off');
  const [isConnected, setIsConnected] = useState(false);

  // Simulate progress when playing
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            // Auto-play next track
            handleNext();
            return 0;
          }
          return prev + (100 / currentTrack.duration);
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentTrack]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handlePrevious = () => {
    const currentIndex = demoTracks.findIndex((t) => t.id === currentTrack.id);
    const prevIndex = currentIndex === 0 ? demoTracks.length - 1 : currentIndex - 1;
    setCurrentTrack(demoTracks[prevIndex]);
    setProgress(0);
  };

  const handleNext = () => {
    const currentIndex = demoTracks.findIndex((t) => t.id === currentTrack.id);
    const nextIndex = (currentIndex + 1) % demoTracks.length;
    setCurrentTrack(demoTracks[nextIndex]);
    setProgress(0);
  };

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0]);
    if (value[0] > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const toggleShuffle = () => {
    setIsShuffled(!isShuffled);
  };

  const cycleRepeat = () => {
    const modes: ('off' | 'all' | 'one')[] = ['off', 'all', 'one'];
    const currentIndex = modes.indexOf(repeatMode);
    setRepeatMode(modes[(currentIndex + 1) % modes.length]);
  };

  const connectSpotify = () => {
    // In production, this would redirect to Spotify OAuth
    // For now, we'll simulate a connection
    setIsConnected(true);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="music-player gap-2 h-9"
        >
          <Music className="h-4 w-4 text-green-500" />
          {isPlaying && (
            <div className="flex items-center gap-1">
              <span className="text-xs text-muted-foreground truncate max-w-[100px]">
                {currentTrack.name}
              </span>
              <div className="flex gap-0.5">
                {[...Array(3)].map((_, i) => (
                  <div
                    key={i}
                    className="w-0.5 bg-green-500 rounded-full animate-pulse"
                    style={{
                      height: `${8 + Math.random() * 8}px`,
                      animationDelay: `${i * 0.2}s`,
                    }}
                  />
                ))}
              </div>
            </div>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-4" align="end">
        {!isConnected ? (
          <div className="text-center py-4">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-500/20 flex items-center justify-center">
              <Music className="h-8 w-8 text-green-500" />
            </div>
            <h3 className="font-semibold mb-2">Connect Spotify</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Listen to music while you work with Kaiden
            </p>
            <Button onClick={connectSpotify} className="w-full bg-green-500 hover:bg-green-600">
              <ExternalLink className="h-4 w-4 mr-2" />
              Connect Spotify
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Track Info */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-green-500/20 to-green-600/20 flex items-center justify-center">
                <Music className="h-6 w-6 text-green-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{currentTrack.name}</p>
                <p className="text-sm text-muted-foreground truncate">
                  {currentTrack.artist}
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1">
              <Slider
                value={[progress]}
                max={100}
                step={1}
                className="cursor-pointer"
                onValueChange={(value) => setProgress(value[0])}
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{formatTime((progress / 100) * currentTrack.duration)}</span>
                <span>{formatTime(currentTrack.duration)}</span>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${isShuffled ? 'text-green-500' : ''}`}
                onClick={toggleShuffle}
              >
                <Shuffle className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handlePrevious}
              >
                <SkipBack className="h-4 w-4" />
              </Button>
              <Button
                size="icon"
                className="h-10 w-10 rounded-full bg-white text-black hover:bg-white/90"
                onClick={handlePlayPause}
              >
                {isPlaying ? (
                  <Pause className="h-5 w-5" />
                ) : (
                  <Play className="h-5 w-5 ml-0.5" />
                )}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handleNext}
              >
                <SkipForward className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className={`h-8 w-8 ${repeatMode !== 'off' ? 'text-green-500' : ''}`}
                onClick={cycleRepeat}
              >
                <Repeat className="h-4 w-4" />
                {repeatMode === 'one' && (
                  <span className="absolute text-[8px] font-bold">1</span>
                )}
              </Button>
            </div>

            {/* Volume */}
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={toggleMute}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="h-4 w-4" />
                ) : (
                  <Volume2 className="h-4 w-4" />
                )}
              </Button>
              <Slider
                value={[isMuted ? 0 : volume]}
                max={100}
                step={1}
                className="flex-1"
                onValueChange={handleVolumeChange}
              />
            </div>

            {/* Spotify Link */}
            <div className="pt-2 border-t border-border">
              <a
                href="https://open.spotify.com"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                <span>Open in Spotify</span>
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}

export default SpotifyPlayer;
