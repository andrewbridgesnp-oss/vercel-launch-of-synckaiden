import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  conversations, InsertConversation, Conversation,
  messages, InsertMessage, Message,
  websites, InsertWebsite, Website,
  products, InsertProduct, Product,
  appointments, InsertAppointment, Appointment,
  leads, InsertLead, Lead,
  videos, InsertVideo, Video,
  campaigns, InsertCampaign, Campaign,
  auditLogs, InsertAuditLog, AuditLog,
  securityEvents, InsertSecurityEvent, SecurityEvent,
  apiTokens, InsertApiToken, ApiToken,
  approvalRequests, InsertApprovalRequest, ApprovalRequest,
  orders, InsertOrder, Order,
  savedMedicalCodes, InsertSavedMedicalCode, SavedMedicalCode,
  expenses, InsertExpense, Expense,
  income, InsertIncome, Income,
  scheduledAppointments, InsertScheduledAppointment, ScheduledAppointment
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER OPERATIONS ============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ CONVERSATION OPERATIONS ============

export async function createConversation(data: InsertConversation): Promise<Conversation> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(conversations).values(data);
  const id = Number(result[0].insertId);
  
  const created = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return created[0]!;
}

export async function getConversationsByUserId(userId: number): Promise<Conversation[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(conversations)
    .where(eq(conversations.userId, userId))
    .orderBy(desc(conversations.updatedAt));
}

export async function getConversationById(id: number): Promise<Conversation | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return result[0];
}

export async function updateConversationTitle(id: number, title: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(conversations).set({ title }).where(eq(conversations.id, id));
}

// ============ MESSAGE OPERATIONS ============

export async function createMessage(data: InsertMessage): Promise<Message> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(messages).values(data);
  const id = Number(result[0].insertId);
  
  const created = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  
  // Update conversation timestamp
  await db.update(conversations)
    .set({ updatedAt: new Date() })
    .where(eq(conversations.id, data.conversationId));
  
  return created[0]!;
}

export async function getMessagesByConversationId(conversationId: number): Promise<Message[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.createdAt);
}

// ============ AUDIT LOG OPERATIONS ============

export async function createAuditLog(data: InsertAuditLog): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Audit] Cannot log: database not available");
    return;
  }

  try {
    await db.insert(auditLogs).values(data);
  } catch (error) {
    console.error("[Audit] Failed to create log:", error);
  }
}

export async function getRecentAuditLogs(userId: number, limit: number = 100): Promise<AuditLog[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(auditLogs)
    .where(eq(auditLogs.userId, userId))
    .orderBy(desc(auditLogs.createdAt))
    .limit(limit);
}

// ============ SECURITY EVENT OPERATIONS ============

export async function createSecurityEvent(data: InsertSecurityEvent): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Security] Cannot log event: database not available");
    return;
  }

  try {
    await db.insert(securityEvents).values(data);
  } catch (error) {
    console.error("[Security] Failed to create event:", error);
  }
}

export async function getUnresolvedSecurityEvents(): Promise<SecurityEvent[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(securityEvents)
    .where(eq(securityEvents.resolved, false))
    .orderBy(desc(securityEvents.createdAt));
}

// ============ WEBSITE OPERATIONS ============

export async function createWebsite(data: InsertWebsite): Promise<Website> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(websites).values(data);
  const id = Number(result[0].insertId);
  
  const created = await db.select().from(websites).where(eq(websites.id, id)).limit(1);
  return created[0]!;
}

export async function getWebsitesByUserId(userId: number): Promise<Website[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(websites)
    .where(eq(websites.userId, userId))
    .orderBy(desc(websites.updatedAt));
}

// ============ PRODUCT OPERATIONS ============

export async function createProduct(data: InsertProduct): Promise<Product> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(products).values(data);
  const id = Number(result[0].insertId);
  
  const created = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return created[0]!;
}

export async function getProductsByUserId(userId: number): Promise<Product[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(products)
    .where(eq(products.userId, userId))
    .orderBy(desc(products.updatedAt));
}

export async function updateProduct(id: number, data: Partial<InsertProduct>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(products).set(data).where(eq(products.id, id));
}

// ============ APPOINTMENT OPERATIONS ============

export async function createAppointment(data: InsertAppointment): Promise<Appointment> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(appointments).values(data);
  const id = Number(result[0].insertId);
  
  const created = await db.select().from(appointments).where(eq(appointments.id, id)).limit(1);
  return created[0]!;
}

export async function getAppointmentsByUserId(userId: number): Promise<Appointment[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(appointments)
    .where(eq(appointments.userId, userId))
    .orderBy(desc(appointments.startTime));
}

// ============ LEAD OPERATIONS ============

export async function createLead(data: InsertLead): Promise<Lead> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(leads).values(data);
  const id = Number(result[0].insertId);
  
  const created = await db.select().from(leads).where(eq(leads.id, id)).limit(1);
  return created[0]!;
}

export async function getLeadsByUserId(userId: number): Promise<Lead[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(leads)
    .where(eq(leads.userId, userId))
    .orderBy(desc(leads.createdAt));
}

// ============ VIDEO OPERATIONS ============

export async function createVideo(data: InsertVideo): Promise<Video> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(videos).values(data);
  const id = Number(result[0].insertId);
  
  const created = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  return created[0]!;
}

export async function getVideosByUserId(userId: number): Promise<Video[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(videos)
    .where(eq(videos.userId, userId))
    .orderBy(desc(videos.createdAt));
}

// ============ CAMPAIGN OPERATIONS ============

export async function createCampaign(data: InsertCampaign): Promise<Campaign> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(campaigns).values(data);
  const id = Number(result[0].insertId);
  
  const created = await db.select().from(campaigns).where(eq(campaigns.id, id)).limit(1);
  return created[0]!;
}

export async function getCampaignsByUserId(userId: number): Promise<Campaign[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(campaigns)
    .where(eq(campaigns.userId, userId))
    .orderBy(desc(campaigns.updatedAt));
}

export async function getCampaignById(id: number): Promise<Campaign | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(campaigns).where(eq(campaigns.id, id)).limit(1);
  return result[0];
}

export async function updateCampaignMetrics(
  id: number, 
  metrics: { sentCount?: number; openCount?: number; clickCount?: number; conversionCount?: number; revenue?: number }
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(campaigns).set(metrics).where(eq(campaigns.id, id));
}

// ============ APPROVAL REQUEST OPERATIONS ============

export async function createApprovalRequest(data: InsertApprovalRequest): Promise<ApprovalRequest> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(approvalRequests).values(data);
  const id = Number(result[0].insertId);
  
  const created = await db.select().from(approvalRequests).where(eq(approvalRequests.id, id)).limit(1);
  return created[0]!;
}

export async function getPendingApprovalRequests(userId: number): Promise<ApprovalRequest[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(approvalRequests)
    .where(eq(approvalRequests.userId, userId))
    .orderBy(desc(approvalRequests.createdAt));
}

export async function updateApprovalRequest(
  id: number,
  data: { status: 'approved' | 'rejected'; approvedBy?: number; rejectedReason?: string }
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = { status: data.status };
  if (data.status === 'approved') {
    updateData.approvedBy = data.approvedBy;
    updateData.approvedAt = new Date();
  } else if (data.status === 'rejected') {
    updateData.rejectedReason = data.rejectedReason;
  }

  await db.update(approvalRequests).set(updateData).where(eq(approvalRequests.id, id));
}

// ============ ORDER OPERATIONS ============

export async function createOrder(data: InsertOrder): Promise<Order> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(orders).values(data);
  const insertId = Number(result[0].insertId);

  const created = await db.select().from(orders).where(eq(orders.id, insertId)).limit(1);
  if (!created[0]) throw new Error("Failed to create order");

  return created[0];
}

export async function getOrdersByUserId(userId: number): Promise<Order[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
}

export async function getOrderById(id: number): Promise<Order | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result[0];
}

export async function updateOrderStatus(id: number, status: string, metadata?: any): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = { status, updatedAt: new Date() };
  if (metadata) {
    updateData.metadata = metadata;
  }

  await db.update(orders).set(updateData).where(eq(orders.id, id));
}

export async function processOrderRefund(id: number, refundData: { refundId: string; refundAmount: number; refundReason: string }): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(orders).set({
    status: "refunded",
    refundId: refundData.refundId,
    refundAmount: refundData.refundAmount,
    refundReason: refundData.refundReason,
    updatedAt: new Date(),
  }).where(eq(orders.id, id));
}


// ============ SAVED MEDICAL CODES OPERATIONS ============

export async function getSavedMedicalCodes(userId: number): Promise<SavedMedicalCode[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(savedMedicalCodes)
    .where(eq(savedMedicalCodes.userId, userId))
    .orderBy(desc(savedMedicalCodes.usageCount));
}

export async function getSavedMedicalCodesByType(userId: number, codeType: 'cpt' | 'icd10'): Promise<SavedMedicalCode[]> {
  const db = await getDb();
  if (!db) return [];

  const { and } = await import("drizzle-orm");
  return db.select().from(savedMedicalCodes)
    .where(and(
      eq(savedMedicalCodes.userId, userId),
      eq(savedMedicalCodes.codeType, codeType)
    ))