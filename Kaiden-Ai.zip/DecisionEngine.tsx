/**
 * KAI(DEN) TAX - Decision Engine
 * Tax strategy simulator with scenario comparison
 */

import { useState, useMemo } from 'react';
import {
  Zap, Plus, Trash2, Copy, ChevronDown, ChevronUp,
  TrendingUp, TrendingDown, DollarSign, Percent, Target,
  Lightbulb, ArrowRight, Check, AlertTriangle, Info,
  BarChart3, PieChart, RefreshCw, Download, Share2
} from 'lucide-react';
import { calculateFederalTax, TaxInput, formatCurrency, formatPercent } from '../lib/taxCalculator';

interface Scenario {
  id: string;
  name: string;
  isBaseline: boolean;
  inputs: Partial<TaxInput>;
  description?: string;
}

const DEFAULT_BASELINE: TaxInput = {
  filingStatus: 'single',
  wages: 85000,
  selfEmploymentIncome: 0,
  interestIncome: 500,
  dividendIncome: 1200,
  qualifiedDividends: 1000,
  shortTermGains: 0,
  longTermGains: 2500,
  otherIncome: 0,
  federalWithholding: 12000,
  stateWithholding: 4000,
  itemizedDeductions: 8000,
  useItemized: false,
  traditionalIraContribution: 0,
  hsaContribution: 0,
  studentLoanInterest: 0,
  selfEmploymentHealthInsurance: 0,
  numDependentsUnder17: 0,
  numDependents17Plus: 0,
  educationExpenses: 0,
  childCareExpenses: 0,
  retirementContributions: 0,
  isOver65: false,
  isBlind: false,
};

const STRATEGY_SUGGESTIONS = [
  {
    id: 'max-401k',
    title: 'Maximize 401(k) Contribution',
    description: 'Contribute the maximum $23,000 to reduce taxable income',
    impact: 'traditionalIraContribution',
    value: 23000,
    potentialSavings: 5060,
  },
  {
    id: 'hsa-max',
    title: 'Max Out HSA',
    description: 'Contribute $4,150 (individual) for triple tax advantage',
    impact: 'hsaContribution',
    value: 4150,
    potentialSavings: 913,
  },
  {
    id: 'itemize',
    title: 'Switch to Itemized Deductions',
    description: 'If your itemized deductions exceed $14,600',
    impact: 'useItemized',
    value: true,
    potentialSavings: 0,
  },
  {
    id: 'tax-loss',
    title: 'Tax-Loss Harvesting',
    description: 'Offset capital gains with realized losses',
    impact: 'longTermGains',
    value: -2500,
    potentialSavings: 375,
  },
];

export function DecisionEngine() {
  const [scenarios, setScenarios] = useState<Scenario[]>([
    {
      id: 'baseline',
      name: 'Current Situation',
      isBaseline: true,
      inputs: {},
      description: 'Your current tax situation based on entered data',
    },
  ]);
  const [selectedScenarios, setSelectedScenarios] = useState<string[]>(['baseline']);
  const [showAddScenario, setShowAddScenario] = useState(false);
  const [expandedScenario, setExpandedScenario] = useState<string | null>('baseline');

  // Calculate results for all scenarios
  const results = useMemo(() => {
    return scenarios.map(scenario => {
      const inputs = { ...DEFAULT_BASELINE, ...scenario.inputs } as TaxInput;
      const result = calculateFederalTax(inputs);
      return { scenario, result };
    });
  }, [scenarios]);

  const baselineResult = results.find(r => r.scenario.isBaseline)?.result;

  const addScenario = (name: string, inputs: Partial<TaxInput>, description?: string) => {
    const newScenario: Scenario = {
      id: `scenario-${Date.now()}`,
      name,
      isBaseline: false,
      inputs,
      description,
    };
    setScenarios([...scenarios, newScenario]);
    setSelectedScenarios([...selectedScenarios, newScenario.id]);
    setShowAddScenario(false);
  };

  const removeScenario = (id: string) => {
    if (id === 'baseline') return;
    setScenarios(scenarios.filter(s => s.id !== id));
    setSelectedScenarios(selectedScenarios.filter(s => s !== id));
  };

  const applyStrategy = (strategy: typeof STRATEGY_SUGGESTIONS[0]) => {
    const inputs: Partial<TaxInput> = {
      [strategy.impact]: strategy.value,
    };
    addScenario(strategy.title, inputs, strategy.description);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-3">
            <Zap className="w-7 h-7 text-amber-400" />
            Decision Engine
          </h2>
          <p className="text-[#c0c0c0]/60 mt-1">Compare tax strategies and optimize your outcome</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-[#c0c0c0]/20 rounded-lg hover:bg-white/10 transition-colors">
            <Download className="w-4 h-4" />
            Export
          </button>
          <button
            onClick={() => setShowAddScenario(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#c0c0c0] to-[#e8e8e8] text-[#0a1628] rounded-lg font-medium hover:opacity-90 transition-opacity"
          >
            <Plus className="w-4 h-4" />
            Add Scenario
          </button>
        </div>
      </div>

      {/* AI Suggestions */}
      <div className="rounded-xl bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/30 p-6">
        <div className="flex items-center gap-3 mb-4">
          <Lightbulb className="w-6 h-6 text-amber-400" />
          <h3 className="text-lg font-semibold">AI-Powered Suggestions</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {STRATEGY_SUGGESTIONS.map((strategy) => (
            <div
              key={strategy.id}
              className="p-4 rounded-lg bg-white/5 border border-white/10 hover:border-amber-500/30 transition-colors"
            >
              <h4 className="font-medium mb-1">{strategy.title}</h4>
              <p className="text-sm text-[#c0c0c0]/60 mb-3">{strategy.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-green-400">
                  Save ~{formatCurrency(strategy.potentialSavings)}
                </span>
                <button
                  onClick={() => applyStrategy(strategy)}
                  className="text-sm text-amber-400 hover:text-amber-300 font-medium"
                >
                  Try It →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Comparison Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Scenarios List */}
        <div className="lg:col-span-1 space-y-4">
          <h3 className="font-semibold">Scenarios</h3>
          <div className="space-y-3">
            {results.map(({ scenario, result }) => (
              <ScenarioCard
                key={scenario.id}
                scenario={scenario}
                result={result}
                baselineResult={baselineResult}
                isExpanded={expandedScenario === scenario.id}
                onToggle={() => setExpandedScenario(expandedScenario === scenario.id ? null : scenario.id)}
                onRemove={() => removeScenario(scenario.id)}
                isSelected={selectedScenarios.includes(scenario.id)}
                onSelect={() => {
                  if (selectedScenarios.includes(scenario.id)) {
                    setSelectedScenarios(selectedScenarios.filter(s => s !== scenario.id));
                  } else {
                    setSelectedScenarios([...selectedScenarios, scenario.id]);
                  }
                }}
              />
            ))}
          </div>
        </div>

        {/* Comparison Chart */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="font-semibold">Comparison</h3>
          <div className="rounded-xl bg-[#1a2744]/50 border border-[#c0c0c0]/10 p-6">
            <ComparisonChart
              results={results.filter(r => selectedScenarios.includes(r.scenario.id))}
              baselineResult={baselineResult}
            />
          </div>

          {/* Detailed Comparison Table */}
          <div className="rounded-xl bg-[#1a2744]/50 border border-[#c0c0c0]/10 overflow-hidden">
            <div className="p-4 border-b border-white/10">
              <h4 className="font-semibold">Detailed Breakdown</h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/10">
                    <th className="text-left p-4 text-sm font-medium text-[#c0c0c0]/60">Metric</th>
                    {results.filter(r => selectedScenarios.includes(r.scenario.id)).map(({ scenario }) => (
                      <th key={scenario.id} className="text-right p-4 text-sm font-medium">
                        {scenario.name}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <ComparisonRow
                    label="Gross Income"
                    values={results.filter(r => selectedScenarios.includes(r.scenario.id)).map(r => r.result.grossIncome)}
                    baselineValue={baselineResult?.grossIncome}
                  />
                  <ComparisonRow
                    label="Taxable Income"
                    values={results.filter(r => selectedScenarios.includes(r.scenario.id)).map(r => r.result.taxableIncome)}
                    baselineValue={baselineResult?.taxableIncome}
                    lowerIsBetter
                  />
                  <ComparisonRow
                    label="Total Tax"
                    values={results.filter(r => selectedScenarios.includes(r.scenario.id)).map(r => r.result.totalTax)}
                    baselineValue={baselineResult?.totalTax}
                    lowerIsBetter
                  />
                  <ComparisonRow
                    label="Total Credits"
                    values={results.filter(r => selectedScenarios.includes(r.scenario.id)).map(r => r.result.totalCredits)}
                    baselineValue={baselineResult?.totalCredits}
                  />
                  <ComparisonRow
                    label="Refund / (Owed)"
                    values={results.filter(r => selectedScenarios.includes(r.scenario.id)).map(r => r.result.refundOrOwed)}
                    baselineValue={baselineResult?.refundOrOwed}
                    highlight
                  />
                  <ComparisonRow
                    label="Effective Rate"
                    values={results.filter(r => selectedScenarios.includes(r.scenario.id)).map(r => r.result.effectiveRate)}
                    baselineValue={baselineResult?.effectiveRate}
                    lowerIsBetter
                    isPercent
                  />
                  <ComparisonRow
                    label="Marginal Rate"
                    values={results.filter(r => selectedScenarios.includes(r.scenario.id)).map(r => r.result.marginalRate)}
                    baselineValue={baselineResult?.marginalRate}
                    lowerIsBetter
                    isPercent
                  />
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Add Scenario Modal */}
      {showAddScenario && (
        <AddScenarioModal
          onClose={() => setShowAddScenario(false)}
          onAdd={addScenario}
        />
      )}
    </div>
  );
}

function ScenarioCard({ scenario, result, baselineResult, isExpanded, onToggle, onRemove, isSelected, onSelect }: {
  scenario: Scenario;
  result: ReturnType<typeof calculateFederalTax>;
  baselineResult?: ReturnType<typeof calculateFederalTax>;
  isExpanded: boolean;
  onToggle: () => void;
  onRemove: () => void;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const savings = baselineResult && !scenario.isBaseline
    ? baselineResult.totalTax - result.totalTax
    : 0;

  return (
    <div className={`rounded-xl border transition-colors ${
      isSelected 
        ? 'bg-[#c0c0c0]/10 border-[#c0c0c0]/30' 
        : 'bg-[#1a2744]/50 border-[#c0c0c0]/10 hover:border-[#c0c0c0]/20'
    }`}>
      <div className="p-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onSelect}
            className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${
              isSelected ? 'bg-[#c0c0c0] border-[#c0c0c0]' : 'border-[#c0c0c0]/40'
            }`}
          >
            {isSelected && <Check className="w-3 h-3 text-[#0a1628]" />}
          </button>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-medium">{scenario.name}</span>
              {scenario.isBaseline && (
                <span className="px-2 py-0.5 text-xs rounded bg-blue-500/20 text-blue-400">Baseline</span>
              )}
            </div>
            {scenario.description && (
              <p className="text-sm text-[#c0c0c0]/60">{scenario.description}</p>
            )}
          </div>
          <div className="flex items-center gap-2">
            {!scenario.isBaseline && (
              <button onClick={onRemove} className="p-1 hover:bg-white/10 rounded">
                <Trash2 className="w-4 h-4 text-[#c0c0c0]/60" />
              </button>
            )}
            <button onClick={onToggle} className="p-1 hover:bg-white/10 rounded">
              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="p-2 rounded bg-white/5">
            <p className="text-xs text-[#c0c0c0]/60">Total Tax</p>
            <p className="font-semibold">{formatCurrency(result.totalTax)}</p>
          </div>
          <div className="p-2 rounded bg-white/5">
            <p className="text-xs text-[#c0c0c0]/60">Refund/(Owed)</p>
            <p className={`font-semibold ${result.refundOrOwed >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {formatCurrency(result.refundOrOwed)}
            </p>
          </div>
        </div>

        {/* Savings Badge */}
        {savings !== 0 && (
          <div className={`mt-3 p-2 rounded-lg flex items-center gap-2 ${
            savings > 0 ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'
          }`}>
            {savings > 0 ? <TrendingDown className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
            <span className="text-sm font-medium">
              {savings > 0 ? `Save ${formatCurrency(savings)}` : `Costs ${formatCurrency(Math.abs(savings))} more`}
            </span>
          </div>
        )}
      </div>

      {/* Expanded Details */}
      {isExpanded && (
        <div className="px-4 pb-4 pt-2 border-t border-white/10">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-[#c0c0c0]/60">Gross Income</span>
              <span>{formatCurrency(result.grossIncome)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#c0c0c0]/60">Taxable Income</span>
              <span>{formatCurrency(result.taxableIncome)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#c0c0c0]/60">Effective Rate</span>
              <span>{formatPercent(result.effectiveRate)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#c0c0c0]/60">Marginal Rate</span>
              <span>{formatPercent(result.marginalRate)}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ComparisonChart({ results, baselineResult }: {
  results: Array<{ scenario: Scenario; result: ReturnType<typeof calculateFederalTax> }>;
  baselineResult?: ReturnType<typeof calculateFederalTax>;
}) {
  if (results.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-[#c0c0c0]/60">
        Select scenarios to compare
      </div>
    );
  }

  const maxTax = Math.max(...results.map(r => r.result.totalTax));

  return (
    <div className="space-y-6">
      {/* Bar Chart */}
      <div className="space-y-4">
        {results.map(({ scenario, result }) => {
          const width = (result.totalTax / maxTax) * 100;
          const savings = baselineResult && !scenario.isBaseline
            ? baselineResult.totalTax - result.totalTax
            : 0;

          return (
            <div key={scenario.id} className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium">{scenario.name}</span>
                <div className="flex items-center gap-3">
                  <span>{formatCurrency(result.totalTax)}</span>
                  {savings !== 0 && (
                    <span className={savings > 0 ? 'text-green-400' : 'text-red-400'}>
                      ({savings > 0 ? '-' : '+'}{formatCurrency(Math.abs(savings))})
                    </span>
                  )}
                </div>
              </div>
              <div className="h-6 bg-white/10 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${
                    scenario.isBaseline 
                      ? 'bg-gradient-to-r from-blue-500 to-blue-400' 
                      : savings > 0
                      ? 'bg-gradient-to-r from-green-500 to-green-400'
                      : 'bg-gradient-to-r from-[#c0c0c0] to-[#e8e8e8]'
                  }`}
                  style={{ width: `${width}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="flex items-center justify-center gap-6 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-blue-500" />
          <span className="text-[#c0c0c0]/60">Baseline</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-green-500" />
          <span className="text-[#c0c0c0]/60">Lower Tax</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-[#c0c0c0]" />
          <span className="text-[#c0c0c0]/60">Higher Tax</span>
        </div>
      </div>
    </div>
  );
}

function ComparisonRow({ label, values, baselineValue, lowerIsBetter, highlight, isPercent }: {
  label: string;
  values: number[];
  baselineValue?: number;
  lowerIsBetter?: boolean;
  highlight?: boolean;
  isPercent?: boolean;
}) {
  return (
    <tr className={`border-b border-white/5 ${highlight ? 'bg-[#c0c0c0]/5' : ''}`}>
      <td className={`p-4 text-sm ${highlight ? 'font-medium' : 'text-[#c0c0c0]/60'}`}>{label}</td>
      {values.map((value, index) => {
        const diff = baselineValue !== undefined && index > 0 ? value - baselineValue : 0;
        const isBetter = lowerIsBetter ? diff < 0 : diff > 0;
        
        return (
          <td key={index} className="p-4 text-right">
            <span className={highlight ? 'font-semibold' : ''}>
              {isPercent ? formatPercent(value) : formatCurrency(value)}
            </span>
            {diff !== 0 && (
              <span className={`ml-2 text-xs ${isBetter ? 'text-green-400' : 'text-red-400'}`}>
                ({diff > 0 ? '+' : ''}{isPercent ? formatPercent(diff) : formatCurrency(diff)})
              </span>
            )}
          </td>
        );
      })}
    </tr>
  );
}

function AddScenarioModal({ onClose, onAdd }: {
  onClose: () => void;
  onAdd: (name: string, inputs: Partial<TaxInput>, description?: string) => void;
}) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedAdjustment, setSelectedAdjustment] = useState<string>('retirement');
  const [adjustmentValue, setAdjustmentValue] = useState<number>(0);

  const adjustmentOptions = [
    { id: 'retirement', label: 'Retirement Contribution', field: 'traditionalIraContribution', max: 23000 },
    { id: 'hsa', label: 'HSA Contribution', field: 'hsaContribution', max: 8550 },
    { id: 'income', label: 'Additional Income', field: 'wages', max: 100000 },
    { id: 'deductions', label: 'Itemized Deductions', field: 'itemizedDeductions', max: 50000 },
  ];

  const selectedOption = adjustmentOptions.find(o => o.id === selectedAdjustment);

  const handleAdd = () => {
    if (!name.trim()) return;
    const inputs: Partial<TaxInput> = {};
    if (selectedOption && adjustmentValue > 0) {
      (inputs as any)[selectedOption.field] = adjustmentValue;
      if (selectedOption.id === 'deductions') {
        inputs.useItemized = true;
      }
    }
    onAdd(name, inputs, description || undefined);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="w-full max-w-md mx-4 rounded-xl bg-[#1a2744] border border-[#c0c0c0]/20 overflow-hidden">
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <h3 className="text-lg font-semibold">Create Scenario</h3>
          <button onClick={onClose} className="p-1 hover:bg-white/10 rounded">×</button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm text-[#c0c0c0]/60 mb-2">Scenario Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Max 401(k) + HSA"
              className="w-full px-4 py-2 bg-white/5 border border-[#c0c0c0]/20 rounded-lg focus:outline-none focus:border-[#c0c0c0]/40"
            />
          </div>
          <div>
            <label className="block text-sm text-[#c0c0c0]/60 mb-2">Description (optional)</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of this scenario"
              className="w-full px-4 py-2 bg-white/5 border border-[#c0c0c0]/20 rounded-lg focus:outline-none focus:border-[#c0c0c0]/40"
            />
          </div>
          <div>
            <label className="block text-sm text-[#c0c0c0]/60 mb-2">Adjustment Type</label>
            <select
              value={selectedAdjustment}
              onChange={(e) => setSelectedAdjustment(e.target.value)}
              className="w-full px-4 py-2 bg-white/5 border border-[#c0c0c0]/20 rounded-lg focus:outline-none focus:border-[#c0c0c0]/40"
            >
              {adjustmentOptions.map(opt => (
                <option key={opt.id} value={opt.id}>{opt.label}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm text-[#c0c0c0]/60 mb-2">
              Amount {selectedOption && `(max ${formatCurrency(selectedOption.max)})`}
            </label>
            <input
              type="number"
              value={adjustmentValue}
              onChange={(e) => setAdjustmentValue(Math.min(Number(e.target.value), selectedOption?.max || 0))}
              placeholder="0"
              className="w-full px-4 py-2 bg-white/5 border border-[#c0c0c0]/20 rounded-lg focus:outline-none focus:border-[#c0c0c0]/40"
            />
          </div>
          <div className="flex gap-3 pt-4">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-white/5 border border-[#c0c0c0]/20 rounded-lg hover:bg-white/10 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleAdd}
              disabled={!name.trim()}
              className="flex-1 px-4 py-2 bg-gradient-to-r from-[#c0c0c0] to-[#e8e8e8] text-[#0a1628] rounded-lg font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              Create Scenario
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DecisionEngine;
