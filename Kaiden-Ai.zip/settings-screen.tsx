import { useState } from "react";
import { ChevronLeft, User, Lock, Bell, Smartphone, CreditCard, FileText, Building2, Wallet, ShoppingBag, ChevronRight, Shield, ExternalLink, Camera, Palette } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Switch } from "./ui/switch";
import { BrandingScreen } from "./branding-screen";
import { CustomBrandingScreen } from "./custom-branding-screen";
import { FEATURE_FLAGS, isMultiTenantMode } from "../../config/app-mode";

interface SettingsScreenProps {
  onBack: () => void;
}

export function SettingsScreen({ onBack }: SettingsScreenProps) {
  const [activeView, setActiveView] = useState<"main" | "wallet" | "price-compare" | "dispute-letters" | "business-profile" | "branding" | "custom-branding">("main");

  // Build menu sections based on app mode
  const menuSections = [
    {
      title: "Financial Tools",
      items: [
        { id: "wallet", label: "Digital Wallet", icon: Wallet, description: "Store cards & payment methods", badge: "2 accounts" },
        { id: "price-compare", label: "Price Comparison", icon: ShoppingBag, description: "Find best deals on materials", badge: "New" },
        { id: "dispute-letters", label: "Dispute Letters", icon: FileText, description: "Credit dispute templates", badge: "12 templates" },
      ]
    },
    {
      title: "Business",
      items: [
        { id: "business-profile", label: "Business Profile", icon: Building2, description: "License, bonding, portfolio", badge: null },
        // Show different branding options based on mode
        ...(isMultiTenantMode() 
          ? [{ id: "custom-branding", label: "Custom Branding", icon: Palette, description: "Upload logo & customize colors", badge: "Pro" }]
          : [{ id: "branding", label: "Professional Branding", icon: Palette, description: "Logo, colors, marketing assets", badge: "New" }]
        ),
      ]
    },
    {
      title: "Account",
      items: [
        { id: "security", label: "Security", icon: Lock, description: "Password & biometric auth", badge: null },
        { id: "notifications", label: "Notifications", icon: Bell, description: "Alerts & reminders", badge: null },
      ]
    },
  ];

  const savedCards = [
    { 
      id: 1, 
      type: "Business Checking", 
      name: "Truist Business Checking", 
      last4: "8421", 
      balance: 2847,
      color: "from-purple-600 to-purple-800" 
    },
    { 
      id: 2, 
      type: "Personal Checking", 
      name: "Queensborough Bank", 
      last4: "3156", 
      balance: 1523,
      color: "from-blue-700 to-blue-900" 
    },
  ];

  const priceComparisons = [
    {
      item: "2x4x8 Lumber",
      lowes: { price: 4.97, stock: "In Stock", distance: "3.2 mi" },
      homeDepot: { price: 5.12, stock: "In Stock", distance: "4.1 mi" },
      localSupplier: { price: 4.25, stock: "Call for availability", distance: "12 mi" },
    },
    {
      item: "DeWalt 20V Drill Kit",
      lowes: { price: 179.99, stock: "In Stock", distance: "3.2 mi" },
      homeDepot: { price: 169.99, stock: "Limited", distance: "4.1 mi" },
      amazon: { price: 154.99, stock: "2-day shipping", distance: "Online" },
    },
  ];

  const disputeLetters = [
    {
      category: "Repossession Disputes",
      templates: [
        { name: "Basic Repo Dispute", description: "Challenge inaccurate repossession", impact: "High" },
        { name: "Goodwill Deletion Request", description: "Request removal as one-time courtesy", impact: "Medium" },
      ]
    },
    {
      category: "Late Payment Disputes",
      templates: [
        { name: "Late Payment Dispute", description: "Challenge incorrect late payments", impact: "High" },
        { name: "Goodwill Letter", description: "Request removal of isolated late payment", impact: "Medium" },
      ]
    },
    {
      category: "Identity & Verification",
      templates: [
        { name: "Not My Account", description: "Dispute account not belonging to you", impact: "High" },
        { name: "Request Verification", description: "Demand proof of debt", impact: "Medium" },
      ]
    },
  ];

  // Main Settings View
  if (activeView === "main") {
    return (
      <div className="min-h-screen bg-black pb-20">
        {/* Header */}
        <div className="bg-zinc-900 px-6 py-4 border-b border-zinc-800 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="p-2 hover:bg-zinc-800 rounded-lg -ml-2">
              <ChevronLeft className="w-6 h-6 text-white" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white">Settings</h1>
              <p className="text-sm text-zinc-400">Manage your account</p>
            </div>
          </div>
        </div>

        {/* Profile Card */}
        <div className="px-6 py-6 border-b border-zinc-900">
          <Card className="p-6 bg-gradient-to-br from-red-950 to-zinc-900 border border-red-900/30">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center">
                <span className="text-white font-bold text-2xl">K</span>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-1">K.C. Johnson</h3>
                <p className="text-sm text-zinc-400">kc@buildwealthpro.com</p>
                <Badge className="mt-2 bg-zinc-800 text-zinc-300">Basic Plan</Badge>
              </div>
            </div>
            <Button className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800">
              Upgrade to Pro
            </Button>
          </Card>
        </div>

        {/* Menu Sections */}
        <div className="px-6 py-4">
          {menuSections.map((section, idx) => (
            <div key={idx} className="mb-6">
              <h3 className="text-sm font-semibold text-zinc-500 mb-3 uppercase tracking-wide">{section.title}</h3>
              <div className="space-y-2">
                {section.items.map((item) => (
                  <Card
                    key={item.id}
                    className="p-4 bg-zinc-900 border border-zinc-800 hover:border-red-600/50 cursor-pointer transition-all"
                    onClick={() => setActiveView(item.id as any)}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center flex-shrink-0">
                        <item.icon className="w-5 h-5 text-red-500" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-semibold text-white">{item.label}</h4>
                          {item.badge && (
                            <Badge className="bg-red-950 text-red-400 text-xs">{item.badge}</Badge>
                          )}
                        </div>
                        <p className="text-sm text-zinc-500">{item.description}</p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-zinc-600 flex-shrink-0" />
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Website Integration */}
        <div className="px-6 py-4">
          <Card className="p-6 bg-zinc-900 border border-zinc-800">
            <div className="flex items-start gap-3 mb-4">
              <Shield className="w-6 h-6 text-green-500 flex-shrink-0" />
              <div>
                <h3 className="font-bold text-white mb-1">Website Integration</h3>
                <p className="text-sm text-zinc-400 mb-3">
                  Connect your business website to sync reviews, bookings, and before/after galleries
                </p>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-gray-500"></div>
                  <span className="text-xs text-zinc-500">Not connected</span>
                </div>
              </div>
            </div>
            <Button className="w-full bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center gap-2">
              <ExternalLink className="w-4 h-4" />
              Connect Website
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  // Digital Wallet View
  if (activeView === "wallet") {
    return (
      <div className="min-h-screen bg-black pb-20">
        <div className="bg-zinc-900 px-6 py-4 border-b border-zinc-800 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button onClick={() => setActiveView("main")} className="p-2 hover:bg-zinc-800 rounded-lg -ml-2">
              <ChevronLeft className="w-6 h-6 text-white" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white">Digital Wallet</h1>
              <p className="text-sm text-zinc-400">Manage payment methods</p>
            </div>
          </div>
        </div>

        <div className="px-6 py-6">
          <div className="space-y-4">
            {savedCards.map((card) => (
              <Card key={card.id} className={`p-6 bg-gradient-to-br ${card.color} border-0 text-white`}>
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <p className="text-xs opacity-75 mb-1">{card.type}</p>
                    <h3 className="text-lg font-bold">{card.name}</h3>
                  </div>
                  <CreditCard className="w-8 h-8 opacity-75" />
                </div>

                <div className="space-y-3">
                  <div>
                    <p className="text-2xl font-mono tracking-wider">•••• {card.last4}</p>
                  </div>

                  {card.balance && (
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="opacity-75">Balance</p>
                        <p className="font-bold">${card.balance}</p>
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            ))}

            <Button className="w-full h-14 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-white flex items-center justify-center gap-2">
              <CreditCard className="w-5 h-5" />
              Add Payment Method
            </Button>
          </div>

          <Card className="mt-6 p-4 bg-zinc-900 border border-zinc-800">
            <div className="flex items-start gap-2">
              <Shield className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-white text-sm mb-1">PCI-Compliant Storage</p>
                <p className="text-xs text-zinc-400">
                  All payment information is encrypted and stored securely. We never see your full card numbers.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  // Price Comparison View  
  if (activeView === "price-compare") {
    return (
      <div className="min-h-screen bg-black pb-20">
        <div className="bg-zinc-900 px-6 py-4 border-b border-zinc-800 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button onClick={() => setActiveView("main")} className="p-2 hover:bg-zinc-800 rounded-lg -ml-2">
              <ChevronLeft className="w-6 h-6 text-white" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white">Price Comparison</h1>
              <p className="text-sm text-zinc-400">Find the best deals</p>
            </div>
          </div>
        </div>

        <div className="px-6 py-6">
          <div className="mb-6">
            <input
              type="text"
              placeholder="Search for materials or tools..."
              className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-3 text-white placeholder-zinc-600"
            />
          </div>

          <div className="space-y-6">
            {priceComparisons.map((comparison, idx) => (
              <Card key={idx} className="p-4 bg-zinc-900 border border-zinc-800">
                <h3 className="font-bold text-white mb-4">{comparison.item}</h3>

                <div className="space-y-3">
                  {Object.entries(comparison).filter(([key]) => key !== "item").map(([store, data]: [string, any], index) => {
                    const isLowest = Object.values(comparison)
                      .filter(v => typeof v === "object" && v.price)
                      .every((v: any) => data.price <= v.price);

                    return (
                      <div key={index} className={`p-3 rounded-lg border ${isLowest ? "bg-green-950/30 border-green-900" : "bg-zinc-800 border-zinc-700"}`}>
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <h4 className="font-semibold text-white capitalize">{store.replace(/([A-Z])/g, " $1").trim()}</h4>
                            <p className="text-xs text-zinc-500">{data.distance}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-2xl font-bold text-white">${data.price}</p>
                            {isLowest && (
                              <Badge className="bg-green-500/20 text-green-400 text-xs border-green-500/30">
                                Lowest Price
                              </Badge>
                            )}
                          </div>
                        </div>
                        <p className="text-xs text-zinc-400">{data.stock}</p>
                      </div>
                    );
                  })}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Dispute Letters View
  if (activeView === "dispute-letters") {
    return (
      <div className="min-h-screen bg-black pb-20">
        <div className="bg-zinc-900 px-6 py-4 border-b border-zinc-800 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button onClick={() => setActiveView("main")} className="p-2 hover:bg-zinc-800 rounded-lg -ml-2">
              <ChevronLeft className="w-6 h-6 text-white" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white">Credit Dispute Letters</h1>
              <p className="text-sm text-zinc-400">Professional templates</p>
            </div>
          </div>
        </div>

        <div className="px-6 py-6">
          {disputeLetters.map((category, idx) => (
            <div key={idx} className="mb-6">
              <h3 className="text-sm font-semibold text-zinc-500 mb-3 uppercase tracking-wide">{category.category}</h3>
              <div className="space-y-3">
                {category.templates.map((template, tIdx) => (
                  <Card key={tIdx} className="p-4 bg-zinc-900 border border-zinc-800 hover:border-red-600/50 cursor-pointer transition-all">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-semibold text-white">{template.name}</h4>
                          <Badge className={`text-xs ${
                            template.impact === "High" ? "bg-red-950 text-red-400" : "bg-blue-950 text-blue-400"
                          }`}>
                            {template.impact} Impact
                          </Badge>
                        </div>
                        <p className="text-sm text-zinc-400 mb-3">{template.description}</p>
                        <Button className="bg-red-600 hover:bg-red-700 text-sm h-9">
                          Use Template
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          ))}

          <Card className="mt-6 p-4 bg-zinc-900 border border-zinc-800">
            <h4 className="font-semibold text-white mb-2">How to Use Dispute Letters</h4>
            <ol className="text-sm text-zinc-400 space-y-2 list-decimal list-inside">
              <li>Choose the appropriate template for your situation</li>
              <li>Fill in your personal information and account details</li>
              <li>Print and sign the letter</li>
              <li>Send via certified mail to all 3 credit bureaus</li>
              <li>Keep copies and track responses (30-45 day window)</li>
            </ol>
          </Card>
        </div>
      </div>
    );
  }

  // Business Profile View
  if (activeView === "business-profile") {
    return (
      <div className="min-h-screen bg-black pb-20">
        <div className="bg-zinc-900 px-6 py-4 border-b border-zinc-800 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button onClick={() => setActiveView("main")} className="p-2 hover:bg-zinc-800 rounded-lg -ml-2">
              <ChevronLeft className="w-6 h-6 text-white" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white">Business Profile</h1>
              <p className="text-sm text-zinc-400">License, bonding & portfolio</p>
            </div>
          </div>
        </div>

        <div className="px-6 py-6">
          {/* Business Info */}
          <Card className="p-6 bg-zinc-900 border border-zinc-800 mb-4">
            <h3 className="font-bold text-white mb-4">Company Information</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-zinc-400">Business Name</span>
                <span className="text-white font-semibold">K.C. Construction LLC</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">License #</span>
                <span className="text-white font-semibold">GA-CON-2024-1234</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Bonded Amount</span>
                <span className="text-white font-semibold">$50,000</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">Insurance</span>
                <Badge className="bg-green-950 text-green-400">Active</Badge>
              </div>
            </div>
            <Button className="w-full mt-4 bg-zinc-800 hover:bg-zinc-700">
              Edit Information
            </Button>
          </Card>

          {/* Before/After Gallery */}
          <Card className="p-6 bg-zinc-900 border border-zinc-800 mb-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-white">Project Gallery</h3>
              <Button className="bg-red-600 hover:bg-red-700 text-sm h-9 flex items-center gap-2">
                <Camera className="w-4 h-4" />
                Add Project
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="aspect-square bg-zinc-800 rounded-lg flex items-center justify-center border border-zinc-700">
                  <p className="text-xs text-zinc-600">Project {i}</p>
                </div>
              ))}
            </div>

            <p className="text-xs text-zinc-500 mt-4 text-center">
              Syncs with your website automatically
            </p>
          </Card>

          {/* Reviews */}
          <Card className="p-6 bg-zinc-900 border border-zinc-800">
            <h3 className="font-bold text-white mb-4">Customer Reviews</h3>
            
            <div className="flex items-center gap-4 mb-4">
              <div className="text-center">
                <p className="text-4xl font-bold text-white">4.9</p>
                <p className="text-xs text-zinc-500">Average Rating</p>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 text-yellow-500 mb-1">
                  ★★★★★
                </div>
                <p className="text-sm text-zinc-400">Based on 47 reviews</p>
              </div>
            </div>

            <Button className="w-full bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center gap-2">
              <ExternalLink className="w-4 h-4" />
              Manage Reviews
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  // Branding View
  if (activeView === "branding") {
    return <BrandingScreen onBack={() => setActiveView("main")} />;
  }

  // Custom Branding View
  if (activeView === "custom-branding") {
    return (
      <CustomBrandingScreen 
        onBack={() => setActiveView("main")}
        subscriptionTier="pro"
        currentBranding={{
          logoUrl: null,
          primaryColor: "#1e3a8a",
          secondaryColor: "#c0c0c0",
          accentColor: "#ffd700",
          businessName: "K.C. Construction LLC",
          appName: "Kaiden's BuildWealth Pro",
          customGoalTitle: "Build Wealth in 120 Days"
        }}
        onSave={async (branding) => {
          // In a real implementation, save to Supabase here
          console.log("Saving branding:", branding);
        }}
      />
    );
  }

  return null;
}