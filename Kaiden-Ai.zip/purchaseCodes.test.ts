/**
 * Purchase Code System Unit Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { generatePurchaseCode } from './purchaseCodes';

describe('Purchase Code System', () => {
  describe('generatePurchaseCode', () => {
    it('should generate a unique code', () => {
      const code1 = generatePurchaseCode();
      const code2 = generatePurchaseCode();
      
      expect(code1).not.toBe(code2);
    });

    it('should start with KAI- prefix', () => {
      const code = generatePurchaseCode();
      expect(code.startsWith('KAI-')).toBe(true);
    });

    it('should be uppercase', () => {
      const code = generatePurchaseCode();
      expect(code).toBe(code.toUpperCase());
    });

    it('should have correct length', () => {
      const code = generatePurchaseCode();
      // KAI- (4) + 32 char hash = 36 total
      expect(code.length).toBe(36);
    });

    it('should only contain valid characters', () => {
      const code = generatePurchaseCode();
      // Should only contain uppercase letters, numbers, and hyphens
      expect(/^KAI-[A-F0-9]+$/.test(code)).toBe(true);
    });

    it('should generate 1000 unique codes', () => {
      const codes = new Set<string>();
      for (let i = 0; i < 1000; i++) {
        codes.add(generatePurchaseCode());
      }
      expect(codes.size).toBe(1000);
    });
  });

  describe('Code Format Validation', () => {
    it('should validate correct format', () => {
      const code = generatePurchaseCode();
      const isValid = /^KAI-[A-F0-9]{32}$/.test(code);
      expect(isValid).toBe(true);
    });

    it('should reject invalid formats', () => {
      const invalidCodes = [
        'invalid',
        'KAI-short',
        'kai-lowercase',
        'KAI-TOOLONGCODETHATSHOULDNOTBEVALID123456',
        '',
        null,
        undefined,
      ];

      invalidCodes.forEach(code => {
        const isValid = typeof code === 'string' && /^KAI-[A-F0-9]{32}$/.test(code);
        expect(isValid).toBe(false);
      });
    });
  });

  describe('Security Properties', () => {
    it('should be cryptographically random', () => {
      // Generate many codes and check distribution
      const codes = [];
      for (let i = 0; i < 100; i++) {
        codes.push(generatePurchaseCode());
      }

      // Check that codes don't share common patterns
      const prefixes = codes.map(c => c.substring(4, 8));
      const uniquePrefixes = new Set(prefixes);
      
      // With random generation, we expect most prefixes to be unique
      expect(uniquePrefixes.size).toBeGreaterThan(90);
    });

    it('should not be predictable', () => {
      // Generate codes in sequence and verify they're not sequential
      const codes = [];
      for (let i = 0; i < 10; i++) {
        codes.push(generatePurchaseCode());
      }

      // Check that consecutive codes are not similar
      for (let i = 1; i < codes.length; i++) {
        const prev = codes[i - 1].substring(4);
        const curr = codes[i].substring(4);
        
        // Count matching characters
        let matches = 0;
        for (let j = 0; j < prev.length; j++) {
          if (prev[j] === curr[j]) matches++;
        }
        
        // Should have less than 50% matching characters
        expect(matches).toBeLessThan(prev.length * 0.5);
      }
    });
  });
});

describe('Anti-Sharing Protection', () => {
  it('should tie code to user ID', () => {
    // This tests the concept - actual DB tests would be integration tests
    const userId = 123;
    const code = generatePurchaseCode();
    
    // Code should be unique per generation
    expect(code).toBeDefined();
    expect(typeof code).toBe('string');
  });

  it('should support download limits', () => {
    const maxDownloads = 5;
    let downloadCount = 0;
    
    // Simulate download tracking
    const canDownload = () => downloadCount < maxDownloads;
    const recordDownload = () => {
      if (canDownload()) {
        downloadCount++;
        return true;
      }
      return false;
    };

    // First 5 downloads should succeed
    for (let i = 0; i < 5; i++) {
      expect(recordDownload()).toBe(true);
    }

    // 6th download should fail
    expect(recordDownload()).toBe(false);
    expect(downloadCount).toBe(5);
  });

  it('should support code expiration', () => {
    const now = Date.now();
    const expiryDays = 365;
    const expiresAt = new Date(now + expiryDays * 24 * 60 * 60 * 1000);
    
    // Code should be valid before expiry
    expect(expiresAt.getTime()).toBeGreaterThan(now);
    
    // Simulate expired code
    const expiredDate = new Date(now - 1000);
    expect(expiredDate.getTime()).toBeLessThan(now);
  });
});

describe('Suspicious Activity Detection', () => {
  it('should detect multiple IPs', () => {
    const ips = ['1.1.1.1', '2.2.2.2', '3.3.3.3', '4.4.4.4'];
    const uniqueIps = new Set(ips);
    
    // More than 3 unique IPs is suspicious
    expect(uniqueIps.size > 3).toBe(true);
  });

  it('should detect rapid downloads', () => {
    const downloads = [
      { time: Date.now() - 1000 },
      { time: Date.now() - 2000 },
      { time: Date.now() - 3000 },
      { time: Date.now() - 4000 },
    ];
    
    const oneHourAgo = Date.now() - 60 * 60 * 1000;
    const recentDownloads = downloads.filter(d => d.time > oneHourAgo);
    
    // More than 3 downloads in an hour is suspicious
    expect(recentDownloads.length > 3).toBe(true);
  });
});
