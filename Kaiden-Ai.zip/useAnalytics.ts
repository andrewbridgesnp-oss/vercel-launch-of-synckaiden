/**
 * Analytics Hook
 * Fetch and manage analytics data
 */

import { useState, useCallback, useEffect } from 'react';

export interface DateRange {
  startDate: Date;
  endDate: Date;
}

export interface KPISummary {
  totalActiveUsers: number;
  totalNewUsers: number;
  totalSessions: number;
  totalEvents: number;
  avgSessionDuration: number;
  avgBounceRate: number;
  totalRevenue: number;
  totalSubscriptions: number;
}

export interface DailyMetric {
  date: string;
  activeUsers: number;
  newUsers: number;
  totalSessions: number;
  totalEvents: number;
  avgSessionDuration: number;
  bounceRate: number;
  totalRevenue: number;
}

export interface RevenueMetric {
  tier: string;
  revenue: number;
  transactions: number;
}

export interface FeatureUsageMetric {
  featureName: string;
  usageCount: number;
  lastUsed: string;
  totalTimeSpent: number;
}

export interface PerformanceMetric {
  endpoint: string;
  avgResponseTime: number;
  p95ResponseTime: number;
  p99ResponseTime: number;
  errorRate: number;
  totalRequests: number;
}

export function useAnalytics(dateRange: DateRange) {
  const [kpiData, setKpiData] = useState<KPISummary | null>(null);
  const [dailyMetrics, setDailyMetrics] = useState<DailyMetric[]>([]);
  const [revenueMetrics, setRevenueMetrics] = useState<RevenueMetric[]>([]);
  const [featureUsage, setFeatureUsage] = useState<FeatureUsageMetric[]>([]);
  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetric[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchKpiData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch('/api/analytics/kpi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          startDate: dateRange.startDate.toISOString(),
          endDate: dateRange.endDate.toISOString(),
        }),
      });

      if (!response.ok) throw new Error('Failed to fetch KPI data');
      const data = await response.json();
      setKpiData(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  const fetchDailyMetrics = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/analytics/daily', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          startDate: dateRange.startDate.toISOString(),
          endDate: dateRange.endDate.toISOString(),
        }),
      });

      if (!response.ok) throw new Error('Failed to fetch daily metrics');
      const data = await response.json();
      setDailyMetrics(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  const fetchRevenueMetrics = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/analytics/revenue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          startDate: dateRange.startDate.toISOString(),
          endDate: dateRange.endDate.toISOString(),
        }),
      });

      if (!response.ok) throw new Error('Failed to fetch revenue metrics');
      const data = await response.json();
      setRevenueMetrics(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  const fetchFeatureUsage = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/analytics/features', {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });

      if (!response.ok) throw new Error('Failed to fetch feature usage');
      const data = await response.json();
      setFeatureUsage(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchPerformanceMetrics = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/analytics/performance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          startDate: dateRange.startDate.toISOString(),
          endDate: dateRange.endDate.toISOString(),
        }),
      });

      if (!response.ok) throw new Error('Failed to fetch performance metrics');
      const data = await response.json();
      setPerformanceMetrics(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  const trackEvent = useCallback(
    async (eventType: string, eventName: string, eventValue?: string) => {
      try {
        await fetch('/api/analytics/track', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            eventType,
            eventName,
            eventValue,
          }),
        });
      } catch (err) {
        console.error('Failed to track event:', err);
      }
    },
    []
  );

  const trackFeatureUsage = useCallback(async (featureId: string, featureName: string) => {
    try {
      await fetch('/api/analytics/feature-usage', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          featureId,
          featureName,
        }),
      });
    } catch (err) {
      console.error('Failed to track feature usage:', err);
    }
  }, []);

  // Auto-fetch data when date range changes
  useEffect(() => {
    fetchKpiData();
    fetchDailyMetrics();
    fetchRevenueMetrics();
    fetchPerformanceMetrics();
  }, [dateRange, fetchKpiData, fetchDailyMetrics, fetchRevenueMetrics, fetchPerformanceMetrics]);

  return {
    kpiData,
    dailyMetrics,
    revenueMetrics,
    featureUsage,
    performanceMetrics,
    loading,
    error,
    refetch: {
      kpi: fetchKpiData,
      daily: fetchDailyMetrics,
      revenue: fetchRevenueMetrics,
      features: fetchFeatureUsage,
      performance: fetchPerformanceMetrics,
    },
    trackEvent,
    trackFeatureUsage,
  };
}

export default useAnalytics;
