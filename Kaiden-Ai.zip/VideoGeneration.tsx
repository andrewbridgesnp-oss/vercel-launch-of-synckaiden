import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Film, Zap, CheckCircle, Clock, AlertCircle } from "lucide-react";

export default function VideoGeneration() {
  const [activeTab, setActiveTab] = useState("drafts");

  const videoDrafts = [
    {
      id: 1,
      title: "AI Business Automation Tips",
      status: "draft",
      platforms: ["youtube", "tiktok"],
      createdAt: "2024-01-10",
      script: "Welcome to Kaiden AI...",
    },
    {
      id: 2,
      title: "Time Restoration Technology",
      status: "approved",
      platforms: ["instagram", "facebook"],
      createdAt: "2024-01-09",
      script: "Discover how Kaiden helps you...",
    },
    {
      id: 3,
      title: "Agent Swarm Demo",
      status: "generating",
      platforms: ["youtube"],
      createdAt: "2024-01-08",
      script: "Watch our autonomous agents in action...",
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "draft":
        return <AlertCircle className="w-4 h-4" />;
      case "generating":
        return <Zap className="w-4 h-4 animate-spin" />;
      case "approved":
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "draft":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
      case "generating":
        return "bg-blue-500/20 text-blue-400 border-blue-500/30";
      case "approved":
        return "bg-green-500/20 text-green-400 border-green-500/30";
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Film className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold">Video Generation Pipeline</h1>
          </div>
          <p className="text-muted-foreground">Create, manage, and publish AI-generated videos across multiple platforms</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Videos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">24</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Published</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">18</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">In Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">3</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Views</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">45.2K</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Video Library</CardTitle>
                <CardDescription>Manage all your AI-generated video content</CardDescription>
              </div>
              <Button className="btn-shine">
                <Zap className="w-4 h-4 mr-2" />
                Generate New Video
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="drafts">Drafts</TabsTrigger>
                <TabsTrigger value="approved">Approved</TabsTrigger>
                <TabsTrigger value="published">Published</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>

              <TabsContent value="drafts" className="space-y-4">
                <div className="space-y-3">
                  {videoDrafts
                    .filter((v) => v.status === "draft")
                    .map((video) => (
                      <div
                        key={video.id}
                        className="p-4 rounded-lg border border-border/50 hover:border-primary/50 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg mb-1">{video.title}</h3>
                            <p className="text-sm text-muted-foreground mb-2">{video.script}</p>
                            <div className="flex items-center gap-2 flex-wrap">
                              {video.platforms.map((p) => (
                                <Badge key={p} variant="secondary" className="text-xs">
                                  {p}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <Badge className={`${getStatusColor(video.status)} border`}>
                            <span className="flex items-center gap-1">
                              {getStatusIcon(video.status)}
                              {video.status}
                            </span>
                          </Badge>
                        </div>
                        <div className="flex gap-2 justify-end">
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                          <Button size="sm">Submit for Review</Button>
                        </div>
                      </div>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="approved" className="space-y-4">
                <div className="space-y-3">
                  {videoDrafts
                    .filter((v) => v.status === "approved")
                    .map((video) => (
                      <div
                        key={video.id}
                        className="p-4 rounded-lg border border-border/50 hover:border-primary/50 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg mb-1">{video.title}</h3>
                            <p className="text-sm text-muted-foreground mb-2">{video.script}</p>
                            <div className="flex items-center gap-2 flex-wrap">
                              {video.platforms.map((p) => (
                                <Badge key={p} variant="secondary" className="text-xs">
                                  {p}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <Badge className={`${getStatusColor(video.status)} border`}>
                            <span className="flex items-center gap-1">
                              {getStatusIcon(video.status)}
                              {video.status}
                            </span>
                          </Badge>
                        </div>
                        <div className="flex gap-2 justify-end">
                          <Button variant="outline" size="sm">
                            Preview
                          </Button>
                          <Button size="sm">Publish Now</Button>
                        </div>
                      </div>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="published" className="space-y-4">
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">Published videos will appear here</p>
                  <Button>View Published Videos</Button>
                </div>
              </TabsContent>

              <TabsContent value="analytics" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Top Performing Video</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold mb-2">12.5K views</div>
                      <p className="text-sm text-muted-foreground">AI Business Automation Tips</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-sm">Engagement Rate</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold mb-2">8.3%</div>
                      <p className="text-sm text-muted-foreground">↑ 2.1% from last week</p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
