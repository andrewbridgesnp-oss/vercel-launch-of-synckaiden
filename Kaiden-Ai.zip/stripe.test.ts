/**
 * Stripe Payment Flow Tests
 * Tests for checkout, subscriptions, and webhook handling
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock Stripe
const mockStripe = {
  checkout: {
    sessions: {
      create: vi.fn(),
    },
  },
  subscriptions: {
    list: vi.fn(),
    update: vi.fn(),
  },
  invoices: {
    list: vi.fn(),
  },
};

vi.mock('stripe', () => ({
  default: vi.fn(() => mockStripe),
}));

describe('Stripe Payment Flow', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Checkout Session Creation', () => {
    it('should create subscription checkout session with correct parameters', async () => {
      const mockSession = {
        id: 'cs_test_123',
        url: 'https://checkout.stripe.com/pay/cs_test_123',
      };
      mockStripe.checkout.sessions.create.mockResolvedValue(mockSession);

      const input = {
        priceId: 'price_starter_monthly',
        planName: 'Starter',
        planPrice: 9.99,
      };

      const ctx = {
        user: { id: 1, email: 'test@example.com', name: 'Test User' },
        req: { headers: { origin: 'https://synckaiden.com' } },
      };

      // Simulate checkout creation
      const session = await mockStripe.checkout.sessions.create({
        customer_email: ctx.user.email,
        client_reference_id: ctx.user.id.toString(),
        line_items: [{ price: input.priceId, quantity: 1 }],
        mode: 'subscription',
        success_url: `${ctx.req.headers.origin}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${ctx.req.headers.origin}/pricing`,
        metadata: {
          user_id: ctx.user.id.toString(),
          customer_email: ctx.user.email,
          customer_name: ctx.user.name,
          plan_name: input.planName,
        },
        allow_promotion_codes: true,
      });

      expect(mockStripe.checkout.sessions.create).toHaveBeenCalledWith(
        expect.objectContaining({
          customer_email: 'test@example.com',
          mode: 'subscription',
          allow_promotion_codes: true,
        })
      );
      expect(session.url).toBe('https://checkout.stripe.com/pay/cs_test_123');
    });

    it('should create one-time payment checkout session', async () => {
      const mockSession = {
        id: 'cs_test_456',
        url: 'https://checkout.stripe.com/pay/cs_test_456',
      };
      mockStripe.checkout.sessions.create.mockResolvedValue(mockSession);

      const input = {
        amount: 1.00,
        description: 'AI Side Hustle Guide',
        productName: 'Bougie Boutique - AI Side Hustle',
      };

      const session = await mockStripe.checkout.sessions.create({
        line_items: [{
          price_data: {
            currency: 'usd',
            product_data: {
              name: input.productName,
              description: input.description,
            },
            unit_amount: Math.round(input.amount * 100),
          },
          quantity: 1,
        }],
        mode: 'payment',
      });

      expect(mockStripe.checkout.sessions.create).toHaveBeenCalledWith(
        expect.objectContaining({
          mode: 'payment',
          line_items: expect.arrayContaining([
            expect.objectContaining({
              price_data: expect.objectContaining({
                unit_amount: 100, // $1.00 in cents
              }),
            }),
          ]),
        })
      );
    });

    it('should handle checkout creation errors gracefully', async () => {
      mockStripe.checkout.sessions.create.mockRejectedValue(new Error('Invalid API key'));

      try {
        await mockStripe.checkout.sessions.create({});
        expect.fail('Should have thrown error');
      } catch (error) {
        expect((error as Error).message).toBe('Invalid API key');
      }
    });
  });

  describe('Subscription Management', () => {
    it('should fetch active subscriptions', async () => {
      const mockSubscriptions = {
        data: [{
          id: 'sub_123',
          status: 'active',
          current_period_end: Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60,
          cancel_at_period_end: false,
          items: {
            data: [{
              price: {
                id: 'price_starter',
                product: { name: 'Starter Plan' },
                unit_amount: 999,
              },
            }],
          },
        }],
      };
      mockStripe.subscriptions.list.mockResolvedValue(mockSubscriptions);

      const result = await mockStripe.subscriptions.list({ limit: 1 });

      expect(result.data).toHaveLength(1);
      expect(result.data[0].status).toBe('active');
      expect(result.data[0].items.data[0].price.unit_amount).toBe(999);
    });

    it('should cancel subscription at period end', async () => {
      mockStripe.subscriptions.update.mockResolvedValue({
        id: 'sub_123',
        cancel_at_period_end: true,
      });

      const result = await mockStripe.subscriptions.update('sub_123', {
        cancel_at_period_end: true,
      });

      expect(result.cancel_at_period_end).toBe(true);
      expect(mockStripe.subscriptions.update).toHaveBeenCalledWith('sub_123', {
        cancel_at_period_end: true,
      });
    });
  });

  describe('Payment History', () => {
    it('should fetch invoice history', async () => {
      const mockInvoices = {
        data: [
          {
            id: 'in_123',
            amount_paid: 999,
            currency: 'usd',
            status: 'paid',
            created: Math.floor(Date.now() / 1000) - 30 * 24 * 60 * 60,
            description: 'Starter Plan - Monthly',
          },
          {
            id: 'in_124',
            amount_paid: 999,
            currency: 'usd',
            status: 'paid',
            created: Math.floor(Date.now() / 1000),
            description: 'Starter Plan - Monthly',
          },
        ],
      };
      mockStripe.invoices.list.mockResolvedValue(mockInvoices);

      const result = await mockStripe.invoices.list({ limit: 50 });

      expect(result.data).toHaveLength(2);
      expect(result.data[0].amount_paid).toBe(999);
      expect(result.data[0].status).toBe('paid');
    });
  });

  describe('Webhook Handling', () => {
    it('should handle checkout.session.completed event', () => {
      const event = {
        id: 'evt_123',
        type: 'checkout.session.completed',
        data: {
          object: {
            id: 'cs_123',
            customer_email: 'test@example.com',
            metadata: {
              user_id: '1',
              plan_name: 'Starter',
            },
          },
        },
      };

      // Verify event structure
      expect(event.type).toBe('checkout.session.completed');
      expect(event.data.object.metadata.user_id).toBe('1');
    });

    it('should handle customer.subscription.created event', () => {
      const event = {
        id: 'evt_124',
        type: 'customer.subscription.created',
        data: {
          object: {
            id: 'sub_123',
            status: 'active',
            customer: 'cus_123',
          },
        },
      };

      expect(event.type).toBe('customer.subscription.created');
      expect(event.data.object.status).toBe('active');
    });

    it('should handle invoice.payment_failed event', () => {
      const event = {
        id: 'evt_125',
        type: 'invoice.payment_failed',
        data: {
          object: {
            id: 'in_123',
            customer_email: 'test@example.com',
            amount_due: 999,
          },
        },
      };

      expect(event.type).toBe('invoice.payment_failed');
      expect(event.data.object.amount_due).toBe(999);
    });

    it('should handle test events', () => {
      const testEvent = {
        id: 'evt_test_webhook',
        type: 'checkout.session.completed',
        data: { object: {} },
      };

      // Test events should be detected by ID prefix
      expect(testEvent.id.startsWith('evt_test_')).toBe(true);
    });
  });

  describe('Price Calculations', () => {
    it('should correctly convert dollars to cents', () => {
      const prices = [
        { dollars: 1.00, cents: 100 },
        { dollars: 9.99, cents: 999 },
        { dollars: 29.99, cents: 2999 },
        { dollars: 99.99, cents: 9999 },
        { dollars: 0.50, cents: 50 },
      ];

      prices.forEach(({ dollars, cents }) => {
        expect(Math.round(dollars * 100)).toBe(cents);
      });
    });

    it('should handle discount calculations', () => {
      const originalPrice = 9.99;
      const discountPercent = 10;
      const discountedPrice = originalPrice * (1 - discountPercent / 100);
      
      expect(discountedPrice).toBeCloseTo(8.99, 2);
      expect(Math.round(discountedPrice * 100)).toBe(899);
    });

    it('should calculate bundle discounts correctly', () => {
      const singleAppPrice = 1.00;
      const bundleSizes = [
        { count: 1, discount: 0, expected: 1.00 },
        { count: 3, discount: 5, expected: 2.85 },
        { count: 5, discount: 10, expected: 4.50 },
        { count: 10, discount: 20, expected: 8.00 },
      ];

      bundleSizes.forEach(({ count, discount, expected }) => {
        const total = count * singleAppPrice * (1 - discount / 100);
        expect(total).toBeCloseTo(expected, 2);
      });
    });
  });
});

describe('Bougie Boutique Payment Integration', () => {
  it('should create checkout for $1 digital product', async () => {
    const product = {
      name: 'AI Side Hustle Starter Kit',
      price: 1.00,
      description: 'Complete guide to starting an AI-powered side hustle',
    };

    const checkoutData = {
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: {
            name: product.name,
            description: product.description,
          },
          unit_amount: Math.round(product.price * 100),
        },
        quantity: 1,
      }],
      mode: 'payment',
    };

    expect(checkoutData.line_items[0].price_data.unit_amount).toBe(100);
    expect(checkoutData.mode).toBe('payment');
  });

  it('should generate unique purchase code after successful payment', () => {
    const generatePurchaseCode = () => {
      const prefix = 'KAI';
      const timestamp = Date.now().toString(36).toUpperCase();
      const random = Math.random().toString(36).substring(2, 8).toUpperCase();
      return `${prefix}-${timestamp}-${random}`;
    };

    const code1 = generatePurchaseCode();
    const code2 = generatePurchaseCode();

    expect(code1).toMatch(/^KAI-[A-Z0-9]+-[A-Z0-9]+$/);
    expect(code1).not.toBe(code2); // Codes should be unique
  });
});
