import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, ShoppingCart, Zap } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: "tshirt" | "hoodie" | "hat" | "sweatshirt";
  image: string;
  colors: string[];
  sizes: string[];
  message: string;
}

const BOUGIE_PRODUCTS: Product[] = [
  {
    id: "1",
    name: "No Cap, Be Kind",
    description: "Bold text with a cap emoji crossed out, followed by BE KIND in gradient pink/purple",
    price: 24.99,
    category: "tshirt",
    image: "/products/no-cap-be-kind.png",
    colors: ["Black"],
    sizes: ["XS", "S", "M", "L", "XL", "2XL", "3XL"],
    message: "No cap means no lie - being kind is the real truth",
  },
  {
    id: "2",
    name: "Slay The Hate Away",
    description: "Sparkle sword cutting through the word HATE with SLAY above",
    price: 24.99,
    category: "tshirt",
    image: "/products/slay-hate.png",
    colors: ["White"],
    sizes: ["XS", "S", "M", "L", "XL", "2XL", "3XL"],
    message: "You have the power to defeat negativity",
  },
  {
    id: "3",
    name: "Main Character Energy (Kind Edition)",
    description: "Crown above MAIN CHARACTER with KIND EDITION as a subtitle",
    price: 29.99,
    category: "tshirt",
    image: "/products/main-character.png",
    colors: ["Lavender"],
    sizes: ["XS", "S", "M", "L", "XL", "2XL", "3XL"],
    message: "Be the hero of your story by being kind to others",
  },
  {
    id: "16",
    name: "Rizz With Respect",
    description: "RIZZ in large graffiti-style text, with RESPECT in elegant script below",
    price: 44.99,
    category: "hoodie",
    image: "/products/rizz-respect.png",
    colors: ["Black"],
    sizes: ["XS", "S", "M", "L", "XL", "2XL", "3XL"],
    message: "Real charm comes from treating people well",
  },
  {
    id: "21",
    name: "Mental Health Check ✓",
    description: "Simple embroidered text MENTAL HEALTH CHECK with checkmark",
    price: 19.99,
    category: "hat",
    image: "/products/mental-health-check.png",
    colors: ["Dusty Pink"],
    sizes: ["One Size"],
    message: "Reminder to check in on yourself and others",
  },
];

export default function BougieBoutiqueModule() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedColor, setSelectedColor] = useState<string>("");
  const [selectedSize, setSelectedSize] = useState<string>("");
  const [quantity, setQuantity] = useState(1);
  const [cart, setCart] = useState<Array<{ product: Product; color: string; size: string; quantity: number }>>([]);
  const [showCart, setShowCart] = useState(false);

  const stripeCheckout = trpc.stripe.createCheckoutSession.useMutation();

  const handleAddToCart = () => {
    if (!selectedProduct || !selectedColor || !selectedSize) {
      toast.error("Please select color and size");
      return;
    }

    const existingItem = cart.find(
      (item) =>
        item.product.id === selectedProduct.id &&
        item.color === selectedColor &&
        item.size === selectedSize
    );

    if (existingItem) {
      setCart(
        cart.map((item) =>
          item === existingItem
            ? { ...item, quantity: item.quantity + quantity }
            : item
        )
      );
    } else {
      setCart([
        ...cart,
        { product: selectedProduct, color: selectedColor, size: selectedSize, quantity },
      ]);
    }

    toast.success("Added to cart!");
    setSelectedProduct(null);
    setSelectedColor("");
    setSelectedSize("");
    setQuantity(1);
  };

  const handleCheckout = async () => {
    if (cart.length === 0) {
      toast.error("Your cart is empty");
      return;
    }

    try {
      const lineItems = cart.map((item) => ({
        price_data: {
          currency: "usd",
          product_data: {
            name: `${item.product.name} - ${item.color} - ${item.size}`,
            images: [item.product.image],
          },
          unit_amount: Math.round(item.product.price * 100),
        },
        quantity: item.quantity,
      }));

      const session = await stripeCheckout.mutateAsync({
        lineItems,
        metadata: {
          source: "bougie_boutique",
          donation_percentage: "10",
        },
      });

      if (session.url) {
        window.location.href = session.url;
      }
    } catch (error) {
      toast.error("Error creating checkout session");
      console.error(error);
    }
  };

  const cartTotal = cart.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const donationAmount = (cartTotal * 0.1).toFixed(2);

  return (
    <div className="w-full space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Heart className="w-12 h-12 text-pink-400" />
        </div>
        <h2 className="text-4xl font-bold mb-2" style={{
          background: "linear-gradient(135deg, #e0e0e8 0%, #ffffff 50%, #c0c0d0 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}>
          Bougie Boutique
        </h2>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Anti-bullying and mental health awareness products for Gen Alpha. 10% of proceeds support YMCA after-school programs.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Product Grid */}
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {BOUGIE_PRODUCTS.map((product) => (
              <Card
                key={product.id}
                className="glass border-border/50 cursor-pointer hover:border-cyan-500/50 transition-all"
                onClick={() => {
                  setSelectedProduct(product);
                  setSelectedColor(product.colors[0]);
                  setSelectedSize(product.sizes[0]);
                }}
              >
                <CardContent className="p-4 space-y-3">
                  <div className="w-full h-48 bg-gradient-to-br from-purple-500/20 to-cyan-500/20 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-gray-400 text-sm">{product.category.toUpperCase()}</p>
                      <p className="text-gray-300 font-semibold mt-2">{product.name}</p>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-gray-400">{product.message}</p>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold text-cyan-400">
                      ${product.price.toFixed(2)}
                    </span>
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedProduct(product);
                        setSelectedColor(product.colors[0]);
                        setSelectedSize(product.sizes[0]);
                      }}
                      className="bg-cyan-500 hover:bg-cyan-600"
                    >
                      <ShoppingCart className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Product Details & Cart */}
        <div className="space-y-6">
          {/* Product Details */}
          {selectedProduct && (
            <Card className="glass border-border/50">
              <CardHeader>
                <CardTitle>{selectedProduct.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-400">{selectedProduct.description}</p>

                <div>
                  <label className="text-sm text-gray-300 block mb-2">Color</label>
                  <select
                    value={selectedColor}
                    onChange={(e) => setSelectedColor(e.target.value)}
                    className="w-full bg-background/50 border border-border/50 rounded-lg px-3 py-2 text-gray-200"
                  >
                    {selectedProduct.colors.map((color) => (
                      <option key={color} value={color}>
                        {color}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-300 block mb-2">Size</label>
                  <select
                    value={selectedSize}
                    onChange={(e) => setSelectedSize(e.target.value)}
                    className="w-full bg-background/50 border border-border/50 rounded-lg px-3 py-2 text-gray-200"
                  >
                    {selectedProduct.sizes.map((size) => (
                      <option key={size} value={size}>
                        {size}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-300 block mb-2">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(parseInt(e.target.value))}
                    className="w-full bg-background/50 border border-border/50 rounded-lg px-3 py-2 text-gray-200"
                  />
                </div>

                <Button
                  onClick={handleAddToCart}
                  className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:opacity-90"
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Add to Cart
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Cart Summary */}
          <Card className="glass border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5" />
                Cart ({cart.length} items)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {cart.length === 0 ? (
                <p className="text-gray-400 text-sm">Your cart is empty</p>
              ) : (
                <>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {cart.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm text-gray-300">
                        <span>
                          {item.product.name} x{item.quantity}
                        </span>
                        <span>${(item.product.price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-border/50 pt-3 space-y-2">
                    <div className="flex justify-between text-gray-300">
                      <span>Subtotal:</span>
                      <span>${cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-green-400 text-sm">
                      <span className="flex items-center gap-1">
                        <Zap className="w-4 h-4" />
                        Donation (10%):
                      </span>
                      <span>${donationAmount}</span>
                    </div>
                  </div>

                  <Button
                    onClick={handleCheckout}
                    disabled={stripeCheckout.isPending}
                    className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:opacity-90"
                  >
                    {stripeCheckout.isPending ? "Processing..." : "Checkout"}
                  </Button>

                  <p className="text-xs text-gray-500 text-center">
                    10% of your purchase supports YMCA programs
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
