import { Server as HTTPServer } from 'http';
import { Server as SocketIOServer, Socket } from 'socket.io';
import Redis from 'ioredis';
import { createHash } from 'crypto';

/**
 * Real-Time WebSocket & Caching System
 */

let io: SocketIOServer;
let redis: Redis;

/**
 * Initialize WebSocket server
 */
export function initializeWebSocket(httpServer: HTTPServer) {
  io = new SocketIOServer(httpServer, {
    cors: {
      origin: process.env.FRONTEND_URL || 'http://localhost:3000',
      credentials: true,
    },
  });

  // Initialize Redis for caching
  redis = new Redis({
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT || '6379'),
    password: process.env.REDIS_PASSWORD,
  });

  io.on('connection', (socket: Socket) => {
    console.log(`[WebSocket] User connected: ${socket.id}`);

    // Join user room
    socket.on('join', (userId: number) => {
      socket.join(`user:${userId}`);
      console.log(`[WebSocket] User ${userId} joined room`);
    });

    // Capability execution events
    socket.on('execute-capability', async (data) => {
      const { capabilityId, userId } = data;
      io.to(`user:${userId}`).emit('capability-executing', { capabilityId });
    });

    // Real-time data updates
    socket.on('subscribe-data', (dataKey: string) => {
      socket.join(`data:${dataKey}`);
    });

    socket.on('unsubscribe-data', (dataKey: string) => {
      socket.leave(`data:${dataKey}`);
    });

    // Notifications
    socket.on('subscribe-notifications', (userId: number) => {
      socket.join(`notifications:${userId}`);
    });

    socket.disconnect(() => {
      console.log(`[WebSocket] User disconnected: ${socket.id}`);
    });
  });

  return io;
}

/**
 * Emit capability execution update
 */
export function emitCapabilityUpdate(userId: number, capabilityId: string, status: string, data?: any) {
  if (io) {
    io.to(`user:${userId}`).emit('capability-update', {
      capabilityId,
      status,
      data,
      timestamp: new Date(),
    });
  }
}

/**
 * Emit notification to user
 */
export function emitNotification(userId: number, notification: any) {
  if (io) {
    io.to(`notifications:${userId}`).emit('notification', notification);
  }
}

/**
 * Broadcast data update to subscribers
 */
export function broadcastDataUpdate(dataKey: string, data: any) {
  if (io) {
    io.to(`data:${dataKey}`).emit('data-update', {
      key: dataKey,
      data,
      timestamp: new Date(),
    });
  }
}

/**
 * CACHING LAYER
 */

const CACHE_TTL = 3600; // 1 hour default

/**
 * Generate cache key
 */
function getCacheKey(prefix: string, ...args: any[]): string {
  const key = `${prefix}:${args.join(':')}`;
  return createHash('md5').update(key).digest('hex');
}

/**
 * Get from cache
 */
export async function getCache<T>(prefix: string, ...args: any[]): Promise<T | null> {
  if (!redis) return null;

  try {
    const key = getCacheKey(prefix, ...args);
    const data = await redis.get(key);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('[Cache] Get error:', error);
    return null;
  }
}

/**
 * Set cache
 */
export async function setCache(prefix: string, ttl: number, data: any, ...args: any[]): Promise<void> {
  if (!redis) return;

  try {
    const key = getCacheKey(prefix, ...args);
    await redis.setex(key, ttl, JSON.stringify(data));
  } catch (error) {
    console.error('[Cache] Set error:', error);
  }
}

/**
 * Delete cache
 */
export async function deleteCache(prefix: string, ...args: any[]): Promise<void> {
  if (!redis) return;

  try {
    const key = getCacheKey(prefix, ...args);
    await redis.del(key);
  } catch (error) {
    console.error('[Cache] Delete error:', error);
  }
}

/**
 * Clear cache by prefix
 */
export async function clearCacheByPrefix(prefix: string): Promise<void> {
  if (!redis) return;

  try {
    const keys = await redis.keys(`*${prefix}*`);
    if (keys.length > 0) {
      await redis.del(...keys);
    }
  } catch (error) {
    console.error('[Cache] Clear error:', error);
  }
}

/**
 * Cache user preferences
 */
export async function cacheUserPreferences(userId: number, preferences: any): Promise<void> {
  await setCache('user:preferences', CACHE_TTL, preferences, userId);
}

/**
 * Get cached user preferences
 */
export async function getCachedUserPreferences(userId: number): Promise<any | null> {
  return getCache('user:preferences', userId);
}

/**
 * Cache capability results
 */
export async function cacheCapabilityResult(executionId: number, result: any, ttl = CACHE_TTL): Promise<void> {
  await setCache('capability:result', ttl, result, executionId);
}

/**
 * Get cached capability result
 */
export async function getCachedCapabilityResult(executionId: number): Promise<any | null> {
  return getCache('capability:result', executionId);
}

/**
 * Cache analytics data
 */
export async function cacheAnalytics(userId: number, analytics: any): Promise<void> {
  await setCache('user:analytics', CACHE_TTL, analytics, userId);
}

/**
 * Get cached analytics
 */
export async function getCachedAnalytics(userId: number): Promise<any | null> {
  return getCache('user:analytics', userId);
}

/**
 * Invalidate user cache
 */
export async function invalidateUserCache(userId: number): Promise<void> {
  await clearCacheByPrefix(`user:${userId}`);
}

/**
 * Session management with Redis
 */
export async function createSession(userId: number, sessionData: any, ttl = 86400): Promise<string> {
  if (!redis) throw new Error('Redis not available');

  const sessionId = createHash('sha256').update(`${userId}:${Date.now()}:${Math.random()}`).digest('hex');
  await redis.setex(`session:${sessionId}`, ttl, JSON.stringify(sessionData));
  return sessionId;
}

/**
 * Get session
 */
export async function getSession(sessionId: string): Promise<any | null> {
  if (!redis) return null;

  try {
    const data = await redis.get(`session:${sessionId}`);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('[Session] Get error:', error);
    return null;
  }
}

/**
 * Delete session
 */
export async function deleteSession(sessionId: string): Promise<void> {
  if (!redis) return;

  try {
    await redis.del(`session:${sessionId}`);
  } catch (error) {
    console.error('[Session] Delete error:', error);
  }
}

/**
 * Rate limiting with Redis
 */
export async function checkRateLimitRedis(key: string, limit: number, windowSeconds: number): Promise<boolean> {
  if (!redis) return true;

  try {
    const current = await redis.incr(key);
    if (current === 1) {
      await redis.expire(key, windowSeconds);
    }
    return current <= limit;
  } catch (error) {
    console.error('[RateLimit] Check error:', error);
    return true; // Allow on error
  }
}

/**
 * Get rate limit remaining
 */
export async function getRateLimitRemaining(key: string, limit: number): Promise<number> {
  if (!redis) return limit;

  try {
    const current = await redis.get(key);
    return Math.max(0, limit - (parseInt(current || '0')));
  } catch (error) {
    console.error('[RateLimit] Get remaining error:', error);
    return limit;
  }
}

/**
 * Pub/Sub for distributed events
 */
export async function publishEvent(channel: string, data: any): Promise<void> {
  if (!redis) return;

  try {
    await redis.publish(channel, JSON.stringify(data));
  } catch (error) {
    console.error('[PubSub] Publish error:', error);
  }
}

/**
 * Subscribe to events
 */
export async function subscribeToEvents(channel: string, callback: (data: any) => void): Promise<void> {
  if (!redis) return;

  try {
    const subscriber = redis.duplicate();
    subscriber.subscribe(channel, (err) => {
      if (err) console.error('[PubSub] Subscribe error:', err);
    });

    subscriber.on('message', (chan, message) => {
      if (chan === channel) {
        try {
          callback(JSON.parse(message));
        } catch (error) {
          console.error('[PubSub] Parse error:', error);
        }
      }
    });
  } catch (error) {
    console.error('[PubSub] Subscribe error:', error);
  }
}

/**
 * Queue management with Redis
 */
export async function enqueueJob(queueName: string, job: any): Promise<void> {
  if (!redis) return;

  try {
    await redis.rpush(`queue:${queueName}`, JSON.stringify(job));
  } catch (error) {
    console.error('[Queue] Enqueue error:', error);
  }
}

/**
 * Dequeue job
 */
export async function dequeueJob(queueName: string): Promise<any | null> {
  if (!redis) return null;

  try {
    const job = await redis.lpop(`queue:${queueName}`);
    return job ? JSON.parse(job) : null;
  } catch (error) {
    console.error('[Queue] Dequeue error:', error);
    return null;
  }
}

/**
 * Get queue length
 */
export async function getQueueLength(queueName: string): Promise<number> {
  if (!redis) return 0;

  try {
    return await redis.llen(`queue:${queueName}`);
  } catch (error) {
    console.error('[Queue] Get length error:', error);
    return 0;
  }
}

/**
 * Close Redis connection
 */
export async function closeRedis(): Promise<void> {
  if (redis) {
    await redis.quit();
  }
}
