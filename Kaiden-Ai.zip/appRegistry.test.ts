import { describe, it, expect, beforeEach } from 'vitest';
import AppRegistryManager, { AppMetadata, AppLicense } from './appRegistry';

describe('AppRegistry - Independent Scaling Architecture', () => {
  let manager: AppRegistryManager;

  beforeEach(() => {
    manager = new AppRegistryManager();
  });

  describe('App Registration', () => {
    it('should register an app', () => {
      const appMetadata: AppMetadata = {
        id: 'househack-203k',
        name: 'HouseHack 203K',
        description: 'Real estate SaaS',
        icon: '🏠',
        category: 'real-estate',
        version: '1.0.0',
        author: 'HouseHack Team',
        pricing: {
          free: {
            price: 0,
            features: ['1 deal room'],
            limits: { dealRooms: 1 },
          },
          tiers: [
            {
              name: 'Pro',
              price: 29,
              features: ['Unlimited deals'],
              limits: { dealRooms: 999 },
            },
          ],
        },
        features: ['Deal room management'],
        scaling: {
          minInstances: 3,
          maxInstances: 50,
          cpuThreshold: 70,
          memoryThreshold: 80,
        },
        status: 'active',
        integrations: ['Stripe'],
        route: '/apps/househack',
      };

      manager.registerApp(appMetadata);
      const app = manager.getApp('househack-203k');

      expect(app).toBeDefined();
      expect(app?.name).toBe('HouseHack 203K');
    });

    it('should get all registered apps', () => {
      const app1: AppMetadata = {
        id: 'househack-203k',
        name: 'HouseHack',
        description: 'Real estate',
        icon: '🏠',
        category: 'real-estate',
        version: '1.0.0',
        author: 'Team',
        pricing: {
          free: { price: 0, features: [], limits: {} },
          tiers: [],
        },
        features: [],
        scaling: { minInstances: 1, maxInstances: 10, cpuThreshold: 70, memoryThreshold: 80 },
        status: 'active',
        integrations: [],
        route: '/apps/househack',
      };

      const app2: AppMetadata = {
        ...app1,
        id: 'syndica',
        name: 'Syndica',
      };

      manager.registerApp(app1);
      manager.registerApp(app2);

      const apps = manager.getApps();
      expect(apps.length).toBe(2);
    });
  });

  describe('License Management - Independent Per App', () => {
    beforeEach(() => {
      const app1: AppMetadata = {
        id: 'househack-203k',
        name: 'HouseHack',
        description: 'Real estate',
        icon: '🏠',
        category: 'real-estate',
        version: '1.0.0',
        author: 'Team',
        pricing: {
          free: {
            price: 0,
            features: ['basic'],
            limits: { dealRooms: 1 },
          },
          tiers: [
            {
              name: 'Pro',
              price: 29,
              features: ['unlimited'],
              limits: { dealRooms: 999 },
            },
          ],
        },
        features: [],
        scaling: { minInstances: 1, maxInstances: 10, cpuThreshold: 70, memoryThreshold: 80 },
        status: 'active',
        integrations: [],
        route: '/apps/househack',
      };

      const app2: AppMetadata = {
        ...app1,
        id: 'syndica',
        name: 'Syndica',
        pricing: {
          free: {
            price: 0,
            features: ['basic'],
            limits: { ingestions: 5 },
          },
          tiers: [
            {
              name: 'Starter',
              price: 19,
              features: ['more'],
              limits: { ingestions: 100 },
            },
          ],
        },
      };

      manager.registerApp(app1);
      manager.registerApp(app2);
    });

    it('should install app with free tier', () => {
      const license = manager.installApp('househack-203k', 1, 'free');

      expect(license.appId).toBe('househack-203k');
      expect(license.userId).toBe(1);
      expect(license.tier).toBe('free');
      expect(license.status).toBe('active');
    });

    it('should install app with paid tier', () => {
      const license = manager.installApp('househack-203k', 1, 'pro');

      expect(license.tier).toBe('pro');
      expect(license.status).toBe('trial');
      expect(license.expiresAt).toBeDefined();
    });

    it('should allow independent licenses per app', () => {
      // User has free HouseHack but Pro Syndica
      const househackLicense = manager.installApp('househack-203k', 1, 'free');
      const syndicaLicense = manager.installApp('syndica', 1, 'starter');

      expect(househackLicense.tier).toBe('free');
      expect(syndicaLicense.tier).toBe('starter');

      // Get licenses
      const licenses = manager.getUserLicenses(1);
      expect(licenses.length).toBe(2);
    });

    it('should get specific app license', () => {
      manager.installApp('househack-203k', 1, 'pro');
      const license = manager.getAppLicense(1, 'househack-203k');

      expect(license?.appId).toBe('househack-203k');
      expect(license?.tier).toBe('pro');
    });

    it('should upgrade license', () => {
      manager.installApp('househack-203k', 1, 'free');
      const upgraded = manager.upgradeLicense(1, 'househack-203k', 'pro');

      expect(upgraded?.tier).toBe('pro');
      expect(upgraded?.status).toBe('active');
    });

    it('should downgrade license', () => {
      manager.installApp('househack-203k', 1, 'pro');
      const downgraded = manager.downgradeLicense(1, 'househack-203k');

      expect(downgraded?.tier).toBe('free');
    });

    it('should cancel license', () => {
      manager.installApp('househack-203k', 1, 'pro');
      const cancelled = manager.cancelLicense(1, 'househack-203k');

      expect(cancelled).toBe(true);
      const license = manager.getAppLicense(1, 'househack-203k');
      expect(license?.status).toBe('expired');
    });
  });

  describe('Feature Access Control', () => {
    beforeEach(() => {
      const app: AppMetadata = {
        id: 'househack-203k',
        name: 'HouseHack',
        description: 'Real estate',
        icon: '🏠',
        category: 'real-estate',
        version: '1.0.0',
        author: 'Team',
        pricing: {
          free: {
            price: 0,
            features: ['basic'],
            limits: {},
          },
          tiers: [
            {
              name: 'Pro',
              price: 29,
              features: ['basic', 'unlimited', 'team'],
              limits: {},
            },
          ],
        },
        features: [],
        scaling: { minInstances: 1, maxInstances: 10, cpuThreshold: 70, memoryThreshold: 80 },
        status: 'active',
        integrations: [],
        route: '/apps/househack',
      };

      manager.registerApp(app);
    });

    it('should check feature access for free tier', () => {
      manager.installApp('househack-203k', 1, 'free');

      expect(manager.hasFeatureAccess(1, 'househack-203k', 'basic')).toBe(true);
      expect(manager.hasFeatureAccess(1, 'househack-203k', 'unlimited')).toBe(false);
      expect(manager.hasFeatureAccess(1, 'househack-203k', 'team')).toBe(false);
    });

    it('should check feature access for pro tier', () => {
      manager.installApp('househack-203k', 1, 'pro');

      expect(manager.hasFeatureAccess(1, 'househack-203k', 'basic')).toBe(true);
      expect(manager.hasFeatureAccess(1, 'househack-203k', 'unlimited')).toBe(true);
      expect(manager.hasFeatureAccess(1, 'househack-203k', 'team')).toBe(true);
    });
  });

  describe('Usage Limits - Per App', () => {
    beforeEach(() => {
      const app: AppMetadata = {
        id: 'househack-203k',
        name: 'HouseHack',
        description: 'Real estate',
        icon: '🏠',
        category: 'real-estate',
        version: '1.0.0',
        author: 'Team',
        pricing: {
          free: {
            price: 0,
            features: [],
            limits: { dealRooms: 1, teamMembers: 1 },
          },
          tiers: [
            {
              name: 'Pro',
              price: 29,
              features: [],
              limits: { dealRooms: 999, teamMembers: 50 },
            },
          ],
        },
        features: [],
        scaling: { minInstances: 1, maxInstances: 10, cpuThreshold: 70, memoryThreshold: 80 },
        status: 'active',
        integrations: [],
        route: '/apps/househack',
      };

      manager.registerApp(app);
    });

    it('should check usage limits for free tier', () => {
      manager.installApp('househack-203k', 1, 'free');

      // User has created 1 deal room, limit is 1
      expect(manager.checkUsageLimit(1, 'househack-203k', 'dealRooms', 1)).toBe(true);
      expect(manager.checkUsageLimit(1, 'househack-203k', 'dealRooms', 0)).toBe(false);
    });

    it('should check usage limits for pro tier', () => {
      manager.installApp('househack-203k', 1, 'pro');

      // User has created 100 deals, limit is 999
      expect(manager.checkUsageLimit(1, 'househack-203k', 'dealRooms', 100)).toBe(false);
      expect(manager.checkUsageLimit(1, 'househack-203k', 'dealRooms', 999)).toBe(true);
    });
  });

  describe('Scaling Rules', () => {
    it('should get scaling rules for app', () => {
      const app: AppMetadata = {
        id: 'househack-203k',
        name: 'HouseHack',
        description: 'Real estate',
        icon: '🏠',
        category: 'real-estate',
        version: '1.0.0',
        author: 'Team',
        pricing: {
          free: { price: 0, features: [], limits: {} },
          tiers: [],
        },
        features: [],
        scaling: {
          minInstances: 3,
          maxInstances: 50,
          cpuThreshold: 70,
          memoryThreshold: 80,
        },
        status: 'active',
        integrations: [],
        route: '/apps/househack',
      };

      manager.registerApp(app);
      const rules = manager.getScalingRules('househack-203k');

      expect(rules?.minInstances).toBe(3);
      expect(rules?.maxInstances).toBe(50);
    });
  });
});
