import { Router, Request, Response } from 'express';
import Stripe from 'stripe';
import { db } from './db';
import {
  averySubscriptions,
  averyProfiles,
  averyLicenses,
  averyPayments,
  averyTierFeatures,
} from '../drizzle/avery-schema';
import { eq, and } from 'drizzle-orm';
import { v4 as uuidv4 } from 'uuid';

interface AuthRequest extends Request {
  user?: { id: string; email: string };
}

const router = Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2023-10-16',
});

// Create Avery subscription
router.post('/subscriptions', async (req: AuthRequest, res: Response) => {
  try {
    const { tier, email, businessName, cardNumber, expiryDate, cvc } = req.body;
    const userId = req.user?.id;

    if (!userId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    if (!tier || !email || !businessName) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    // Validate tier
    if (!['free_trial', 'starter', 'professional', 'enterprise'].includes(tier)) {
      return res.status(400).json({ message: 'Invalid tier' });
    }

    // Create Stripe customer
    const customer = await stripe.customers.create({
      email,
      metadata: {
        businessName,
        tier,
      },
    });

    // Create Stripe subscription if not free trial
    let stripeSubscriptionId = null;
    let monthlyPrice = '0';

    if (tier !== 'free_trial') {
      const prices: Record<string, number> = {
        starter: 99,
        professional: 299,
        enterprise: 0,
      };

      monthlyPrice = String(prices[tier] || 0);

      // Create payment method (in production, use Stripe tokenization)
      const paymentMethod = await (stripe.paymentMethods.create as any)({
        type: 'card',
        card: {
          number: cardNumber || '4242424242424242',
          exp_month: parseInt(expiryDate?.split('/')[0] || '12'),
          exp_year: parseInt(expiryDate?.split('/')[1] || '25') + 2000,
          cvc: cvc || '123',
        },
      });

      // Attach payment method to customer
      await (stripe.paymentMethods.attach as any)(paymentMethod.id, {
        customer: customer.id,
      });

      // Set as default payment method
      await (stripe.customers.update as any)(customer.id, {
        invoice_settings: {
          default_payment_method: paymentMethod.id,
        },
      });

      // Create subscription using price_data
      const subscription = await (stripe.subscriptions.create as any)({
        customer: customer.id,
        items: [
          {
            price_data: {
              currency: 'usd',
              recurring: {
                interval: 'month',
              },
              unit_amount: prices[tier] * 100,
            },
          },
        ],
      });

      stripeSubscriptionId = subscription.id;
    }

    // Create subscription record
    const subscriptionId = uuidv4();
    const now = new Date();
    const billingCycleEnd = new Date(now);
    billingCycleEnd.setMonth(billingCycleEnd.getMonth() + 1);

    await db.insert(averySubscriptions).values({
      id: subscriptionId,
      userId,
      tier: tier as any,
      status: 'active',
      stripeSubscriptionId,
      stripeCustomerId: customer.id,
      monthlyPrice,
      billingCycleStart: now,
      billingCycleEnd,
      trialEndsAt: tier === 'free_trial' ? new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000) : null,
      createdAt: now,
      updatedAt: now,
    });

    // Create business profile
    const profileId = uuidv4();
    await db.insert(averyProfiles).values({
      id: profileId,
      subscriptionId,
      businessName,
      businessPhone: '',
      timezone: 'America/New_York',
      createdAt: now,
      updatedAt: now,
    });

    // Generate license key
    const licenseKey = `AVERY-${tier.toUpperCase()}-${uuidv4().substring(0, 8)}`;
    const licenseId = uuidv4();
    const expiresAt = new Date(billingCycleEnd);
    expiresAt.setFullYear(expiresAt.getFullYear() + 1);

    await db.insert(averyLicenses).values({
      id: licenseId,
      subscriptionId,
      licenseKey,
      phoneNumber: '',
      isActive: true,
      activatedAt: now,
      expiresAt,
      createdAt: now,
      updatedAt: now,
    });

    // Record payment if not free trial
    if (tier !== 'free_trial') {
      const paymentId = uuidv4();
      const prices: Record<string, number> = {
        starter: 99,
        professional: 299,
        enterprise: 0,
      };

      await db.insert(averyPayments).values({
        id: paymentId,
        subscriptionId,
        stripePaymentIntentId: `pi_${uuidv4().substring(0, 24)}`,
        amount: String(prices[tier]),
        currency: 'USD',
        status: 'succeeded',
        description: `Avery ${tier} subscription`,
        createdAt: now,
      });
    }

    res.json({
      subscriptionId,
      licenseKey,
      tier,
      status: 'active',
      message: 'Subscription created successfully',
    });
  } catch (error) {
    console.error('Subscription creation error:', error);
    res.status(500).json({
      message: error instanceof Error ? error.message : 'Failed to create subscription',
    });
  }
});

// Get subscription details
router.get('/subscriptions/:subscriptionId', async (req: AuthRequest, res: Response) => {
  try {
    const { subscriptionId } = req.params;
    const userId = req.user?.id;

    if (!userId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const subscription = await db.query.averySubscriptions.findFirst({
      where: and(eq(averySubscriptions.id, subscriptionId), eq(averySubscriptions.userId, userId)),
      with: {
        profile: true,
        licenses: true,
      },
    });

    if (!subscription) {
      return res.status(404).json({ message: 'Subscription not found' });
    }

    res.json(subscription);
  } catch (error) {
    console.error('Get subscription error:', error);
    res.status(500).json({
      message: error instanceof Error ? error.message : 'Failed to get subscription',
    });
  }
});

// Update subscription tier
router.put('/subscriptions/:subscriptionId/tier', async (req: AuthRequest, res: Response) => {
  try {
    const { subscriptionId } = req.params;
    const { newTier } = req.body;
    const userId = req.user?.id;

    if (!userId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const subscription = await db.query.averySubscriptions.findFirst({
      where: and(eq(averySubscriptions.id, subscriptionId), eq(averySubscriptions.userId, userId)),
    });

    if (!subscription) {
      return res.status(404).json({ message: 'Subscription not found' });
    }

    // Update in database
    await db
      .update(averySubscriptions)
      .set({
        tier: newTier as any,
        updatedAt: new Date(),
      })
      .where(eq(averySubscriptions.id, subscriptionId));

    // Update in Stripe if applicable
    if (subscription.stripeSubscriptionId) {
      // Implementation for updating Stripe subscription
      // This would involve updating the subscription items
    }

    res.json({ message: 'Tier updated successfully' });
  } catch (error) {
    console.error('Update tier error:', error);
    res.status(500).json({
      message: error instanceof Error ? error.message : 'Failed to update tier',
    });
  }
});

// Cancel subscription
router.post('/subscriptions/:subscriptionId/cancel', async (req: AuthRequest, res: Response) => {
  try {
    const { subscriptionId } = req.params;
    const userId = req.user?.id;

    if (!userId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const subscription = await db.query.averySubscriptions.findFirst({
      where: and(eq(averySubscriptions.id, subscriptionId), eq(averySubscriptions.userId, userId)),
    });

    if (!subscription) {
      return res.status(404).json({ message: 'Subscription not found' });
    }

    // Cancel in Stripe
    if (subscription.stripeSubscriptionId) {
      await (stripe.subscriptions.cancel as any)(subscription.stripeSubscriptionId);
    }

    // Update in database
    await db
      .update(averySubscriptions)
      .set({
        status: 'cancelled',
        cancelledAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(averySubscriptions.id, subscriptionId));

    res.json({ message: 'Subscription cancelled successfully' });
  } catch (error) {
    console.error('Cancel subscription error:', error);
    res.status(500).json({
      message: error instanceof Error ? error.message : 'Failed to cancel subscription',
    });
  }
});

// Get tier features
router.get('/tiers/:tier/features', async (req: AuthRequest, res: Response) => {
  try {
    const { tier } = req.params;

    const features = await db.query.averyTierFeatures.findMany({
      where: eq(averyTierFeatures.tier, tier as any),
    });

    res.json(features);
  } catch (error) {
    console.error('Get features error:', error);
    res.status(500).json({
      message: error instanceof Error ? error.message : 'Failed to get features',
    });
  }
});

export default router;
