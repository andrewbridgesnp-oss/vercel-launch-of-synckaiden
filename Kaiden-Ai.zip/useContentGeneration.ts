/**
 * Content Generation Hook
 * Provides AI-powered content generation capabilities
 */

import { useState, useCallback } from 'react';

export type ContentType = 'text' | 'image' | 'video' | 'audio' | 'code';

export interface GenerationRequest {
  prompt: string;
  contentType: ContentType;
  style?: string;
  tone?: string;
  length?: 'short' | 'medium' | 'long';
  format?: string;
}

export interface GeneratedContent {
  id: string;
  content: string;
  contentType: ContentType;
  prompt: string;
  createdAt: Date;
  metadata?: Record<string, any>;
}

export function useContentGeneration() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent[]>([]);

  /**
   * Generate content using AI
   */
  const generateContent = useCallback(async (request: GenerationRequest) => {
    setIsGenerating(true);
    setError(null);

    try {
      const response = await fetch('/api/content/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to generate content');
      }

      const data = await response.json();

      const content: GeneratedContent = {
        id: data.id,
        content: data.content,
        contentType: request.contentType,
        prompt: request.prompt,
        createdAt: new Date(),
        metadata: data.metadata,
      };

      setGeneratedContent((prev) => [content, ...prev]);
      return content;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsGenerating(false);
    }
  }, []);

  /**
   * Generate text content
   */
  const generateText = useCallback(
    async (
      prompt: string,
      options?: {
        tone?: string;
        length?: 'short' | 'medium' | 'long';
      }
    ) => {
      return generateContent({
        prompt,
        contentType: 'text',
        tone: options?.tone,
        length: options?.length,
      });
    },
    [generateContent]
  );

  /**
   * Generate image
   */
  const generateImage = useCallback(
    async (
      prompt: string,
      options?: {
        style?: string;
        format?: string;
      }
    ) => {
      return generateContent({
        prompt,
        contentType: 'image',
        style: options?.style,
        format: options?.format,
      });
    },
    [generateContent]
  );

  /**
   * Generate code
   */
  const generateCode = useCallback(
    async (
      prompt: string,
      options?: {
        format?: string;
      }
    ) => {
      return generateContent({
        prompt,
        contentType: 'code',
        format: options?.format,
      });
    },
    [generateContent]
  );

  /**
   * Clear generated content history
   */
  const clearHistory = useCallback(() => {
    setGeneratedContent([]);
  }, []);

  /**
   * Delete a generated content item
   */
  const deleteContent = useCallback((id: string) => {
    setGeneratedContent((prev) => prev.filter((c) => c.id !== id));
  }, []);

  return {
    isGenerating,
    error,
    generatedContent,
    generateContent,
    generateText,
    generateImage,
    generateCode,
    clearHistory,
    deleteContent,
  };
}
