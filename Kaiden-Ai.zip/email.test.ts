/**
 * Email Service Tests
 * Tests for SendGrid email notifications
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock fetch for SendGrid API
const mockFetch = vi.fn();
global.fetch = mockFetch;

describe('Email Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockFetch.mockReset();
  });

  describe('Email Template Generation', () => {
    it('should generate HTML email with Kaiden branding', () => {
      const generateEmailTemplate = (
        title: string,
        content: string,
        ctaText?: string,
        ctaUrl?: string
      ): string => {
        return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${title}</title>
</head>
<body style="background-color: #0a1628;">
  <h1>${title}</h1>
  <div>${content}</div>
  ${ctaText && ctaUrl ? `<a href="${ctaUrl}">${ctaText}</a>` : ''}
</body>
</html>
        `.trim();
      };

      const html = generateEmailTemplate(
        'Welcome to Kaiden',
        '<p>Thank you for joining!</p>',
        'Get Started',
        'https://synckaiden.com/dashboard'
      );

      expect(html).toContain('Welcome to Kaiden');
      expect(html).toContain('Thank you for joining!');
      expect(html).toContain('Get Started');
      expect(html).toContain('https://synckaiden.com/dashboard');
      expect(html).toContain('#0a1628'); // Kaiden brand color
    });

    it('should generate email without CTA button', () => {
      const generateEmailTemplate = (title: string, content: string) => {
        return `<h1>${title}</h1><div>${content}</div>`;
      };

      const html = generateEmailTemplate('Notification', 'Your payment was processed.');
      
      expect(html).toContain('Notification');
      expect(html).toContain('Your payment was processed.');
      expect(html).not.toContain('href=');
    });
  });

  describe('Purchase Confirmation Email', () => {
    it('should include product name, amount, and purchase code', () => {
      const emailData = {
        to: 'customer@example.com',
        productName: 'AI Side Hustle Starter Kit',
        amount: 1.00,
        purchaseCode: 'KAI-ABC123-XYZ789',
      };

      // Verify email content structure
      expect(emailData.productName).toBe('AI Side Hustle Starter Kit');
      expect(emailData.amount).toBe(1.00);
      expect(emailData.purchaseCode).toMatch(/^KAI-[A-Z0-9]+-[A-Z0-9]+$/);
    });

    it('should format currency correctly', () => {
      const formatCurrency = (amount: number) => `$${amount.toFixed(2)}`;
      
      expect(formatCurrency(1.00)).toBe('$1.00');
      expect(formatCurrency(9.99)).toBe('$9.99');
      expect(formatCurrency(29.99)).toBe('$29.99');
      expect(formatCurrency(0.50)).toBe('$0.50');
    });
  });

  describe('License Delivery Email', () => {
    it('should include license key in monospace format', () => {
      const licenseKey = 'LICENSE-KEY-ABCDE12345';
      const html = `<div style="font-family: monospace;">${licenseKey}</div>`;
      
      expect(html).toContain('font-family: monospace');
      expect(html).toContain(licenseKey);
    });

    it('should include download URL when provided', () => {
      const downloadUrl = 'https://synckaiden.com/download/product-123';
      const html = `<a href="${downloadUrl}">Download Now</a>`;
      
      expect(html).toContain(downloadUrl);
      expect(html).toContain('Download Now');
    });
  });

  describe('Tax Reminder Email', () => {
    it('should generate quarterly payment reminder', () => {
      const reminder = {
        type: 'quarterly' as const,
        quarter: 'Q2',
        dueDate: 'June 15, 2025',
        amount: 1250,
      };

      const content = `Your ${reminder.quarter} estimated tax payment of $${reminder.amount} is due on ${reminder.dueDate}.`;
      
      expect(content).toContain('Q2');
      expect(content).toContain('$1250');
      expect(content).toContain('June 15, 2025');
    });

    it('should generate deadline reminder', () => {
      const reminder = {
        type: 'deadline' as const,
        deadline: 'April 15, 2025',
        daysRemaining: 14,
      };

      const content = `Tax filing deadline is ${reminder.deadline}. You have ${reminder.daysRemaining} days remaining.`;
      
      expect(content).toContain('April 15, 2025');
      expect(content).toContain('14 days');
    });

    it('should generate missing document reminder', () => {
      const reminder = {
        type: 'document' as const,
        documentType: '1099-NEC',
        source: 'Freelance Client Inc',
      };

      const content = `We detected a missing ${reminder.documentType} from ${reminder.source}.`;
      
      expect(content).toContain('1099-NEC');
      expect(content).toContain('Freelance Client Inc');
    });
  });

  describe('Payment Failed Email', () => {
    it('should include product name and amount', () => {
      const failedPayment = {
        productName: 'Starter Plan',
        amount: 9.99,
        nextRetry: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      };

      const content = `Payment of $${failedPayment.amount.toFixed(2)} for ${failedPayment.productName} failed.`;
      
      expect(content).toContain('$9.99');
      expect(content).toContain('Starter Plan');
    });
  });

  describe('SendGrid API Integration', () => {
    it('should send email via SendGrid API', async () => {
      mockFetch.mockResolvedValueOnce({
        ok: true,
        headers: {
          get: () => 'msg-123',
        },
      });

      const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer test-api-key',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          personalizations: [{ to: [{ email: 'test@example.com' }] }],
          from: { email: 'noreply@synckaiden.com', name: 'Kaiden' },
          subject: 'Test Email',
          content: [{ type: 'text/html', value: '<p>Test</p>' }],
        }),
      });

      expect(mockFetch).toHaveBeenCalledWith(
        'https://api.sendgrid.com/v3/mail/send',
        expect.objectContaining({
          method: 'POST',
          headers: expect.objectContaining({
            'Content-Type': 'application/json',
          }),
        })
      );
      expect(response.ok).toBe(true);
    });

    it('should handle SendGrid API errors', async () => {
      mockFetch.mockResolvedValueOnce({
        ok: false,
        text: async () => 'Invalid API key',
      });

      const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        body: '{}',
      });

      expect(response.ok).toBe(false);
      const error = await response.text();
      expect(error).toBe('Invalid API key');
    });

    it('should log email when API key not configured', () => {
      const consoleSpy = vi.spyOn(console, 'log');
      
      // Simulate no API key scenario
      const apiKey = undefined;
      if (!apiKey) {
        console.log('[Email] SendGrid API key not configured, logging email instead');
        console.log('[Email] Would send to:', 'test@example.com');
      }

      expect(consoleSpy).toHaveBeenCalledWith(
        '[Email] SendGrid API key not configured, logging email instead'
      );
      consoleSpy.mockRestore();
    });
  });

  describe('Email Preferences', () => {
    it('should return default email preferences', () => {
      const defaultPreferences = {
        marketing: false,
        transactional: true,
        taxReminders: true,
        paymentAlerts: true,
      };

      expect(defaultPreferences.marketing).toBe(false);
      expect(defaultPreferences.transactional).toBe(true);
      expect(defaultPreferences.taxReminders).toBe(true);
      expect(defaultPreferences.paymentAlerts).toBe(true);
    });

    it('should allow updating email preferences', () => {
      let preferences = {
        marketing: false,
        transactional: true,
        taxReminders: true,
        paymentAlerts: true,
      };

      const updates = { marketing: true, taxReminders: false };
      preferences = { ...preferences, ...updates };

      expect(preferences.marketing).toBe(true);
      expect(preferences.taxReminders).toBe(false);
      expect(preferences.transactional).toBe(true); // Unchanged
    });
  });

  describe('Email Validation', () => {
    it('should validate email addresses', () => {
      const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

      expect(isValidEmail('test@example.com')).toBe(true);
      expect(isValidEmail('user.name@domain.co.uk')).toBe(true);
      expect(isValidEmail('invalid-email')).toBe(false);
      expect(isValidEmail('missing@domain')).toBe(false);
      expect(isValidEmail('@nodomain.com')).toBe(false);
    });
  });

  describe('Privacy Compliance', () => {
    it('should include unsubscribe link in footer', () => {
      const footer = `
        <a href="https://synckaiden.com/unsubscribe">Unsubscribe</a> | 
        <a href="https://synckaiden.com/privacy">Privacy Policy</a>
      `;

      expect(footer).toContain('unsubscribe');
      expect(footer).toContain('privacy');
    });

    it('should not include tracking pixels', () => {
      const html = '<p>Email content here</p>';
      
      // Verify no tracking pixels (1x1 images)
      expect(html).not.toMatch(/<img[^>]*1x1/);
      expect(html).not.toMatch(/beacon/);
      expect(html).not.toMatch(/analytics/);
    });
  });
});
