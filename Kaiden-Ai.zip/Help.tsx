import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { HelpCircle, MessageSquare, BookOpen, Mail, Phone, ChevronDown } from "lucide-react";

export default function Help() {
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);

  const faqs = [
    {
      id: 1,
      question: "How do I get started with Kaiden?",
      answer:
        "Sign up for an account, complete your profile, and start exploring the dashboard. You can create your first agent or video project within minutes.",
    },
    {
      id: 2,
      question: "What payment methods do you accept?",
      answer:
        "We accept all major credit cards (Visa, Mastercard, American Express), PayPal, and bank transfers for enterprise plans.",
    },
    {
      id: 3,
      question: "Can I cancel my subscription anytime?",
      answer:
        "Yes, you can cancel your subscription at any time from your account settings. Your access will continue until the end of your billing period.",
    },
    {
      id: 4,
      question: "How do I enable two-factor authentication?",
      answer:
        "Go to Settings > Security and click 'Enable 2FA'. Scan the QR code with your authenticator app and enter the verification code.",
    },
    {
      id: 5,
      question: "What is the maximum number of agents I can create?",
      answer:
        "On the Professional plan, you can create up to 10 autonomous agents. Enterprise plans have unlimited agents.",
    },
    {
      id: 6,
      question: "How do I export my data?",
      answer:
        "Visit Settings > Privacy and click 'Download My Data'. Your data will be prepared and sent to your email within 24 hours.",
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <HelpCircle className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold">Help & Support</h1>
          </div>
          <p className="text-muted-foreground">Get answers and support for your Kaiden account</p>
        </div>

        <Tabs defaultValue="faq" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="faq">FAQ</TabsTrigger>
            <TabsTrigger value="contact">Contact Us</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          {/* FAQ */}
          <TabsContent value="faq" className="mt-6 space-y-4">
            <div className="mb-6">
              <input
                type="text"
                placeholder="Search FAQ..."
                className="w-full p-3 rounded-lg border border-border/50 bg-background"
              />
            </div>

            {faqs.map((faq) => (
              <Card key={faq.id} className="cursor-pointer hover:border-primary/50 transition-colors">
                <CardHeader
                  onClick={() => setExpandedFAQ(expandedFAQ === faq.id ? null : faq.id)}
                  className="flex flex-row items-center justify-between space-y-0"
                >
                  <CardTitle className="text-lg">{faq.question}</CardTitle>
                  <ChevronDown
                    className={`w-5 h-5 transition-transform ${
                      expandedFAQ === faq.id ? "rotate-180" : ""
                    }`}
                  />
                </CardHeader>
                {expandedFAQ === faq.id && (
                  <CardContent>
                    <p className="text-muted-foreground">{faq.answer}</p>
                  </CardContent>
                )}
              </Card>
            ))}
          </TabsContent>

          {/* Contact Us */}
          <TabsContent value="contact" className="mt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Email Support */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <Mail className="w-5 h-5 text-primary" />
                    <CardTitle>Email Support</CardTitle>
                  </div>
                  <CardDescription>We respond within 24 hours</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-4">support@kaiden.ai</p>
                  <Button className="w-full">Send Email</Button>
                </CardContent>
              </Card>

              {/* Phone Support */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <Phone className="w-5 h-5 text-primary" />
                    <CardTitle>Phone Support</CardTitle>
                  </div>
                  <CardDescription>Available 9 AM - 5 PM EST</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-4">+1 (555) 123-4567</p>
                  <Button className="w-full">Schedule Call</Button>
                </CardContent>
              </Card>

              {/* Live Chat */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <MessageSquare className="w-5 h-5 text-primary" />
                    <CardTitle>Live Chat</CardTitle>
                  </div>
                  <CardDescription>Chat with our support team</CardDescription>
                </CardHeader>
                <CardContent>
                  <Badge className="mb-4">Online</Badge>
                  <Button className="w-full">Start Chat</Button>
                </CardContent>
              </Card>

              {/* Documentation */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <BookOpen className="w-5 h-5 text-primary" />
                    <CardTitle>Documentation</CardTitle>
                  </div>
                  <CardDescription>Read our guides and tutorials</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-4">Comprehensive documentation available</p>
                  <Button variant="outline" className="w-full">
                    View Docs
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Contact Form */}
            <Card>
              <CardHeader>
                <CardTitle>Send us a message</CardTitle>
                <CardDescription>Tell us how we can help</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Subject</label>
                  <input
                    type="text"
                    className="w-full mt-2 p-2 rounded-lg border border-border/50 bg-background"
                    placeholder="What is this about?"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Category</label>
                  <select className="w-full mt-2 p-2 rounded-lg border border-border/50 bg-background">
                    <option>General Question</option>
                    <option>Technical Issue</option>
                    <option>Billing</option>
                    <option>Feature Request</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium">Message</label>
                  <textarea
                    className="w-full mt-2 p-2 rounded-lg border border-border/50 bg-background h-32"
                    placeholder="Describe your issue or question..."
                  />
                </div>
                <Button className="btn-shine">Send Message</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Resources */}
          <TabsContent value="resources" className="mt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                {
                  title: "Getting Started Guide",
                  description: "Learn the basics of Kaiden in 10 minutes",
                  icon: "📖",
                },
                {
                  title: "Video Tutorials",
                  description: "Step-by-step video guides for all features",
                  icon: "🎥",
                },
                {
                  title: "API Documentation",
                  description: "Integrate Kaiden with your own applications",
                  icon: "⚙️",
                },
                {
                  title: "Best Practices",
                  description: "Tips and tricks for maximizing Kaiden",
                  icon: "💡",
                },
                {
                  title: "Community Forum",
                  description: "Connect with other Kaiden users",
                  icon: "👥",
                },
                {
                  title: "Status Page",
                  description: "Check Kaiden system status and updates",
                  icon: "📊",
                },
              ].map((resource, idx) => (
                <Card key={idx} className="cursor-pointer hover:border-primary/50 transition-colors">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{resource.title}</CardTitle>
                        <CardDescription>{resource.description}</CardDescription>
                      </div>
                      <span className="text-2xl">{resource.icon}</span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" size="sm">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
