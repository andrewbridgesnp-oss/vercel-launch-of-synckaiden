import React, { useState } from 'react';
import { ChevronRight, Star, Users, Clock, Zap, Phone, Calendar, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PricingTier {
  name: string;
  price: number | null;
  period: string;
  description: string;
  features: string[];
  callLimit: number;
  bookingLimit: number;
  cta: string;
  highlighted?: boolean;
}

interface Testimonial {
  name: string;
  title: string;
  company: string;
  quote: string;
  rating: number;
  image: string;
}

const AveryListing: React.FC = () => {
  const [selectedTier, setSelectedTier] = useState<string>('professional');

  const pricingTiers: PricingTier[] = [
    {
      name: 'Free Trial',
      price: 0,
      period: '14 days',
      description: 'Try Avery risk-free',
      features: [
        'Up to 50 calls',
        'Basic call handling',
        'Email support',
        'Standard greeting',
        'Call transcripts',
      ],
      callLimit: 50,
      bookingLimit: 10,
      cta: 'Start Free Trial',
    },
    {
      name: 'Starter',
      price: 99,
      period: '/month',
      description: 'Perfect for small businesses',
      features: [
        'Up to 500 calls/month',
        'Advanced call handling',
        'Priority email support',
        'Custom greeting',
        'Call transcripts & recordings',
        'Basic integrations',
        'Up to 100 bookings/month',
      ],
      callLimit: 500,
      bookingLimit: 100,
      cta: 'Get Started',
    },
    {
      name: 'Professional',
      price: 299,
      period: '/month',
      description: 'For growing teams',
      features: [
        'Up to 2,000 calls/month',
        'Advanced AI features',
        'Phone & email support',
        'Custom greeting & routing',
        'Full call analytics',
        'Multiple integrations',
        'Up to 500 bookings/month',
        'Team management',
        'Custom workflows',
      ],
      callLimit: 2000,
      bookingLimit: 500,
      cta: 'Get Started',
      highlighted: true,
    },
    {
      name: 'Enterprise',
      price: null,
      period: 'Custom',
      description: 'For large organizations',
      features: [
        'Unlimited calls',
        'Unlimited bookings',
        'Dedicated support',
        'Custom integrations',
        'Advanced analytics',
        'SLA guarantee',
        'Custom features',
        'On-premise option',
        'API access',
      ],
      callLimit: Infinity,
      bookingLimit: Infinity,
      cta: 'Contact Sales',
    },
  ];

  const testimonials: Testimonial[] = [
    {
      name: 'Sarah Johnson',
      title: 'Owner',
      company: 'Salon Sano',
      quote: 'Avery has transformed how we handle client calls. We never miss an appointment again, and our clients love the professional service.',
      rating: 5,
      image: '/reviews/person-1.jpg',
    },
    {
      name: 'Michael Chen',
      title: 'Manager',
      company: 'Tech Consulting Group',
      quote: 'The AI is incredibly smart. It understands complex booking requests and handles them perfectly. Our team productivity increased by 40%.',
      rating: 5,
      image: '/reviews/person-2.jpg',
    },
    {
      name: 'Jessica Martinez',
      title: 'Director',
      company: 'Healthcare Services',
      quote: 'HIPAA compliant, secure, and reliable. Avery handles hundreds of calls daily without any issues. Highly recommended.',
      rating: 5,
      image: '/reviews/person-3.jpg',
    },
  ];

  const features = [
    {
      icon: Phone,
      title: 'AI-Powered Answering',
      description: 'Avery answers calls 24/7 with natural, human-like conversations',
    },
    {
      icon: Calendar,
      title: 'Smart Booking',
      description: 'Automatically schedules appointments based on your availability',
    },
    {
      icon: Zap,
      title: 'Instant Notifications',
      description: 'Get real-time alerts for important calls and bookings',
    },
    {
      icon: CreditCard,
      title: 'Payment Links',
      description: 'Send secure payment links directly to clients',
    },
    {
      icon: Users,
      title: 'Team Management',
      description: 'Manage multiple team members and their schedules',
    },
    {
      icon: Clock,
      title: 'Analytics & Insights',
      description: 'Detailed reports on calls, bookings, and customer interactions',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-cyan-500/10 px-4 py-2 text-sm font-semibold text-cyan-400">
              <Zap className="h-4 w-4" />
              Your 24/7 AI Receptionist
            </div>
            <h1 className="mb-6 text-5xl font-bold tracking-tight text-white sm:text-6xl">
              Avery — Your 24/7 <span className="text-cyan-400">AI Receptionist</span>
            </h1>
            <p className="mb-8 text-xl text-slate-300">
              Avery answers calls, books appointments, sends follow-ups, and collects payments automatically — so your business never misses an opportunity.
            </p>
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
              <Button size="lg" className="bg-cyan-500 hover:bg-cyan-600 text-white">
                Get Started <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="border-slate-600 text-white hover:bg-slate-800">
                Watch Demo
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-3">
            <div className="rounded-lg bg-slate-800/50 p-6 text-center backdrop-blur">
              <div className="text-4xl font-bold text-cyan-400">10,000+</div>
              <div className="mt-2 text-slate-300">Calls Answered</div>
            </div>
            <div className="rounded-lg bg-slate-800/50 p-6 text-center backdrop-blur">
              <div className="text-4xl font-bold text-cyan-400">5,000+</div>
              <div className="mt-2 text-slate-300">Appointments Booked</div>
            </div>
            <div className="rounded-lg bg-slate-800/50 p-6 text-center backdrop-blur">
              <div className="text-4xl font-bold text-cyan-400">$2.5M+</div>
              <div className="mt-2 text-slate-300">Revenue Captured</div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <h2 className="mb-4 text-center text-4xl font-bold text-white">Everything Your Business Needs</h2>
          <p className="mb-12 text-center text-xl text-slate-400">
            Avery handles the busy work so you can focus on growing your business
          </p>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="rounded-lg bg-slate-800/50 p-6 backdrop-blur">
                  <Icon className="mb-4 h-8 w-8 text-cyan-400" />
                  <h3 className="mb-2 text-lg font-semibold text-white">{feature.title}</h3>
                  <p className="text-slate-400">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Pricing Section */}
      <div className="px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <h2 className="mb-4 text-center text-4xl font-bold text-white">Simple, Transparent Pricing</h2>
          <p className="mb-12 text-center text-xl text-slate-400">
            Choose the plan that fits your business
          </p>

          <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
            {pricingTiers.map((tier, index) => (
              <div
                key={index}
                className={`relative rounded-lg backdrop-blur transition-all ${
                  tier.highlighted
                    ? 'border-2 border-cyan-400 bg-slate-800/80 ring-2 ring-cyan-400/20'
                    : 'border border-slate-700 bg-slate-800/50'
                }`}
              >
                {tier.highlighted && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 transform">
                    <span className="rounded-full bg-cyan-500 px-4 py-1 text-sm font-semibold text-white">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="p-6">
                  <h3 className="text-xl font-bold text-white">{tier.name}</h3>
                  <p className="mt-2 text-sm text-slate-400">{tier.description}</p>

                  <div className="mt-6">
                    {tier.price !== null ? (
                      <>
                        <span className="text-4xl font-bold text-white">${tier.price}</span>
                        <span className="text-slate-400">{tier.period}</span>
                      </>
                    ) : (
                      <span className="text-2xl font-bold text-cyan-400">Custom Pricing</span>
                    )}
                  </div>

                  <Button
                    className={`mt-6 w-full ${
                      tier.highlighted
                        ? 'bg-cyan-500 hover:bg-cyan-600 text-white'
                        : 'bg-slate-700 hover:bg-slate-600 text-white'
                    }`}
                  >
                    {tier.cta}
                  </Button>

                  <div className="mt-6 space-y-3">
                    {tier.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-start gap-3">
                        <div className="mt-1 h-5 w-5 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                          <div className="h-2 w-2 rounded-full bg-cyan-400" />
                        </div>
                        <span className="text-sm text-slate-300">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <h2 className="mb-4 text-center text-4xl font-bold text-white">Loved by Businesses</h2>
          <p className="mb-12 text-center text-xl text-slate-400">
            See what our customers have to say
          </p>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="rounded-lg bg-slate-800/50 p-6 backdrop-blur">
                <div className="mb-4 flex gap-1">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="mb-6 text-slate-300">"{testimonial.quote}"</p>
                <div className="flex items-center gap-3">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-semibold text-white">{testimonial.name}</div>
                    <div className="text-sm text-slate-400">
                      {testimonial.title} at {testimonial.company}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl rounded-lg bg-gradient-to-r from-cyan-500/20 to-blue-500/20 p-12 text-center backdrop-blur">
          <h2 className="mb-4 text-3xl font-bold text-white">Ready to Transform Your Business?</h2>
          <p className="mb-8 text-lg text-slate-300">
            Start your free 14-day trial today. No credit card required.
          </p>
          <Button size="lg" className="bg-cyan-500 hover:bg-cyan-600 text-white">
            Start Free Trial <ChevronRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AveryListing;
