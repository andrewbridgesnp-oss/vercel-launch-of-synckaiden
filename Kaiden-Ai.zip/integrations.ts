import axios from 'axios';
import { ENV } from '../_core/env';

/**
 * External API Integrations
 * Stripe, Twilio, SendGrid, Slack, etc.
 */

/**
 * STRIPE INTEGRATION
 */
export const stripe = {
  async createPaymentIntent(amount: number, currency = 'usd', metadata?: Record<string, any>) {
    try {
      const response = await axios.post(
        'https://api.stripe.com/v1/payment_intents',
        {
          amount: Math.round(amount * 100),
          currency,
          metadata,
        },
        {
          auth: {
            username: process.env.STRIPE_SECRET_KEY || '',
            password: '',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Stripe error:', error);
      throw new Error('Failed to create payment intent');
    }
  },

  async retrievePaymentIntent(intentId: string) {
    try {
      const response = await axios.get(
        `https://api.stripe.com/v1/payment_intents/${intentId}`,
        {
          auth: {
            username: process.env.STRIPE_SECRET_KEY || '',
            password: '',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Stripe error:', error);
      throw new Error('Failed to retrieve payment intent');
    }
  },

  async createCustomer(email: string, name?: string) {
    try {
      const response = await axios.post(
        'https://api.stripe.com/v1/customers',
        {
          email,
          name,
        },
        {
          auth: {
            username: process.env.STRIPE_SECRET_KEY || '',
            password: '',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Stripe error:', error);
      throw new Error('Failed to create customer');
    }
  },

  async listCharges(limit = 10) {
    try {
      const response = await axios.get(
        `https://api.stripe.com/v1/charges?limit=${limit}`,
        {
          auth: {
            username: process.env.STRIPE_SECRET_KEY || '',
            password: '',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Stripe error:', error);
      throw new Error('Failed to list charges');
    }
  },
};

/**
 * TWILIO INTEGRATION
 */
export const twilio = {
  async sendSMS(to: string, message: string) {
    try {
      const response = await axios.post(
        `https://api.twilio.com/2010-04-01/Accounts/${process.env.TWILIO_ACCOUNT_SID}/Messages.json`,
        {
          From: process.env.TWILIO_PHONE_NUMBER,
          To: to,
          Body: message,
        },
        {
          auth: {
            username: process.env.TWILIO_ACCOUNT_SID || '',
            password: process.env.TWILIO_AUTH_TOKEN || '',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Twilio error:', error);
      throw new Error('Failed to send SMS');
    }
  },

  async sendWhatsApp(to: string, message: string) {
    try {
      const response = await axios.post(
        `https://api.twilio.com/2010-04-01/Accounts/${process.env.TWILIO_ACCOUNT_SID}/Messages.json`,
        {
          From: `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`,
          To: `whatsapp:${to}`,
          Body: message,
        },
        {
          auth: {
            username: process.env.TWILIO_ACCOUNT_SID || '',
            password: process.env.TWILIO_AUTH_TOKEN || '',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Twilio error:', error);
      throw new Error('Failed to send WhatsApp message');
    }
  },

  async makeCall(to: string, twiml: string) {
    try {
      const response = await axios.post(
        `https://api.twilio.com/2010-04-01/Accounts/${process.env.TWILIO_ACCOUNT_SID}/Calls.json`,
        {
          From: process.env.TWILIO_PHONE_NUMBER,
          To: to,
          Twiml: twiml,
        },
        {
          auth: {
            username: process.env.TWILIO_ACCOUNT_SID || '',
            password: process.env.TWILIO_AUTH_TOKEN || '',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Twilio error:', error);
      throw new Error('Failed to make call');
    }
  },
};

/**
 * SENDGRID INTEGRATION
 */
export const sendgrid = {
  async sendEmail(to: string, subject: string, htmlContent: string, from = 'noreply@synckaiden.com') {
    try {
      const response = await axios.post(
        'https://api.sendgrid.com/v3/mail/send',
        {
          personalizations: [{ to: [{ email: to }] }],
          from: { email: from },
          subject,
          content: [{ type: 'text/html', value: htmlContent }],
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.SENDGRID_API_KEY}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('SendGrid error:', error);
      throw new Error('Failed to send email');
    }
  },

  async sendBulkEmail(recipients: Array<{ email: string; name: string }>, subject: string, htmlContent: string) {
    try {
      const personalizations = recipients.map((r) => ({
        to: [{ email: r.email, name: r.name }],
      }));

      const response = await axios.post(
        'https://api.sendgrid.com/v3/mail/send',
        {
          personalizations,
          from: { email: 'noreply@synckaiden.com' },
          subject,
          content: [{ type: 'text/html', value: htmlContent }],
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.SENDGRID_API_KEY}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('SendGrid error:', error);
      throw new Error('Failed to send bulk email');
    }
  },
};

/**
 * SLACK INTEGRATION
 */
export const slack = {
  async sendMessage(channel: string, text: string, blocks?: any[]) {
    try {
      const response = await axios.post(
        'https://slack.com/api/chat.postMessage',
        {
          channel,
          text,
          blocks,
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.SLACK_BOT_TOKEN}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Slack error:', error);
      throw new Error('Failed to send Slack message');
    }
  },

  async uploadFile(channel: string, file: Buffer, filename: string) {
    try {
      const formData = new FormData();
      formData.append('channels', channel);
      formData.append('file', new Blob([file]), filename);

      const response = await axios.post(
        'https://slack.com/api/files.upload',
        formData,
        {
          headers: {
            Authorization: `Bearer ${process.env.SLACK_BOT_TOKEN}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Slack error:', error);
      throw new Error('Failed to upload file to Slack');
    }
  },
};

/**
 * GITHUB INTEGRATION
 */
export const github = {
  async createIssue(owner: string, repo: string, title: string, body: string) {
    try {
      const response = await axios.post(
        `https://api.github.com/repos/${owner}/${repo}/issues`,
        {
          title,
          body,
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('GitHub error:', error);
      throw new Error('Failed to create GitHub issue');
    }
  },

  async getRepository(owner: string, repo: string) {
    try {
      const response = await axios.get(
        `https://api.github.com/repos/${owner}/${repo}`,
        {
          headers: {
            Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('GitHub error:', error);
      throw new Error('Failed to get repository');
    }
  },
};

/**
 * GOOGLE SHEETS INTEGRATION
 */
export const googleSheets = {
  async appendRow(spreadsheetId: string, range: string, values: any[]) {
    try {
      const response = await axios.post(
        `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}:append?valueInputOption=USER_ENTERED`,
        {
          values: [values],
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.GOOGLE_SHEETS_TOKEN}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Google Sheets error:', error);
      throw new Error('Failed to append row to Google Sheets');
    }
  },

  async readRange(spreadsheetId: string, range: string) {
    try {
      const response = await axios.get(
        `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}`,
        {
          headers: {
            Authorization: `Bearer ${process.env.GOOGLE_SHEETS_TOKEN}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Google Sheets error:', error);
      throw new Error('Failed to read from Google Sheets');
    }
  },
};

/**
 * ZAPIER INTEGRATION
 */
export const zapier = {
  async triggerZap(webhookUrl: string, data: Record<string, any>) {
    try {
      const response = await axios.post(webhookUrl, data);
      return response.data;
    } catch (error) {
      console.error('Zapier error:', error);
      throw new Error('Failed to trigger Zapier webhook');
    }
  },
};

/**
 * HUBSPOT INTEGRATION
 */
export const hubspot = {
  async createContact(email: string, firstName: string, lastName: string) {
    try {
      const response = await axios.post(
        'https://api.hubapi.com/crm/v3/objects/contacts',
        {
          properties: {
            email,
            firstname: firstName,
            lastname: lastName,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.HUBSPOT_API_KEY}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('HubSpot error:', error);
      throw new Error('Failed to create HubSpot contact');
    }
  },

  async createDeal(dealName: string, amount: number) {
    try {
      const response = await axios.post(
        'https://api.hubapi.com/crm/v3/objects/deals',
        {
          properties: {
            dealname: dealName,
            amount: amount,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.HUBSPOT_API_KEY}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('HubSpot error:', error);
      throw new Error('Failed to create HubSpot deal');
    }
  },
};

/**
 * OPENAI INTEGRATION (Already available via invokeLLM)
 */
export const openai = {
  async generateText(prompt: string, maxTokens = 500) {
    try {
      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-4',
          messages: [{ role: 'user', content: prompt }],
          max_tokens: maxTokens,
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('OpenAI error:', error);
      throw new Error('Failed to generate text with OpenAI');
    }
  },
};

/**
 * AIRTABLE INTEGRATION
 */
export const airtable = {
  async createRecord(baseId: string, tableId: string, fields: Record<string, any>) {
    try {
      const response = await axios.post(
        `https://api.airtable.com/v0/${baseId}/${tableId}`,
        {
          records: [{ fields }],
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.AIRTABLE_API_KEY}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Airtable error:', error);
      throw new Error('Failed to create Airtable record');
    }
  },

  async listRecords(baseId: string, tableId: string) {
    try {
      const response = await axios.get(
        `https://api.airtable.com/v0/${baseId}/${tableId}`,
        {
          headers: {
            Authorization: `Bearer ${process.env.AIRTABLE_API_KEY}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Airtable error:', error);
      throw new Error('Failed to list Airtable records');
    }
  },
};

/**
 * NOTION INTEGRATION
 */
export const notion = {
  async createPage(databaseId: string, properties: Record<string, any>) {
    try {
      const response = await axios.post(
        'https://api.notion.com/v1/pages',
        {
          parent: { database_id: databaseId },
          properties,
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.NOTION_API_KEY}`,
            'Notion-Version': '2022-06-28',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Notion error:', error);
      throw new Error('Failed to create Notion page');
    }
  },

  async queryDatabase(databaseId: string, filter?: any) {
    try {
      const response = await axios.post(
        `https://api.notion.com/v1/databases/${databaseId}/query`,
        filter ? { filter } : {},
        {
          headers: {
            Authorization: `Bearer ${process.env.NOTION_API_KEY}`,
            'Notion-Version': '2022-06-28',
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error('Notion error:', error);
      throw new Error('Failed to query Notion database');
    }
  },
};

export default {
  stripe,
  twilio,
  sendgrid,
  slack,
  github,
  googleSheets,
  zapier,
  hubspot,
  openai,
  airtable,
  notion,
};
