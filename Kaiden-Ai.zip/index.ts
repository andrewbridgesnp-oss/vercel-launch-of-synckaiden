/**
 * Shared Type Definitions for Synckaiden Ecosystem
 * Single source of truth for all types across frontend and backend
 */

export type CapabilityStatus = 'LIVE' | 'BETA' | 'COMING_SOON';
export type CapabilityPriority = 'HIGH' | 'MEDIUM' | 'LOW';
export type CapabilityComplexity = 'SIMPLE' | 'MEDIUM' | 'COMPLEX';
export type ComponentType = 'FORM' | 'DASHBOARD' | 'WIZARD' | 'CHART' | 'TABLE' | 'CARD' | 'MODAL' | 'LIST';

/**
 * Core Capability Definition
 * Represents a single feature or function in the system
 */
export interface Capability {
  id: string;
  name: string;
  description: string;
  module: string;
  subsection: string;
  status: CapabilityStatus;
  priority: CapabilityPriority;
  complexity: CapabilityComplexity;
  componentType?: ComponentType;
  icon?: string;
  tags?: string[];
  dependencies?: string[]; // IDs of other capabilities this depends on
  apiEndpoint?: string;
  requiredPermissions?: string[];
  estimatedLoadTime?: number; // ms
  metadata?: Record<string, unknown>;
}

/**
 * Module Definition
 * Groups related capabilities together
 */
export interface Module {
  id: string;
  name: string;
  description: string;
  icon?: string;
  capabilities: Capability[];
  order: number;
  isExpanded?: boolean;
  color?: string;
}

/**
 * Capability Registry
 * Complete collection of all capabilities
 */
export interface CapabilityRegistry {
  version: string;
  lastUpdated: string;
  totalCapabilities: number;
  capabilities: Capability[];
  modules?: Module[];
}

/**
 * Component Template Configuration
 * Defines how a capability should be rendered
 */
export interface ComponentTemplate {
  id: string;
  name: string;
  type: ComponentType;
  component: React.ComponentType<any>;
  defaultProps?: Record<string, unknown>;
  schema?: Record<string, unknown>; // JSON Schema for validation
  slots?: string[]; // Named slots for composition
}

/**
 * Capability State
 * Runtime state for a capability instance
 */
export interface CapabilityState {
  id: string;
  capabilityId: string;
  isLoading: boolean;
  isError: boolean;
  error?: Error;
  data?: unknown;
  lastUpdated?: Date;
  userPermissions?: string[];
}

/**
 * User Context
 * Information about current user
 */
export interface UserContext {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user' | 'guest';
  permissions: string[];
  subscriptionTier: 'free' | 'basic' | 'pro' | 'enterprise';
  preferences?: {
    theme?: 'light' | 'dark';
    language?: string;
    notifications?: boolean;
  };
}

/**
 * API Response Wrapper
 * Standard response format for all API calls
 */
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
  timestamp: string;
  requestId: string;
}

/**
 * Navigation Item
 * For dynamic navigation generation
 */
export interface NavigationItem {
  id: string;
  label: string;
  path: string;
  icon?: string;
  children?: NavigationItem[];
  badge?: string | number;
  isActive?: boolean;
  isVisible?: boolean;
}

/**
 * Feature Flag
 * For gradual rollout and A/B testing
 */
export interface FeatureFlag {
  id: string;
  name: string;
  enabled: boolean;
  rolloutPercentage?: number;
  targetUsers?: string[];
  metadata?: Record<string, unknown>;
}

/**
 * Audit Log Entry
 * For tracking user actions
 */
export interface AuditLogEntry {
  id: string;
  userId: string;
  action: string;
  resource: string;
  resourceId: string;
  changes?: Record<string, [unknown, unknown]>;
  timestamp: Date;
  ipAddress?: string;
  userAgent?: string;
}

/**
 * Notification
 * For in-app and push notifications
 */
export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  actionUrl?: string;
  timestamp: Date;
  expiresAt?: Date;
}

/**
 * Pagination
 * Standard pagination parameters
 */
export interface PaginationParams {
  page: number;
  pageSize: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

/**
 * Paginated Response
 */
export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}
