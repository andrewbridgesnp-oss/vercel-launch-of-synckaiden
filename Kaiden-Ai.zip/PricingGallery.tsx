/**
 * Pricing Gallery Component
 * Displays products and subscription tiers with pricing comparison
 */

import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, X, ArrowRight } from 'lucide-react';
import { useState } from 'react';

export interface PricingTier {
  id: string;
  name: string;
  description: string;
  price: number;
  billingPeriod: 'monthly' | 'yearly' | 'one-time';
  features: string[];
  limitations: string[];
  isPopular?: boolean;
  ctaText: string;
  ctaAction: () => void;
}

export interface PricingGalleryProps {
  title?: string;
  subtitle?: string;
  tiers: PricingTier[];
  showComparison?: boolean;
}

export function PricingGallery({
  title = 'Simple, Transparent Pricing',
  subtitle = 'Choose the perfect plan for your needs',
  tiers,
  showComparison = true,
}: PricingGalleryProps) {
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'yearly'>('monthly');

  const filteredTiers = tiers.filter(
    (tier) => tier.billingPeriod === billingPeriod || tier.billingPeriod === 'one-time'
  );

  return (
    <div className="w-full py-12 md:py-24">
      {/* Header */}
      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-bold mb-4">{title}</h2>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">{subtitle}</p>

        {/* Billing Toggle */}
        {showComparison && (
          <div className="flex justify-center gap-4 mt-8">
            <button
              onClick={() => setBillingPeriod('monthly')}
              className={`px-6 py-2 rounded-lg font-semibold transition-colors ${
                billingPeriod === 'monthly'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingPeriod('yearly')}
              className={`px-6 py-2 rounded-lg font-semibold transition-colors ${
                billingPeriod === 'yearly'
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              }`}
            >
              Yearly
              <Badge className="ml-2 bg-accent text-accent-foreground">Save 20%</Badge>
            </button>
          </div>
        )}
      </div>

      {/* Pricing Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto px-4">
        {filteredTiers.map((tier) => (
          <div
            key={tier.id}
            className={`relative rounded-2xl border transition-all duration-300 ${
              tier.isPopular
                ? 'border-primary bg-primary/5 scale-105 shadow-2xl'
                : 'border-border bg-card hover:border-primary/50 hover:shadow-lg'
            }`}
          >
            {/* Popular Badge */}
            {tier.isPopular && (
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-primary text-primary-foreground px-4 py-1">
                  Most Popular
                </Badge>
              </div>
            )}

            <div className="p-8">
              {/* Tier Name */}
              <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
              <p className="text-muted-foreground mb-6">{tier.description}</p>

              {/* Price */}
              <div className="mb-8">
                <div className="flex items-baseline gap-1">
                  <span className="text-5xl font-bold">${tier.price}</span>
                  <span className="text-muted-foreground">
                    /{tier.billingPeriod === 'one-time' ? 'one-time' : 'month'}
                  </span>
                </div>
              </div>

              {/* CTA Button */}
              <Button
                onClick={tier.ctaAction}
                className={`w-full mb-8 ${
                  tier.isPopular
                    ? 'bg-primary hover:bg-primary/90'
                    : 'bg-secondary hover:bg-secondary/80'
                }`}
              >
                {tier.ctaText}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>

              {/* Features */}
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-3 text-sm">Included Features:</h4>
                  <ul className="space-y-2">
                    {tier.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Limitations */}
                {tier.limitations.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-3 text-sm text-muted-foreground">
                      Not Included:
                    </h4>
                    <ul className="space-y-2">
                      {tier.limitations.map((limitation, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <X className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-muted-foreground">{limitation}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Comparison Table */}
      {showComparison && (
        <div className="mt-16 max-w-7xl mx-auto px-4">
          <h3 className="text-2xl font-bold mb-8 text-center">Feature Comparison</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-4 px-4 font-semibold">Feature</th>
                  {filteredTiers.map((tier) => (
                    <th key={tier.id} className="text-center py-4 px-4 font-semibold">
                      {tier.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Combine all unique features */}
                {Array.from(
                  new Set([
                    ...filteredTiers.flatMap((t) => t.features),
                    ...filteredTiers.flatMap((t) => t.limitations),
                  ])
                ).map((feature, idx) => (
                  <tr key={idx} className="border-b border-border/50">
                    <td className="py-4 px-4 text-sm">{feature}</td>
                    {filteredTiers.map((tier) => (
                      <td key={tier.id} className="text-center py-4 px-4">
                        {tier.features.includes(feature) ? (
                          <Check className="h-5 w-5 text-green-500 mx-auto" />
                        ) : (
                          <X className="h-5 w-5 text-muted-foreground mx-auto" />
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
