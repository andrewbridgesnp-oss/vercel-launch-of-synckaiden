import React, { lazy, Suspense } from 'react';
import type { Capability, ComponentType } from '@/types';
import { Card } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';

/**
 * Capability Factory
 * Dynamically selects and renders the appropriate component for each capability
 * based on its type and complexity
 */

// Import component templates
import DashboardAnalyticsTemplate from '@/components/templates/DashboardAnalyticsTemplate';
import DataTableTemplate from '@/components/templates/DataTableTemplate';
import CardGridTemplate from '@/components/templates/CardGridTemplate';
import ModalDialogTemplate from '@/components/templates/ModalDialogTemplate';
import ListViewTemplate from '@/components/templates/ListViewTemplate';
import SettingsPanelTemplate from '@/components/templates/SettingsPanelTemplate';
import SearchFilterTemplate from '@/components/templates/SearchFilterTemplate';
import TimelineTemplate from '@/components/templates/TimelineTemplate';
import ChatMessagingTemplate from '@/components/templates/ChatMessagingTemplate';
import NotificationCenterTemplate from '@/components/templates/NotificationCenterTemplate';
import FileUploadTemplate from '@/components/templates/FileUploadTemplate';
import FormWizardTemplate from '@/components/templates/FormWizardTemplate';

/**
 * Component type to template mapping
 */
const COMPONENT_TEMPLATES: Record<ComponentType, React.ComponentType<any>> = {
  DASHBOARD: DashboardAnalyticsTemplate,
  TABLE: DataTableTemplate,
  CARD: CardGridTemplate,
  MODAL: ModalDialogTemplate,
  LIST: ListViewTemplate,
  FORM: FormWizardTemplate,
  CHART: DashboardAnalyticsTemplate, // Reuse dashboard for charts
  WIZARD: FormWizardTemplate,
};

/**
 * Default component template based on complexity
 */
const DEFAULT_TEMPLATES: Record<string, React.ComponentType<any>> = {
  SIMPLE: CardGridTemplate,
  MEDIUM: ListViewTemplate,
  COMPLEX: DashboardAnalyticsTemplate,
};

/**
 * Props for capability renderer
 */
export interface CapabilityRendererProps {
  capability: Capability;
  onExecute?: (params?: Record<string, unknown>) => Promise<any>;
  onClose?: () => void;
  isLoading?: boolean;
  error?: Error | null;
  data?: unknown;
}

/**
 * Loading fallback component
 */
const LoadingFallback = () => (
  <Card className="flex items-center justify-center p-12">
    <div className="flex flex-col items-center gap-4">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
      <p className="text-sm text-muted-foreground">Loading capability...</p>
    </div>
  </Card>
);

/**
 * Error fallback component
 */
const ErrorFallback = ({ error }: { error: Error | null }) => (
  <Card className="border-red-200 bg-red-50 p-6">
    <h3 className="font-semibold text-red-900">Error Loading Capability</h3>
    <p className="mt-2 text-sm text-red-700">{error?.message || 'An unknown error occurred'}</p>
  </Card>
);

/**
 * Main capability renderer component
 * Intelligently selects and renders the appropriate template
 */
export function CapabilityRenderer({
  capability,
  onExecute,
  onClose,
  isLoading = false,
  error = null,
  data = null,
}: CapabilityRendererProps) {
  // Select template based on componentType or complexity
  let Template: React.ComponentType<any> | null = null;

  if (capability.componentType && COMPONENT_TEMPLATES[capability.componentType]) {
    Template = COMPONENT_TEMPLATES[capability.componentType];
  } else if (capability.complexity && DEFAULT_TEMPLATES[capability.complexity]) {
    Template = DEFAULT_TEMPLATES[capability.complexity];
  } else {
    // Fallback to card grid
    Template = CardGridTemplate;
  }

  if (!Template) {
    return <ErrorFallback error={new Error('No template found for this capability')} />;
  }

  return (
    <Suspense fallback={<LoadingFallback />}>
      {error ? (
        <ErrorFallback error={error} />
      ) : (
        <Template
          capability={capability}
          onExecute={onExecute}
          onClose={onClose}
          isLoading={isLoading}
          data={data}
        />
      )}
    </Suspense>
  );
}

/**
 * Capability card component for browsing
 * Lightweight component for displaying capability in a list/grid
 */
export function CapabilityCard({
  capability,
  onClick,
  isSelected = false,
}: {
  capability: Capability;
  onClick?: () => void;
  isSelected?: boolean;
}) {
  const statusColors = {
    LIVE: 'bg-green-100 text-green-800',
    BETA: 'bg-yellow-100 text-yellow-800',
    COMING_SOON: 'bg-gray-100 text-gray-800',
  };

  const priorityColors = {
    HIGH: 'text-red-600',
    MEDIUM: 'text-yellow-600',
    LOW: 'text-blue-600',
  };

  return (
    <Card
      className={`cursor-pointer p-4 transition-all hover:shadow-lg ${
        isSelected ? 'ring-2 ring-primary' : ''
      }`}
      onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <h3 className="font-semibold text-sm">{capability.name}</h3>
          <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
            {capability.description}
          </p>
        </div>
        <span className={`ml-2 inline-block rounded-full px-2 py-1 text-xs font-medium ${statusColors[capability.status]}`}>
          {capability.status}
        </span>
      </div>

      <div className="mt-3 flex items-center justify-between">
        <span className="text-xs text-muted-foreground">{capability.module}</span>
        <span className={`text-xs font-semibold ${priorityColors[capability.priority]}`}>
          {capability.priority}
        </span>
      </div>
    </Card>
  );
}

/**
 * Batch capability renderer
 * Renders multiple capabilities in a grid
 */
export function CapabilityGrid({
  capabilities,
  onSelect,
  selectedId,
}: {
  capabilities: Capability[];
  onSelect?: (capability: Capability) => void;
  selectedId?: string;
}) {
  return (
    <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
      {capabilities.map((capability) => (
        <CapabilityCard
          key={capability.id}
          capability={capability}
          onClick={() => onSelect?.(capability)}
          isSelected={capability.id === selectedId}
        />
      ))}
    </div>
  );
}

/**
 * Get component type recommendation based on capability
 */
export function recommendComponentType(capability: Capability): ComponentType {
  // Rule-based recommendations
  if (capability.name.toLowerCase().includes('chart') || capability.name.toLowerCase().includes('analytics')) {
    return 'DASHBOARD';
  }
  if (capability.name.toLowerCase().includes('table') || capability.name.toLowerCase().includes('list')) {
    return 'TABLE';
  }
  if (capability.name.toLowerCase().includes('form') || capability.name.toLowerCase().includes('wizard')) {
    return 'FORM';
  }
  if (capability.name.toLowerCase().includes('chat') || capability.name.toLowerCase().includes('message')) {
    return 'MODAL';
  }
  if (capability.name.toLowerCase().includes('settings') || capability.name.toLowerCase().includes('config')) {
    return 'CARD';
  }

  // Default based on complexity
  switch (capability.complexity) {
    case 'SIMPLE':
      return 'CARD';
    case 'MEDIUM':
      return 'LIST';
    case 'COMPLEX':
      return 'DASHBOARD';
    default:
      return 'CARD';
  }
}

/**
 * Capability preview component
 * Shows a quick preview of a capability without full rendering
 */
export function CapabilityPreview({ capability }: { capability: Capability }) {
  return (
    <div className="space-y-2">
      <div>
        <h4 className="font-semibold text-sm">{capability.name}</h4>
        <p className="text-xs text-muted-foreground">{capability.description}</p>
      </div>
      <div className="flex gap-2 flex-wrap">
        <span className="inline-block rounded-full bg-primary/10 px-2 py-1 text-xs">
          {capability.module}
        </span>
        <span className="inline-block rounded-full bg-secondary/10 px-2 py-1 text-xs">
          {capability.status}
        </span>
        <span className="inline-block rounded-full bg-accent/10 px-2 py-1 text-xs">
          {capability.complexity}
        </span>
      </div>
    </div>
  );
}
