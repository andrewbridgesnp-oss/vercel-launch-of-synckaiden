import { useMemo, useState } from 'react';
import { useCapabilities, useCapabilitySearch, useModules } from '@/hooks/useCapability';
import { CapabilityGrid } from '@/lib/capabilityFactory';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, Filter } from 'lucide-react';

/**
 * Capabilities Hub Page
 * Main page for browsing and searching all capabilities
 */
export default function CapabilitiesHub() {
  const { filtered, filteredCount, count } = useCapabilities();
  const { searchQuery, setSearchQuery, filterStatus, setFilterStatus, filterPriority, setFilterPriority, clearFilters } =
    useCapabilitySearch();
  const { modules } = useModules();
  const [selectedModule, setSelectedModule] = useState<string | null>(null);

  // Filter by selected module
  const displayCapabilities = useMemo(() => {
    if (!selectedModule) return filtered;
    return filtered.filter((c) => c.module === selectedModule);
  }, [filtered, selectedModule]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/20">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container py-8">
          <h1 className="text-4xl font-bold">Capabilities Hub</h1>
          <p className="mt-2 text-lg text-muted-foreground">
            Explore {count} powerful features to transform your business
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="container py-8">
        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search capabilities..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4">
            {/* Module Filter */}
            <Select value={selectedModule || ''} onValueChange={(v) => setSelectedModule(v || null)}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Modules" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Modules</SelectItem>
                {modules.map((module) => (
                  <SelectItem key={module.id} value={module.name}>
                    {module.name} ({module.capabilities.length})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Status Filter */}
            <Select value={filterStatus} onValueChange={(v: any) => setFilterStatus(v)}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Status</SelectItem>
                <SelectItem value="LIVE">Live</SelectItem>
                <SelectItem value="BETA">Beta</SelectItem>
                <SelectItem value="COMING_SOON">Coming Soon</SelectItem>
              </SelectContent>
            </Select>

            {/* Priority Filter */}
            <Select value={filterPriority} onValueChange={(v: any) => setFilterPriority(v)}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Priority</SelectItem>
                <SelectItem value="HIGH">High</SelectItem>
                <SelectItem value="MEDIUM">Medium</SelectItem>
                <SelectItem value="LOW">Low</SelectItem>
              </SelectContent>
            </Select>

            {/* Clear Filters */}
            {(searchQuery || filterStatus !== 'ALL' || filterPriority !== 'ALL' || selectedModule) && (
              <Button variant="outline" onClick={clearFilters}>
                Clear Filters
              </Button>
            )}
          </div>

          {/* Results Info */}
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              Showing <Badge variant="secondary">{displayCapabilities.length}</Badge> of{' '}
              <Badge variant="secondary">{count}</Badge> capabilities
            </div>
          </div>
        </div>

        {/* Capabilities Grid */}
        {displayCapabilities.length > 0 ? (
          <CapabilityGrid capabilities={displayCapabilities} />
        ) : (
          <div className="rounded-lg border border-dashed p-12 text-center">
            <Filter className="mx-auto h-12 w-12 text-muted-foreground/50" />
            <h3 className="mt-4 text-lg font-semibold">No capabilities found</h3>
            <p className="mt-2 text-muted-foreground">Try adjusting your search or filters</p>
            <Button variant="outline" onClick={clearFilters} className="mt-4">
              Clear Filters
            </Button>
          </div>
        )}

        {/* Stats Section */}
        <div className="mt-16 grid gap-4 grid-cols-2 sm:grid-cols-4">
          <div className="rounded-lg border bg-card p-6">
            <div className="text-sm font-medium text-muted-foreground">Total Capabilities</div>
            <div className="mt-2 text-3xl font-bold">{count}</div>
          </div>
          <div className="rounded-lg border bg-card p-6">
            <div className="text-sm font-medium text-muted-foreground">Live</div>
            <div className="mt-2 text-3xl font-bold text-green-600">
              {filtered.filter((c) => c.status === 'LIVE').length}
            </div>
          </div>
          <div className="rounded-lg border bg-card p-6">
            <div className="text-sm font-medium text-muted-foreground">Beta</div>
            <div className="mt-2 text-3xl font-bold text-yellow-600">
              {filtered.filter((c) => c.status === 'BETA').length}
            </div>
          </div>
          <div className="rounded-lg border bg-card p-6">
            <div className="text-sm font-medium text-muted-foreground">Modules</div>
            <div className="mt-2 text-3xl font-bold">{modules.length}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
