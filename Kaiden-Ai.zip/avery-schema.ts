import { pgTable, text, integer, boolean, timestamp, decimal, varchar, jsonb, enum as pgEnum } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';
import { users } from './schema';

// Avery Pricing Tiers
export const averyTiers = pgEnum('avery_tier', ['free_trial', 'starter', 'professional', 'enterprise']);
export const averyStatus = pgEnum('avery_status', ['active', 'paused', 'cancelled', 'suspended']);
export const callOutcome = pgEnum('call_outcome', ['booked', 'missed', 'transferred', 'voicemail', 'callback', 'no_answer']);

// Avery Subscription Table
export const averySubscriptions = pgTable('avery_subscriptions', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  tier: averyTiers('tier').notNull().default('free_trial'),
  status: averyStatus('status').notNull().default('active'),
  stripeSubscriptionId: text('stripe_subscription_id'),
  stripeCustomerId: text('stripe_customer_id'),
  monthlyPrice: decimal('monthly_price', { precision: 10, scale: 2 }).notNull(),
  billingCycleStart: timestamp('billing_cycle_start').notNull(),
  billingCycleEnd: timestamp('billing_cycle_end').notNull(),
  trialEndsAt: timestamp('trial_ends_at'),
  cancelledAt: timestamp('cancelled_at'),
  pausedAt: timestamp('paused_at'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

// Avery License Table
export const averyLicenses = pgTable('avery_licenses', {
  id: text('id').primaryKey(),
  subscriptionId: text('subscription_id').notNull().references(() => averySubscriptions.id, { onDelete: 'cascade' }),
  licenseKey: text('license_key').notNull().unique(),
  phoneNumber: varchar('phone_number', { length: 20 }).notNull(),
  isActive: boolean('is_active').notNull().default(true),
  activatedAt: timestamp('activated_at'),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

// Avery Business Profile Table
export const averyProfiles = pgTable('avery_profiles', {
  id: text('id').primaryKey(),
  subscriptionId: text('subscription_id').notNull().unique().references(() => averySubscriptions.id, { onDelete: 'cascade' }),
  businessName: text('business_name').notNull(),
  businessPhone: varchar('business_phone', { length: 20 }).notNull(),
  industry: text('industry'),
  businessHours: jsonb('business_hours'), // { monday: { open: "09:00", close: "17:00" }, ... }
  timezone: text('timezone').notNull().default('America/New_York'),
  customGreeting: text('custom_greeting'),
  fallbackNumber: varchar('fallback_number', { length: 20 }),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

// Avery Services Table
export const averyServices = pgTable('avery_services', {
  id: text('id').primaryKey(),
  profileId: text('profile_id').notNull().references(() => averyProfiles.id, { onDelete: 'cascade' }),
  serviceName: text('service_name').notNull(),
  description: text('description'),
  duration: integer('duration').notNull(), // in minutes
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

// Avery Calls Table
export const averyCalls = pgTable('avery_calls', {
  id: text('id').primaryKey(),
  subscriptionId: text('subscription_id').notNull().references(() => averySubscriptions.id, { onDelete: 'cascade' }),
  callSid: text('call_sid').notNull().unique(), // Twilio Call SID
  fromNumber: varchar('from_number', { length: 20 }).notNull(),
  toNumber: varchar('to_number', { length: 20 }).notNull(),
  duration: integer('duration').notNull(), // in seconds
  outcome: callOutcome('outcome').notNull(),
  transcript: text('transcript'),
  recordingUrl: text('recording_url'),
  recordingDuration: integer('recording_duration'), // in seconds
  sentiment: text('sentiment'), // positive, neutral, negative
  metadata: jsonb('metadata'), // Additional call data
  startedAt: timestamp('started_at').notNull(),
  endedAt: timestamp('ended_at').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

// Avery Bookings Table
export const averyBookings = pgTable('avery_bookings', {
  id: text('id').primaryKey(),
  subscriptionId: text('subscription_id').notNull().references(() => averySubscriptions.id, { onDelete: 'cascade' }),
  callId: text('call_id').references(() => averyCalls.id, { onDelete: 'set null' }),
  serviceId: text('service_id').references(() => averyServices.id, { onDelete: 'set null' }),
  clientName: text('client_name').notNull(),
  clientPhone: varchar('client_phone', { length: 20 }).notNull(),
  clientEmail: text('client_email'),
  appointmentTime: timestamp('appointment_time').notNull(),
  status: text('status').notNull().default('confirmed'), // confirmed, cancelled, completed, no-show
  notes: text('notes'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

// Avery Payments Table
export const averyPayments = pgTable('avery_payments', {
  id: text('id').primaryKey(),
  subscriptionId: text('subscription_id').notNull().references(() => averySubscriptions.id, { onDelete: 'cascade' }),
  stripePaymentIntentId: text('stripe_payment_intent_id').notNull().unique(),
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  currency: varchar('currency', { length: 3 }).notNull().default('USD'),
  status: text('status').notNull(), // succeeded, pending, failed
  description: text('description'),
  invoiceUrl: text('invoice_url'),
  paidAt: timestamp('paid_at'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

// Avery Usage Tracking Table
export const averyUsage = pgTable('avery_usage', {
  id: text('id').primaryKey(),
  subscriptionId: text('subscription_id').notNull().references(() => averySubscriptions.id, { onDelete: 'cascade' }),
  month: varchar('month', { length: 7 }).notNull(), // YYYY-MM format
  callsAnswered: integer('calls_answered').notNull().default(0),
  appointmentsBooked: integer('appointments_booked').notNull().default(0),
  totalCallDuration: integer('total_call_duration').notNull().default(0), // in minutes
  recordingsStored: integer('recordings_stored').notNull().default(0),
  overageCharges: decimal('overage_charges', { precision: 10, scale: 2 }).notNull().default('0'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

// Avery Integrations Table
export const averyIntegrations = pgTable('avery_integrations', {
  id: text('id').primaryKey(),
  subscriptionId: text('subscription_id').notNull().references(() => averySubscriptions.id, { onDelete: 'cascade' }),
  integrationType: text('integration_type').notNull(), // twilio, google_calendar, zapier, slack, etc.
  isConnected: boolean('is_connected').notNull().default(false),
  credentials: jsonb('credentials'), // Encrypted credentials
  config: jsonb('config'), // Integration-specific configuration
  lastSyncedAt: timestamp('last_synced_at'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

// Avery Tier Features Table (Feature Gating)
export const averyTierFeatures = pgTable('avery_tier_features', {
  id: text('id').primaryKey(),
  tier: averyTiers('tier').notNull(),
  featureName: text('feature_name').notNull(),
  isEnabled: boolean('is_enabled').notNull().default(true),
  monthlyLimit: integer('monthly_limit'), // null = unlimited
  rateLimit: integer('rate_limit'), // calls per minute, null = unlimited
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

// Avery Invoices Table
export const averyInvoices = pgTable('avery_invoices', {
  id: text('id').primaryKey(),
  subscriptionId: text('subscription_id').notNull().references(() => averySubscriptions.id, { onDelete: 'cascade' }),
  invoiceNumber: text('invoice_number').notNull().unique(),
  stripeInvoiceId: text('stripe_invoice_id'),
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  currency: varchar('currency', { length: 3 }).notNull().default('USD'),
  status: text('status').notNull(), // draft, open, paid, void, uncollectible
  dueDate: timestamp('due_date'),
  paidAt: timestamp('paid_at'),
  pdfUrl: text('pdf_url'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
});

// Avery Audit Log Table
export const averyAuditLog = pgTable('avery_audit_log', {
  id: text('id').primaryKey(),
  subscriptionId: text('subscription_id').notNull().references(() => averySubscriptions.id, { onDelete: 'cascade' }),
  action: text('action').notNull(), // subscription_created, call_received, booking_made, etc.
  details: jsonb('details'),
  ipAddress: varchar('ip_address', { length: 45 }),
  userAgent: text('user_agent'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

// Relations
export const averySubscriptionsRelations = relations(averySubscriptions, ({ one, many }) => ({
  user: one(users, {
    fields: [averySubscriptions.userId],
    references: [users.id],
  }),
  profile: one(averyProfiles),
  licenses: many(averyLicenses),
  calls: many(averyCalls),
  bookings: many(averyBookings),
  payments: many(averyPayments),
  usage: many(averyUsage),
  integrations: many(averyIntegrations),
  invoices: many(averyInvoices),
  auditLog: many(averyAuditLog),
}));

export const averyProfilesRelations = relations(averyProfiles, ({ one, many }) => ({
  subscription: one(averySubscriptions, {
    fields: [averyProfiles.subscriptionId],
    references: [averySubscriptions.id],
  }),
  services: many(averyServices),
}));

export const averyServicesRelations = relations(averyServices, ({ one }) => ({
  profile: one(averyProfiles, {
    fields: [averyServices.profileId],
    references: [averyProfiles.id],
  }),
}));

export const averyCallsRelations = relations(averyCalls, ({ one, many }) => ({
  subscription: one(averySubscriptions, {
    fields: [averyCalls.subscriptionId],
    references: [averySubscriptions.id],
  }),
  bookings: many(averyBookings),
}));

export const averyBookingsRelations = relations(averyBookings, ({ one }) => ({
  subscription: one(averySubscriptions, {
    fields: [averyBookings.subscriptionId],
    references: [averySubscriptions.id],
  }),
  call: one(averyCalls, {
    fields: [averyBookings.callId],
    references: [averyCalls.id],
  }),
  service: one(averyServices, {
    fields: [averyBookings.serviceId],
    references: [averyServices.id],
  }),
}));
