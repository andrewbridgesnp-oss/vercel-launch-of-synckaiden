import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";

interface Review {
  id: number;
  name: string;
  role: string;
  company: string;
  review: string;
  rating: number;
  avatar: string;
  verified: boolean;
}

const reviews: Review[] = [
  {
    id: 1,
    name: "Marcus Johnson",
    role: "Founder",
    company: "MJ Consulting Group",
    review: "Kaiden helped me build my business credit from zero to $50K in credit lines within 6 months. The step-by-step guidance was exactly what I needed.",
    rating: 5,
    avatar: "/avatars/marcus.jpg",
    verified: true,
  },
  {
    id: 2,
    name: "Sarah Williams",
    role: "Real Estate Investor",
    company: "Williams Properties LLC",
    review: "The real estate strategies in Kaiden are game-changing. I closed my first fix-and-flip deal using the 203K loan strategy outlined in the platform.",
    rating: 5,
    avatar: "/avatars/sarah.jpg",
    verified: true,
  },
  {
    id: 3,
    name: "David Chen",
    role: "E-Commerce Owner",
    company: "Chen Digital Ventures",
    review: "From LLC formation to business banking, Kaiden walked me through everything. My credit score went from 580 to 720 in 8 months following the credit stack strategy.",
    rating: 5,
    avatar: "/avatars/david.jpg",
    verified: true,
  },
  {
    id: 4,
    name: "Tanya Brooks",
    role: "Serial Entrepreneur",
    company: "Brooks Enterprises",
    review: "I have used many business tools, but Kaiden is different. The AI understands my goals and provides personalized recommendations that actually work.",
    rating: 5,
    avatar: "/avatars/tanya.jpg",
    verified: true,
  },
  {
    id: 5,
    name: "Michael Torres",
    role: "Contractor",
    company: "Torres Construction",
    review: "The EIN-only loan strategies helped me secure fleet financing for my construction business without using my personal credit. Absolute game-changer.",
    rating: 5,
    avatar: "/avatars/michael.jpg",
    verified: true,
  },
  {
    id: 6,
    name: "Jennifer Adams",
    role: "Financial Coach",
    company: "Adams Wealth Academy",
    review: "I recommend Kaiden to all my clients. The credit repair workflow and dispute letter templates have helped dozens of people improve their scores.",
    rating: 5,
    avatar: "/avatars/jennifer.jpg",
    verified: true,
  },
];

export function ReviewsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % reviews.length);
        setIsAnimating(false);
      }, 500);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const currentReview = reviews[currentIndex];
  const nextIndex = (currentIndex + 1) % reviews.length;
  const prevIndex = (currentIndex - 1 + reviews.length) % reviews.length;

  return (
    <section className="py-24 bg-secondary/30">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Trusted by <span className="gradient-text">Entrepreneurs</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Real results from real people building their businesses and credit with Kaiden.
          </p>
        </div>

        {/* Main Review */}
        <div className="max-w-4xl mx-auto">
          <Card className={`luxury-card transition-all duration-500 ${isAnimating ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
            <CardContent className="p-8 md:p-12">
              <div className="flex justify-center mb-6">
                <Quote className="h-12 w-12 text-primary/30" />
              </div>
              
              <blockquote className="text-xl md:text-2xl text-center mb-8 leading-relaxed">
                "{currentReview.review}"
              </blockquote>

              <div className="flex flex-col items-center">
                {/* Avatar placeholder - using initials */}
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-cyan-400 flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-xl">
                    {currentReview.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>

                {/* Rating */}
                <div className="flex gap-1 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${i < currentReview.rating ? 'text-yellow-500 fill-yellow-500' : 'text-muted'}`}
                    />
                  ))}
                </div>

                {/* Name and Role */}
                <div className="text-center">
                  <p className="font-semibold text-lg">{currentReview.name}</p>
                  <p className="text-muted-foreground">
                    {currentReview.role} at {currentReview.company}
                  </p>
                  {currentReview.verified && (
                    <span className="inline-flex items-center gap-1 text-xs text-green-500 mt-2">
                      <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      Verified User
                    </span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Dots Navigation */}
        <div className="flex justify-center gap-2 mt-8">
          {reviews.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setIsAnimating(true);
                setTimeout(() => {
                  setCurrentIndex(index);
                  setIsAnimating(false);
                }, 300);
              }}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentIndex
                  ? 'w-8 bg-primary'
                  : 'bg-muted-foreground/30 hover:bg-muted-foreground/50'
              }`}
              aria-label={`Go to review ${index + 1}`}
            />
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto mt-16">
          <div className="text-center">
            <div className="text-3xl font-bold gradient-text">4.9/5</div>
            <div className="text-sm text-muted-foreground">Average Rating</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold gradient-text">10K+</div>
            <div className="text-sm text-muted-foreground">Active Users</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold gradient-text">$50M+</div>
            <div className="text-sm text-muted-foreground">Credit Secured</div>
          </div>
        </div>
      </div>
    </section>
  );
}
