import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, Lock, Smartphone, AlertTriangle, CheckCircle } from "lucide-react";

export default function Security() {
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [show2FASetup, setShow2FASetup] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold">Security</h1>
          </div>
          <p className="text-muted-foreground">Protect your Kaiden account</p>
        </div>

        {/* Security Status */}
        <Card className="mb-8 border-green-500/30 bg-green-500/5">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-green-500" />
                <div>
                  <CardTitle>Your account is secure</CardTitle>
                  <CardDescription>All security features are enabled</CardDescription>
                </div>
              </div>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Protected</Badge>
            </div>
          </CardHeader>
        </Card>

        {/* Password Management */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-primary" />
                <div>
                  <CardTitle>Password</CardTitle>
                  <CardDescription>Change your password regularly for security</CardDescription>
                </div>
              </div>
              <Badge variant="secondary">Last changed 3 months ago</Badge>
            </div>
          </CardHeader>
          <CardContent>
            {!showPasswordForm ? (
              <Button onClick={() => setShowPasswordForm(true)}>Change Password</Button>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Current Password</label>
                  <input
                    type="password"
                    className="w-full mt-2 p-2 rounded-lg border border-border/50 bg-background"
                    placeholder="Enter current password"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">New Password</label>
                  <input
                    type="password"
                    className="w-full mt-2 p-2 rounded-lg border border-border/50 bg-background"
                    placeholder="Enter new password"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Confirm Password</label>
                  <input
                    type="password"
                    className="w-full mt-2 p-2 rounded-lg border border-border/50 bg-background"
                    placeholder="Confirm new password"
                  />
                </div>
                <div className="flex gap-2">
                  <Button className="btn-shine">Update Password</Button>
                  <Button variant="outline" onClick={() => setShowPasswordForm(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Two-Factor Authentication */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Smartphone className="w-5 h-5 text-primary" />
                <div>
                  <CardTitle>Two-Factor Authentication</CardTitle>
                  <CardDescription>Add an extra layer of security to your account</CardDescription>
                </div>
              </div>
              <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">Not Enabled</Badge>
            </div>
          </CardHeader>
          <CardContent>
            {!show2FASetup ? (
              <div>
                <p className="text-sm text-muted-foreground mb-4">
                  Two-factor authentication adds an extra layer of security by requiring a second form of
                  verification when you log in.
                </p>
                <Button onClick={() => setShow2FASetup(true)}>Enable 2FA</Button>
              </div>
            ) : (
              <div className="space-y-4">
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)
                  </AlertDescription>
                </Alert>
                <div className="p-4 bg-white rounded-lg flex items-center justify-center">
                  <div className="w-32 h-32 bg-gray-200 rounded flex items-center justify-center text-xs text-gray-600">
                    QR Code
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium">Verification Code</label>
                  <input
                    type="text"
                    className="w-full mt-2 p-2 rounded-lg border border-border/50 bg-background"
                    placeholder="Enter 6-digit code"
                    maxLength={6}
                  />
                </div>
                <div className="flex gap-2">
                  <Button className="btn-shine">Verify & Enable</Button>
                  <Button variant="outline" onClick={() => setShow2FASetup(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Sessions */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Active Sessions</CardTitle>
            <CardDescription>Manage your active login sessions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 rounded-lg border border-border/50">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <p className="font-medium">Current Session</p>
                  <p className="text-sm text-muted-foreground">Chrome on macOS</p>
                </div>
                <Badge className="bg-green-500/20 text-green-400">Active</Badge>
              </div>
              <p className="text-xs text-muted-foreground">Last active: Just now</p>
            </div>
            <div className="p-4 rounded-lg border border-border/50">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <p className="font-medium">Mobile Session</p>
                  <p className="text-sm text-muted-foreground">Safari on iPhone</p>
                </div>
                <Button size="sm" variant="outline" className="text-destructive">
                  Sign Out
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">Last active: 2 hours ago</p>
            </div>
          </CardContent>
        </Card>

        {/* Login Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Login Activity</CardTitle>
            <CardDescription>Recent login attempts to your account</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { time: "Today at 1:45 PM", device: "Chrome on macOS", location: "New York, USA", status: "Success" },
              { time: "Yesterday at 9:30 AM", device: "Safari on iPhone", location: "New York, USA", status: "Success" },
              { time: "Jan 8 at 3:15 PM", device: "Firefox on Windows", location: "New York, USA", status: "Success" },
            ].map((activity, idx) => (
              <div key={idx} className="p-4 rounded-lg border border-border/50">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <p className="font-medium">{activity.device}</p>
                    <p className="text-sm text-muted-foreground">{activity.location}</p>
                  </div>
                  <Badge className="bg-green-500/20 text-green-400">{activity.status}</Badge>
                </div>
                <p className="text-xs text-muted-foreground">{activity.time}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
