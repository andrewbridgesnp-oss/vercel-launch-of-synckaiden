import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Redirect } from "wouter";
import { toast } from "sonner";
import {
  Users,
  Gift,
  DollarSign,
  Copy,
  Share2,
  CheckCircle2,
  Star,
  Trophy,
  Zap,
  ArrowRight,
  TrendingUp,
  Crown,
} from "lucide-react";

// Referral Tiers
const referralTiers = [
  { signups: 1, reward: "20% off your first year", icon: Gift },
  { signups: 10, reward: "30% off your subscription", icon: Star },
  { signups: 25, reward: "50% off your subscription", icon: TrendingUp },
  { signups: 50, reward: "75% off your subscription", icon: Trophy },
  { signups: 100, reward: "FREE for 1 year (up to $1K value)", icon: Crown },
];

export default function Referrals() {
  const { user, isAuthenticated, loading } = useAuth();
  const [copied, setCopied] = useState(false);
  
  // Generate referral link (in production, this would come from the backend)
  const referralCode = user?.id ? `KAIDEN-${user.id.toString().padStart(6, '0')}` : 'KAIDEN-XXXXXX';
  const referralLink = `https://synckaiden.com/join?ref=${referralCode}`;
  
  // Mock referral stats (in production, these would come from the backend)
  const referralStats = {
    totalReferrals: 23,
    pendingReferrals: 5,
    earnedRewards: 450,
    currentTier: 2,
    nextTierProgress: 23,
    nextTierTarget: 25,
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    toast.success("Referral link copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };

  const shareReferral = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join Kaiden - AI Business Consultant',
          text: 'I\'ve been using Kaiden to build my business and credit. Use my link to get 20% off!',
          url: referralLink,
        });
      } catch (err) {
        copyToClipboard();
      }
    } else {
      copyToClipboard();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
            <Users className="h-8 w-8 text-primary" />
          </div>
          <p className="text-muted-foreground">Loading referral program...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-primary/20 text-primary">Referral Program</Badge>
          <h1 className="text-4xl font-bold mb-4">
            <span className="gradient-text">Share Kaiden, Earn Rewards</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Refer friends and earn up to a FREE year of Kaiden. 
            They get 20% off, you get rewarded.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="luxury-card">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-primary/20 flex items-center justify-center">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div className="text-3xl font-bold mb-1">{referralStats.totalReferrals}</div>
              <div className="text-sm text-muted-foreground">Total Referrals</div>
            </CardContent>
          </Card>
          <Card className="luxury-card">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-yellow-500/20 flex items-center justify-center">
                <Star className="h-6 w-6 text-yellow-500" />
              </div>
              <div className="text-3xl font-bold mb-1">{referralStats.pendingReferrals}</div>
              <div className="text-sm text-muted-foreground">Pending</div>
            </CardContent>
          </Card>
          <Card className="luxury-card">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-green-500/20 flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-green-500" />
              </div>
              <div className="text-3xl font-bold mb-1">${referralStats.earnedRewards}</div>
              <div className="text-sm text-muted-foreground">Earned Value</div>
            </CardContent>
          </Card>
          <Card className="luxury-card">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-purple-500/20 flex items-center justify-center">
                <Trophy className="h-6 w-6 text-purple-500" />
              </div>
              <div className="text-3xl font-bold mb-1">Tier {referralStats.currentTier}</div>
              <div className="text-sm text-muted-foreground">Current Level</div>
            </CardContent>
          </Card>
        </div>

        {/* Referral Link Card */}
        <Card className="luxury-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Share2 className="h-5 w-5 text-primary" />
              Your Referral Link
            </CardTitle>
            <CardDescription>
              Share this link with friends. When they sign up, you both win!
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input
                value={referralLink}
                readOnly
                className="font-mono text-sm"
              />
              <Button onClick={copyToClipboard} variant="outline" className="flex-shrink-0">
                {copied ? <CheckCircle2 className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
              </Button>
              <Button onClick={shareReferral} className="btn-shine flex-shrink-0">
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </Button>
            </div>
            <div className="mt-4 p-4 rounded-lg bg-secondary/50">
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="outline">Your Code</Badge>
                <span className="font-mono font-bold text-primary">{referralCode}</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Friends can also enter this code at checkout
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Progress to Next Tier */}
        <Card className="luxury-card mb-8">
          <CardHeader>
            <CardTitle>Progress to Next Tier</CardTitle>
            <CardDescription>
              {referralStats.nextTierTarget - referralStats.nextTierProgress} more referrals to unlock the next reward
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-2">
                <span>{referralStats.nextTierProgress} referrals</span>
                <span>{referralStats.nextTierTarget} referrals</span>
              </div>
              <Progress 
                value={(referralStats.nextTierProgress / referralStats.nextTierTarget) * 100} 
                className="h-3"
              />
            </div>
            <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/10 border border-primary/20">
              <Zap className="h-5 w-5 text-primary" />
              <span className="text-sm">
                <strong>Next reward:</strong> 50% off your subscription
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Reward Tiers */}
        <Card className="luxury-card mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-primary" />
              Reward Tiers
            </CardTitle>
            <CardDescription>
              The more you share, the more you earn
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {referralTiers.map((tier, index) => {
                const Icon = tier.icon;
                const isUnlocked = referralStats.totalReferrals >= tier.signups;
                const isCurrent = index === referralStats.currentTier - 1;
                
                return (
                  <div 
                    key={tier.signups}
                    className={`flex items-center gap-4 p-4 rounded-lg transition-all ${
                      isUnlocked 
                        ? 'bg-green-500/10 border border-green-500/30' 
                        : isCurrent
                        ? 'bg-primary/10 border border-primary/30'
                        : 'bg-secondary/50'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      isUnlocked ? 'bg-green-500/20' : 'bg-secondary'
                    }`}>
                      <Icon className={`h-6 w-6 ${isUnlocked ? 'text-green-500' : 'text-muted-foreground'}`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{tier.signups} Referrals</span>
                        {isUnlocked && (
                          <Badge className="bg-green-500/20 text-green-500">Unlocked</Badge>
                        )}
                        {isCurrent && !isUnlocked && (
                          <Badge variant="outline">Current Goal</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{tier.reward}</p>
                    </div>
                    {isUnlocked && (
                      <CheckCircle2 className="h-6 w-6 text-green-500" />
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card className="luxury-card">
          <CardHeader>
            <CardTitle>How It Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Share2 className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">1. Share Your Link</h3>
                <p className="text-sm text-muted-foreground">
                  Send your unique referral link to friends, family, or your network
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Users className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">2. They Sign Up</h3>
                <p className="text-sm text-muted-foreground">
                  When they join using your link, they get 20% off their first year
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Gift className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">3. You Earn Rewards</h3>
                <p className="text-sm text-muted-foreground">
                  Unlock bigger discounts as you refer more people. 100 referrals = FREE year!
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Fine Print */}
        <p className="text-xs text-center text-muted-foreground mt-8">
          Referral rewards apply to subscription costs up to $1,000/year. 
          Rewards are applied as account credits. 
          Referred users must maintain an active subscription for 30 days for referral to count.
          Terms subject to change.
        </p>
      </div>
    </div>
  );
}
