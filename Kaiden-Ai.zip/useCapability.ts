import { useCallback, useEffect, useMemo } from 'react';
import { useCapabilityStore } from '@/stores/capabilityStore';
import { trpc } from '@/lib/trpc';
import type { Capability } from '@/types';

/**
 * Hook for accessing and managing a single capability
 */
export function useCapability(capabilityId: string | null) {
  const capability = useCapabilityStore((state) =>
    state.capabilities.find((c) => c.id === capabilityId)
  );

  const capabilityState = useCapabilityStore((state) =>
    capabilityId ? state.capabilityStates.get(capabilityId) : undefined
  );

  const updateState = useCapabilityStore((state) => state.updateCapabilityState);

  return {
    capability,
    state: capabilityState,
    updateState: (newState: Partial<any>) => {
      if (capabilityId) {
        updateState(capabilityId, newState);
      }
    },
    isLoading: capabilityState?.isLoading ?? false,
    isError: capabilityState?.isError ?? false,
    error: capabilityState?.error,
  };
}

/**
 * Hook for accessing all capabilities with filtering
 */
export function useCapabilities() {
  const capabilities = useCapabilityStore((state) => state.capabilities);
  const getFiltered = useCapabilityStore((state) => state.getFilteredCapabilities);
  const searchQuery = useCapabilityStore((state) => state.searchQuery);
  const filterStatus = useCapabilityStore((state) => state.filterStatus);
  const filterPriority = useCapabilityStore((state) => state.filterPriority);

  const filtered = useMemo(() => getFiltered(), [getFiltered, searchQuery, filterStatus, filterPriority]);

  return {
    all: capabilities,
    filtered,
    count: capabilities.length,
    filteredCount: filtered.length,
  };
}

/**
 * Hook for accessing modules
 */
export function useModules() {
  const modules = useCapabilityStore((state) => state.modules);
  const expandedModules = useCapabilityStore((state) => state.expandedModules);
  const toggleExpanded = useCapabilityStore((state) => state.toggleModuleExpanded);

  return {
    modules,
    expandedModules,
    toggleExpanded,
    isExpanded: (moduleId: string) => expandedModules.has(moduleId),
  };
}

/**
 * Hook for capability search and filtering
 */
export function useCapabilitySearch() {
  const searchQuery = useCapabilityStore((state) => state.searchQuery);
  const setSearchQuery = useCapabilityStore((state) => state.setSearchQuery);
  const filterStatus = useCapabilityStore((state) => state.filterStatus);
  const setFilterStatus = useCapabilityStore((state) => state.setFilterStatus);
  const filterPriority = useCapabilityStore((state) => state.filterPriority);
  const setFilterPriority = useCapabilityStore((state) => state.setFilterPriority);

  return {
    searchQuery,
    setSearchQuery,
    filterStatus,
    setFilterStatus,
    filterPriority,
    setFilterPriority,
    clearFilters: () => {
      setSearchQuery('');
      setFilterStatus('ALL');
      setFilterPriority('ALL');
    },
  };
}

/**
 * Hook for loading capability registry from server
 */
export function useCapabilityRegistry() {
  const setRegistry = useCapabilityStore((state) => state.setRegistry);
  const setLoading = useCapabilityStore((state) => state.setLoading);
  const setError = useCapabilityStore((state) => state.setError);
  const isLoading = useCapabilityStore((state) => state.isLoading);
  const error = useCapabilityStore((state) => state.error);

  const { data: registry, isLoading: queryLoading, error: queryError } = trpc.capability.getRegistry.useQuery();

  useEffect(() => {
    if (queryLoading) {
      setLoading(true);
    } else if (queryError) {
      setError(queryError);
      setLoading(false);
    } else if (registry) {
      setRegistry(registry);
      setLoading(false);
    }
  }, [registry, queryLoading, queryError, setRegistry, setLoading, setError]);

  return {
    isLoading: isLoading || queryLoading,
    error,
    registry,
  };
}

/**
 * Hook for capability selection
 */
export function useCapabilitySelection() {
  const selectedCapabilityId = useCapabilityStore((state) => state.selectedCapabilityId);
  const selectedModuleId = useCapabilityStore((state) => state.selectedModuleId);
  const selectCapability = useCapabilityStore((state) => state.selectCapability);
  const selectModule = useCapabilityStore((state) => state.selectModule);
  const getSelectedCapability = useCapabilityStore((state) => state.getSelectedCapability);
  const getSelectedModule = useCapabilityStore((state) => state.getSelectedModule);

  return {
    selectedCapabilityId,
    selectedModuleId,
    selectedCapability: getSelectedCapability(),
    selectedModule: getSelectedModule(),
    selectCapability,
    selectModule,
  };
}

/**
 * Hook for capability execution/interaction
 */
export function useCapabilityAction(capabilityId: string) {
  const updateState = useCapabilityStore((state) => state.updateCapabilityState);
  const executeCapability = trpc.capability.execute.useMutation();

  const execute = useCallback(
    async (params?: Record<string, unknown>) => {
      try {
        updateState(capabilityId, { isLoading: true, isError: false });
        const result = await executeCapability.mutateAsync({
          capabilityId,
          params,
        });
        updateState(capabilityId, {
          isLoading: false,
          data: result,
          lastUpdated: new Date(),
        });
        return result;
      } catch (error) {
        updateState(capabilityId, {
          isLoading: false,
          isError: true,
          error: error instanceof Error ? error : new Error('Unknown error'),
        });
        throw error;
      }
    },
    [capabilityId, updateState, executeCapability]
  );

  return {
    execute,
    isPending: executeCapability.isPending,
    error: executeCapability.error,
  };
}
