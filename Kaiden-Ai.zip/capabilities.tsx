import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { capabilities, Capability, CapabilityStatus, RevenueRank } from '../../src/config/capabilities';

const STATUS_LABEL: Record<CapabilityStatus, string> = {
  LIVE: 'Live',
  BETA: 'Beta',
  COMING_SOON: 'Coming Soon',
};

const STATUS_COLOR: Record<CapabilityStatus, string> = {
  LIVE: '#22C55E',
  BETA: '#FACC15',
  COMING_SOON: '#6B7280',
};

const REVENUE_LABEL: Record<RevenueRank, string> = {
  HIGH: 'High Revenue',
  MEDIUM: 'Medium',
  LONG_TERM: 'Long-Term',
};

export default function CapabilitiesScreen() {
  const [statusFilter, setStatusFilter] = useState<CapabilityStatus | 'ALL'>('ALL');
  const [revenueFilter, setRevenueFilter] = useState<RevenueRank | 'ALL'>('ALL');

  const grouped = useMemo(() => {
    let list: Capability[] = capabilities;

    if (statusFilter !== 'ALL') {
      list = list.filter((c) => c.status === statusFilter);
    }
    if (revenueFilter !== 'ALL') {
      list = list.filter((c) => c.revenueRank === revenueFilter);
    }

    const byModule: Record<string, Capability[]> = {};
    list.forEach((cap) => {
      if (!byModule[cap.module]) byModule[cap.module] = [];
      byModule[cap.module].push(cap);
    });
    return byModule;
  }, [statusFilter, revenueFilter]);

  const modules = Object.keys(grouped).sort();

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>KAYDEN Capability Map</Text>
        <Text style={styles.subtitle}>
          A living overview of whats live today, whats in beta, and whats coming next. Built
          to give people their time back—and help you make money while you do it.
        </Text>

        {/* Filters */}
        <View style={styles.chipRow}>
          {(['ALL', 'LIVE', 'BETA', 'COMING_SOON'] as const).map((status) => (
            <TouchableOpacity
              key={status}
              style={[styles.chip, statusFilter === status && styles.chipActive]}
              onPress={() => setStatusFilter(status as CapabilityStatus | 'ALL')}
            >
              <Text
                style={[
                  styles.chipText,
                  statusFilter === status && styles.chipTextActive,
                ]}
              >
                {status === 'ALL' ? 'All' : STATUS_LABEL[status as CapabilityStatus]}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.chipRow}>
          {(['ALL', 'HIGH', 'MEDIUM', 'LONG_TERM'] as const).map((tier) => (
            <TouchableOpacity
              key={tier}
              style={[styles.chip, revenueFilter === tier && styles.chipActive]}
              onPress={() => setRevenueFilter(tier as RevenueRank | 'ALL')}
            >
              <Text
                style={[
                  styles.chipText,
                  revenueFilter === tier && styles.chipTextActive,
                ]}
              >
                {tier === 'ALL' ? 'All Revenue' : REVENUE_LABEL[tier as RevenueRank]}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {modules.map((module) => (
          <View key={module} style={styles.moduleCard}>
            <Text style={styles.moduleTitle}>{module}</Text>
            {grouped[module].map((cap) => (
              <View key={cap.id} style={styles.capRow}>