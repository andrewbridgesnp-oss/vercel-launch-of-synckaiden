/**
 * Linear Design System - Navy Blue Theme
 * Extracted from Linear app screenshot
 * Applied to Synckaiden/Kaiden application
 */

export const LinearDesignSystem = {
  // Color Palette - Navy Blue Theme
  colors: {
    // Primary Navy Blues
    navy: {
      50: '#f0f4ff',
      100: '#e0e9ff',
      200: '#c1d3ff',
      300: '#a2bdff',
      400: '#7a9eff',
      500: '#5b7fff', // Primary
      600: '#4a6bdb',
      700: '#3a57b8',
      800: '#2a4395',
      900: '#1a2f72',
      950: '#0f1f4d', // Dark navy - main background
    },
    // Accent Colors
    purple: {
      500: '#7c3aed', // Sign up button
      600: '#6d28d9',
    },
    // Neutral Grays
    gray: {
      50: '#f9fafb',
      100: '#f3f4f6',
      200: '#e5e7eb',
      300: '#d1d5db',
      400: '#9ca3af',
      500: '#6b7280',
      600: '#4b5563',
      700: '#374151',
      800: '#1f2937',
      900: '#111827',
    },
    // Status Colors
    success: '#10b981',
    warning: '#f59e0b',
    error: '#ef4444',
    info: '#3b82f6',
    // Text Colors
    text: {
      primary: '#ffffff',
      secondary: '#d1d5db',
      tertiary: '#9ca3af',
      muted: '#6b7280',
    },
    // Background
    background: {
      primary: '#0f1f4d', // Dark navy
      secondary: '#1a2f72',
      tertiary: '#2a4395',
      surface: '#1f2937',
    },
  },

  // Typography
  typography: {
    fontFamily: {
      sans: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
      mono: '"Fira Code", "Courier New", monospace',
    },
    fontSize: {
      xs: '12px',
      sm: '13px',
      base: '14px',
      lg: '16px',
      xl: '18px',
      '2xl': '20px',
      '3xl': '24px',
      '4xl': '28px',
      '5xl': '32px',
      '6xl': '40px',
    },
    fontWeight: {
      light: 300,
      normal: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
      extrabold: 800,
    },
    lineHeight: {
      tight: 1.2,
      normal: 1.5,
      relaxed: 1.75,
      loose: 2,
    },
  },

  // Spacing System
  spacing: {
    0: '0px',
    1: '4px',
    2: '8px',
    3: '12px',
    4: '16px',
    5: '20px',
    6: '24px',
    8: '32px',
    10: '40px',
    12: '48px',
    16: '64px',
    20: '80px',
    24: '96px',
  },

  // Border Radius
  borderRadius: {
    none: '0px',
    sm: '4px',
    base: '6px',
    md: '8px',
    lg: '12px',
    xl: '16px',
    '2xl': '20px',
    full: '9999px',
  },

  // Shadows
  shadows: {
    none: 'none',
    sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
    base: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
    xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
    '2xl': '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
    inner: 'inset 0 2px 4px 0 rgba(0, 0, 0, 0.06)',
  },

  // Transitions
  transitions: {
    fast: '150ms cubic-bezier(0.4, 0, 0.2, 1)',
    base: '200ms cubic-bezier(0.4, 0, 0.2, 1)',
    slow: '300ms cubic-bezier(0.4, 0, 0.2, 1)',
  },

  // Component Styles
  components: {
    // Button Styles
    button: {
      primary: {
        background: '#5b7fff',
        color: '#ffffff',
        hover: '#4a6bdb',
        active: '#3a57b8',
        disabled: '#9ca3af',
      },
      secondary: {
        background: '#2a4395',
        color: '#ffffff',
        hover: '#1a2f72',
        active: '#0f1f4d',
        disabled: '#9ca3af',
      },
      ghost: {
        background: 'transparent',
        color: '#d1d5db',
        hover: '#374151',
        active: '#1f2937',
        disabled: '#6b7280',
      },
    },

    // Input Styles
    input: {
      background: '#1f2937',
      border: '#374151',
      text: '#ffffff',
      placeholder: '#9ca3af',
      focus: '#5b7fff',
      disabled: '#6b7280',
    },

    // Card Styles
    card: {
      background: '#1a2f72',
      border: '#2a4395',
      shadow: '0 1px 3px rgba(0, 0, 0, 0.3)',
    },

    // Navigation
    nav: {
      background: '#0f1f4d',
      text: '#d1d5db',
      activeText: '#ffffff',
      activeBackground: '#2a4395',
      hover: '#1a2f72',
    },

    // Sidebar
    sidebar: {
      background: '#0f1f4d',
      border: '#1a2f72',
      text: '#d1d5db',
      activeText: '#ffffff',
      activeBackground: '#2a4395',
    },
  },

  // Z-Index Scale
  zIndex: {
    hide: -1,
    auto: 'auto',
    base: 0,
    dropdown: 1000,
    sticky: 1020,
    fixed: 1030,
    backdrop: 1040,
    modal: 1050,
    popover: 1060,
    tooltip: 1070,
  },

  // Breakpoints
  breakpoints: {
    xs: '320px',
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px',
    '2xl': '1536px',
  },
};

/**
 * CSS Variables for Tailwind Integration
 */
export const tailwindConfig = {
  theme: {
    extend: {
      colors: {
        navy: LinearDesignSystem.colors.navy,
        gray: LinearDesignSystem.colors.gray,
        success: LinearDesignSystem.colors.success,
        warning: LinearDesignSystem.colors.warning,
        error: LinearDesignSystem.colors.error,
        info: LinearDesignSystem.colors.info,
      },
      fontFamily: {
        sans: LinearDesignSystem.typography.fontFamily.sans,
        mono: LinearDesignSystem.typography.fontFamily.mono,
      },
      spacing: LinearDesignSystem.spacing,
      borderRadius: LinearDesignSystem.borderRadius,
      boxShadow: LinearDesignSystem.shadows,
      transitionDuration: LinearDesignSystem.transitions,
    },
  },
};

/**
 * CSS Custom Properties for Global Styling
 */
export const cssVariables = `
:root {
  /* Navy Blues */
  --color-navy-50: ${LinearDesignSystem.colors.navy[50]};
  --color-navy-100: ${LinearDesignSystem.colors.navy[100]};
  --color-navy-200: ${LinearDesignSystem.colors.navy[200]};
  --color-navy-300: ${LinearDesignSystem.colors.navy[300]};
  --color-navy-400: ${LinearDesignSystem.colors.navy[400]};
  --color-navy-500: ${LinearDesignSystem.colors.navy[500]};
  --color-navy-600: ${LinearDesignSystem.colors.navy[600]};
  --color-navy-700: ${LinearDesignSystem.colors.navy[700]};
  --color-navy-800: ${LinearDesignSystem.colors.navy[800]};
  --color-navy-900: ${LinearDesignSystem.colors.navy[900]};
  --color-navy-950: ${LinearDesignSystem.colors.navy[950]};

  /* Accent Colors */
  --color-purple-500: ${LinearDesignSystem.colors.purple[500]};
  --color-purple-600: ${LinearDesignSystem.colors.purple[600]};

  /* Grays */
  --color-gray-50: ${LinearDesignSystem.colors.gray[50]};
  --color-gray-100: ${LinearDesignSystem.colors.gray[100]};
  --color-gray-200: ${LinearDesignSystem.colors.gray[200]};
  --color-gray-300: ${LinearDesignSystem.colors.gray[300]};
  --color-gray-400: ${LinearDesignSystem.colors.gray[400]};
  --color-gray-500: ${LinearDesignSystem.colors.gray[500]};
  --color-gray-600: ${LinearDesignSystem.colors.gray[600]};
  --color-gray-700: ${LinearDesignSystem.colors.gray[700]};
  --color-gray-800: ${LinearDesignSystem.colors.gray[800]};
  --color-gray-900: ${LinearDesignSystem.colors.gray[900]};

  /* Status Colors */
  --color-success: ${LinearDesignSystem.colors.success};
  --color-warning: ${LinearDesignSystem.colors.warning};
  --color-error: ${LinearDesignSystem.colors.error};
  --color-info: ${LinearDesignSystem.colors.info};

  /* Text Colors */
  --color-text-primary: ${LinearDesignSystem.colors.text.primary};
  --color-text-secondary: ${LinearDesignSystem.colors.text.secondary};
  --color-text-tertiary: ${LinearDesignSystem.colors.text.tertiary};
  --color-text-muted: ${LinearDesignSystem.colors.text.muted};

  /* Background Colors */
  --color-bg-primary: ${LinearDesignSystem.colors.background.primary};
  --color-bg-secondary: ${LinearDesignSystem.colors.background.secondary};
  --color-bg-tertiary: ${LinearDesignSystem.colors.background.tertiary};
  --color-bg-surface: ${LinearDesignSystem.colors.background.surface};

  /* Typography */
  --font-sans: ${LinearDesignSystem.typography.fontFamily.sans};
  --font-mono: ${LinearDesignSystem.typography.fontFamily.mono};

  /* Spacing */
  --spacing-0: ${LinearDesignSystem.spacing[0]};
  --spacing-1: ${LinearDesignSystem.spacing[1]};
  --spacing-2: ${LinearDesignSystem.spacing[2]};
  --spacing-3: ${LinearDesignSystem.spacing[3]};
  --spacing-4: ${LinearDesignSystem.spacing[4]};
  --spacing-5: ${LinearDesignSystem.spacing[5]};
  --spacing-6: ${LinearDesignSystem.spacing[6]};
  --spacing-8: ${LinearDesignSystem.spacing[8]};
  --spacing-10: ${LinearDesignSystem.spacing[10]};
  --spacing-12: ${LinearDesignSystem.spacing[12]};
  --spacing-16: ${LinearDesignSystem.spacing[16]};
  --spacing-20: ${LinearDesignSystem.spacing[20]};
  --spacing-24: ${LinearDesignSystem.spacing[24]};

  /* Border Radius */
  --radius-none: ${LinearDesignSystem.borderRadius.none};
  --radius-sm: ${LinearDesignSystem.borderRadius.sm};
  --radius-base: ${LinearDesignSystem.borderRadius.base};
  --radius-md: ${LinearDesignSystem.borderRadius.md};
  --radius-lg: ${LinearDesignSystem.borderRadius.lg};
  --radius-xl: ${LinearDesignSystem.borderRadius.xl};
  --radius-2xl: ${LinearDesignSystem.borderRadius['2xl']};
  --radius-full: ${LinearDesignSystem.borderRadius.full};

  /* Transitions */
  --transition-fast: ${LinearDesignSystem.transitions.fast};
  --transition-base: ${LinearDesignSystem.transitions.base};
  --transition-slow: ${LinearDesignSystem.transitions.slow};
}

/* Dark Mode (Default) */
body {
  background-color: var(--color-bg-primary);
  color: var(--color-text-primary);
  font-family: var(--font-sans);
}

/* Smooth Transitions */
* {
  transition: background-color var(--transition-base), color var(--transition-base);
}
`;

export default LinearDesignSystem;
