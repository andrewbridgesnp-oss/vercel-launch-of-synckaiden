import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, X, Send, Bot, User, Minimize2, Maximize2 } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

const initialMessages: Message[] = [
  {
    id: '1',
    role: 'assistant',
    content: 'Hello! I am Kaiden, your AI business consultant. I am here to help you navigate the platform, troubleshoot issues, or answer any questions about our services. How can I assist you today?',
    timestamp: new Date(),
  },
];

const quickResponses = [
  'How do I get started?',
  'What are the pricing options?',
  'I need help with payments',
  'Tell me about AI Receptionist',
];

export function LiveChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('started') || lowerMessage.includes('begin')) {
      return 'Great question! To get started with Kaiden:\n\n1. Create your account using the "Get Started" button\n2. Complete the personality sync questionnaire\n3. Set up your business profile\n4. Explore our 282 capabilities\n\nWould you like me to guide you through any specific feature?';
    }
    
    if (lowerMessage.includes('pricing') || lowerMessage.includes('cost') || lowerMessage.includes('price')) {
      return 'We offer flexible pricing to fit any budget:\n\n- Starter: $29/month (50 capabilities)\n- Professional: $79/month (150 capabilities)\n- Enterprise: $199/month (all 282 capabilities)\n\nWe also offer standalone apps starting at $7.99/month. Would you like me to explain the bundle discounts?';
    }
    
    if (lowerMessage.includes('payment') || lowerMessage.includes('pay') || lowerMessage.includes('billing')) {
      return 'We accept payments through:\n\n- Stripe (Credit/Debit Cards)\n- Gumroad (Digital Payments)\n- Square (Business Payments)\n\nAll payments are secure and encrypted. For payment issues, please check your billing settings or contact support@synckaiden.com.';
    }
    
    if (lowerMessage.includes('receptionist') || lowerMessage.includes('phone') || lowerMessage.includes('calls')) {
      return 'The AI Receptionist is our flagship business automation tool! It can:\n\n- Answer phones 24/7\n- Schedule appointments\n- Send follow-up texts and coupons\n- Generate secure payment links\n- Manage inventory\n- Play ambient music\n\nVisit the AI Receptionist page to set it up for your business!';
    }
    
    if (lowerMessage.includes('credit') || lowerMessage.includes('repair')) {
      return 'Our Credit Repair & Building system helps you:\n\n- Dispute inaccurate items\n- Build credit strategically (580 to 700+)\n- Access secured cards and credit builders\n- Navigate business credit\n\nNote: We are not CPAs or financial advisors. Always consult licensed professionals.';
    }
    
    if (lowerMessage.includes('help') || lowerMessage.includes('support')) {
      return 'I am here to help! You can:\n\n- Ask me questions about any feature\n- Get navigation assistance\n- Troubleshoot issues\n- Learn about capabilities\n\nFor urgent matters, email support@synckaiden.com or use the contact form.';
    }
    
    return 'Thank you for your message. I am Kaiden, here to help you succeed. Could you tell me more about what you are looking for? I can help with:\n\n- Getting started\n- Pricing and plans\n- Feature explanations\n- Troubleshooting\n- Business automation';
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI thinking
    setTimeout(() => {
      const response = generateResponse(input);
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1000);
  };

  const handleQuickResponse = (text: string) => {
    setInput(text);
  };

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg btn-shine glow-blue z-50"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>
    );
  }

  return (
    <Card className={`fixed bottom-6 right-6 z-50 shadow-2xl border-border/50 overflow-hidden transition-all duration-300 ${
      isMinimized ? 'w-80 h-14' : 'w-96 h-[500px]'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-primary/10 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <Bot className="h-5 w-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-sm">Kaiden AI Support</h3>
            <Badge variant="secondary" className="text-xs">Online</Badge>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setIsMinimized(!isMinimized)}
          >
            {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setIsOpen(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 h-[340px] bg-background">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                  message.role === 'user' 
                    ? 'bg-primary/20' 
                    : 'bg-gradient-to-br from-primary to-accent'
                }`}>
                  {message.role === 'user' 
                    ? <User className="h-4 w-4 text-primary" />
                    : <Bot className="h-4 w-4 text-white" />
                  }
                </div>
                <div className={`max-w-[80%] rounded-lg p-3 text-sm ${
                  message.role === 'user'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                }`}>
                  <p className="whitespace-pre-line">{message.content}</p>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <Bot className="h-4 w-4 text-white" />
                </div>
                <div className="bg-muted rounded-lg p-3">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Responses */}
          <div className="px-4 py-2 border-t border-border/50 bg-muted/30">
            <div className="flex gap-2 overflow-x-auto pb-2">
              {quickResponses.map((text, idx) => (
                <Button
                  key={idx}
                  variant="outline"
                  size="sm"
                  className="text-xs whitespace-nowrap shrink-0"
                  onClick={() => handleQuickResponse(text)}
                >
                  {text}
                </Button>
              ))}
            </div>
          </div>

          {/* Input */}
          <div className="p-4 border-t border-border/50 bg-background">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex gap-2"
            >
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                className="flex-1"
              />
              <Button type="submit" size="icon" disabled={!input.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </>
      )}
    </Card>
  );
}

export default LiveChat;
