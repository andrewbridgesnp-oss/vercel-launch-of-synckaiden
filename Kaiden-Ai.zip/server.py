import logging
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, WebSocket, WebSocketDisconnect, APIRouter, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, BeforeValidator
from typing import List, Optional, Dict, Annotated
import jwt
from datetime import datetime, timedelta
from passlib.context import CryptContext
from dotenv import load_dotenv
from models import User, Message, Tribe, Event, Rating, VenueProposal, DailyLog, ScoreProposal, EventResource
from bson import ObjectId
from bson.errors import InvalidId
import json
import numpy as np
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from emergentintegrations.llm.chat import LlmChat, UserMessage
from emergentintegrations.llm.openai import OpenAIChatRealtime
from openai import OpenAI

# Configure Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

limiter = Limiter(key_func=get_remote_address)
app = FastAPI()
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

origins = os.getenv("CORS_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "wheresmytribe")
client = AsyncIOMotorClient(MONGO_URL)
db = client[DB_NAME]

@app.on_event("startup")
async def startup_db_client():
    await db.users.create_index("email", unique=True)
    await db.users.create_index("tribe_id")
    await db.daily_logs.create_index([("user_id", 1), ("date", 1)], unique=True)
    await db.events.create_index("type")
    
    if await db.events.count_documents({}) < 5:
        augusta_events = [
            Event(
                tribe_id="global",
                title="Skydiving Over the Savannah",
                description="Bucket List Item #1: Jump from 14,000 feet. Conquer fear together.",
                type="bucket_list",
                is_bucket_list=True,
                location_lat=33.4709,
                location_lng=-81.9748, 
                address="Skydive Carolina (Trip)",
                start_time=datetime(2026, 6, 15, 10, 0),
                is_revealed=True,
                price=250.00
            ),
            Event(
                tribe_id="global",
                title="Family Game Night: Riverwalk",
                description="Bring board games, kids, and partners. Sunset play by the Savannah River.",
                type="game_night",
                is_family_friendly=True,
                location_lat=33.4735,
                location_lng=-81.9665,
                address="Augusta Riverwalk Amphitheater",
                start_time=datetime(2026, 1, 10, 18, 0),
                is_revealed=True,
                price=0.0
            ),
            Event(
                tribe_id="global",
                title="Couples Catan Championship",
                description="Private hosting by Member 'Sarah & Tom'. Bring your own snacks.",
                type="game_night",
                location_lat=33.5020, 
                location_lng=-82.1080,
                address="Private Residence (Evans, GA)",
                start_time=datetime(2026, 1, 12, 19, 0),
                is_revealed=False,
                price=0.0
            )
        ]
        for e in augusta_events:
            await db.events.insert_one(e.model_dump(by_alias=True, exclude=["id"]))

SECRET_KEY = "supersecretkey" 