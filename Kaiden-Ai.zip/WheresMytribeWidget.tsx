/**
 * Where's My Tribe Integration Widget
 * 
 * Integrates the social matching and community features.
 * Connects to FastAPI backend with WebSocket support.
 */

import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Users,
  MapPin,
  Heart,
  MessageCircle,
  Star,
  Zap,
  Loader2,
  Send,
} from "lucide-react";
import { toast } from "sonner";

interface TribeMember {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  rating: number;
  location: string;
  interests: string[];
}

interface TribeEvent {
  id: string;
  title: string;
  description: string;
  location: string;
  lat: number;
  lng: number;
  startTime: string;
  isRevealed: boolean;
  attendees: number;
  type: "bucket_list" | "game_night" | "social" | "adventure";
}

interface Message {
  id: string;
  sender: string;
  senderAvatar: string;
  content: string;
  timestamp: string;
}

export default function WheresMytribeWidget() {
  const [activeTab, setActiveTab] = useState<"discover" | "events" | "chat">(
    "discover"
  );
  const [tribeMembers, setTribeMembers] = useState<TribeMember[]>([]);
  const [upcomingEvents, setUpcomingEvents] = useState<TribeEvent[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageInput, setMessageInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [selectedMember, setSelectedMember] = useState<TribeMember | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);

  // Initialize WebSocket connection
  useEffect(() => {
    const backendUrl = process.env.VITE_BACKEND_URL || "http://localhost:8001";
    const wsUrl = backendUrl.replace("http", "ws") + "/ws/tribe-chat";

    wsRef.current = new WebSocket(wsUrl);

    wsRef.current.onopen = () => {
      console.log("Connected to Tribe Chat");
      toast.success("Connected to Tribe Chat");
    };

    wsRef.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === "message") {
        setMessages((prev) => [
          ...prev,
          {
            id: data.id,
            sender: data.sender,
            senderAvatar: data.senderAvatar,
            content: data.content,
            timestamp: new Date().toLocaleTimeString(),
          },
        ]);
      }
    };

    wsRef.current.onerror = (error) => {
      console.error("WebSocket error:", error);
      toast.error("Connection error");
    };

    return () => {
      wsRef.current?.close();
    };
  }, []);

  // Auto-scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Fetch tribe members
  useEffect(() => {
    if (activeTab === "discover") {
      fetchTribeMembers();
    }
  }, [activeTab]);

  // Fetch events
  useEffect(() => {
    if (activeTab === "events") {
      fetchUpcomingEvents();
    }
  }, [activeTab]);

  const fetchTribeMembers = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:8001"}/api/tribe/members`,
        {
          credentials: "include",
        }
      );
      const data = await response.json();
      setTribeMembers(data.members || []);
    } catch (error) {
      console.error("Error fetching tribe members:", error);
      toast.error("Failed to load tribe members");
    } finally {
      setIsLoading(false);
    }
  };

  const fetchUpcomingEvents = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:8001"}/api/tribe/events`,
        {
          credentials: "include",
        }
      );
      const data = await response.json();
      setUpcomingEvents(data.events || []);
    } catch (error) {
      console.error("Error fetching events:", error);
      toast.error("Failed to load events");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = () => {
    if (!messageInput.trim() || !wsRef.current) return;

    wsRef.current.send(
      JSON.stringify({
        type: "message",
        content: messageInput,
        recipient: selectedMember?.id,
      })
    );

    setMessageInput("");
  };

  const handleRateMember = async (memberId: string, rating: number) => {
    try {
      await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:8001"}/api/tribe/rate`,
        {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ memberId, rating }),
        }
      );
      toast.success("Rating submitted!");
    } catch (error) {
      console.error("Error rating member:", error);
      toast.error("Failed to submit rating");
    }
  };

  const handleJoinEvent = async (eventId: string) => {
    try {
      await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:8001"}/api/tribe/events/${eventId}/join`,
        {
          method: "POST",
          credentials: "include",
        }
      );
      toast.success("Joined event!");
      fetchUpcomingEvents();
    } catch (error) {
      console.error("Error joining event:", error);
      toast.error("Failed to join event");
    }
  };

  return (
    <div className="w-full space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Users className="w-12 h-12 text-purple-400" />
        </div>
        <h2 className="text-4xl font-bold mb-2" style={{
          background: "linear-gradient(135deg, #e0e0e8 0%, #ffffff 50%, #c0c0d0 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}>
          Where's My Tribe?
        </h2>
        <p className="text-gray-400">
          Find your people. Build your community. Create memories together.
        </p>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-2 border-b border-border/50">
        <Button
          onClick={() => setActiveTab("discover")}
          variant={activeTab === "discover" ? "default" : "ghost"}
          className="flex items-center gap-2"
        >
          <Heart className="w-4 h-4" />
          Discover
        </Button>
        <Button
          onClick={() => setActiveTab("events")}
          variant={activeTab === "events" ? "default" : "ghost"}
          className="flex items-center gap-2"
        >
          <MapPin className="w-4 h-4" />
          Events
        </Button>
        <Button
          onClick={() => setActiveTab("chat")}
          variant={activeTab === "chat" ? "default" : "ghost"}
          className="flex items-center gap-2"
        >
          <MessageCircle className="w-4 h-4" />
          Chat
        </Button>
      </div>

      {/* Discover Tab */}
      {activeTab === "discover" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {isLoading ? (
            <div className="col-span-full flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
          ) : tribeMembers.length === 0 ? (
            <div className="col-span-full text-center py-12 text-gray-400">
              <p>No tribe members found. Be the first to join!</p>
            </div>
          ) : (
            tribeMembers.map((member) => (
              <Card
                key={member.id}
                className="glass border-border/50 overflow-hidden hover:border-purple-500/50 transition-all"
              >
                <CardContent className="p-0">
                  <div className="h-32 bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-white font-bold text-xl">
                      {member.name.charAt(0)}
                    </div>
                  </div>

                  <div className="p-4 space-y-3">
                    <div>
                      <h3 className="font-semibold text-white">{member.name}</h3>
                      <p className="text-xs text-gray-400 flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {member.location}
                      </p>
                    </div>

                    <p className="text-sm text-gray-300">{member.bio}</p>

                    <div className="flex flex-wrap gap-1">
                      {member.interests.slice(0, 3).map((interest) => (
                        <span
                          key={interest}
                          className="text-xs px-2 py-1 bg-purple-500/20 border border-purple-500/30 rounded-full text-purple-300"
                        >
                          {interest}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-border/50">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                        <span className="text-sm font-medium text-white">
                          {member.rating.toFixed(1)}
                        </span>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          onClick={() => setSelectedMember(member)}
                          size="sm"
                          className="bg-purple-500 hover:bg-purple-600"
                        >
                          <MessageCircle className="w-3 h-3" />
                        </Button>
                        <Button
                          onClick={() => handleRateMember(member.id, 5)}
                          size="sm"
                          variant="outline"
                          className="border-border/50"
                        >
                          <Heart className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {/* Events Tab */}
      {activeTab === "events" && (
        <div className="space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
          ) : upcomingEvents.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <p>No upcoming events. Check back soon!</p>
            </div>
          ) : (
            upcomingEvents.map((event) => (
              <Card key={event.id} className="glass border-border/50">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-semibold text-white text-lg">
                        {event.title}
                      </h3>
                      <p className="text-sm text-gray-400 flex items-center gap-1 mt-1">
                        <MapPin className="w-4 h-4" />
                        {event.location}
                      </p>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        event.isRevealed
                          ? "bg-green-500/20 text-green-300"
                          : "bg-yellow-500/20 text-yellow-300"
                      }`}
                    >
                      {event.isRevealed ? "Revealed" : "Secret"}
                    </span>
                  </div>

                  <p className="text-gray-300 text-sm mb-4">{event.description}</p>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <span className="text-sm text-gray-400">
                        {event.attendees} attending
                      </span>
                      <span className="text-sm text-gray-400">
                        {new Date(event.startTime).toLocaleDateString()}
                      </span>
                    </div>

                    <Button
                      onClick={() => handleJoinEvent(event.id)}
                      className="bg-gradient-to-r from-purple-500 to-pink-600 hover:opacity-90"
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      Join Event
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {/* Chat Tab */}
      {activeTab === "chat" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Member List */}
          <div className="lg:col-span-1">
            <Card className="glass border-border/50">
              <CardHeader>
                <CardTitle className="text-lg">Recent Chats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {tribeMembers.slice(0, 5).map((member) => (
                  <button
                    key={member.id}
                    onClick={() => setSelectedMember(member)}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${
                      selectedMember?.id === member.id
                        ? "bg-purple-500/20 border border-purple-500/50"
                        : "hover:bg-background/50"
                    }`}
                  >
                    <p className="font-medium text-white text-sm">{member.name}</p>
                    <p className="text-xs text-gray-400">{member.location}</p>
                  </button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Chat Window */}
          <div className="lg:col-span-2">
            <Card className="glass border-border/50 h-96 flex flex-col">
              <CardHeader className="border-b border-border/50">
                <CardTitle className="text-lg">
                  {selectedMember ? selectedMember.name : "Select a member"}
                </CardTitle>
              </CardHeader>

              <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex gap-2 ${
                      msg.sender === "you" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-xs px-4 py-2 rounded-lg ${
                        msg.sender === "you"
                          ? "bg-purple-500/20 border border-purple-500/50"
                          : "bg-gray-800/50 border border-border/50"
                      }`}
                    >
                      <p className="text-sm text-gray-200">{msg.content}</p>
                      <p className="text-xs text-gray-500 mt-1">{msg.timestamp}</p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </CardContent>

              <div className="border-t border-border/50 p-4 flex gap-2">
                <Input
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter") handleSendMessage();
                  }}
                  placeholder="Type a message..."
                  className="bg-background/50 border-border/50"
                />
                <Button
                  onClick={handleSendMessage}
                  className="bg-purple-500 hover:bg-purple-600"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
