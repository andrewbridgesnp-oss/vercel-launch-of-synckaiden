import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Mic,
  MicOff,
  Shield,
  CheckCircle2,
  AlertCircle,
  Fingerprint,
  Lock,
  Volume2,
  Loader2,
} from 'lucide-react';

interface VoiceAuthProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  requiredAccess: 'financial' | 'personal' | 'admin';
}

const accessLevels = {
  financial: {
    title: 'Financial Data Access',
    description: 'Voice verification required to access sensitive financial information',
    phrase: 'My voice is my password, unlock my finances',
  },
  personal: {
    title: 'Personal Data Access',
    description: 'Voice verification required to access personal information',
    phrase: 'My voice is my password, show my data',
  },
  admin: {
    title: 'Admin Access',
    description: 'Voice verification required for administrative actions',
    phrase: 'My voice is my password, grant admin access',
  },
};

export function VoiceAuth({ isOpen, onClose, onSuccess, requiredAccess }: VoiceAuthProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<'idle' | 'recording' | 'processing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [audioLevel, setAudioLevel] = useState(0);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  const accessConfig = accessLevels[requiredAccess];

  useEffect(() => {
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Set up audio analysis for visualization
      audioContextRef.current = new AudioContext();
      analyserRef.current = audioContextRef.current.createAnalyser();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      source.connect(analyserRef.current);
      analyserRef.current.fftSize = 256;
      
      // Start visualization
      const updateAudioLevel = () => {
        if (analyserRef.current) {
          const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
          analyserRef.current.getByteFrequencyData(dataArray);
          const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
          setAudioLevel(average / 255 * 100);
        }
        animationFrameRef.current = requestAnimationFrame(updateAudioLevel);
      };
      updateAudioLevel();

      // Set up media recorder
      mediaRecorderRef.current = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];
      
      mediaRecorderRef.current.ondataavailable = (e) => {
        chunks.push(e.data);
      };
      
      mediaRecorderRef.current.onstop = async () => {
        // Stop visualization
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
        setAudioLevel(0);
        
        // Process the recording
        setStatus('processing');
        setIsProcessing(true);
        
        // Simulate voice verification (in production, this would call a real API)
        let progressValue = 0;
        const progressInterval = setInterval(() => {
          progressValue += 10;
          setProgress(progressValue);
          if (progressValue >= 100) {
            clearInterval(progressInterval);
            // Simulate success (90% success rate for demo)
            const isSuccess = Math.random() > 0.1;
            if (isSuccess) {
              setStatus('success');
              setTimeout(() => {
                onSuccess();
                onClose();
              }, 1500);
            } else {
              setStatus('error');
              setErrorMessage('Voice not recognized. Please try again.');
            }
            setIsProcessing(false);
          }
        }, 200);
        
        // Clean up stream
        stream.getTracks().forEach(track => track.stop());
      };
      
      mediaRecorderRef.current.start();
      setIsRecording(true);
      setStatus('recording');
      
      // Auto-stop after 5 seconds
      setTimeout(() => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
          stopRecording();
        }
      }, 5000);
      
    } catch (error) {
      console.error('Error accessing microphone:', error);
      setStatus('error');
      setErrorMessage('Could not access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const resetState = () => {
    setStatus('idle');
    setProgress(0);
    setErrorMessage('');
    setAudioLevel(0);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            {accessConfig.title}
          </DialogTitle>
          <DialogDescription>
            {accessConfig.description}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Security Badge */}
          <div className="flex justify-center">
            <Badge variant="outline" className="gap-2 px-4 py-2">
              <Lock className="h-3 w-3" />
              End-to-End Encrypted
            </Badge>
          </div>

          {/* Voice Visualization */}
          <div className="relative">
            <div className={`w-32 h-32 mx-auto rounded-full flex items-center justify-center transition-all duration-300 ${
              status === 'recording' 
                ? 'bg-primary/20 animate-pulse' 
                : status === 'success'
                ? 'bg-green-500/20'
                : status === 'error'
                ? 'bg-destructive/20'
                : 'bg-secondary'
            }`}>
              {/* Audio level rings */}
              {isRecording && (
                <>
                  <div 
                    className="absolute inset-0 rounded-full border-2 border-primary/50 animate-ping"
                    style={{ transform: `scale(${1 + audioLevel / 100})` }}
                  />
                  <div 
                    className="absolute inset-2 rounded-full border border-primary/30"
                    style={{ transform: `scale(${1 + audioLevel / 150})` }}
                  />
                </>
              )}
              
              {/* Icon */}
              {status === 'idle' && <Fingerprint className="h-12 w-12 text-muted-foreground" />}
              {status === 'recording' && <Mic className="h-12 w-12 text-primary animate-pulse" />}
              {status === 'processing' && <Loader2 className="h-12 w-12 text-primary animate-spin" />}
              {status === 'success' && <CheckCircle2 className="h-12 w-12 text-green-500" />}
              {status === 'error' && <AlertCircle className="h-12 w-12 text-destructive" />}
            </div>
          </div>

          {/* Instructions */}
          <div className="text-center space-y-2">
            {status === 'idle' && (
              <>
                <p className="text-sm text-muted-foreground">Please say the following phrase:</p>
                <p className="font-medium text-primary">"{accessConfig.phrase}"</p>
              </>
            )}
            {status === 'recording' && (
              <>
                <p className="text-sm text-primary font-medium">Listening...</p>
                <div className="flex items-center justify-center gap-2">
                  <Volume2 className="h-4 w-4 text-muted-foreground" />
                  <div className="w-32 h-2 bg-secondary rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary transition-all duration-100"
                      style={{ width: `${audioLevel}%` }}
                    />
                  </div>
                </div>
              </>
            )}
            {status === 'processing' && (
              <>
                <p className="text-sm text-muted-foreground">Verifying your voice...</p>
                <Progress value={progress} className="w-48 mx-auto" />
              </>
            )}
            {status === 'success' && (
              <p className="text-sm text-green-500 font-medium">Voice verified successfully!</p>
            )}
            {status === 'error' && (
              <p className="text-sm text-destructive">{errorMessage}</p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-center gap-2">
            {status === 'idle' && (
              <Button onClick={startRecording} className="gap-2 btn-shine">
                <Mic className="h-4 w-4" />
                Start Recording
              </Button>
            )}
            {status === 'recording' && (
              <Button onClick={stopRecording} variant="destructive" className="gap-2">
                <MicOff className="h-4 w-4" />
                Stop Recording
              </Button>
            )}
            {status === 'error' && (
              <Button onClick={resetState} variant="outline" className="gap-2">
                Try Again
              </Button>
            )}
          </div>

          {/* Security Notice */}
          <p className="text-xs text-center text-muted-foreground">
            Your voice data is processed locally and never stored or shared with third parties.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default VoiceAuth;
