import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function AgentSwarmDashboard() {
  const [selectedAgent, setSelectedAgent] = useState<number | null>(0);

  const agents = [
    { id: 0, name: "Kaiden Prime", type: "Autonomous", status: "active", efficiency: 94, tasks: 247 },
    { id: 1, name: "Marketing Agent", type: "Collaborative", status: "active", efficiency: 87, tasks: 156 },
    { id: 2, name: "Sales Agent", type: "Supervised", status: "idle", efficiency: 91, tasks: 203 },
    { id: 3, name: "Support Agent", type: "Autonomous", status: "active", efficiency: 89, tasks: 312 },
    { id: 4, name: "Analytics Agent", type: "Autonomous", status: "active", efficiency: 96, tasks: 89 },
  ];

  const performanceData = [
    { name: "Mon", efficiency: 85, tasks: 45 },
    { name: "Tue", efficiency: 88, tasks: 52 },
    { name: "Wed", efficiency: 91, tasks: 48 },
    { name: "Thu", efficiency: 89, tasks: 61 },
    { name: "Fri", efficiency: 94, tasks: 58 },
    { name: "Sat", efficiency: 92, tasks: 42 },
    { name: "Sun", efficiency: 87, tasks: 39 },
  ];

  const agentTypeDistribution = [
    { name: "Autonomous", value: 3, color: "#3b82f6" },
    { name: "Collaborative", value: 1, color: "#8b5cf6" },
    { name: "Supervised", value: 1, color: "#ec4899" },
  ];

  const tasksByAgent = agents.map(a => ({ name: a.name.split(" ")[0], tasks: a.tasks }));

  return (
    <div className="min-h-screen bg-background text-foreground p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Agent Swarm Dashboard</h1>
          <p className="text-muted-foreground">Monitor and manage your autonomous AI agents in real-time</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Agents</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">4</div>
              <p className="text-xs text-muted-foreground mt-1">of 5 agents running</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Avg Efficiency</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">91%</div>
              <p className="text-xs text-muted-foreground mt-1">↑ 3% from last week</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Tasks Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">1,007</div>
              <p className="text-xs text-muted-foreground mt-1">This week</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">System Health</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">99.8%</div>
              <p className="text-xs text-muted-foreground mt-1">Uptime</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Agent List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Your Agents</CardTitle>
              <CardDescription>Manage and monitor each agent</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {agents.map((agent) => (
                <div
                  key={agent.id}
                  onClick={() => setSelectedAgent(agent.id)}
                  className={`p-3 rounded-lg cursor-pointer transition-all ${
                    selectedAgent === agent.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted hover:bg-muted/80"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-medium text-sm">{agent.name}</div>
                    <Badge
                      variant={agent.status === "active" ? "default" : "secondary"}
                      className="text-xs"
                    >
                      {agent.status}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground space-y-1">
                    <div>Type: {agent.type}</div>
                    <div>Efficiency: {agent.efficiency}%</div>
                    <div>Tasks: {agent.tasks}</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Performance Chart */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Weekly Performance</CardTitle>
              <CardDescription>Agent efficiency and task completion trends</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                  <XAxis dataKey="name" stroke="rgba(255,255,255,0.5)" />
                  <YAxis stroke="rgba(255,255,255,0.5)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(0,0,0,0.8)",
                      border: "1px solid rgba(255,255,255,0.2)",
                    }}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="efficiency" stroke="#3b82f6" strokeWidth={2} />
                  <Line type="monotone" dataKey="tasks" stroke="#8b5cf6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Tasks by Agent */}
          <Card>
            <CardHeader>
              <CardTitle>Tasks by Agent</CardTitle>
              <CardDescription>Distribution of completed tasks</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={tasksByAgent}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                  <XAxis dataKey="name" stroke="rgba(255,255,255,0.5)" />
                  <YAxis stroke="rgba(255,255,255,0.5)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(0,0,0,0.8)",
                      border: "1px solid rgba(255,255,255,0.2)",
                    }}
                  />
                  <Bar dataKey="tasks" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Agent Type Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Agent Type Distribution</CardTitle>
              <CardDescription>Breakdown by agent classification</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={agentTypeDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {agentTypeDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(0,0,0,0.8)",
                      border: "1px solid rgba(255,255,255,0.2)",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Selected Agent Details */}
        {selectedAgent !== null && (
          <Card>
            <CardHeader>
              <CardTitle>{agents[selectedAgent].name} - Detailed View</CardTitle>
              <CardDescription>Real-time monitoring and control</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Status</div>
                  <Badge variant={agents[selectedAgent].status === "active" ? "default" : "secondary"}>
                    {agents[selectedAgent].status}
                  </Badge>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Efficiency Score</div>
                  <div className="text-2xl font-bold">{agents[selectedAgent].efficiency}%</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Tasks Completed</div>
                  <div className="text-2xl font-bold">{agents[selectedAgent].tasks}</div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button>Pause Agent</Button>
                <Button variant="outline">View Logs</Button>
                <Button variant="outline">Configure</Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
