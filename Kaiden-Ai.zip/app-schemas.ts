/**
 * App-Specific Database Schemas
 * Each app has isolated tables with {appId}_ prefix
 */

import { mysqlTable, int, varchar, timestamp, json, enum as mysqlEnum, text } from 'drizzle-orm/mysql-core';
import { users } from './schema';

// ============================================================================
// SHARED: User App Installations (Kaiden Core)
// ============================================================================

export const userAppInstalls = mysqlTable('userAppInstalls', {
  id: int().primaryKey().autoincrement(),
  userId: int().notNull().references(() => users.id),
  appId: varchar(255).notNull(), // 'househack-203k', 'syndica', etc.
  tier: mysqlEnum('tier', ['free', 'starter', 'pro', 'enterprise']).notNull().default('free'),
  licenseKey: varchar(255),
  status: mysqlEnum('status', ['trial', 'active', 'paused', 'expired']).notNull().default('active'),
  config: json(), // App-specific configuration
  installedAt: timestamp().defaultNow(),
  expiresAt: timestamp(),
  updatedAt: timestamp().onUpdateNow(),
});

// ============================================================================
// HOUSEHACK 203K: Isolated App Tables
// ============================================================================

export const househack_dealRooms = mysqlTable('househack_dealRooms', {
  id: int().primaryKey().autoincrement(),
  userId: int().notNull().references(() => users.id),
  appId: varchar(255).notNull().default('househack-203k'),
  name: varchar(255).notNull(),
  propertyAddress: varchar(500),
  propertyType: varchar(100), // 'single-family', 'multi-family', 'condo', etc.
  purchasePrice: int(), // in cents
  renovationBudget: int(), // in cents
  status: mysqlEnum('status', ['draft', 'active', 'completed', 'archived']).notNull().default('draft'),
  data: json(), // Flexible app-specific data
  createdAt: timestamp().defaultNow(),
  updatedAt: timestamp().onUpdateNow(),
});

export const househack_calculations = mysqlTable('househack_calculations', {
  id: int().primaryKey().autoincrement(),
  userId: int().notNull().references(() => users.id),
  dealRoomId: int().notNull().references(() => househack_dealRooms.id),
  appId: varchar(255).notNull().default('househack-203k'),
  type: varchar(100), // 'roi', 'cashflow', 'appreciation', etc.
  result: json(), // Calculation results
  createdAt: timestamp().defaultNow(),
  updatedAt: timestamp().onUpdateNow(),
});

export const househack_teamMembers = mysqlTable('househack_teamMembers', {
  id: int().primaryKey().autoincrement(),
  userId: int().notNull().references(() => users.id),
  dealRoomId: int().notNull().references(() => househack_dealRooms.id),
  appId: varchar(255).notNull().default('househack-203k'),
  memberEmail: varchar(255).notNull(),
  role: varchar(100), // 'owner', 'agent', 'lender', 'contractor', etc.
  permissions: json(), // Role-specific permissions
  invitedAt: timestamp().defaultNow(),
  acceptedAt: timestamp(),
});

// ============================================================================
// SYNDICA: Isolated App Tables
// ============================================================================

export const syndica_ingestions = mysqlTable('syndica_ingestions', {
  id: int().primaryKey().autoincrement(),
  userId: int().notNull().references(() => users.id),
  appId: varchar(255).notNull().default('syndica'),
  name: varchar(255).notNull(),
  source: varchar(255).notNull(), // 'csv', 'api', 'database', 'webhook', etc.
  sourceConfig: json(), // Source-specific configuration
  status: mysqlEnum('status', ['pending', 'processing', 'complete', 'failed']).notNull().default('pending'),
  recordsProcessed: int().default(0),
  recordsFailed: int().default(0),
  errorMessage: text(),
  data: json(), // Ingestion metadata
  createdAt: timestamp().defaultNow(),
  updatedAt: timestamp().onUpdateNow(),
});

export const syndica_compositions = mysqlTable('syndica_compositions', {
  id: int().primaryKey().autoincrement(),
  userId: int().notNull().references(() => users.id),
  appId: varchar(255).notNull().default('syndica'),
  name: varchar(255).notNull(),
  ingestionId: int().notNull().references(() => syndica_ingestions.id),
  template: varchar(255), // 'email', 'report', 'summary', etc.
  output: text(), // Composed content
  status: mysqlEnum('status', ['draft', 'published', 'archived']).notNull().default('draft'),
  metadata: json(),
  createdAt: timestamp().defaultNow(),
  updatedAt: timestamp().onUpdateNow(),
});

export const syndica_workflows = mysqlTable('syndica_workflows', {
  id: int().primaryKey().autoincrement(),
  userId: int().notNull().references(() => users.id),
  appId: varchar(255).notNull().default('syndica'),
  name: varchar(255).notNull(),
  description: text(),
  steps: json(), // Workflow steps configuration
  isActive: int().notNull().default(1), // 1 = true, 0 = false
  triggerConfig: json(), // When workflow runs
  createdAt: timestamp().defaultNow(),
  updatedAt: timestamp().onUpdateNow(),
});

// ============================================================================
// TEMPLATE: For New Apps (Copy and Modify)
// ============================================================================

export const template_resources = mysqlTable('template_resources', {
  id: int().primaryKey().autoincrement(),
  userId: int().notNull().references(() => users.id),
  appId: varchar(255).notNull(), // 'your-app-id'
  name: varchar(255).notNull(),
  type: varchar(100), // App-specific resource type
  status: mysqlEnum('status', ['active', 'inactive', 'archived']).notNull().default('active'),
  data: json(), // App-specific data
  createdAt: timestamp().defaultNow(),
  updatedAt: timestamp().onUpdateNow(),
});

// ============================================================================
// AUDIT LOGS: Shared Across All Apps
// ============================================================================

export const appAuditLogs = mysqlTable('appAuditLogs', {
  id: int().primaryKey().autoincrement(),
  userId: int().notNull().references(() => users.id),
  appId: varchar(255).notNull(),
  action: varchar(255).notNull(), // 'create', 'update', 'delete', etc.
  resource: varchar(255), // Resource type
  resourceId: int(),
  changes: json(), // What changed
  ipAddress: varchar(45),
  userAgent: text(),
  timestamp: timestamp().defaultNow(),
});

// ============================================================================
// USAGE TRACKING: Per-App Usage Metrics
// ============================================================================

export const appUsageMetrics = mysqlTable('appUsageMetrics', {
  id: int().primaryKey().autoincrement(),
  userId: int().notNull().references(() => users.id),
  appId: varchar(255).notNull(),
  metricName: varchar(255).notNull(), // 'api_calls', 'storage_used', 'features_used', etc.
  value: int().notNull(),
  period: varchar(50).notNull(), // 'daily', 'monthly', 'yearly'
  date: timestamp().notNull(),
  createdAt: timestamp().defaultNow(),
});

// ============================================================================
// KEY PRINCIPLES FOR NEW APPS
// ============================================================================

/**
 * When creating a new app schema:
 * 
 * 1. Prefix all tables with {appId}_ (e.g., househack_, syndica_, yourapp_)
 * 2. Always include userId for access control
 * 3. Always include appId for multi-tenancy
 * 4. Always include timestamps (createdAt, updatedAt)
 * 5. Use json() for flexible app-specific data
 * 6. Never reference another app's tables
 * 7. Define your own status enums for your resources
 * 8. Use int() for IDs (auto-increment)
 * 9. Use varchar() for strings with reasonable limits
 * 10. Use text() for long content
 * 
 * Example for a new app called "YourApp":
 * 
 * export const yourapp_projects = mysqlTable('yourapp_projects', {
 *   id: int().primaryKey().autoincrement(),
 *   userId: int().notNull().references(() => users.id),
 *   appId: varchar(255).notNull().default('yourapp'),
 *   name: varchar(255).notNull(),
 *   status: mysqlEnum('status', ['active', 'completed', 'archived']).default('active'),
 *   data: json(),
 *   createdAt: timestamp().defaultNow(),
 *   updatedAt: timestamp().onUpdateNow(),
 * });
 */
