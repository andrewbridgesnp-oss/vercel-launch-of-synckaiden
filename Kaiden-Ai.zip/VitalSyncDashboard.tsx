/**
 * VitalSync Health Tracking Dashboard
 * 
 * Integrates health metrics, wearable data, and wellness tracking.
 */

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Heart,
  Activity,
  Zap,
  TrendingUp,
  Calendar,
  Settings,
  Loader2,
  Download,
  Share2,
} from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { toast } from "sonner";

interface HealthMetric {
  date: string;
  heartRate: number;
  steps: number;
  calories: number;
  sleep: number;
  stress: number;
  bloodPressure: { systolic: number; diastolic: number };
  bloodOxygen: number;
}

interface WearableDevice {
  id: string;
  name: string;
  type: "smartwatch" | "fitbit" | "oura" | "whoop" | "apple_watch";
  connected: boolean;
  lastSync: string;
  batteryLevel: number;
}

export default function VitalSyncDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [metrics, setMetrics] = useState<HealthMetric[]>([]);
  const [devices, setDevices] = useState<WearableDevice[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [timeRange, setTimeRange] = useState("7d");
  const [todayMetrics, setTodayMetrics] = useState<HealthMetric | null>(null);

  // Fetch health metrics
  useEffect(() => {
    fetchHealthMetrics();
    fetchConnectedDevices();
  }, [timeRange]);

  const fetchHealthMetrics = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/vitalsync/metrics?range=${timeRange}`,
        {
          credentials: "include",
        }
      );
      const data = await response.json();
      setMetrics(data.metrics || []);
      setTodayMetrics(data.today || null);
    } catch (error) {
      console.error("Error fetching metrics:", error);
      toast.error("Failed to load health metrics");
    } finally {
      setIsLoading(false);
    }
  };

  const fetchConnectedDevices = async () => {
    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/vitalsync/devices`,
        {
          credentials: "include",
        }
      );
      const data = await response.json();
      setDevices(data.devices || []);
    } catch (error) {
      console.error("Error fetching devices:", error);
    }
  };

  const handleConnectDevice = async (deviceType: string) => {
    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/vitalsync/connect`,
        {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ deviceType }),
        }
      );
      const data = await response.json();
      if (data.authUrl) {
        window.open(data.authUrl, "_blank");
        toast.info("Authorize the connection in the new window");
      }
    } catch (error) {
      console.error("Error connecting device:", error);
      toast.error("Failed to connect device");
    }
  };

  const handleExportData = async () => {
    try {
      const response = await fetch(
        `${process.env.VITE_BACKEND_URL || "http://localhost:3000"}/api/vitalsync/export`,
        {
          credentials: "include",
        }
      );
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `vitalsync-data-${new Date().toISOString().split("T")[0]}.csv`;
      a.click();
      toast.success("Data exported successfully");
    } catch (error) {
      console.error("Error exporting data:", error);
      toast.error("Failed to export data");
    }
  };

  const getHealthScore = (metric: HealthMetric): number => {
    let score = 100;
    if (metric.heartRate > 100) score -= 10;
    if (metric.heartRate < 60) score -= 5;
    if (metric.steps < 5000) score -= 15;
    if (metric.sleep < 7) score -= 20;
    if (metric.stress > 7) score -= 15;
    if (metric.bloodPressure.systolic > 140) score -= 20;
    return Math.max(0, score);
  };

  return (
    <div className="w-full space-y-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Heart className="w-12 h-12 text-red-400" />
        </div>
        <h2 className="text-4xl font-bold mb-2" style={{
          background: "linear-gradient(135deg, #e0e0e8 0%, #ffffff 50%, #c0c0d0 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
        }}>
          VitalSync
        </h2>
        <p className="text-gray-400">
          Track your health metrics and wellness journey in real-time.
        </p>
      </div>

      {/* Time Range Selector */}
      <div className="flex gap-2 flex-wrap">
        {["24h", "7d", "30d", "90d"].map((range) => (
          <Button
            key={range}
            onClick={() => setTimeRange(range)}
            variant={timeRange === range ? "default" : "outline"}
            className="border-border/50"
          >
            {range}
          </Button>
        ))}
      </div>

      {/* Today's Overview */}
      {todayMetrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="glass border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Heart Rate</p>
                  <p className="text-3xl font-bold text-red-400">
                    {todayMetrics.heartRate}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">bpm</p>
                </div>
                <Heart className="w-12 h-12 text-red-400 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="glass border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Steps</p>
                  <p className="text-3xl font-bold text-blue-400">
                    {todayMetrics.steps.toLocaleString()}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">steps</p>
                </div>
                <Activity className="w-12 h-12 text-blue-400 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="glass border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Sleep</p>
                  <p className="text-3xl font-bold text-purple-400">
                    {todayMetrics.sleep}h
                  </p>
                  <p className="text-xs text-gray-500 mt-1">hours</p>
                </div>
                <Zap className="w-12 h-12 text-purple-400 opacity-20" />
              </div>
            </CardContent>
          </Card>

          <Card className="glass border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Health Score</p>
                  <p className="text-3xl font-bold text-green-400">
                    {getHealthScore(todayMetrics)}%
                  </p>
                  <p className="text-xs text-gray-500 mt-1">overall</p>
                </div>
                <TrendingUp className="w-12 h-12 text-green-400 opacity-20" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-background/50 border border-border/50">
          <TabsTrigger value="overview">Trends</TabsTrigger>
          <TabsTrigger value="devices">Devices</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        {/* Trends Tab */}
        <TabsContent value="overview" className="space-y-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
          ) : (
            <>
              {/* Heart Rate Trend */}
              <Card className="glass border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="w-5 h-5 text-red-400" />
                    Heart Rate Trend
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={metrics}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
                      <YAxis stroke="rgba(255,255,255,0.5)" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "rgba(0,0,0,0.8)",
                          border: "1px solid rgba(255,255,255,0.2)",
                        }}
                      />
                      <Line
                        type="monotone"
                        dataKey="heartRate"
                        stroke="#ef4444"
                        dot={false}
                        strokeWidth={2}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Activity Metrics */}
              <Card className="glass border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-blue-400" />
                    Activity & Sleep
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={metrics}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
                      <YAxis stroke="rgba(255,255,255,0.5)" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "rgba(0,0,0,0.8)",
                          border: "1px solid rgba(255,255,255,0.2)",
                        }}
                      />
                      <Bar dataKey="steps" fill="#3b82f6" name="Steps" />
                      <Bar dataKey="sleep" fill="#a855f7" name="Sleep (hrs)" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Devices Tab */}
        <TabsContent value="devices" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {devices.map((device) => (
              <Card key={device.id} className="glass border-border/50">
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-white">{device.name}</h3>
                      <p className="text-xs text-gray-400 mt-1">
                        {device.type.replace("_", " ").toUpperCase()}
                      </p>
                    </div>
                    <div
                      className={`w-3 h-3 rounded-full ${
                        device.connected ? "bg-green-500" : "bg-gray-500"
                      }`}
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Battery</span>
                      <span className="text-white">{device.batteryLevel}%</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-green-500 to-yellow-500 h-2 rounded-full"
                        style={{ width: `${device.batteryLevel}%` }}
                      />
                    </div>
                  </div>

                  <p className="text-xs text-gray-500">
                    Last sync: {new Date(device.lastSync).toLocaleString()}
                  </p>
                </CardContent>
              </Card>
            ))}

            {/* Connect New Device */}
            <Card className="glass border-border/50 border-dashed">
              <CardContent className="p-6 flex flex-col items-center justify-center h-full space-y-4">
                <div className="w-12 h-12 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                  <Settings className="w-6 h-6 text-cyan-400" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-white">Connect Device</p>
                  <p className="text-xs text-gray-400 mt-1">
                    Add a wearable to track your health
                  </p>
                </div>
                <Button
                  onClick={() => handleConnectDevice("smartwatch")}
                  className="w-full bg-cyan-500 hover:bg-cyan-600"
                >
                  Connect
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Insights Tab */}
        <TabsContent value="insights" className="space-y-6">
          <Card className="glass border-border/50">
            <CardHeader>
              <CardTitle>Health Insights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                <p className="text-sm text-green-300">
                  ✓ You're averaging 8,500 steps per day. Keep it up!
                </p>
              </div>

              <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                <p className="text-sm text-yellow-300">
                  ⚠ Your sleep has decreased by 1 hour this week. Try to get more rest.
                </p>
              </div>

              <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                <p className="text-sm text-blue-300">
                  ℹ Your stress levels are trending down. Great job managing stress!
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Export & Share */}
          <div className="flex gap-4">
            <Button
              onClick={handleExportData}
              className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:opacity-90"
            >
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
            <Button
              variant="outline"
              className="flex-1 border-border/50"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share Report
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
