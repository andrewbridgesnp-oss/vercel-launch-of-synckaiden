import React, { useState } from 'react';
import { ChevronRight, Zap } from 'lucide-react';
import '../styles/liquid-glass.css';

interface SmartSyncButtonProps {
  onSync?: () => void;
  className?: string;
}

export const SmartSyncButton: React.FC<SmartSyncButtonProps> = ({
  onSync,
  className = '',
}) => {
  const [showMenu, setShowMenu] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSync = async (destination: 'dashboard' | 'onboarding' | 'personality') => {
    setIsLoading(true);
    
    // Track event
    if (onSync) {
      onSync();
    }

    // Simulate sync delay
    await new Promise(resolve => setTimeout(resolve, 800));

    // Navigate based on selection
    switch (destination) {
      case 'dashboard':
        window.location.href = '/dashboard';
        break;
      case 'onboarding':
        window.location.href = '/onboarding';
        break;
      case 'personality':
        window.location.href = '/';
        break;
      default:
        window.location.href = '/dashboard';
    }

    setIsLoading(false);
    setShowMenu(false);
  };

  return (
    <div className={`relative ${className}`}>
      {/* Main Sync Button */}
      <button
        onClick={() => setShowMenu(!showMenu)}
        disabled={isLoading}
        className="liquid-glass-button group relative px-8 py-3 rounded-lg border border-cyan-400/50 hover:border-cyan-400 transition-all duration-300 flex items-center gap-3"
      >
        <Zap className="w-5 h-5 group-hover:animate-pulse" />
        <span className="text-lg font-bold tracking-widest">
          {isLoading ? 'Syncing...' : 'Sync Now'}
        </span>
        <ChevronRight className={`w-5 h-5 transition-transform ${showMenu ? 'rotate-90' : ''}`} />
      </button>

      {/* Dropdown Menu */}
      {showMenu && !isLoading && (
        <div className="absolute top-full mt-3 right-0 w-72 bg-slate-900/95 backdrop-blur-md border border-cyan-400/30 rounded-lg shadow-2xl z-50 overflow-hidden">
          {/* Menu Header */}
          <div className="px-6 py-4 border-b border-cyan-400/20 bg-gradient-to-r from-cyan-500/10 to-blue-500/10">
            <h3 className="liquid-glass-text text-lg font-bold">
              Choose Your Path
            </h3>
            <p className="text-cyan-300/70 text-sm mt-1">
              Where would you like to sync to?
            </p>
          </div>

          {/* Menu Items */}
          <div className="p-4 space-y-2">
            {/* Dashboard Option */}
            <button
              onClick={() => handleSync('dashboard')}
              className="w-full px-4 py-3 rounded-lg bg-slate-800/50 hover:bg-cyan-500/20 border border-cyan-400/30 hover:border-cyan-400 transition-all text-left group"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="liquid-glass-text font-bold">Dashboard</p>
                  <p className="text-cyan-300/60 text-sm mt-1">
                    View your analytics and KPIs
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-cyan-400 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>

            {/* Onboarding Option */}
            <button
              onClick={() => handleSync('onboarding')}
              className="w-full px-4 py-3 rounded-lg bg-slate-800/50 hover:bg-cyan-500/20 border border-cyan-400/30 hover:border-cyan-400 transition-all text-left group"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="liquid-glass-text font-bold">Sync with Kaiden</p>
                  <p className="text-cyan-300/60 text-sm mt-1">
                    Begin onboarding with AI assistant
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-cyan-400 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>

            {/* Personality Selection Option */}
            <button
              onClick={() => handleSync('personality')}
              className="w-full px-4 py-3 rounded-lg bg-slate-800/50 hover:bg-cyan-500/20 border border-cyan-400/30 hover:border-cyan-400 transition-all text-left group"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="liquid-glass-text font-bold">Choose Personality</p>
                  <p className="text-cyan-300/60 text-sm mt-1">
                    Select your preferred AI personality
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-cyan-400 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
          </div>

          {/* Menu Footer */}
          <div className="px-6 py-3 border-t border-cyan-400/20 bg-slate-800/30">
            <button
              onClick={() => setShowMenu(false)}
              className="w-full text-center text-cyan-300/60 hover:text-cyan-300 text-sm transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 rounded-lg bg-cyan-500/20 flex items-center justify-center">
          <div className="animate-spin">
            <Zap className="w-6 h-6 text-cyan-400" />
          </div>
        </div>
      )}
    </div>
  );
};

export default SmartSyncButton;
