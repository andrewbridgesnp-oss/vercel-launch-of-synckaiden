/**
 * Approval Workflow Service
 * Manages approval workflows, tasks, and gating
 */

import { getDb } from '../db';
import {
  workflows,
  approvalTasks,
  approvals,
  approvalGates,
  approvalHistory,
  type Workflow,
  type ApprovalTask,
  type Approval,
  type ApprovalGate,
} from '../../drizzle/approval-schema';
import { eq, and } from 'drizzle-orm';

export interface CreateWorkflowInput {
  userId: string;
  name: string;
  description?: string;
  approvalLevels?: number;
  requiresAllApprovals?: boolean;
  autoApproveAfterDays?: number;
}

export interface CreateTaskInput {
  workflowId: number;
  userId: string;
  title: string;
  description?: string;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  assignedTo?: string;
  dueDate?: Date;
}

export interface CreateApprovalInput {
  taskId: number;
  workflowId: number;
  approverUserId: string;
  approvalLevel?: 'low' | 'medium' | 'high' | 'critical';
}

export class ApprovalWorkflowService {
  /**
   * Create a new workflow
   */
  async createWorkflow(input: CreateWorkflowInput) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    const workflow = await db
      .insert(workflows)
      .values({
        userId: input.userId,
        name: input.name,
        description: input.description,
        approvalLevels: input.approvalLevels || 1,
        requiresAllApprovals: input.requiresAllApprovals !== false,
        autoApproveAfterDays: input.autoApproveAfterDays,
      })
      .returning();

    return workflow[0];
  }

  /**
   * Create a task within a workflow
   */
  async createTask(input: CreateTaskInput) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    const task = await db
      .insert(approvalTasks)
      .values({
        workflowId: input.workflowId,
        userId: input.userId,
        title: input.title,
        description: input.description,
        priority: input.priority || 'medium',
        assignedTo: input.assignedTo,
        dueDate: input.dueDate,
      })
      .returning();

    return task[0];
  }

  /**
   * Create an approval for a task
   */
  async createApproval(input: CreateApprovalInput) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    const approval = await db
      .insert(approvals)
      .values({
        taskId: input.taskId,
        workflowId: input.workflowId,
        approverUserId: input.approverUserId,
        approvalLevel: input.approvalLevel || 'medium',
      })
      .returning();

    // Record history
    await this.recordHistory(approval[0].id, 'submitted', input.approverUserId);

    return approval[0];
  }

  /**
   * Approve a task
   */
  async approveTask(approvalId: string, approverUserId: string, comments?: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    const approval = await db
      .update(approvals)
      .set({
        status: 'approved',
        approvedAt: new Date(),
        comments,
        updatedAt: new Date(),
      })
      .where(eq(approvals.id, approvalId))
      .returning();

    // Record history
    await this.recordHistory(approvalId, 'approved', approverUserId, {
      comments,
    });

    return approval[0];
  }

  /**
   * Reject a task
   */
  async rejectTask(approvalId: string, approverUserId: string, comments?: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    const approval = await db
      .update(approvals)
      .set({
        status: 'rejected',
        rejectedAt: new Date(),
        comments,
        updatedAt: new Date(),
      })
      .where(eq(approvals.id, approvalId))
      .returning();

    // Record history
    await this.recordHistory(approvalId, 'rejected', approverUserId, {
      comments,
    });

    return approval[0];
  }

  /**
   * Get workflow by ID
   */
  async getWorkflow(workflowId: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    const workflow = await db
      .select()
      .from(workflows)
      .where(eq(workflows.id, workflowId));

    return workflow[0] || null;
  }

  /**
   * Get all workflows for a user
   */
  async getUserWorkflows(userId: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    return await db
      .select()
      .from(workflows)
      .where(eq(workflows.userId, userId));
  }

  /**
   * Get tasks for a workflow
   */
  async getWorkflowTasks(workflowId: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    return await db
      .select()
      .from(approvalTasks)
      .where(eq(approvalTasks.workflowId, workflowId));
  }

  /**
   * Get pending approvals for a user
   */
  async getPendingApprovalsForUser(userId: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    return await db
      .select()
      .from(approvals)
      .where(
        and(
          eq(approvals.approverUserId, userId),
          eq(approvals.status, 'pending')
        )
      );
  }

  /**
   * Check if feature is gated
   */
  async isFeatureGated(userId: string, featureName: string): Promise<boolean> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    const gate = await db
      .select()
      .from(approvalGates)
      .where(
        and(
          eq(approvalGates.userId, userId),
          eq(approvalGates.featureName, featureName),
          eq(approvalGates.isGated, true)
        )
      );

    if (gate.length === 0) return false;

    const gateRecord = gate[0];
    if (gateRecord.expiresAt && gateRecord.expiresAt < new Date()) {
      // Gate has expired, remove it
      const db2 = await getDb();
      if (db2) await db2
        .delete(approvalGates)
        .where(eq(approvalGates.id, gateRecord.id));
      return false;
    }

    // Check if all required approvals are met
    return gateRecord.currentApprovals < gateRecord.requiredApprovals;
  }

  /**
   * Create approval gate for feature
   */
  async createApprovalGate(
    userId: string,
    featureName: string,
    requiredApprovals: number,
    expiresAt?: Date
  ) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    const gate = await db
      .insert(approvalGates)
      .values({
        userId,
        featureName,
        requiredApprovals,
        isGated: true,
        expiresAt,
      })
      .returning();

    return gate[0];
  }

  /**
   * Record approval history
   */
  private async recordHistory(
    approvalId: string,
    action: string,
    performedBy: string,
    details?: any
  ) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    await db.insert(approvalHistory).values({
      approvalId,
      action,
      performedBy,
      details,
    });
  }

  /**
   * Get approval history
   */
  async getApprovalHistory(approvalId: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    return await db
      .select()
      .from(approvalHistory)
      .where(eq(approvalHistory.approvalId, approvalId));
  }

  /**
   * Get task status
   */
  async getTaskStatus(taskId: string) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    const task = await db
      .select()
      .from(approvalTasks)
      .where(eq(approvalTasks.id, taskId));

    if (!task[0]) return null;

    const taskApprovals = await db
      .select()
      .from(approvals)
      .where(eq(approvals.taskId, taskId));

    return {
      task: task[0],
      approvals: taskApprovals,
      approvalCount: taskApprovals.filter((a: any) => a.status === 'approved').length,
      rejectionCount: taskApprovals.filter((a: any) => a.status === 'rejected').length,
      pendingCount: taskApprovals.filter((a: any) => a.status === 'pending').length,
    };
  }
}

export const approvalService = new ApprovalWorkflowService();
