/**
 * Unified App Router for all 10 Kaiden Apps
 * Routes all apps through single entry point
 * Preserves existing styling and layout
 */

import React, { Suspense, lazy } from 'react';
// import { useParams } from 'react-router-dom';
// Using window.location for routing instead
import { KAIDEN_APPS } from '../../lib/appRegistryConfig';

// Lazy load all app components
const AgenticAIBusinessSwarm = lazy(() => import('./apps/AgenticAIBusinessSwarm'));
const AudioMasteringApplication = lazy(() => import('./apps/AudioMasteringApplication'));
const AveryAIReceptionist = lazy(() => import('./apps/AveryAIReceptionist'));
const BuildWealthPro = lazy(() => import('./apps/BuildWealthPro'));
const FinancialCoPilot = lazy(() => import('./apps/FinancialCoPilot'));
const HealthSyncScribe = lazy(() => import('./apps/HealthSyncScribe'));
const HouseHack203K = lazy(() => import('./apps/HouseHack203K'));
const PantryIQ = lazy(() => import('./apps/PantryIQ'));
const RealitySync = lazy(() => import('./apps/RealitySync'));
const SpamSlayerSync = lazy(() => import('./apps/SpamSlayerSync'));

// Loading fallback
const AppLoader = () => (
  <div className="flex items-center justify-center min-h-screen bg-black">
    <div className="text-center">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-500 mx-auto mb-4"></div>
      <p className="text-cyan-400 font-mono">Loading app...</p>
    </div>
  </div>
);

// App component map
const APP_COMPONENTS: Record<string, React.LazyExoticComponent<React.ComponentType<any>>> = {
  'agentic-ai-business-swarm': AgenticAIBusinessSwarm,
  'audio-mastering-application': AudioMasteringApplication,
  'avery-ai-receptionist-design': AveryAIReceptionist,
  'buildwealth-pro': BuildWealthPro,
  'financial-co-pilot': FinancialCoPilot,
  'healthsync-scribe': HealthSyncScribe,
  'househack-203k': HouseHack203K,
  'pantryiq': PantryIQ,
  'realitysync-app': RealitySync,
  'spamslayer-sync': SpamSlayerSync,
};

/**
 * Main App Router Component
 */
export function AppRouter() {
  // Extract appId from URL path
  const pathParts = window.location.pathname.split('/');
  const appId = pathParts[pathParts.length - 1];

  if (!appId) {
    return <AppNotFound />;
  }

  const AppComponent = APP_COMPONENTS[appId];

  if (!AppComponent) {
    return <AppNotFound />;
  }

  return (
    <Suspense fallback={<AppLoader />}>
      {React.createElement(AppComponent)}
    </Suspense>
  );
}

/**
 * App Not Found Component
 */
function AppNotFound() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-black">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-cyan-400 mb-4">App Not Found</h1>
        <p className="text-gray-400 mb-8">The app you're looking for doesn't exist or isn't available.</p>
        <a
          href="/apps"
          className="inline-block px-6 py-3 bg-cyan-500 hover:bg-cyan-600 text-black font-bold rounded-lg transition"
        >
          Back to App Store
        </a>
      </div>
    </div>
  );
}

/**
 * App Store Page - Lists all available apps
 */
export function AppStore() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="border-b border-cyan-500/30 py-8">
        <div className="max-w-7xl mx-auto px-6">
          <h1 className="text-4xl font-bold mb-2">
            <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              App Store
            </span>
          </h1>
          <p className="text-gray-400">Discover and install powerful apps for your business</p>
        </div>
      </div>

      {/* Apps Grid */}
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {KAIDEN_APPS.map(app => (
            <AppCard key={app.id} app={app} />
          ))}
        </div>
      </div>
    </div>
  );
}

/**
 * App Card Component
 */
function AppCard({ app }: { app: (typeof KAIDEN_APPS)[0] }) {
  const freePrice = app.pricing.free.price;
  const starterPrice = app.pricing.tiers[0]?.price || 'Contact';

  return (
    <div className="group relative bg-gradient-to-br from-gray-900 to-black border border-cyan-500/20 hover:border-cyan-500/50 rounded-lg p-6 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/20">
      {/* Icon */}
      <div className="text-4xl mb-4">{app.icon}</div>

      {/* Title */}
      <h3 className="text-xl font-bold text-white mb-2">{app.name}</h3>

      {/* Description */}
      <p className="text-sm text-gray-400 mb-4">{app.description}</p>

      {/* Features */}
      <div className="mb-4">
        <p className="text-xs text-gray-500 mb-2">Key Features:</p>
        <div className="flex flex-wrap gap-1">
          {app.features.slice(0, 3).map((feature, idx) => (
            <span key={idx} className="text-xs bg-cyan-500/10 text-cyan-400 px-2 py-1 rounded">
              {feature}
            </span>
          ))}
        </div>
      </div>

      {/* Pricing */}
      <div className="mb-6 pb-6 border-b border-gray-700">
        <p className="text-xs text-gray-500 mb-1">Starting at</p>
        <p className="text-2xl font-bold text-cyan-400">
          {freePrice === 0 ? 'Free' : `$${freePrice}`}
          {freePrice === 0 && <span className="text-sm text-gray-400"> or ${starterPrice}/mo</span>}
        </p>
      </div>

      {/* CTA Button */}
      <a
        href={`/apps/${app.id}`}
        className="block w-full text-center px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-black font-bold rounded-lg transition-colors duration-200"
      >
        Launch App
      </a>
    </div>
  );
}

export default AppRouter;
