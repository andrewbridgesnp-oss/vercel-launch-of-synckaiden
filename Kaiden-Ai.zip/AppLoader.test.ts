/**
 * AppLoader Unit Tests
 * Tests for app loading, license management, and routing
 */

import { describe, it, expect, vi, beforeEach, beforeAll } from 'vitest';
import { KAIDEN_APPS, getAppById, getAppsByCategory, searchApps } from '@/lib/appRegistryConfig';
import { appRegistry, AppLicense } from '@/lib/appRegistry';

// Initialize registry with apps before tests
beforeAll(() => {
  KAIDEN_APPS.forEach(app => {
    appRegistry.registerApp(app);
  });
});

describe('AppLoader', () => {
  describe('App Registry Configuration', () => {
    it('should have all 11 apps registered', () => {
      expect(KAIDEN_APPS.length).toBeGreaterThanOrEqual(10);
    });

    it('should find app by ID', () => {
      const app = getAppById('buildwealth-pro');
      expect(app).toBeDefined();
      expect(app?.name).toBe('BuildWealth Pro');
    });

    it('should return undefined for unknown app ID', () => {
      const app = getAppById('unknown-app');
      expect(app).toBeUndefined();
    });

    it('should filter apps by category', () => {
      const financeApps = getAppsByCategory('finance');
      expect(financeApps.length).toBeGreaterThan(0);
      financeApps.forEach(app => {
        expect(app.category).toBe('finance');
      });
    });

    it('should search apps by name', () => {
      const results = searchApps('wealth');
      expect(results.length).toBeGreaterThan(0);
      expect(results.some(app => app.id === 'buildwealth-pro')).toBe(true);
    });

    it('should search apps by feature', () => {
      const results = searchApps('credit');
      expect(results.length).toBeGreaterThan(0);
    });
  });

  describe('App Metadata', () => {
    it('should have valid pricing for each app', () => {
      KAIDEN_APPS.forEach(app => {
        expect(app.pricing).toBeDefined();
        expect(app.pricing.free).toBeDefined();
        expect(app.pricing.free.price).toBe(0);
        expect(app.pricing.tiers).toBeDefined();
        expect(Array.isArray(app.pricing.tiers)).toBe(true);
      });
    });

    it('should have valid scaling rules for each app', () => {
      KAIDEN_APPS.forEach(app => {
        expect(app.scaling).toBeDefined();
        expect(app.scaling.minInstances).toBeGreaterThan(0);
        expect(app.scaling.maxInstances).toBeGreaterThanOrEqual(app.scaling.minInstances);
        expect(app.scaling.cpuThreshold).toBeGreaterThan(0);
        expect(app.scaling.cpuThreshold).toBeLessThanOrEqual(100);
      });
    });

    it('should have valid routes for each app', () => {
      KAIDEN_APPS.forEach(app => {
        expect(app.route).toBeDefined();
        expect(app.route.startsWith('/apps/')).toBe(true);
      });
    });

    it('should have required metadata fields', () => {
      KAIDEN_APPS.forEach(app => {
        expect(app.id).toBeDefined();
        expect(app.name).toBeDefined();
        expect(app.description).toBeDefined();
        expect(app.icon).toBeDefined();
        expect(app.category).toBeDefined();
        expect(app.version).toBeDefined();
        expect(app.author).toBeDefined();
        expect(app.features).toBeDefined();
        expect(Array.isArray(app.features)).toBe(true);
        expect(app.features.length).toBeGreaterThan(0);
      });
    });
  });

  describe('License Management', () => {
    it('should install free tier license', () => {
      const license = appRegistry.installApp('buildwealth-pro', 1, 'free');
      expect(license).toBeDefined();
      expect(license.appId).toBe('buildwealth-pro');
      expect(license.userId).toBe(1);
      expect(license.tier).toBe('free');
      expect(license.status).toBe('active');
    });

    it('should install paid tier license with trial status', () => {
      const license = appRegistry.installApp('buildwealth-pro', 2, 'pro');
      expect(license).toBeDefined();
      expect(license.tier).toBe('pro');
      expect(license.status).toBe('trial');
      expect(license.expiresAt).toBeDefined();
    });

    it('should generate valid license key', () => {
      const license = appRegistry.installApp('buildwealth-pro', 3, 'free');
      expect(license.licenseKey).toBeDefined();
      expect(appRegistry.validateLicenseKey(license.licenseKey!)).toBe(true);
    });

    it('should retrieve user licenses', () => {
      appRegistry.installApp('buildwealth-pro', 4, 'free');
      appRegistry.installApp('financial-co-pilot', 4, 'starter');
      
      const licenses = appRegistry.getUserLicenses(4);
      expect(licenses.length).toBe(2);
    });

    it('should get specific app license for user', () => {
      appRegistry.installApp('healthsync-scribe', 5, 'pro');
      
      const license = appRegistry.getAppLicense(5, 'healthsync-scribe');
      expect(license).toBeDefined();
      expect(license?.appId).toBe('healthsync-scribe');
      expect(license?.tier).toBe('pro');
    });

    it('should upgrade license tier', () => {
      appRegistry.installApp('pantryiq', 6, 'free');
      const upgraded = appRegistry.upgradeLicense(6, 'pantryiq', 'pro');
      
      expect(upgraded).toBeDefined();
      expect(upgraded?.tier).toBe('pro');
      expect(upgraded?.status).toBe('active');
    });

    it('should downgrade license tier', () => {
      appRegistry.installApp('realitysync-app', 7, 'pro');
      const downgraded = appRegistry.downgradeLicense(7, 'realitysync-app');
      
      expect(downgraded).toBeDefined();
      expect(downgraded?.tier).toBe('free');
    });

    it('should cancel license', () => {
      appRegistry.installApp('spamslayer-sync', 8, 'starter');
      const cancelled = appRegistry.cancelLicense(8, 'spamslayer-sync');
      
      expect(cancelled).toBe(true);
      const license = appRegistry.getAppLicense(8, 'spamslayer-sync');
      expect(license?.status).toBe('expired');
    });
  });

  describe('Feature Access Control', () => {
    it('should check feature access for free tier', () => {
      appRegistry.installApp('buildwealth-pro', 10, 'free');
      
      // Free tier should have access to free features
      const hasAccess = appRegistry.hasFeatureAccess(10, 'buildwealth-pro', 'credit monitoring');
      expect(hasAccess).toBe(true);
    });

    it('should deny feature access for expired license', () => {
      appRegistry.installApp('financial-co-pilot', 11, 'free');
      appRegistry.cancelLicense(11, 'financial-co-pilot');
      
      const hasAccess = appRegistry.hasFeatureAccess(11, 'financial-co-pilot', 'basic dashboard');
      expect(hasAccess).toBe(false);
    });

    it('should return false for non-existent license', () => {
      const hasAccess = appRegistry.hasFeatureAccess(999, 'unknown-app', 'feature');
      expect(hasAccess).toBe(false);
    });
  });

  describe('Usage Limits', () => {
    it('should check usage limits for free tier', () => {
      appRegistry.installApp('avery-ai-receptionist-design', 12, 'free');
      
      // Free tier has 100 calls/month limit
      const atLimit = appRegistry.checkUsageLimit(12, 'avery-ai-receptionist-design', 'callsPerMonth', 100);
      expect(atLimit).toBe(true);
      
      const underLimit = appRegistry.checkUsageLimit(12, 'avery-ai-receptionist-design', 'callsPerMonth', 50);
      expect(underLimit).toBe(false);
    });
  });

  describe('Scaling Rules', () => {
    it('should get scaling rules for app', () => {
      const rules = appRegistry.getScalingRules('agentic-ai-business-swarm');
      expect(rules).toBeDefined();
      expect(rules?.minInstances).toBe(3);
      expect(rules?.maxInstances).toBe(50);
    });

    it('should return undefined for unknown app', () => {
      const rules = appRegistry.getScalingRules('unknown-app');
      expect(rules).toBeUndefined();
    });
  });

  describe('App Discovery', () => {
    it('should get featured apps', () => {
      const featured = appRegistry.getFeaturedApps();
      expect(featured.length).toBeLessThanOrEqual(6);
    });

    it('should search apps', () => {
      const results = appRegistry.searchApps('AI');
      expect(results.length).toBeGreaterThan(0);
    });
  });
});
