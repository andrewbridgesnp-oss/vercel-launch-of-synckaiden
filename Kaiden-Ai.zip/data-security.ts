/**
 * DATA SECURITY & ENCRYPTION
 * 
 * Implements:
 * - AES-256-GCM encryption for sensitive data
 * - Input sanitization
 * - SQL injection prevention
 * - XSS protection
 * - CORS configuration
 * - Rate limiting
 * - DDoS protection
 * - Secure headers
 */

import crypto from 'crypto';
import { z } from 'zod';

/**
 * Encryption configuration
 */
const ENCRYPTION_ALGORITHM = 'aes-256-gcm';
const AUTH_TAG_LENGTH = 16;
const SALT_LENGTH = 32;
const IV_LENGTH = 12;

/**
 * Encrypted data structure
 */
export interface EncryptedData {
  ciphertext: string;
  iv: string;
  salt: string;
  authTag: string;
  algorithm: string;
}

/**
 * Derive encryption key from master key and salt
 */
function deriveKey(masterKey: string, salt: Buffer): Buffer {
  return crypto.pbkdf2Sync(masterKey, salt, 100000, 32, 'sha256');
}

/**
 * Encrypt sensitive data
 */
export function encryptData(plaintext: string, masterKey: string): EncryptedData {
  const salt = crypto.randomBytes(SALT_LENGTH);
  const iv = crypto.randomBytes(IV_LENGTH);
  const key = deriveKey(masterKey, salt);

  const cipher = crypto.createCipheriv(ENCRYPTION_ALGORITHM, key, iv);
  let ciphertext = cipher.update(plaintext, 'utf8', 'hex');
  ciphertext += cipher.final('hex');

  const authTag = cipher.getAuthTag();

  return {
    ciphertext,
    iv: iv.toString('hex'),
    salt: salt.toString('hex'),
    authTag: authTag.toString('hex'),
    algorithm: ENCRYPTION_ALGORITHM,
  };
}

/**
 * Decrypt sensitive data
 */
export function decryptData(encrypted: EncryptedData, masterKey: string): string {
  const salt = Buffer.from(encrypted.salt, 'hex');
  const iv = Buffer.from(encrypted.iv, 'hex');
  const authTag = Buffer.from(encrypted.authTag, 'hex');
  const key = deriveKey(masterKey, salt);

  const decipher = crypto.createDecipheriv(ENCRYPTION_ALGORITHM, key, iv);
  decipher.setAuthTag(authTag);

  let plaintext = decipher.update(encrypted.ciphertext, 'hex', 'utf8');
  plaintext += decipher.final('utf8');

  return plaintext;
}

/**
 * Hash sensitive data (one-way)
 */
export function hashData(data: string, salt?: string): string {
  const hashSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(data, hashSalt, 100000, 64, 'sha256');
  return `${hashSalt}:${hash.toString('hex')}`;
}

/**
 * Verify hashed data
 */
export function verifyHashedData(data: string, hash: string): boolean {
  const [salt, hashValue] = hash.split(':');
  const newHash = hashData(data, salt);
  return newHash === hash;
}

/**
 * Sanitize input to prevent SQL injection
 */
export function sanitizeInput(input: string): string {
  // Remove potentially dangerous characters
  return input
    .replace(/['";\\]/g, (char) => {
      const escapeMap: Record<string, string> = {
        "'": "''",
        '"': '""',
        ';': '',
        '\\': '',
      };
      return escapeMap[char] || char;
    })
    .trim();
}

/**
 * Sanitize HTML to prevent XSS
 */
export function sanitizeHtml(html: string): string {
  return html
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

/**
 * Validate email format
 */
export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate phone number format
 */
export function validatePhoneNumber(phone: string): boolean {
  const phoneRegex = /^[\d\s\-\+\(\)]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 10;
}

/**
 * Validate credit card number (Luhn algorithm)
 */
export function validateCreditCard(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  if (digits.length < 13 || digits.length > 19) return false;

  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Mask sensitive data for logging
 */
export function maskSensitiveData(data: string, visibleChars: number = 4): string {
  if (data.length <= visibleChars) {
    return '*'.repeat(data.length);
  }

  const visible = data.slice(-visibleChars);
  const masked = '*'.repeat(data.length - visibleChars);
  return masked + visible;
}

/**
 * Mask credit card number
 */
export function maskCreditCard(cardNumber: string): string {
  const digits = cardNumber.replace(/\D/g, '');
  if (digits.length < 4) return '*'.repeat(digits.length);
  return '*'.repeat(digits.length - 4) + digits.slice(-4);
}

/**
 * Mask email address
 */
export function maskEmail(email: string): string {
  const [localPart, domain] = email.split('@');
  if (!domain) return email;

  const visibleChars = Math.max(1, Math.floor(localPart.length / 3));
  const masked = '*'.repeat(localPart.length - visibleChars) + localPart.slice(-visibleChars);
  return `${masked}@${domain}`;
}

/**
 * Generate secure random token
 */
export function generateSecureToken(length: number = 32): string {
  return crypto.randomBytes(length).toString('hex');
}

/**
 * CORS configuration
 */
export const CORS_CONFIG = {
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000', 'https://synckaiden.com'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['X-Total-Count', 'X-Page-Count'],
  maxAge: 86400, // 24 hours
};

/**
 * Secure headers configuration
 */
export const SECURE_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'X-XSS-Protection': '1; mode=block',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'",
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'geolocation=(), microphone=(), camera=()',
};

/**
 * Rate limiting configuration
 */
export interface RateLimitConfig {
  windowMs: number; // Time window in milliseconds
  maxRequests: number; // Max requests per window
  keyGenerator?: (req: any) => string; // Function to generate rate limit key
}

/**
 * Rate limit store
 */
export class RateLimiter {
  private store: Map<string, { count: number; resetTime: number }> = new Map();
  private config: RateLimitConfig;

  constructor(config: RateLimitConfig) {
    this.config = config;
  }

  /**
   * Check if request is allowed
   */
  isAllowed(key: string): boolean {
    const now = Date.now();
    const record = this.store.get(key);

    if (!record || now > record.resetTime) {
      // Create new record
      this.store.set(key, {
        count: 1,
        resetTime: now + this.config.windowMs,
      });
      return true;
    }

    if (record.count < this.config.maxRequests) {
      record.count++;
      return true;
    }

    return false;
  }

  /**
   * Get remaining requests
   */
  getRemaining(key: string): number {
    const record = this.store.get(key);
    if (!record || Date.now() > record.resetTime) {
      return this.config.maxRequests;
    }
    return Math.max(0, this.config.maxRequests - record.count);
  }

  /**
   * Get reset time
   */
  getResetTime(key: string): number {
    const record = this.store.get(key);
    if (!record) {
      return Date.now() + this.config.windowMs;
    }
    return record.resetTime;
  }

  /**
   * Clean up expired records
   */
  cleanup(): void {
    const now = Date.now();
    const keysToDelete: string[] = [];
    this.store.forEach((record, key) => {
      if (now > record.resetTime) {
        keysToDelete.push(key);
      }
    });
    keysToDelete.forEach((key) => this.store.delete(key));
  }
}

/**
 * DDoS protection - track suspicious patterns
 */
export class DDoSDetector {
  private ipRequests: Map<string, number[]> = new Map();
  private threshold: number;
  private timeWindow: number;

  constructor(threshold: number = 100, timeWindow: number = 60000) {
    this.threshold = threshold;
    this.timeWindow = timeWindow;
  }

  /**
   * Check if IP is suspicious
   */
  isSuspicious(ip: string): boolean {
    const now = Date.now();
    const requests = this.ipRequests.get(ip) || [];

    // Remove old requests outside time window
    const recentRequests = requests.filter((time) => now - time < this.timeWindow);

    if (recentRequests.length >= this.threshold) {
      return true; // Suspicious activity
    }

    // Update records
    recentRequests.push(now);
    this.ipRequests.set(ip, recentRequests);

    return false;
  }

  /**
   * Get request count for IP
   */
  getRequestCount(ip: string): number {
    const now = Date.now();
    const requests = this.ipRequests.get(ip) || [];
    return requests.filter((time) => now - time < this.timeWindow).length;
  }

  /**
   * Clean up old records
   */
  cleanup(): void {
    const now = Date.now();
    const keysToDelete: string[] = [];
    this.ipRequests.forEach((requests, ip) => {
      const recentRequests = requests.filter((time: number) => now - time < this.timeWindow);
      if (recentRequests.length === 0) {
        keysToDelete.push(ip);
      } else {
        this.ipRequests.set(ip, recentRequests);
      }
    });
    keysToDelete.forEach((ip) => this.ipRequests.delete(ip));
  }
}

/**
 * Validation schemas
 */
export const encryptedDataSchema = z.object({
  ciphertext: z.string(),
  iv: z.string(),
  salt: z.string(),
  authTag: z.string(),
  algorithm: z.string(),
});

export const emailSchema = z.string().email().transform(sanitizeInput);

export const phoneSchema = z.string().refine(validatePhoneNumber, 'Invalid phone number');

export const creditCardSchema = z.string().refine(validateCreditCard, 'Invalid credit card number');

export default {
  encryptData,
  decryptData,
  hashData,
  verifyHashedData,
  sanitizeInput,
  sanitizeHtml,
  validateEmail,
  validatePhoneNumber,
  validateCreditCard,
  maskSensitiveData,
  maskCreditCard,
  maskEmail,
  generateSecureToken,
  CORS_CONFIG,
  SECURE_HEADERS,
  RateLimiter,
  DDoSDetector,
};
