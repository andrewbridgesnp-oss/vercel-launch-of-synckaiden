/**
 * Analytics Schema
 * Comprehensive tracking for user behavior, revenue, and performance metrics
 */

import {
  mysqlTable,
  int,
  varchar,
  text,
  timestamp,
  boolean,
  decimal,
  json,
  index,
} from 'drizzle-orm/mysql-core';

/**
 * Daily Metrics - Aggregated daily statistics
 */
export const dailyMetrics = mysqlTable(
  'dailyMetrics',
  {
    id: int('id').autoincrement().primaryKey(),
    date: timestamp('date').notNull(),
    activeUsers: int('activeUsers').default(0),
    newUsers: int('newUsers').default(0),
    totalSessions: int('totalSessions').default(0),
    totalEvents: int('totalEvents').default(0),
    avgSessionDuration: decimal('avgSessionDuration', { precision: 10, scale: 2 }).default('0'),
    bounceRate: decimal('bounceRate', { precision: 5, scale: 2 }).default('0'),
    totalRevenue: decimal('totalRevenue', { precision: 12, scale: 2 }).default('0'),
    newSubscriptions: int('newSubscriptions').default(0),
    cancelledSubscriptions: int('cancelledSubscriptions').default(0),
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow(),
  },
  (table) => ({
    dateIdx: index('metrics_date_idx').on(table.date),
  })
);

/**
 * User Behavior - Detailed user interaction tracking
 */
export const userBehavior = mysqlTable(
  'userBehavior',
  {
    id: int('id').autoincrement().primaryKey(),
    userId: varchar('userId', { length: 64 }).notNull(),
    eventType: varchar('eventType', { length: 100 }).notNull(),
    eventName: varchar('eventName', { length: 255 }).notNull(),
    eventValue: varchar('eventValue', { length: 500 }),
    pageUrl: varchar('pageUrl', { length: 500 }),
    referrer: varchar('referrer', { length: 500 }),
    userAgent: text('userAgent'),
    ipAddress: varchar('ipAddress', { length: 45 }),
    sessionId: varchar('sessionId', { length: 100 }),
    duration: int('duration'), // milliseconds
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow(),
  },
  (table) => ({
    userIdIdx: index('behavior_userId_idx').on(table.userId),
    eventTypeIdx: index('behavior_eventType_idx').on(table.eventType),
    dateIdx: index('behavior_date_idx').on(table.createdAt),
  })
);

/**
 * Revenue Metrics - Subscription and payment tracking
 */
export const revenueMetrics = mysqlTable(
  'revenueMetrics',
  {
    id: int('id').autoincrement().primaryKey(),
    userId: varchar('userId', { length: 64 }).notNull(),
    subscriptionTier: varchar('subscriptionTier', { length: 50 }).notNull(),
    amount: decimal('amount', { precision: 12, scale: 2 }).notNull(),
    currency: varchar('currency', { length: 3 }).default('USD'),
    paymentMethod: varchar('paymentMethod', { length: 50 }),
    status: varchar('status', { length: 50 }).notNull(), // 'completed', 'pending', 'failed', 'refunded'
    stripePaymentId: varchar('stripePaymentId', { length: 100 }),
    billingPeriod: varchar('billingPeriod', { length: 20 }).notNull(), // 'monthly', 'yearly'
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow(),
  },
  (table) => ({
    userIdIdx: index('revenue_userId_idx').on(table.userId),
    statusIdx: index('revenue_status_idx').on(table.status),
    dateIdx: index('revenue_date_idx').on(table.createdAt),
  })
);

/**
 * Feature Usage - Track feature adoption and usage
 */
export const featureUsage = mysqlTable(
  'featureUsage',
  {
    id: int('id').autoincrement().primaryKey(),
    userId: varchar('userId', { length: 64 }).notNull(),
    featureName: varchar('featureName', { length: 255 }).notNull(),
    featureId: varchar('featureId', { length: 100 }).notNull(),
    usageCount: int('usageCount').default(1),
    lastUsed: timestamp('lastUsed').defaultNow(),
    totalTimeSpent: int('totalTimeSpent').default(0), // seconds
    isActive: boolean('isActive').default(true),
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow(),
    updatedAt: timestamp('updatedAt').defaultNow().onUpdateNow(),
  },
  (table) => ({
    userIdIdx: index('feature_userId_idx').on(table.userId),
    featureIdIdx: index('feature_featureId_idx').on(table.featureId),
  })
);

/**
 * Performance Metrics - System and API performance
 */
export const performanceMetrics = mysqlTable(
  'performanceMetrics',
  {
    id: int('id').autoincrement().primaryKey(),
    endpoint: varchar('endpoint', { length: 255 }).notNull(),
    method: varchar('method', { length: 10 }).notNull(),
    responseTime: int('responseTime').notNull(), // milliseconds
    statusCode: int('statusCode').notNull(),
    errorMessage: text('errorMessage'),
    userId: varchar('userId', { length: 64 }),
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow(),
  },
  (table) => ({
    endpointIdx: index('perf_endpoint_idx').on(table.endpoint),
    statusIdx: index('perf_status_idx').on(table.statusCode),
    dateIdx: index('perf_date_idx').on(table.createdAt),
  })
);

/**
 * Cohort Analysis - User cohort tracking
 */
export const cohortAnalysis = mysqlTable(
  'cohortAnalysis',
  {
    id: int('id').autoincrement().primaryKey(),
    cohortDate: timestamp('cohortDate').notNull(),
    cohortName: varchar('cohortName', { length: 100 }).notNull(),
    userId: varchar('userId', { length: 64 }).notNull(),
    cohortSize: int('cohortSize').default(1),
    retentionDay: int('retentionDay').default(0),
    isActive: boolean('isActive').default(true),
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow(),
  },
  (table) => ({
    cohortDateIdx: index('cohort_date_idx').on(table.cohortDate),
    userIdIdx: index('cohort_userId_idx').on(table.userId),
  })
);

/**
 * Funnel Analysis - Conversion funnel tracking
 */
export const funnelAnalysis = mysqlTable(
  'funnelAnalysis',
  {
    id: int('id').autoincrement().primaryKey(),
    userId: varchar('userId', { length: 64 }).notNull(),
    funnelName: varchar('funnelName', { length: 100 }).notNull(),
    step: int('step').notNull(),
    stepName: varchar('stepName', { length: 255 }).notNull(),
    completed: boolean('completed').default(false),
    completedAt: timestamp('completedAt'),
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow(),
  },
  (table) => ({
    userIdIdx: index('funnel_userId_idx').on(table.userId),
    funnelIdx: index('funnel_name_idx').on(table.funnelName),
  })
);

/**
 * Custom Events - Flexible custom event tracking
 */
export const customEvents = mysqlTable(
  'customEvents',
  {
    id: int('id').autoincrement().primaryKey(),
    userId: varchar('userId', { length: 64 }).notNull(),
    eventCategory: varchar('eventCategory', { length: 100 }).notNull(),
    eventAction: varchar('eventAction', { length: 255 }).notNull(),
    eventLabel: varchar('eventLabel', { length: 255 }),
    eventValue: varchar('eventValue', { length: 500 }),
    metadata: json('metadata'),
    createdAt: timestamp('createdAt').defaultNow(),
  },
  (table) => ({
    userIdIdx: index('event_userId_idx').on(table.userId),
    categoryIdx: index('event_category_idx').on(table.eventCategory),
    dateIdx: index('event_date_idx').on(table.createdAt),
  })
);

/**
 * Types
 */
export type DailyMetrics = typeof dailyMetrics.$inferSelect;
export type InsertDailyMetrics = typeof dailyMetrics.$inferInsert;

export type UserBehavior = typeof userBehavior.$inferSelect;
export type InsertUserBehavior = typeof userBehavior.$inferInsert;

export type RevenueMetrics = typeof revenueMetrics.$inferSelect;
export type InsertRevenueMetrics = typeof revenueMetrics.$inferInsert;

export type FeatureUsage = typeof featureUsage.$inferSelect;
export type InsertFeatureUsage = typeof featureUsage.$inferInsert;

export type PerformanceMetrics = typeof performanceMetrics.$inferSelect;
export type InsertPerformanceMetrics = typeof performanceMetrics.$inferInsert;

export type CohortAnalysis = typeof cohortAnalysis.$inferSelect;
export type InsertCohortAnalysis = typeof cohortAnalysis.$inferInsert;

export type FunnelAnalysis = typeof funnelAnalysis.$inferSelect;
export type InsertFunnelAnalysis = typeof funnelAnalysis.$inferInsert;

export type CustomEvents = typeof customEvents.$inferSelect;
export type InsertCustomEvents = typeof customEvents.$inferInsert;
