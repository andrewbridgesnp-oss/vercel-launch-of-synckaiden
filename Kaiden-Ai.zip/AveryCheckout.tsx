import React, { useState } from 'react';
import { ChevronRight, Check, AlertCircle, Loader } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface CheckoutProps {
  tier: 'starter' | 'professional' | 'enterprise';
  onSuccess?: (subscriptionId: string) => void;
  onError?: (error: string) => void;
}

const AveryCheckout: React.FC<CheckoutProps> = ({ tier, onSuccess, onError }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [email, setEmail] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvc, setCvc] = useState('');

  const tierPrices: Record<string, { price: number; name: string }> = {
    starter: { price: 99, name: 'Starter' },
    professional: { price: 299, name: 'Professional' },
    enterprise: { price: 0, name: 'Enterprise' },
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setLoading(true);
    setError(null);

    try {
      // Validate inputs
      if (!email || !businessName) {
        throw new Error('Please fill in all required fields');
      }

      if (tier !== 'enterprise' && (!cardNumber || !expiryDate || !cvc)) {
        throw new Error('Please fill in card details');
      }

      // Create subscription via backend
      const response = await fetch('/api/avery/subscriptions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tier,
          email,
          businessName,
          cardNumber: tier !== 'enterprise' ? cardNumber : undefined,
          expiryDate: tier !== 'enterprise' ? expiryDate : undefined,
          cvc: tier !== 'enterprise' ? cvc : undefined,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to create subscription');
      }

      const data = await response.json();
      setSuccess(true);

      if (onSuccess) {
        onSuccess(data.subscriptionId);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'An error occurred';
      setError(message);
      if (onError) {
        onError(message);
      }
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4 py-12 flex items-center justify-center">
        <div className="rounded-lg bg-green-500/10 border border-green-500/20 p-8 text-center max-w-md">
          <div className="mb-4 flex justify-center">
            <div className="rounded-full bg-green-500/20 p-3">
              <Check className="h-8 w-8 text-green-400" />
            </div>
          </div>
          <h3 className="mb-2 text-2xl font-bold text-white">Subscription Successful!</h3>
          <p className="mb-6 text-slate-300">
            Your {tierPrices[tier].name} plan is now active. Check your email for confirmation and setup instructions.
          </p>
          <Button className="bg-cyan-500 hover:bg-cyan-600 text-white">
            Go to Dashboard <ChevronRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 px-4 py-12">
      <div className="mx-auto max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-white mb-2">Complete Your Purchase</h1>
          <p className="text-slate-400">Secure payment for Avery AI Receptionist</p>
        </div>

        <div className="rounded-lg bg-slate-800/50 backdrop-blur border border-slate-700 p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="rounded-lg bg-red-500/10 border border-red-500/20 p-4 flex gap-3">
                <AlertCircle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-red-400">Error</h4>
                  <p className="text-sm text-red-300">{error}</p>
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-white mb-2">Business Name</label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                required
                className="w-full rounded-lg bg-slate-700 px-4 py-3 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
                placeholder="Your Business Name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full rounded-lg bg-slate-700 px-4 py-3 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
                placeholder="your@email.com"
              />
            </div>

            {tier !== 'enterprise' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-white mb-2">Card Number</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value.replace(/\s/g, ''))}
                    placeholder="4242 4242 4242 4242"
                    maxLength={16}
                    className="w-full rounded-lg bg-slate-700 px-4 py-3 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
                  />
                  <p className="mt-1 text-xs text-slate-400">Test: 4242 4242 4242 4242</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Expiry Date</label>
                    <input
                      type="text"
                      value={expiryDate}
                      onChange={(e) => setExpiryDate(e.target.value)}
                      placeholder="MM/YY"
                      maxLength={5}
                      className="w-full rounded-lg bg-slate-700 px-4 py-3 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">CVC</label>
                    <input
                      type="text"
                      value={cvc}
                      onChange={(e) => setCvc(e.target.value)}
                      placeholder="123"
                      maxLength={3}
                      className="w-full rounded-lg bg-slate-700 px-4 py-3 text-white placeholder-slate-400 border border-slate-600 focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>
              </>
            )}

            <div className="rounded-lg bg-slate-800/50 p-4">
              <div className="flex justify-between mb-2">
                <span className="text-slate-300">{tierPrices[tier].name} Plan</span>
                <span className="font-semibold text-white">
                  {tierPrices[tier].price > 0 ? `$${tierPrices[tier].price}/month` : 'Contact Sales'}
                </span>
              </div>
              <div className="flex justify-between text-sm text-slate-400">
                <span>Billed monthly</span>
                <span>Auto-renews</span>
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-cyan-500 hover:bg-cyan-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <Loader className="mr-2 h-5 w-5 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  Subscribe Now <ChevronRight className="ml-2 h-5 w-5" />
                </>
              )}
            </Button>

            <p className="text-center text-xs text-slate-400">
              Your payment is secure and encrypted. You can cancel anytime.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AveryCheckout;
