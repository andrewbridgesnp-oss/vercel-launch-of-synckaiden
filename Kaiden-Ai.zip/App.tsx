import { Suspense, useEffect } from 'react';
import { Route, Switch } from 'wouter';
import { useCapabilityRegistry } from '@/hooks/useCapability';
import { useCapabilityStore } from '@/stores/capabilityStore';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { ThemeProvider } from '@/contexts/ThemeContext';
import ErrorBoundary from '@/components/ErrorBoundary';

// Pages
import Home from '@/pages/Home';
import CapabilitiesHub from '@/pages/CapabilitiesHub';
import CapabilityDetail from '@/pages/CapabilityDetail';
import ModuleView from '@/pages/ModuleView';
import NotFound from '@/pages/NotFound';
import Dashboard from '@/pages/Dashboard';

// Loading component
function LoadingPage() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="animate-pulse">
        <div className="h-12 w-48 bg-muted rounded mb-4"></div>
        <div className="h-4 w-96 bg-muted rounded"></div>
      </div>
    </div>
  );
}

/**
 * Main Router Component
 * Handles all routing with dynamic capability routes
 */
function Router() {
  const { isLoading, error } = useCapabilityRegistry();
  const capabilities = useCapabilityStore((state) => state.capabilities);

  if (isLoading) {
    return <LoadingPage />;
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600">Error Loading Application</h1>
          <p className="mt-2 text-muted-foreground">{error.message}</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      {/* Home page */}
      <Route path="/" component={Home} />

      {/* Dashboard */}
      <Route path="/dashboard" component={Dashboard} />

      {/* Capabilities hub */}
      <Route path="/capabilities" component={CapabilitiesHub} />

      {/* Module view */}
      <Route path="/capabilities/:module" component={ModuleView} />

      {/* Capability detail view */}
      <Route path="/capabilities/:module/:capability" component={CapabilityDetail} />

      {/* 404 fallback */}
      <Route component={NotFound} />
    </Switch>
  );
}

/**
 * Main App Component
 */
function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Suspense fallback={<LoadingPage />}>
            <Router />
          </Suspense>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
