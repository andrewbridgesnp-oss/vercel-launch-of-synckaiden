import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the database with proper chaining
const createMockDb = () => {
  const mockChain = {
    select: vi.fn().mockReturnThis(),
    from: vi.fn().mockReturnThis(),
    where: vi.fn().mockImplementation(() => Promise.resolve([])),
    orderBy: vi.fn().mockReturnThis(),
    limit: vi.fn().mockImplementation(() => Promise.resolve([])),
    insert: vi.fn().mockReturnThis(),
    values: vi.fn().mockImplementation(() => Promise.resolve([{ insertId: 1 }])),
    update: vi.fn().mockReturnThis(),
    set: vi.fn().mockReturnThis(),
  };
  // Make where chainable and return array
  mockChain.where = vi.fn().mockImplementation(() => ({
    limit: vi.fn().mockResolvedValue([]),
  }));
  // Make orderBy chainable
  mockChain.orderBy = vi.fn().mockImplementation(() => ({
    limit: vi.fn().mockResolvedValue([]),
  }));
  return mockChain;
};

vi.mock("./db", () => ({
  getDb: vi.fn().mockImplementation(() => Promise.resolve(createMockDb())),
}));

describe("appRouter", () => {
  const createMockContext = (user?: { id: number; openId: string; role: string }): TrpcContext => {
    const clearedCookies: Array<{ name: string; options: unknown }> = [];
    return {
      user: user || null,
      req: {
        ip: "127.0.0.1",
        headers: {
          "user-agent": "test-agent",
          "x-forwarded-for": "127.0.0.1",
        },
      } as any,
      res: {
        clearCookie: (name: string, options: unknown) => {
          clearedCookies.push({ name, options });
        },
      } as any,
    };
  };

  describe("auth.me", () => {
    it("should return null for unauthenticated users", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.auth.me();
      expect(result).toBeNull();
    });

    it("should return user for authenticated users", async () => {
      const mockUser = { id: 1, openId: "test-open-id", role: "user" };
      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);
      const result = await caller.auth.me();
      expect(result).toEqual(mockUser);
    });
  });

  describe("auth.logout", () => {
    it("should clear session cookie and return success", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.auth.logout();
      expect(result).toEqual({ success: true });
    });
  });

  describe("visitors.track", () => {
    it("should track visitor without email", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.visitors.track({
        landingPage: "/",
        referrer: "https://google.com",
      });
      expect(result).toEqual({ success: true });
    });

    it("should track visitor with email", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.visitors.track({
        email: "test@example.com",
        landingPage: "/",
      });
      expect(result).toEqual({ success: true });
    });
  });

  describe("visitors.list", () => {
    it("should require authentication", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);
      await expect(caller.visitors.list()).rejects.toThrow();
    });

    it("should return visitor list for authenticated users", async () => {
      const mockUser = { id: 1, openId: "test-open-id", role: "admin" };
      const ctx = createMockContext(mockUser);
      const caller = appRouter.createCaller(ctx);
      const result = await caller.visitors.list();
      expect(Array.isArray(result)).toBe(true);
    });
  });

  // Note: businesses.list, businesses.getBySubdomain, and reviews.list tests
  // require more complex database mocking due to chained query patterns.
  // These are tested via integration tests in the browser.
});
