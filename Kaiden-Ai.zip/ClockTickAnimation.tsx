import React, { useEffect, useState } from 'react';
import '../styles/liquid-glass.css';

interface ClockTickAnimationProps {
  onComplete?: () => void;
  autoStart?: boolean;
}

export const ClockTickAnimation: React.FC<ClockTickAnimationProps> = ({
  onComplete,
  autoStart = true,
}) => {
  const [isAnimating, setIsAnimating] = useState(autoStart);
  const [ticks, setTicks] = useState<number[]>([]);

  useEffect(() => {
    if (!isAnimating) return;

    // Play clock tick sounds
    const playTickSound = () => {
      // Create audio context for tick sound
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const now = audioContext.currentTime;
      
      // Create oscillator for tick sound
      const osc = audioContext.createOscillator();
      const gain = audioContext.createGain();
      
      osc.connect(gain);
      gain.connect(audioContext.destination);
      
      // Tick sound: high frequency, short duration
      osc.frequency.setValueAtTime(1200, now);
      osc.frequency.exponentialRampToValueAtTime(800, now + 0.05);
      
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
      
      osc.start(now);
      osc.stop(now + 0.05);
    };

    // Animate 3 ticks with brightness increase
    const tickTimings = [0, 600, 1200]; // milliseconds between ticks
    const tickTimeouts: NodeJS.Timeout[] = [];

    tickTimings.forEach((delay, index) => {
      const timeout = setTimeout(() => {
        // Play sound
        playTickSound();
        
        // Add tick to animation queue
        setTicks((prev) => [...prev, index]);
      }, delay);
      
      tickTimeouts.push(timeout);
    });

    // Complete animation after all ticks
    const completeTimeout = setTimeout(() => {
      setIsAnimating(false);
      setTicks([]);
      onComplete?.();
    }, 1800);

    return () => {
      tickTimeouts.forEach(timeout => clearTimeout(timeout));
      clearTimeout(completeTimeout);
    };
  }, [isAnimating, onComplete]);

  const startAnimation = () => {
    setIsAnimating(true);
  };

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Animated text with clock ticks */}
      <div className="relative">
        {ticks.map((tickIndex) => (
          <div
            key={tickIndex}
            className={`clock-tick clock-tick-${tickIndex + 1} absolute inset-0`}
            style={{
              animation: `liquidGlassBrighten 0.5s ease-out forwards`,
              animationDelay: `${tickIndex * 0.6}s`,
            }}
          >
            <span className="liquid-glass-headline">
              Restore Your Time
            </span>
          </div>
        ))}
        
        {/* Base text */}
        {ticks.length === 0 && (
          <span className="liquid-glass-headline opacity-30">
            Restore Your Time
          </span>
        )}
      </div>

      {/* Manual trigger button (for testing) */}
      {!isAnimating && (
        <button
          onClick={startAnimation}
          className="px-6 py-2 rounded-lg border border-cyan-400 text-cyan-400 hover:bg-cyan-400/10 transition-all"
        >
          Replay Animation
        </button>
      )}
    </div>
  );
};

export default ClockTickAnimation;
