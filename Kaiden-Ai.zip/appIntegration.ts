/**
 * App Integration Framework
 * Manages standalone app registration, routing, and lifecycle
 */

export interface AppMetadata {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'finance' | 'real-estate' | 'data' | 'productivity' | 'ai' | 'other';
  version: string;
  author: string;
  website?: string;
  pricing: {
    free: boolean;
    plans: {
      name: string;
      price: number;
      features: string[];
    }[];
  };
  features: string[];
  status: 'active' | 'beta' | 'coming-soon';
  integrations: string[];
  route: string;
  component: React.ComponentType<any>;
  requiredPermissions?: string[];
  installDate?: Date;
}

export interface AppRegistry {
  [appId: string]: AppMetadata;
}

export interface AppInstance {
  appId: string;
  userId: string;
  config: Record<string, any>;
  status: 'installed' | 'active' | 'paused' | 'uninstalled';
  installedAt: Date;
  lastUsed?: Date;
}

class AppIntegrationManager {
  private registry: AppRegistry = {};
  private instances: Map<string, AppInstance[]> = new Map();

  /**
   * Register a new app in the platform
   */
  registerApp(metadata: AppMetadata): void {
    if (this.registry[metadata.id]) {
      console.warn(`App ${metadata.id} already registered, updating...`);
    }
    this.registry[metadata.id] = metadata;
  }

  /**
   * Get all registered apps
   */
  getApps(): AppMetadata[] {
    return Object.values(this.registry);
  }

  /**
   * Get app by ID
   */
  getApp(appId: string): AppMetadata | undefined {
    return this.registry[appId];
  }

  /**
   * Get apps by category
   */
  getAppsByCategory(category: string): AppMetadata[] {
    return Object.values(this.registry).filter(app => app.category === category);
  }

  /**
   * Install app for user
   */
  installApp(appId: string, userId: string, config?: Record<string, any>): AppInstance {
    const app = this.registry[appId];
    if (!app) {
      throw new Error(`App ${appId} not found in registry`);
    }

    const instance: AppInstance = {
      appId,
      userId,
      config: config || {},
      status: 'installed',
      installedAt: new Date(),
    };

    if (!this.instances.has(userId)) {
      this.instances.set(userId, []);
    }
    this.instances.get(userId)!.push(instance);

    return instance;
  }

  /**
   * Get user's installed apps
   */
  getUserApps(userId: string): AppInstance[] {
    return this.instances.get(userId) || [];
  }

  /**
   * Uninstall app for user
   */
  uninstallApp(appId: string, userId: string): boolean {
    const userApps = this.instances.get(userId);
    if (!userApps) return false;

    const index = userApps.findIndex(app => app.appId === appId);
    if (index === -1) return false;

    userApps[index].status = 'uninstalled';
    return true;
  }

  /**
   * Update app configuration
   */
  updateAppConfig(appId: string, userId: string, config: Record<string, any>): boolean {
    const userApps = this.instances.get(userId);
    if (!userApps) return false;

    const app = userApps.find(a => a.appId === appId);
    if (!app) return false;

    app.config = { ...app.config, ...config };
    app.lastUsed = new Date();
    return true;
  }

  /**
   * Get app route
   */
  getAppRoute(appId: string): string | undefined {
    return this.registry[appId]?.route;
  }

  /**
   * Get app component
   */
  getAppComponent(appId: string): React.ComponentType<any> | undefined {
    return this.registry[appId]?.component;
  }

  /**
   * Search apps
   */
  searchApps(query: string): AppMetadata[] {
    const lowerQuery = query.toLowerCase();
    return Object.values(this.registry).filter(app =>
      app.name.toLowerCase().includes(lowerQuery) ||
      app.description.toLowerCase().includes(lowerQuery) ||
      app.features.some(f => f.toLowerCase().includes(lowerQuery))
    );
  }

  /**
   * Get featured apps
   */
  getFeaturedApps(): AppMetadata[] {
    return Object.values(this.registry)
      .filter(app => app.status === 'active')
      .slice(0, 6);
  }

  /**
   * Validate app permissions
   */
  validatePermissions(appId: string, userPermissions: string[]): boolean {
    const app = this.registry[appId];
    if (!app || !app.requiredPermissions) return true;

    return app.requiredPermissions.every(perm =>
      userPermissions.includes(perm)
    );
  }
}

// Export singleton instance
export const appManager = new AppIntegrationManager();

// Export manager class for testing
export default AppIntegrationManager;
