/**
 * KAI(DEN) TAX - Tax Calculation Engine
 * 2025 Tax Year Federal Calculations
 * Privacy-first: All calculations run client-side
 */

// 2025 Tax Brackets (Projected based on inflation adjustments)
export const TAX_BRACKETS_2025 = {
  single: [
    { min: 0, max: 11600, rate: 0.10 },
    { min: 11600, max: 47150, rate: 0.12 },
    { min: 47150, max: 100525, rate: 0.22 },
    { min: 100525, max: 191950, rate: 0.24 },
    { min: 191950, max: 243725, rate: 0.32 },
    { min: 243725, max: 609350, rate: 0.35 },
    { min: 609350, max: Infinity, rate: 0.37 },
  ],
  married_filing_jointly: [
    { min: 0, max: 23200, rate: 0.10 },
    { min: 23200, max: 94300, rate: 0.12 },
    { min: 94300, max: 201050, rate: 0.22 },
    { min: 201050, max: 383900, rate: 0.24 },
    { min: 383900, max: 487450, rate: 0.32 },
    { min: 487450, max: 731200, rate: 0.35 },
    { min: 731200, max: Infinity, rate: 0.37 },
  ],
  married_filing_separately: [
    { min: 0, max: 11600, rate: 0.10 },
    { min: 11600, max: 47150, rate: 0.12 },
    { min: 47150, max: 100525, rate: 0.22 },
    { min: 100525, max: 191950, rate: 0.24 },
    { min: 191950, max: 243725, rate: 0.32 },
    { min: 243725, max: 365600, rate: 0.35 },
    { min: 365600, max: Infinity, rate: 0.37 },
  ],
  head_of_household: [
    { min: 0, max: 16550, rate: 0.10 },
    { min: 16550, max: 63100, rate: 0.12 },
    { min: 63100, max: 100500, rate: 0.22 },
    { min: 100500, max: 191950, rate: 0.24 },
    { min: 191950, max: 243700, rate: 0.32 },
    { min: 243700, max: 609350, rate: 0.35 },
    { min: 609350, max: Infinity, rate: 0.37 },
  ],
  qualifying_widow: [
    { min: 0, max: 23200, rate: 0.10 },
    { min: 23200, max: 94300, rate: 0.12 },
    { min: 94300, max: 201050, rate: 0.22 },
    { min: 201050, max: 383900, rate: 0.24 },
    { min: 383900, max: 487450, rate: 0.32 },
    { min: 487450, max: 731200, rate: 0.35 },
    { min: 731200, max: Infinity, rate: 0.37 },
  ],
};

// 2025 Standard Deductions
export const STANDARD_DEDUCTIONS_2025 = {
  single: 14600,
  married_filing_jointly: 29200,
  married_filing_separately: 14600,
  head_of_household: 21900,
  qualifying_widow: 29200,
};

// 2025 Additional Standard Deduction (65+ or blind)
export const ADDITIONAL_STANDARD_DEDUCTION_2025 = {
  single: 1950,
  married_filing_jointly: 1550,
  married_filing_separately: 1550,
  head_of_household: 1950,
  qualifying_widow: 1550,
};

// Self-Employment Tax Rate
export const SELF_EMPLOYMENT_TAX_RATE = 0.153; // 15.3% (12.4% SS + 2.9% Medicare)
export const SELF_EMPLOYMENT_SS_WAGE_BASE_2025 = 176100;

// Capital Gains Tax Rates 2025
export const LONG_TERM_CAPITAL_GAINS_RATES = {
  single: [
    { max: 47025, rate: 0 },
    { max: 518900, rate: 0.15 },
    { max: Infinity, rate: 0.20 },
  ],
  married_filing_jointly: [
    { max: 94050, rate: 0 },
    { max: 583750, rate: 0.15 },
    { max: Infinity, rate: 0.20 },
  ],
};

// Child Tax Credit
export const CHILD_TAX_CREDIT_2025 = {
  amountPerChild: 2000,
  refundableMax: 1700,
  phaseoutStart: {
    single: 200000,
    married_filing_jointly: 400000,
  },
  phaseoutRate: 50, // $50 reduction per $1000 over threshold
};

// Earned Income Credit 2025 (simplified)
export const EARNED_INCOME_CREDIT_2025 = {
  noChildren: { maxCredit: 632, phaseoutStart: 9800, phaseoutEnd: 18591 },
  oneChild: { maxCredit: 4213, phaseoutStart: 22120, phaseoutEnd: 49622 },
  twoChildren: { maxCredit: 6960, phaseoutStart: 22120, phaseoutEnd: 55768 },
  threeOrMore: { maxCredit: 7830, phaseoutStart: 22120, phaseoutEnd: 59899 },
};

// Types
export type FilingStatus = keyof typeof TAX_BRACKETS_2025;

export interface TaxInput {
  filingStatus: FilingStatus;
  wages: number;
  selfEmploymentIncome: number;
  interestIncome: number;
  dividendIncome: number;
  qualifiedDividends: number;
  shortTermGains: number;
  longTermGains: number;
  otherIncome: number;
  federalWithholding: number;
  stateWithholding: number;
  // Deductions
  itemizedDeductions: number;
  useItemized: boolean;
  // Adjustments
  traditionalIraContribution: number;
  hsaContribution: number;
  studentLoanInterest: number;
  selfEmploymentHealthInsurance: number;
  // Credits
  numDependentsUnder17: number;
  numDependents17Plus: number;
  educationExpenses: number;
  childCareExpenses: number;
  retirementContributions: number;
  // Additional info
  isOver65: boolean;
  isBlind: boolean;
  spouseOver65?: boolean;
  spouseBlind?: boolean;
}

export interface TaxResult {
  // Income
  grossIncome: number;
  adjustedGrossIncome: number;
  taxableIncome: number;
  // Tax
  ordinaryIncomeTax: number;
  capitalGainsTax: number;
  selfEmploymentTax: number;
  totalTax: number;
  // Credits
  childTaxCredit: number;
  earnedIncomeCredit: number;
  educationCredit: number;
  childCareCredit: number;
  retirementSavingsCredit: number;
  totalCredits: number;
  // Final
  taxAfterCredits: number;
  totalWithholding: number;
  refundOrOwed: number;
  effectiveRate: number;
  marginalRate: number;
  // Breakdown
  breakdown: TaxBreakdownItem[];
}

export interface TaxBreakdownItem {
  label: string;
  amount: number;
  type: 'income' | 'deduction' | 'adjustment' | 'tax' | 'credit' | 'payment';
}

/**
 * Calculate federal income tax
 */
export function calculateFederalTax(input: TaxInput): TaxResult {
  const breakdown: TaxBreakdownItem[] = [];

  // Step 1: Calculate Gross Income
  const grossIncome = 
    input.wages +
    input.selfEmploymentIncome +
    input.interestIncome +
    input.dividendIncome +
    input.shortTermGains +
    input.longTermGains +
    input.otherIncome;

  breakdown.push({ label: 'Wages & Salaries', amount: input.wages, type: 'income' });
  if (input.selfEmploymentIncome > 0) {
    breakdown.push({ label: 'Self-Employment Income', amount: input.selfEmploymentIncome, type: 'income' });
  }
  if (input.interestIncome > 0) {
    breakdown.push({ label: 'Interest Income', amount: input.interestIncome, type: 'income' });
  }
  if (input.dividendIncome > 0) {
    breakdown.push({ label: 'Dividend Income', amount: input.dividendIncome, type: 'income' });
  }
  if (input.shortTermGains !== 0) {
    breakdown.push({ label: 'Short-Term Capital Gains', amount: input.shortTermGains, type: 'income' });
  }
  if (input.longTermGains !== 0) {
    breakdown.push({ label: 'Long-Term Capital Gains', amount: input.longTermGains, type: 'income' });
  }

  // Step 2: Calculate Adjustments (Above-the-line deductions)
  let adjustments = 0;

  // Self-employment tax deduction (half of SE tax)
  const selfEmploymentTax = calculateSelfEmploymentTax(input.selfEmploymentIncome);
  const seDeduction = selfEmploymentTax / 2;
  if (seDeduction > 0) {
    adjustments += seDeduction;
    breakdown.push({ label: 'Self-Employment Tax Deduction', amount: -seDeduction, type: 'adjustment' });
  }

  // Traditional IRA
  if (input.traditionalIraContribution > 0) {
    const iraLimit = 7000; // 2025 limit
    const iraDeduction = Math.min(input.traditionalIraContribution, iraLimit);
    adjustments += iraDeduction;
    breakdown.push({ label: 'Traditional IRA Contribution', amount: -iraDeduction, type: 'adjustment' });
  }

  // HSA
  if (input.hsaContribution > 0) {
    const hsaLimit = input.filingStatus === 'married_filing_jointly' ? 8550 : 4300; // 2025 family/individual
    const hsaDeduction = Math.min(input.hsaContribution, hsaLimit);
    adjustments += hsaDeduction;
    breakdown.push({ label: 'HSA Contribution', amount: -hsaDeduction, type: 'adjustment' });
  }

  // Student Loan Interest
  if (input.studentLoanInterest > 0) {
    const studentLoanDeduction = Math.min(input.studentLoanInterest, 2500);
    adjustments += studentLoanDeduction;
    breakdown.push({ label: 'Student Loan Interest', amount: -studentLoanDeduction, type: 'adjustment' });
  }

  // Self-employed health insurance
  if (input.selfEmploymentHealthInsurance > 0 && input.selfEmploymentIncome > 0) {
    adjustments += input.selfEmploymentHealthInsurance;
    breakdown.push({ label: 'Self-Employed Health Insurance', amount: -input.selfEmploymentHealthInsurance, type: 'adjustment' });
  }

  const adjustedGrossIncome = grossIncome - adjustments;
  breakdown.push({ label: 'Adjusted Gross Income', amount: adjustedGrossIncome, type: 'income' });

  // Step 3: Calculate Deductions
  let standardDeduction = STANDARD_DEDUCTIONS_2025[input.filingStatus];
  
  // Additional standard deduction for 65+ or blind
  if (input.isOver65) standardDeduction += ADDITIONAL_STANDARD_DEDUCTION_2025[input.filingStatus];
  if (input.isBlind) standardDeduction += ADDITIONAL_STANDARD_DEDUCTION_2025[input.filingStatus];
  if (input.spouseOver65) standardDeduction += ADDITIONAL_STANDARD_DEDUCTION_2025[input.filingStatus];
  if (input.spouseBlind) standardDeduction += ADDITIONAL_STANDARD_DEDUCTION_2025[input.filingStatus];

  const deduction = input.useItemized && input.itemizedDeductions > standardDeduction 
    ? input.itemizedDeductions 
    : standardDeduction;

  breakdown.push({ 
    label: input.useItemized && input.itemizedDeductions > standardDeduction ? 'Itemized Deductions' : 'Standard Deduction', 
    amount: -deduction, 
    type: 'deduction' 
  });

  // Step 4: Calculate Taxable Income
  const taxableIncome = Math.max(0, adjustedGrossIncome - deduction);
  breakdown.push({ label: 'Taxable Income', amount: taxableIncome, type: 'income' });

  // Step 5: Calculate Ordinary Income Tax
  // Separate ordinary income from capital gains for preferential rates
  const ordinaryIncome = taxableIncome - Math.max(0, input.longTermGains) - Math.max(0, input.qualifiedDividends);
  const ordinaryIncomeTax = calculateTaxFromBrackets(Math.max(0, ordinaryIncome), input.filingStatus);
  
  // Step 6: Calculate Capital Gains Tax
  const capitalGainsTax = calculateCapitalGainsTax(
    Math.max(0, input.longTermGains) + Math.max(0, input.qualifiedDividends),
    ordinaryIncome,
    input.filingStatus
  );

  const totalTax = ordinaryIncomeTax + capitalGainsTax + selfEmploymentTax;
  
  breakdown.push({ label: 'Federal Income Tax', amount: ordinaryIncomeTax + capitalGainsTax, type: 'tax' });
  if (selfEmploymentTax > 0) {
    breakdown.push({ label: 'Self-Employment Tax', amount: selfEmploymentTax, type: 'tax' });
  }

  // Step 7: Calculate Credits
  const childTaxCredit = calculateChildTaxCredit(input, adjustedGrossIncome);
  const earnedIncomeCredit = calculateEarnedIncomeCredit(input, adjustedGrossIncome);
  const educationCredit = calculateEducationCredit(input.educationExpenses, adjustedGrossIncome);
  const childCareCredit = calculateChildCareCredit(input.childCareExpenses, adjustedGrossIncome, input.numDependentsUnder17);
  const retirementSavingsCredit = calculateRetirementSavingsCredit(input.retirementContributions, adjustedGrossIncome, input.filingStatus);

  const totalCredits = childTaxCredit + earnedIncomeCredit + educationCredit + childCareCredit + retirementSavingsCredit;

  if (childTaxCredit > 0) breakdown.push({ label: 'Child Tax Credit', amount: -childTaxCredit, type: 'credit' });
  if (earnedIncomeCredit > 0) breakdown.push({ label: 'Earned Income Credit', amount: -earnedIncomeCredit, type: 'credit' });
  if (educationCredit > 0) breakdown.push({ label: 'Education Credit', amount: -educationCredit, type: 'credit' });
  if (childCareCredit > 0) breakdown.push({ label: 'Child Care Credit', amount: -childCareCredit, type: 'credit' });
  if (retirementSavingsCredit > 0) breakdown.push({ label: 'Retirement Savings Credit', amount: -retirementSavingsCredit, type: 'credit' });

  // Step 8: Calculate Final Tax
  const taxAfterCredits = Math.max(0, totalTax - totalCredits);
  const totalWithholding = input.federalWithholding;
  const refundOrOwed = totalWithholding - taxAfterCredits;

  breakdown.push({ label: 'Federal Withholding', amount: -input.federalWithholding, type: 'payment' });
  breakdown.push({ 
    label: refundOrOwed >= 0 ? 'Refund' : 'Amount Owed', 
    amount: Math.abs(refundOrOwed), 
    type: 'payment' 
  });

  // Calculate rates
  const effectiveRate = grossIncome > 0 ? (taxAfterCredits / grossIncome) * 100 : 0;
  const marginalRate = getMarginalRate(taxableIncome, input.filingStatus) * 100;

  return {
    grossIncome,
    adjustedGrossIncome,
    taxableIncome,
    ordinaryIncomeTax,
    capitalGainsTax,
    selfEmploymentTax,
    totalTax,
    childTaxCredit,
    earnedIncomeCredit,
    educationCredit,
    childCareCredit,
    retirementSavingsCredit,
    totalCredits,
    taxAfterCredits,
    totalWithholding,
    refundOrOwed,
    effectiveRate,
    marginalRate,
    breakdown,
  };
}

/**
 * Calculate tax from brackets
 */
function calculateTaxFromBrackets(income: number, filingStatus: FilingStatus): number {
  const brackets = TAX_BRACKETS_2025[filingStatus];
  let tax = 0;
  let remainingIncome = income;

  for (const bracket of brackets) {
    if (remainingIncome <= 0) break;
    const taxableInBracket = Math.min(remainingIncome, bracket.max - bracket.min);
    tax += taxableInBracket * bracket.rate;
    remainingIncome -= taxableInBracket;
  }

  return Math.round(tax * 100) / 100;
}

/**
 * Get marginal tax rate
 */
function getMarginalRate(income: number, filingStatus: FilingStatus): number {
  const brackets = TAX_BRACKETS_2025[filingStatus];
  for (const bracket of brackets) {
    if (income <= bracket.max) {
      return bracket.rate;
    }
  }
  return brackets[brackets.length - 1].rate;
}

/**
 * Calculate self-employment tax
 */
function calculateSelfEmploymentTax(selfEmploymentIncome: number): number {
  if (selfEmploymentIncome <= 0) return 0;
  
  const netEarnings = selfEmploymentIncome * 0.9235; // 92.35% of SE income
  
  // Social Security portion (12.4% up to wage base)
  const ssTax = Math.min(netEarnings, SELF_EMPLOYMENT_SS_WAGE_BASE_2025) * 0.124;
  
  // Medicare portion (2.9% on all, plus 0.9% additional on high earners)
  let medicareTax = netEarnings * 0.029;
  if (netEarnings > 200000) {
    medicareTax += (netEarnings - 200000) * 0.009;
  }
  
  return Math.round((ssTax + medicareTax) * 100) / 100;
}

/**
 * Calculate capital gains tax with preferential rates
 */
function calculateCapitalGainsTax(gains: number, ordinaryIncome: number, filingStatus: FilingStatus): number {
  if (gains <= 0) return 0;
  
  const rates = LONG_TERM_CAPITAL_GAINS_RATES[
    filingStatus === 'married_filing_jointly' || filingStatus === 'qualifying_widow' 
      ? 'married_filing_jointly' 
      : 'single'
  ];
  
  let tax = 0;
  let remainingGains = gains;
  let incomeLevel = ordinaryIncome;
  
  for (const bracket of rates) {
    if (remainingGains <= 0) break;
    const roomInBracket = Math.max(0, bracket.max - incomeLevel);
    const gainsInBracket = Math.min(remainingGains, roomInBracket);
    tax += gainsInBracket * bracket.rate;
    remainingGains -= gainsInBracket;
    incomeLevel += gainsInBracket;
  }
  
  return Math.round(tax * 100) / 100;
}

/**
 * Calculate Child Tax Credit
 */
function calculateChildTaxCredit(input: TaxInput, agi: number): number {
  const numChildren = input.numDependentsUnder17;
  if (numChildren === 0) return 0;
  
  const baseCredit = numChildren * CHILD_TAX_CREDIT_2025.amountPerChild;
  const threshold = CHILD_TAX_CREDIT_2025.phaseoutStart[
    input.filingStatus === 'married_filing_jointly' ? 'married_filing_jointly' : 'single'
  ];
  
  if (agi <= threshold) return baseCredit;
  
  const excess = Math.ceil((agi - threshold) / 1000) * CHILD_TAX_CREDIT_2025.phaseoutRate;
  return Math.max(0, baseCredit - excess);
}

/**
 * Calculate Earned Income Credit (simplified)
 */
function calculateEarnedIncomeCredit(input: TaxInput, agi: number): number {
  // Only available for certain filing statuses and income levels
  if (input.filingStatus === 'married_filing_separately') return 0;
  
  const earnedIncome = input.wages + input.selfEmploymentIncome;
  if (earnedIncome <= 0) return 0;
  
  const numChildren = input.numDependentsUnder17;
  const eicParams = numChildren >= 3 ? EARNED_INCOME_CREDIT_2025.threeOrMore :
                    numChildren === 2 ? EARNED_INCOME_CREDIT_2025.twoChildren :
                    numChildren === 1 ? EARNED_INCOME_CREDIT_2025.oneChild :
                    EARNED_INCOME_CREDIT_2025.noChildren;
  
  if (agi > eicParams.phaseoutEnd) return 0;
  if (agi <= eicParams.phaseoutStart) return eicParams.maxCredit;
  
  const reduction = ((agi - eicParams.phaseoutStart) / (eicParams.phaseoutEnd - eicParams.phaseoutStart)) * eicParams.maxCredit;
  return Math.max(0, Math.round((eicParams.maxCredit - reduction) * 100) / 100);
}

/**
 * Calculate Education Credit (American Opportunity / Lifetime Learning)
 */
function calculateEducationCredit(expenses: number, agi: number): number {
  if (expenses <= 0) return 0;
  
  // American Opportunity Credit: 100% of first $2,000 + 25% of next $2,000 = max $2,500
  const aocCredit = Math.min(2000, expenses) + Math.min(500, Math.max(0, expenses - 2000) * 0.25);
  
  // Phase out for higher incomes (simplified)
  if (agi > 90000) return 0;
  if (agi > 80000) {
    return aocCredit * ((90000 - agi) / 10000);
  }
  
  return Math.round(aocCredit * 100) / 100;
}

/**
 * Calculate Child and Dependent Care Credit
 */
function calculateChildCareCredit(expenses: number, agi: number, numDependents: number): number {
  if (expenses <= 0 || numDependents === 0) return 0;
  
  const maxExpenses = numDependents >= 2 ? 6000 : 3000;
  const qualifyingExpenses = Math.min(expenses, maxExpenses);
  
  // Credit percentage based on AGI (20% to 35%)
  let creditPercent = 0.35;
  if (agi > 15000) {
    creditPercent = Math.max(0.20, 0.35 - ((agi - 15000) / 2000) * 0.01);
  }
  
  return Math.round(qualifyingExpenses * creditPercent * 100) / 100;
}

/**
 * Calculate Retirement Savings Contributions Credit (Saver's Credit)
 */
function calculateRetirementSavingsCredit(contributions: number, agi: number, filingStatus: FilingStatus): number {
  if (contributions <= 0) return 0;
  
  const maxContribution = 2000;
  const qualifyingContribution = Math.min(contributions, maxContribution);
  
  // Credit rate based on AGI and filing status
  const thresholds = filingStatus === 'married_filing_jointly' 
    ? { fifty: 46000, twenty: 50000, ten: 76500 }
    : filingStatus === 'head_of_household'
    ? { fifty: 34500, twenty: 37500, ten: 57375 }
    : { fifty: 23000, twenty: 25000, ten: 38250 };
  
  let rate = 0;
  if (agi <= thresholds.fifty) rate = 0.50;
  else if (agi <= thresholds.twenty) rate = 0.20;
  else if (agi <= thresholds.ten) rate = 0.10;
  
  return Math.round(qualifyingContribution * rate * 100) / 100;
}

/**
 * Format currency
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Format percentage
 */
export function formatPercent(rate: number): string {
  return `${rate.toFixed(1)}%`;
}
