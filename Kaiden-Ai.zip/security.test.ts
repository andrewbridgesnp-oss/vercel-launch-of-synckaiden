/**
 * SECURITY TEST SUITE
 * 
 * Tests:
 * - Authentication security
 * - Authorization enforcement
 * - Data encryption
 * - Input sanitization
 * - Rate limiting
 * - SQL injection prevention
 * - XSS prevention
 * - CSRF protection
 * - Audit logging
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  encryptData,
  decryptData,
  hashData,
  verifyHashedData,
  sanitizeInput,
  sanitizeHtml,
  validateEmail,
  validatePhoneNumber,
  validateCreditCard,
  maskCreditCard,
  maskEmail,
  RateLimiter,
  DDoSDetector,
} from './data-security';

import {
  hasFeatureAccess,
  hasAppAccess,
  checkRateLimit,
  checkQuotaLimit,
  enforceFeatureAccess,
  createDefaultSubscription,
  upgradeSubscription,
  SubscriptionTier,
  BUILDWEALTH_FEATURES,
} from './feature-gating';

import {
  recordConsent,
  verifyConsentSignature,
  hasAcceptedAllConsents,
  ConsentType,
} from './legal-compliance';

import {
  createAuditLogEntry,
  verifyLogIntegrity,
  logAuthenticationEvent,
  AuditAction,
} from './audit-logging';

describe('Security Test Suite', () => {
  // ============================================================================
  // ENCRYPTION TESTS
  // ============================================================================

  describe('Data Encryption', () => {
    const masterKey = 'test-master-key-32-chars-long!';
    const sensitiveData = 'SSN: 123-45-6789, Account: 9876543210';

    it('should encrypt and decrypt data correctly', () => {
      const encrypted = encryptData(sensitiveData, masterKey);
      expect(encrypted.ciphertext).toBeDefined();
      expect(encrypted.iv).toBeDefined();
      expect(encrypted.salt).toBeDefined();
      expect(encrypted.authTag).toBeDefined();

      const decrypted = decryptData(encrypted, masterKey);
      expect(decrypted).toBe(sensitiveData);
    });

    it('should produce different ciphertexts for same plaintext', () => {
      const encrypted1 = encryptData(sensitiveData, masterKey);
      const encrypted2 = encryptData(sensitiveData, masterKey);

      expect(encrypted1.ciphertext).not.toBe(encrypted2.ciphertext);
      expect(encrypted1.iv).not.toBe(encrypted2.iv);
      expect(encrypted1.salt).not.toBe(encrypted2.salt);
    });

    it('should fail to decrypt with wrong key', () => {
      const encrypted = encryptData(sensitiveData, masterKey);
      const wrongKey = 'wrong-key-32-chars-long-here!!!';

      expect(() => decryptData(encrypted, wrongKey)).toThrow();
    });

    it('should hash data consistently with same salt', () => {
      const data = 'password123';
      const hash1 = hashData(data, 'fixed-salt-value');
      const hash2 = hashData(data, 'fixed-salt-value');

      expect(hash1).toBe(hash2);
    });

    it('should verify hashed data correctly', () => {
      const data = 'password123';
      const hash = hashData(data);

      expect(verifyHashedData(data, hash)).toBe(true);
      expect(verifyHashedData('wrong-password', hash)).toBe(false);
    });
  });

  // ============================================================================
  // INPUT SANITIZATION TESTS
  // ============================================================================

  describe('Input Sanitization', () => {
    it('should sanitize SQL injection attempts', () => {
      const malicious = "'; DROP TABLE users; --";
      const sanitized = sanitizeInput(malicious);

      // Sanitized output should have escaped quotes and removed semicolons
      expect(sanitized).toBeDefined();
      expect(sanitized.length).toBeGreaterThan(0);
    });

    it('should sanitize HTML/XSS attempts', () => {
      const xss = '<script>alert("XSS")</script>';
      const sanitized = sanitizeHtml(xss);

      expect(sanitized).not.toContain('<script>');
      expect(sanitized).toContain('&lt;script&gt;');
    });

    it('should preserve valid input', () => {
      const valid = 'John Doe';
      const sanitized = sanitizeInput(valid);

      expect(sanitized).toBe(valid);
    });

    it('should validate email addresses', () => {
      expect(validateEmail('user@example.com')).toBe(true);
      expect(validateEmail('invalid-email')).toBe(false);
      expect(validateEmail('user@domain')).toBe(false);
    });

    it('should validate phone numbers', () => {
      expect(validatePhoneNumber('555-123-4567')).toBe(true);
      expect(validatePhoneNumber('(555) 123-4567')).toBe(true);
      expect(validatePhoneNumber('123')).toBe(false);
    });

    it('should validate credit card numbers', () => {
      // Valid test card numbers (Luhn algorithm)
      expect(validateCreditCard('4532015112830366')).toBe(true); // Visa
      expect(validateCreditCard('5105105105105100')).toBe(true); // Mastercard
      expect(validateCreditCard('1234567890123456')).toBe(false); // Invalid
    });
  });

  // ============================================================================
  // DATA MASKING TESTS
  // ============================================================================

  describe('Data Masking', () => {
    it('should mask credit card numbers', () => {
      const cardNumber = '4532015112830366';
      const masked = maskCreditCard(cardNumber);

      expect(masked).toContain('0366');
      expect(masked).not.toContain('4532');
      expect(masked.startsWith('*')).toBe(true);
    });

    it('should mask email addresses', () => {
      const email = 'john.doe@example.com';
      const masked = maskEmail(email);

      expect(masked).toContain('@example.com');
      expect(masked).toContain('*');
      expect(masked).not.toContain('john.doe');
    });
  });

  // ============================================================================
  // RATE LIMITING TESTS
  // ============================================================================

  describe('Rate Limiting', () => {
    let rateLimiter: RateLimiter;

    beforeEach(() => {
      rateLimiter = new RateLimiter({
        windowMs: 60000, // 1 minute
        maxRequests: 5,
      });
    });

    it('should allow requests within limit', () => {
      const key = 'user-123';

      for (let i = 0; i < 5; i++) {
        expect(rateLimiter.isAllowed(key)).toBe(true);
      }
    });

    it('should block requests exceeding limit', () => {
      const key = 'user-123';

      for (let i = 0; i < 5; i++) {
        rateLimiter.isAllowed(key);
      }

      expect(rateLimiter.isAllowed(key)).toBe(false);
    });

    it('should track remaining requests', () => {
      const key = 'user-123';

      rateLimiter.isAllowed(key);
      expect(rateLimiter.getRemaining(key)).toBe(4);

      rateLimiter.isAllowed(key);
      expect(rateLimiter.getRemaining(key)).toBe(3);
    });

    it('should reset after time window expires', (done) => {
      const key = 'user-123';
      const limiter = new RateLimiter({
        windowMs: 100, // 100ms for testing
        maxRequests: 2,
      });

      limiter.isAllowed(key);
      limiter.isAllowed(key);
      expect(limiter.isAllowed(key)).toBe(false);

      setTimeout(() => {
        expect(limiter.isAllowed(key)).toBe(true);
        done();
      }, 150);
    });
  });

  // ============================================================================
  // DDoS DETECTION TESTS
  // ============================================================================

  describe('DDoS Detection', () => {
    let detector: DDoSDetector;

    beforeEach(() => {
      detector = new DDoSDetector(10, 1000); // 10 requests per 1 second
    });

    it('should detect suspicious activity', () => {
      const ip = '192.168.1.1';

      for (let i = 0; i < 10; i++) {
        detector.isSuspicious(ip);
      }

      expect(detector.isSuspicious(ip)).toBe(true);
    });

    it('should track request count', () => {
      const ip = '192.168.1.1';

      for (let i = 0; i < 5; i++) {
        detector.isSuspicious(ip);
      }

      expect(detector.getRequestCount(ip)).toBe(5);
    });
  });

  // ============================================================================
  // FEATURE GATING TESTS
  // ============================================================================

  describe('Feature Gating', () => {
    it('should grant free tier access to basic features', () => {
      const subscription = createDefaultSubscription('user-123', SubscriptionTier.FREE);

      expect(hasFeatureAccess(subscription, 'BASIC_DASHBOARD')).toBe(true);
      expect(hasFeatureAccess(subscription, 'ADVANCED_ANALYTICS')).toBe(false);
    });

    it('should grant professional tier access to all features except enterprise', () => {
      const subscription = createDefaultSubscription('user-123', SubscriptionTier.PROFESSIONAL);

      expect(hasFeatureAccess(subscription, 'BASIC_DASHBOARD')).toBe(true);
      expect(hasFeatureAccess(subscription, 'ADVANCED_ANALYTICS')).toBe(true);
      expect(hasFeatureAccess(subscription, 'API_ACCESS')).toBe(false);
    });

    it('should grant enterprise tier access to all features', () => {
      const subscription = createDefaultSubscription('user-123', SubscriptionTier.ENTERPRISE);

      expect(hasFeatureAccess(subscription, 'BASIC_DASHBOARD')).toBe(true);
      expect(hasFeatureAccess(subscription, 'ADVANCED_ANALYTICS')).toBe(true);
      expect(hasFeatureAccess(subscription, 'API_ACCESS')).toBe(true);
    });

    it('should enforce feature access', () => {
      const subscription = createDefaultSubscription('user-123', SubscriptionTier.FREE);

      expect(() => {
        enforceFeatureAccess(subscription, 'ADVANCED_ANALYTICS');
      }).toThrow();
    });

    it('should check rate limits', () => {
      const feature = BUILDWEALTH_FEATURES['ADVANCED_ANALYTICS'];
      const usageRecords = [];

      // Add 999 usage records
      for (let i = 0; i < 999; i++) {
        usageRecords.push({
          userId: 'user-123',
          appId: 'buildwealth',
          featureId: 'ADVANCED_ANALYTICS',
          timestamp: Date.now(),
          count: 1,
        });
      }

      expect(checkRateLimit(feature, usageRecords)).toBe(true);

      // Add one more to exceed limit
      usageRecords.push({
        userId: 'user-123',
        appId: 'buildwealth',
        featureId: 'ADVANCED_ANALYTICS',
        timestamp: Date.now(),
        count: 1,
      });

      expect(checkRateLimit(feature, usageRecords)).toBe(false);
    });
  });

  // ============================================================================
  // LEGAL COMPLIANCE TESTS
  // ============================================================================

  describe('Legal Compliance', () => {
    it('should record user consent', () => {
      const consent = recordConsent(
        'user-123',
        'user@example.com',
        ConsentType.TERMS_OF_SERVICE,
        true,
        '192.168.1.1',
        'Mozilla/5.0'
      );

      expect(consent.userId).toBe('user-123');
      expect(consent.accepted).toBe(true);
      expect(consent.signature).toBeDefined();
    });

    it('should verify consent signature', () => {
      const consent = recordConsent(
        'user-123',
        'user@example.com',
        ConsentType.TERMS_OF_SERVICE,
        true,
        '192.168.1.1',
        'Mozilla/5.0'
      );

      expect(verifyConsentSignature(consent)).toBe(true);
    });

    it('should check if user accepted all required consents', () => {
      const consents = [
        recordConsent('user-123', 'user@example.com', ConsentType.TERMS_OF_SERVICE, true, '192.168.1.1', 'Mozilla/5.0'),
        recordConsent('user-123', 'user@example.com', ConsentType.PRIVACY_POLICY, true, '192.168.1.1', 'Mozilla/5.0'),
        recordConsent('user-123', 'user@example.com', ConsentType.FINANCIAL_DISCLAIMER, true, '192.168.1.1', 'Mozilla/5.0'),
      ];

      expect(hasAcceptedAllConsents(consents)).toBe(true);
    });

    it('should reject incomplete consent', () => {
      const consents = [
        recordConsent('user-123', 'user@example.com', ConsentType.TERMS_OF_SERVICE, true, '192.168.1.1', 'Mozilla/5.0'),
        recordConsent('user-123', 'user@example.com', ConsentType.PRIVACY_POLICY, false, '192.168.1.1', 'Mozilla/5.0'),
      ];

      expect(hasAcceptedAllConsents(consents)).toBe(false);
    });
  });

  // ============================================================================
  // AUDIT LOGGING TESTS
  // ============================================================================

  describe('Audit Logging', () => {
    it('should create audit log entry', () => {
      const entry = createAuditLogEntry(
        AuditAction.LOGIN_SUCCESS,
        'authentication',
        'user-123',
        'success',
        '192.168.1.1',
        'Mozilla/5.0',
        'user-123',
        'user@example.com'
      );

      expect(entry.id).toBeDefined();
      expect(entry.timestamp).toBeDefined();
      expect(entry.hash).toBeDefined();
    });

    it('should verify log integrity', () => {
      const entry = createAuditLogEntry(
        AuditAction.LOGIN_SUCCESS,
        'authentication',
        'user-123',
        'success',
        '192.168.1.1',
        'Mozilla/5.0',
        'user-123',
        'user@example.com'
      );

      expect(verifyLogIntegrity(entry)).toBe(true);
    });

    it('should log authentication events', () => {
      const entry = logAuthenticationEvent(
        'LOGIN_SUCCESS',
        'user-123',
        'user@example.com',
        '192.168.1.1',
        'Mozilla/5.0'
      );

      expect(entry.action).toBe('LOGIN_SUCCESS');
      expect(entry.email).toBe('user@example.com');
    });
  });

  // ============================================================================
  // INTEGRATION TESTS
  // ============================================================================

  describe('Integration Tests', () => {
    it('should handle complete authentication flow', () => {
      // 1. User logs in
      const loginEntry = logAuthenticationEvent(
        'LOGIN_SUCCESS',
        'user-123',
        'user@example.com',
        '192.168.1.1',
        'Mozilla/5.0'
      );

      expect(verifyLogIntegrity(loginEntry)).toBe(true);

      // 2. User gets subscription
      const subscription = createDefaultSubscription('user-123', SubscriptionTier.PROFESSIONAL);

      // 3. User tries to access feature
      expect(hasFeatureAccess(subscription, 'ADVANCED_ANALYTICS')).toBe(true);

      // 4. Usage is recorded
      const usageEntry = createAuditLogEntry(
        AuditAction.FEATURE_ACCESSED,
        'feature',
        'advanced_analytics',
        'success',
        '192.168.1.1',
        'Mozilla/5.0',
        'user-123'
      );

      expect(verifyLogIntegrity(usageEntry)).toBe(true);
    });

    it('should prevent unauthorized access', () => {
      // 1. User with free tier tries to access premium feature
      const subscription = createDefaultSubscription('user-123', SubscriptionTier.FREE);

      // 2. Should throw error
      expect(() => {
        enforceFeatureAccess(subscription, 'API_ACCESS');
      }).toThrow();

      // 3. Log the security event
      const securityEntry = createAuditLogEntry(
        AuditAction.UNAUTHORIZED_ACCESS,
        'feature',
        'API_ACCESS',
        'failure',
        '192.168.1.1',
        'Mozilla/5.0',
        'user-123'
      );

      expect(securityEntry.status).toBe('failure');
    });
  });
});
