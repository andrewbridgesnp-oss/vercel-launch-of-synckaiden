import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Redirect } from "wouter";
import {
  Home,
  Building2,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Hammer,
  Users,
  FileText,
  Target,
  Zap,
  Phone,
  MessageSquare,
  ArrowRight,
  Star,
  Clock,
  Shield,
  Percent,
  CreditCard,
  Truck,
  Key,
} from "lucide-react";

// Fix & Flip Process
const fixFlipSteps = [
  {
    step: 1,
    title: "Find the Deal",
    description: "Use SMS lead generation, agent networks, and land bank auctions to find distressed properties.",
    icon: Target,
  },
  {
    step: 2,
    title: "Analyze the Numbers",
    description: "ARV (After Repair Value) - Repairs - Holding Costs - Profit = Maximum Purchase Price",
    icon: TrendingUp,
  },
  {
    step: 3,
    title: "Secure Financing",
    description: "Hard money, private money, or DSCR loans. EIN-only options available at higher credit scores.",
    icon: DollarSign,
  },
  {
    step: 4,
    title: "Renovate",
    description: "Focus on kitchen, bathrooms, flooring, and curb appeal. Stay on budget and timeline.",
    icon: Hammer,
  },
  {
    step: 5,
    title: "Sell or Refinance",
    description: "List with agent or BRRRR (Buy, Rehab, Rent, Refinance, Repeat) into a rental.",
    icon: Key,
  },
];

// Loan Types
const loanTypes = [
  {
    name: "203K Loan",
    description: "FHA renovation loan. Purchase + rehab in one loan. Low down payment (3.5%).",
    pros: ["Low down payment", "One loan for purchase + rehab", "FHA-insured"],
    cons: ["Strict requirements", "Longer closing times", "Property must be primary residence"],
    bestFor: "First-time investors buying primary residence to renovate",
  },
  {
    name: "DSCR Loan",
    description: "Debt Service Coverage Ratio loan. Qualifies based on property income, not personal income.",
    pros: ["No personal income verification", "Unlimited properties", "Fast closing"],
    cons: ["Higher rates", "Larger down payment (20-25%)", "Requires rental income"],
    bestFor: "Investors with multiple properties or self-employed",
  },
  {
    name: "Hard Money",
    description: "Short-term, asset-based loans from private lenders. Fast funding for flips.",
    pros: ["Fast approval (days)", "Credit flexible", "Based on property value"],
    cons: ["High interest (10-15%)", "Short terms (6-24 months)", "Points and fees"],
    bestFor: "Quick flips and bridge financing",
  },
  {
    name: "HUD Homes",
    description: "Government-owned properties sold at discount. Special programs for investors.",
    pros: ["Below market prices", "Less competition", "Government-backed"],
    cons: ["As-is condition", "Specific bidding process", "Limited inventory"],
    bestFor: "Patient investors looking for deals",
  },
];

// House Hacking Strategies
const houseHackingStrategies = [
  {
    title: "Multi-Family House Hack",
    description: "Buy a 2-4 unit property, live in one unit, rent the others. FHA allows 3.5% down.",
    example: "Buy a triplex for $300K, live in one unit, rent two for $1,500/month each = $3,000 income",
  },
  {
    title: "Rent by Room",
    description: "Buy a single-family home and rent individual rooms. Higher cash flow per property.",
    example: "4-bedroom home, rent 3 rooms at $700/month each = $2,100 income",
  },
  {
    title: "ADU Strategy",
    description: "Add an Accessory Dwelling Unit (in-law suite, garage apartment) for rental income.",
    example: "Convert garage to studio apartment, rent for $1,200/month",
  },
];

// EIN-Only Strategies
const einOnlyStrategies = [
  {
    title: "0% Interest Business Cards",
    description: "Apply for business credit cards with 0% intro APR. Use for materials and holding costs.",
    requirements: "650+ personal credit, established LLC, business bank account",
    cards: ["Chase Ink", "Amex Blue Business", "Capital One Spark"],
  },
  {
    title: "EIN-Only Credit Lines",
    description: "Business credit lines that don't require personal guarantee after established history.",
    requirements: "2+ years in business, strong business credit, $100K+ revenue",
    lenders: ["BlueVine", "Fundbox", "OnDeck"],
  },
  {
    title: "Fleet Vehicle Financing",
    description: "Finance work vehicles under EIN only. Build business credit while getting equipment.",
    requirements: "Established business credit, 680+ business credit score",
    options: ["Ford Commercial", "GM Fleet", "Enterprise Fleet"],
  },
];

// Land Bank Hacks
const landBankHacks = [
  "Check your local land bank for tax-foreclosed properties",
  "Many sell for $1-$5,000 with clear title",
  "Some offer renovation financing programs",
  "First-time buyer and investor programs available",
  "Side lot programs for adjacent property owners",
  "Demolition-to-development programs",
];

// Lead Generation
const leadGenStrategies = [
  {
    title: "SMS Lead Scraping",
    description: "Automated SMS campaigns to distressed property owners",
    features: ["Skip tracing integration", "Automated follow-up", "Human callback routing"],
  },
  {
    title: "Agent Network",
    description: "Build relationships with agents who find off-market deals",
    features: ["Pocket listings", "Pre-foreclosure leads", "Estate sales"],
  },
  {
    title: "Driving for Dollars",
    description: "Find distressed properties by driving neighborhoods",
    features: ["Property tracking apps", "Owner lookup", "Direct mail campaigns"],
  },
];

export default function RealEstate() {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
            <Home className="h-8 w-8 text-primary" />
          </div>
          <p className="text-muted-foreground">Loading real estate tools...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        {/* Legal Disclaimer */}
        <Alert className="mb-8 border-yellow-500/50 bg-yellow-500/10">
          <AlertTriangle className="h-4 w-4 text-yellow-500" />
          <AlertTitle className="text-yellow-500">Important Legal Disclaimer</AlertTitle>
          <AlertDescription className="text-muted-foreground">
            <strong>I am NOT a licensed real estate agent, attorney, or financial advisor.</strong> Real estate investing involves significant risk. Always conduct your own due diligence and consult with qualified professionals before making investment decisions.
          </AlertDescription>
        </Alert>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            <span className="gradient-text">Real Estate Investment</span>
          </h1>
          <p className="text-muted-foreground">
            Strategies for fix & flip, house hacking, and building a real estate portfolio.
          </p>
        </div>

        <Tabs defaultValue="fixflip" className="space-y-8">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="fixflip">Fix & Flip</TabsTrigger>
            <TabsTrigger value="loans">Loan Types</TabsTrigger>
            <TabsTrigger value="househack">House Hacking</TabsTrigger>
            <TabsTrigger value="einonly">EIN-Only</TabsTrigger>
            <TabsTrigger value="leads">Lead Generation</TabsTrigger>
          </TabsList>

          {/* Fix & Flip */}
          <TabsContent value="fixflip" className="space-y-6">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Hammer className="h-5 w-5 text-primary" />
                  How to Become a Fix & Flipper
                </CardTitle>
                <CardDescription>
                  Step-by-step process to find, fund, renovate, and profit from distressed properties
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {fixFlipSteps.map((step) => {
                  const Icon = step.icon;
                  return (
                    <div key={step.step} className="flex gap-4">
                      <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline">Step {step.step}</Badge>
                          <h3 className="font-semibold">{step.title}</h3>
                        </div>
                        <p className="text-sm text-muted-foreground">{step.description}</p>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Land Bank Hacks */}
            <Card className="luxury-card border-primary/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  Land Bank Hacks & Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {landBankHacks.map((hack, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span>{hack}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Loan Types */}
          <TabsContent value="loans" className="space-y-6">
            {loanTypes.map((loan) => (
              <Card key={loan.name} className="luxury-card">
                <CardHeader>
                  <CardTitle>{loan.name}</CardTitle>
                  <CardDescription>{loan.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <h4 className="font-medium text-green-500 mb-2 flex items-center gap-1">
                        <CheckCircle2 className="h-4 w-4" /> Pros
                      </h4>
                      <ul className="text-sm space-y-1">
                        {loan.pros.map((pro, i) => (
                          <li key={i} className="text-muted-foreground">• {pro}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-red-500 mb-2 flex items-center gap-1">
                        <AlertTriangle className="h-4 w-4" /> Cons
                      </h4>
                      <ul className="text-sm space-y-1">
                        {loan.cons.map((con, i) => (
                          <li key={i} className="text-muted-foreground">• {con}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-primary mb-2 flex items-center gap-1">
                        <Target className="h-4 w-4" /> Best For
                      </h4>
                      <p className="text-sm text-muted-foreground">{loan.bestFor}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* House Hacking */}
          <TabsContent value="househack" className="space-y-6">
            <Card className="luxury-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Multi-Tenant House Hacking
                </CardTitle>
                <CardDescription>
                  Live for free (or get paid) while building equity
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {houseHackingStrategies.map((strategy, index) => (
                  <div key={index} className="p-4 rounded-lg bg-secondary/50">
                    <h4 className="font-medium mb-2">{strategy.title}</h4>
                    <p className="text-sm text-muted-foreground mb-3">{strategy.description}</p>
                    <div className="flex items-center gap-2 p-3 rounded bg-primary/10 border border-primary/20">
                      <DollarSign className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">{strategy.example}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* EIN-Only Strategies */}
          <TabsContent value="einonly" className="space-y-6">
            {einOnlyStrategies.map((strategy, index) => (
              <Card key={index} className="luxury-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {index === 0 && <Percent className="h-5 w-5 text-primary" />}
                    {index === 1 && <CreditCard className="h-5 w-5 text-primary" />}
                    {index === 2 && <Truck className="h-5 w-5 text-primary" />}
                    {strategy.title}
                  </CardTitle>
                  <CardDescription>{strategy.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <h4 className="text-sm font-medium mb-2">Requirements:</h4>
                    <p className="text-sm text-muted-foreground">{strategy.requirements}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {(strategy.cards || strategy.lenders || strategy.options)?.map((item, i) => (
                      <Badge key={i} variant="outline">{item}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Vehicle Purchase Strategy */}
            <Card className="luxury-card border-primary/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  0% Interest Vehicle Purchase Strategy
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="space-y-3">
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">1</Badge>
                    <span>Apply for 0% APR business credit cards (Chase Ink, Amex Blue Business)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">2</Badge>
                    <span>Find dealer that accepts credit card for down payment or full purchase</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">3</Badge>
                    <span>Pay off within 0% period (12-21 months typically)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Badge variant="outline" className="mt-0.5">4</Badge>
                    <span>Earn points/cashback on purchase while paying 0% interest</span>
                  </li>
                </ol>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Lead Generation */}
          <TabsContent value="leads" className="space-y-6">
            {leadGenStrategies.map((strategy, index) => (
              <Card key={index} className="luxury-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {index === 0 && <MessageSquare className="h-5 w-5 text-primary" />}
                    {index === 1 && <Users className="h-5 w-5 text-primary" />}
                    {index === 2 && <Target className="h-5 w-5 text-primary" />}
                    {strategy.title}
                  </CardTitle>
                  <CardDescription>{strategy.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {strategy.features.map((feature, i) => (
                      <Badge key={i} className="bg-primary/20 text-primary">{feature}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* SMS Lead System */}
            <Card className="luxury-card border-yellow-500/30">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-yellow-500/20 flex items-center justify-center">
                    <Phone className="h-8 w-8 text-yellow-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Agent SMS Lead System</h3>
                    <p className="text-muted-foreground">Scrape leads → Send SMS → Report back → Connect to human on callback</p>
                    <Badge variant="outline" className="mt-2">Automated + Human Handoff</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
