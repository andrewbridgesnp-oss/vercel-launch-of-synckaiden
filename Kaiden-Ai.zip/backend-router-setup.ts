/**
 * Backend tRPC Router Setup for synckaiden.com Integration
 * 
 * This file shows how to set up the tRPC router on the backend.
 * Place this in your server directory.
 */

import express, { Express } from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "./routers";
import { createContext } from "./_core/context";
import cors from "cors";
import cookieParser from "cookie-parser";

/**
 * Initialize Express app with tRPC
 */
export function setupTRPCRouter(app: Express) {
  // Middleware
  app.use(
    cors({
      origin: process.env.FRONTEND_URL || "http://localhost:5173",
      credentials: true,
    })
  );

  app.use(cookieParser());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // tRPC endpoint
  app.use(
    "/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
      onError: ({ path, error }) => {
        console.error(`tRPC Error on ${path}:`, error);
      },
    })
  );

  // Health check endpoint
  app.get("/health", (req, res) => {
    res.json({ status: "ok" });
  });

  return app;
}

/**
 * Example Express server setup:
 * 
 * import express from "express";
 * import { setupTRPCRouter } from "./setup";
 * 
 * const app = express();
 * setupTRPCRouter(app);
 * 
 * const PORT = process.env.PORT || 3000;
 * app.listen(PORT, () => {
 *   console.log(`Server running on http://localhost:${PORT}`);
 * });
 */
