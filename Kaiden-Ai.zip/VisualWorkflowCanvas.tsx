import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Play, Save } from "lucide-react";
import { useState } from "react";

interface WorkflowNode {
  id: string;
  type: "trigger" | "action" | "condition";
  label: string;
  x: number;
  y: number;
}

interface VisualWorkflowCanvasProps {
  onSave?: (nodes: WorkflowNode[]) => void;
  onRun?: () => void;
  className?: string;
}

export function VisualWorkflowCanvas({ onSave, onRun, className = "" }: VisualWorkflowCanvasProps) {
  const [nodes, setNodes] = useState<WorkflowNode[]>([
    { id: "1", type: "trigger", label: "When...", x: 50, y: 50 },
  ]);

  const addNode = (type: WorkflowNode["type"]) => {
    const newNode: WorkflowNode = {
      id: Date.now().toString(),
      type,
      label: type === "trigger" ? "When..." : type === "action" ? "Then..." : "If...",
      x: 50,
      y: 50 + nodes.length * 100,
    };
    setNodes([...nodes, newNode]);
  };

  return (
    <Card className={`p-6 ${className}`}>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Workflow Canvas</h3>
        <div className="flex gap-2">
          <Button onClick={() => addNode("action")} size="sm" variant="outline">
            <Plus className="h-4 w-4 mr-2" />
            Add Step
          </Button>
          {onSave && (
            <Button onClick={() => onSave(nodes)} size="sm" variant="outline">
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
          )}
          {onRun && (
            <Button onClick={onRun} size="sm">
              <Play className="h-4 w-4 mr-2" />
              Run
            </Button>
          )}
        </div>
      </div>

      <div className="relative min-h-[400px] bg-slate-900/50 rounded-lg border border-slate-700 p-4">
        {nodes.map((node, index) => (
          <div
            key={node.id}
            className="absolute bg-blue-500/20 border border-blue-500/50 rounded-lg p-4 min-w-[200px]"
            style={{ top: `${node.y}px`, left: `${node.x}px` }}
          >
            <div className="text-sm font-medium text-blue-300">{node.type.toUpperCase()}</div>
            <div className="text-white mt-1">{node.label}</div>
            {index < nodes.length - 1 && (
              <div className="absolute left-1/2 -bottom-8 w-0.5 h-8 bg-blue-500/50" />
            )}
          </div>
        ))}
        
        {nodes.length === 0 && (
          <div className="flex items-center justify-center h-full text-slate-400">
            Click "Add Step" to start building your workflow
          </div>
        )}
      </div>
    </Card>
  );
}
