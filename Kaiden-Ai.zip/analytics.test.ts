import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import Analytics, { getAnalytics } from './analytics';

describe('Analytics', () => {
  let analytics: Analytics;
  let localStorageMock: Record<string, string>;

  beforeEach(() => {
    // Mock localStorage
    localStorageMock = {};
    global.localStorage = {
      getItem: (key: string) => localStorageMock[key] || null,
      setItem: (key: string, value: string) => {
        localStorageMock[key] = value;
      },
      removeItem: (key: string) => {
        delete localStorageMock[key];
      },
      clear: () => {
        localStorageMock = {};
      },
      length: 0,
      key: () => null,
    } as any;

    // Create new analytics instance
    analytics = new Analytics({
      enabled: true,
      debug: false,
    });
  });

  afterEach(() => {
    analytics.destroy();
  });

  describe('Session Management', () => {
    it('should generate a unique session ID', () => {
      expect(analytics['sessionId']).toBeDefined();
      expect(analytics['sessionId']).toMatch(/^session_/);
    });

    it('should persist session ID to localStorage', () => {
      expect(localStorageMock['analytics_session_id']).toBeDefined();
    });

    it('should reuse existing session ID', () => {
      const firstSessionId = analytics['sessionId'];
      analytics.destroy();

      const analytics2 = new Analytics({ enabled: true });
      expect(analytics2['sessionId']).toBe(firstSessionId);
      analytics2.destroy();
    });
  });

  describe('Event Tracking', () => {
    it('should track personality selection', () => {
      analytics.trackPersonalitySelection('visionary');
      expect(analytics['eventQueue'].length).toBeGreaterThan(0);

      const event = analytics['eventQueue'][analytics['eventQueue'].length - 1];
      expect(event.eventName).toBe('personality_selected');
      expect(event.eventData?.personalityId).toBe('visionary');
    });

    it('should track button clicks', () => {
      analytics.trackButtonClick('continue_button', { personalityId: 'strategist' });
      expect(analytics['eventQueue'].length).toBeGreaterThan(0);

      const event = analytics['eventQueue'][analytics['eventQueue'].length - 1];
      expect(event.eventName).toBe('button_clicked');
      expect(event.eventData?.buttonName).toBe('continue_button');
    });

    it('should track feature access', () => {
      analytics.trackFeatureAccess('dashboard', { userId: 123 });
      expect(analytics['eventQueue'].length).toBeGreaterThan(0);

      const event = analytics['eventQueue'][analytics['eventQueue'].length - 1];
      expect(event.eventName).toBe('feature_accessed');
      expect(event.eventData?.featureName).toBe('dashboard');
    });

    it('should track conversions', () => {
      analytics.trackConversion('signup', { source: 'personality_selection' });
      expect(analytics['eventQueue'].length).toBeGreaterThan(0);

      const event = analytics['eventQueue'][analytics['eventQueue'].length - 1];
      expect(event.eventName).toBe('conversion');
      expect(event.eventData?.conversionType).toBe('signup');
    });

    it('should track custom events', () => {
      analytics.trackEvent('custom_event', { customData: 'test' });
      expect(analytics['eventQueue'].length).toBeGreaterThan(0);

      const event = analytics['eventQueue'][analytics['eventQueue'].length - 1];
      expect(event.eventName).toBe('custom_event');
      expect(event.eventData?.customData).toBe('test');
    });
  });

  describe('Event Queue Management', () => {
    it('should queue events', () => {
      const initialLength = analytics['eventQueue'].length; // Account for page_view event
      analytics.trackEvent('event1');
      analytics.trackEvent('event2');
      analytics.trackEvent('event3');

      expect(analytics['eventQueue'].length).toBe(initialLength + 3);
    });

    it('should auto-flush when queue reaches 10 events', async () => {
      const flushSpy = vi.spyOn(analytics, 'flush');

      for (let i = 0; i < 10; i++) {
        analytics.trackEvent(`event_${i}`);
      }

      // Wait for async flush
      await new Promise(resolve => setTimeout(resolve, 100));

      expect(flushSpy).toHaveBeenCalled();
      flushSpy.mockRestore();
    });

    it('should include session ID in events', () => {
      analytics.trackEvent('test_event');
      const event = analytics['eventQueue'][0];

      expect(event.sessionId).toBe(analytics['sessionId']);
    });

    it('should include timestamp in events', () => {
      const beforeTime = Date.now() - 10; // Add buffer for timing
      analytics.trackEvent('test_event');
      const afterTime = Date.now() + 10; // Add buffer for timing

      const event = analytics['eventQueue'][0];
      expect(event.timestamp).toBeGreaterThanOrEqual(beforeTime);
      expect(event.timestamp).toBeLessThanOrEqual(afterTime);
    });
  });

  describe('Singleton Pattern', () => {
    it('should return same instance on multiple calls', () => {
      const instance1 = getAnalytics();
      const instance2 = getAnalytics();

      expect(instance1).toBe(instance2);
    });
  });

  describe('Configuration', () => {
    it('should respect enabled flag', () => {
      const disabledAnalytics = new Analytics({ enabled: false });
      disabledAnalytics.trackEvent('test');

      expect(disabledAnalytics['eventQueue'].length).toBe(0);
      disabledAnalytics.destroy();
    });

    it('should use custom endpoint', () => {
      const customAnalytics = new Analytics({
        enabled: true,
        endpoint: '/custom/analytics',
      });

      expect(customAnalytics['config'].endpoint).toBe('/custom/analytics');
      customAnalytics.destroy();
    });
  });
});
