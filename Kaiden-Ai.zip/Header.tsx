import { Link, useLocation } from 'wouter';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { SpotifyPlayer } from './SpotifyPlayer';
import { getLoginUrl } from '@/const';
import {
  Menu,
  X,
  Settings,
  User,
  LogOut,
  Shield,
  Bell,
  HelpCircle,
  Sparkles,
} from 'lucide-react';

const publicNavLinks = [
  { href: '/apps', label: 'Apps' },
  { href: '/app-store', label: 'App Store' },
  { href: '/agent-swarm', label: 'Agent Swarm' },
  { href: '/video-generation', label: 'Videos' },
  { href: '/social-media', label: 'Social' },
  { href: '/ai-receptionist', label: 'AI Receptionist' },
  { href: '/pricing', label: 'Pricing' },
];

const authNavLinks = [
  { href: '/dashboard', label: 'Dashboard' },
  { href: '/capabilities', label: 'Capabilities' },
  { href: '/integrations', label: 'Integrations' },
];

export function Header() {
  const { user, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();