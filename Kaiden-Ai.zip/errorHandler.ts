import { Request, Response, NextFunction } from 'express';
import { TRPCError } from '@trpc/server';

/**
 * Error Handling & Logging System
 */

export enum ErrorCode {
  // Client errors (4xx)
  BAD_REQUEST = 'BAD_REQUEST',
  UNAUTHORIZED = 'UNAUTHORIZED',
  FORBIDDEN = 'FORBIDDEN',
  NOT_FOUND = 'NOT_FOUND',
  CONFLICT = 'CONFLICT',
  RATE_LIMIT = 'RATE_LIMIT',
  VALIDATION_ERROR = 'VALIDATION_ERROR',

  // Server errors (5xx)
  INTERNAL_ERROR = 'INTERNAL_ERROR',
  SERVICE_UNAVAILABLE = 'SERVICE_UNAVAILABLE',
  TIMEOUT = 'TIMEOUT',
  DATABASE_ERROR = 'DATABASE_ERROR',
  EXTERNAL_API_ERROR = 'EXTERNAL_API_ERROR',
}

export interface AppError extends Error {
  code: ErrorCode;
  statusCode: number;
  details?: Record<string, any>;
  timestamp: Date;
  requestId: string;
}

/**
 * Create application error
 */
export function createAppError(
  code: ErrorCode,
  message: string,
  statusCode: number,
  details?: Record<string, any>,
  requestId?: string
): AppError {
  const error = new Error(message) as AppError;
  error.code = code;
  error.statusCode = statusCode;
  error.details = details;
  error.timestamp = new Date();
  error.requestId = requestId || generateRequestId();
  return error;
}

/**
 * Generate request ID for tracking
 */
export function generateRequestId(): string {
  return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Logger
 */
export class Logger {
  private requestId: string;

  constructor(requestId?: string) {
    this.requestId = requestId || generateRequestId();
  }

  private formatLog(level: string, message: string, data?: any): string {
    const timestamp = new Date().toISOString();
    const logData = data ? ` ${JSON.stringify(data)}` : '';
    return `[${timestamp}] [${level}] [${this.requestId}] ${message}${logData}`;
  }

  info(message: string, data?: any): void {
    console.log(this.formatLog('INFO', message, data));
  }

  warn(message: string, data?: any): void {
    console.warn(this.formatLog('WARN', message, data));
  }

  error(message: string, error?: Error | any, data?: any): void {
    const errorData = {
      ...data,
      error: error?.message,
      stack: error?.stack,
    };
    console.error(this.formatLog('ERROR', message, errorData));
  }

  debug(message: string, data?: any): void {
    if (process.env.DEBUG === 'true') {
      console.debug(this.formatLog('DEBUG', message, data));
    }
  }
}

/**
 * Request logging middleware
 */
export function requestLoggingMiddleware(req: Request, res: Response, next: NextFunction) {
  const requestId = generateRequestId();
  const logger = new Logger(requestId);

  res.locals.requestId = requestId;
  res.locals.logger = logger;

  const startTime = Date.now();

  logger.info('Request received', {
    method: req.method,
    path: req.path,
    ip: req.ip,
    userAgent: req.headers['user-agent'],
  });

  const originalSend = res.send;
  res.send = function (data: any) {
    const duration = Date.now() - startTime;

    logger.info('Request completed', {
      statusCode: res.statusCode,
      duration: `${duration}ms`,
    });

    res.send = originalSend;
    return originalSend.call(this, data);
  };

  next();
}

/**
 * Error handling middleware
 */
export function errorHandlingMiddleware(err: any, req: Request, res: Response, next: NextFunction) {
  const requestId = res.locals.requestId || generateRequestId();
  const logger = new Logger(requestId);

  let appError: AppError;

  if (err instanceof TRPCError) {
    // Handle tRPC errors
    const statusCodeMap: Record<string, number> = {
      BAD_REQUEST: 400,
      UNAUTHORIZED: 401,
      FORBIDDEN: 403,
      NOT_FOUND: 404,
      CONFLICT: 409,
      INTERNAL_SERVER_ERROR: 500,
      SERVICE_UNAVAILABLE: 503,
    };

    appError = createAppError(
      ErrorCode.INTERNAL_ERROR,
      err.message,
      statusCodeMap[err.code] || 500,
      { trpcCode: err.code },
      requestId
    );
  } else if (err instanceof AppError) {
    appError = err;
    appError.requestId = requestId;
  } else if (err instanceof SyntaxError) {
    appError = createAppError(
      ErrorCode.VALIDATION_ERROR,
      'Invalid JSON in request body',
      400,
      undefined,
      requestId
    );
  } else if (err.code === 'ENOTFOUND') {
    appError = createAppError(
      ErrorCode.EXTERNAL_API_ERROR,
      'External service not available',
      503,
      { originalError: err.message },
      requestId
    );
  } else if (err.code === 'ETIMEDOUT') {
    appError = createAppError(
      ErrorCode.TIMEOUT,
      'Request timeout',
      504,
      undefined,
      requestId
    );
  } else {
    appError = createAppError(
      ErrorCode.INTERNAL_ERROR,
      err.message || 'Internal server error',
      500,
      undefined,
      requestId
    );
  }

  // Log error
  logger.error('Request error', err, {
    code: appError.code,
    statusCode: appError.statusCode,
    details: appError.details,
  });

  // Send response
  res.status(appError.statusCode).json({
    error: {
      code: appError.code,
      message: appError.message,
      requestId: appError.requestId,
      timestamp: appError.timestamp,
      details: appError.details,
    },
  });
}

/**
 * Async handler wrapper
 */
export function asyncHandler(fn: (req: Request, res: Response, next: NextFunction) => Promise<any>) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

/**
 * Validation error handler
 */
export function handleValidationError(errors: any[]): AppError {
  const details = errors.reduce(
    (acc, error) => {
      acc[error.path] = error.message;
      return acc;
    },
    {} as Record<string, string>
  );

  return createAppError(ErrorCode.VALIDATION_ERROR, 'Validation failed', 400, details);
}

/**
 * Database error handler
 */
export function handleDatabaseError(error: any): AppError {
  if (error.code === 'ER_DUP_ENTRY') {
    return createAppError(ErrorCode.CONFLICT, 'Duplicate entry', 409, { field: error.sqlMessage });
  }

  if (error.code === 'ER_NO_REFERENCED_ROW') {
    return createAppError(ErrorCode.NOT_FOUND, 'Referenced record not found', 404);
  }

  if (error.code === 'ER_ACCESS_DENIED_ERROR') {
    return createAppError(ErrorCode.UNAUTHORIZED, 'Database access denied', 401);
  }

  return createAppError(ErrorCode.DATABASE_ERROR, 'Database operation failed', 500, {
    code: error.code,
  });
}

/**
 * External API error handler
 */
export function handleExternalAPIError(error: any, service: string): AppError {
  if (error.response?.status === 401) {
    return createAppError(
      ErrorCode.UNAUTHORIZED,
      `${service} authentication failed`,
      401,
      { service }
    );
  }

  if (error.response?.status === 429) {
    return createAppError(
      ErrorCode.RATE_LIMIT,
      `${service} rate limit exceeded`,
      429,
      { service, retryAfter: error.response.headers['retry-after'] }
    );
  }

  if (error.response?.status >= 500) {
    return createAppError(
      ErrorCode.SERVICE_UNAVAILABLE,
      `${service} is temporarily unavailable`,
      503,
      { service }
    );
  }

  return createAppError(
    ErrorCode.EXTERNAL_API_ERROR,
    `${service} request failed`,
    500,
    { service, status: error.response?.status }
  );
}

/**
 * Circuit breaker for external services
 */
export class CircuitBreaker {
  private failureCount = 0;
  private lastFailureTime = 0;
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' = 'CLOSED';

  constructor(
    private failureThreshold = 5,
    private resetTimeout = 60000 // 1 minute
  ) {}

  async execute<T>(fn: () => Promise<T>): Promise<T> {
    if (this.state === 'OPEN') {
      if (Date.now() - this.lastFailureTime > this.resetTimeout) {
        this.state = 'HALF_OPEN';
      } else {
        throw new Error('Circuit breaker is OPEN');
      }
    }

    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess(): void {
    this.failureCount = 0;
    this.state = 'CLOSED';
  }

  private onFailure(): void {
    this.failureCount++;
    this.lastFailureTime = Date.now();

    if (this.failureCount >= this.failureThreshold) {
      this.state = 'OPEN';
    }
  }

  getState(): string {
    return this.state;
  }
}

/**
 * Retry logic
 */
export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries = 3,
  initialDelayMs = 1000,
  backoffMultiplier = 2
): Promise<T> {
  let lastError: Error | undefined;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;

      if (attempt < maxRetries - 1) {
        const delayMs = initialDelayMs * Math.pow(backoffMultiplier, attempt);
        await new Promise((resolve) => setTimeout(resolve, delayMs));
      }
    }
  }

  throw lastError || new Error('Max retries exceeded');
}

/**
 * Monitoring & Metrics
 */
export class Metrics {
  private metrics: Map<string, { count: number; totalTime: number }> = new Map();

  recordOperation(name: string, durationMs: number): void {
    const existing = this.metrics.get(name) || { count: 0, totalTime: 0 };
    existing.count++;
    existing.totalTime += durationMs;
    this.metrics.set(name, existing);
  }

  getMetrics(): Record<string, { count: number; avgTime: number }> {
    const result: Record<string, { count: number; avgTime: number }> = {};

    this.metrics.forEach((value, key) => {
      result[key] = {
        count: value.count,
        avgTime: value.totalTime / value.count,
      };
    });

    return result;
  }

  reset(): void {
    this.metrics.clear();
  }
}

export const metrics = new Metrics();
