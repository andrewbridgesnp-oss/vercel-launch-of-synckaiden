## Mandatory Disclaimers
- No legal advice
- No financial advice
- Educational + automation support only

## Compliance Rules
- No credit repair under Business
- No misleading funding claims
- Transparent risk disclosures
