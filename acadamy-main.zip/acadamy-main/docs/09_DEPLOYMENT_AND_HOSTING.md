## Environments
- Local
- Staging
- Production

## Hosting
- Self-host capable
- Env-variable driven
- No hardcoded credentials

## CI/CD
- GitHub Actions
- Tests before deploy
