
  # Agentic AI Business Swarm

  This is a code bundle for Agentic AI Business Swarm. The original project is available at https://www.figma.com/design/8bYRfTpEgVRvKl0edxA8ol/Agentic-AI-Business-Swarm.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  