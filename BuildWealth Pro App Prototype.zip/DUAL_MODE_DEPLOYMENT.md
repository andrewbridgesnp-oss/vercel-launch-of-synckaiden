# 🚀 Dual-Mode Deployment Guide

## BuildWealth Pro - White-Label & Multi-Tenant Modes

This app supports **TWO DEPLOYMENT MODES** to serve different business needs:

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Mode A: White-Label (K.C.'s Custom Version)](#mode-a-white-label)
3. [Mode B: Multi-Tenant (SaaS Version)](#mode-b-multi-tenant)
4. [Configuration](#configuration)
5. [Database Schema](#database-schema)
6. [Deployment Strategy](#deployment-strategy)
7. [Feature Comparison](#feature-comparison)

---

## Overview

### Mode A: White-Label
- **Purpose**: Custom version for K.C. (original client)
- **Branding**: Cox & Co. Professional Services LLC branding locked in
- **Users**: Single user (K.C.) or their team
- **Domain**: Separate domain (e.g., `buildwealth.coxandco.com`)

### Mode B: Multi-Tenant SaaS
- **Purpose**: Sell to broader market
- **Branding**: Each user uploads their own logo and colors
- **Users**: Multiple independent businesses
- **Domain**: Main marketing domain (e.g., `buildwealthpro.com`)

---

## Mode A: White-Label

### 🎯 Configuration

Edit `/src/config/app-mode.ts`:

```typescript
export const APP_MODE: AppMode = 'WHITE_LABEL';
export const WHITE_LABEL_CLIENT_EMAIL = 'kc@coxandcoprofessional.com';
```

### ✨ Features

**LOCKED BRANDING:**
- Cox & Co. logo appears throughout app
- Navy blue/silver/gold color scheme enforced
- Company name: "Cox & Co. Professional Services LLC"
- Cannot be changed by user

**AVAILABLE:**
- ✅ Business profile customization (address, phone, etc.)
- ✅ Custom goals and tasks
- ✅ All credit repair features
- ✅ Grant search
- ✅ Vehicle finder (Trail Boss focus)
- ✅ Time tracking/mileage/receipts

**NOT AVAILABLE:**
- ❌ Logo upload
- ❌ Color customization
- ❌ Branding settings page

### 🌐 Deployment

**Domain:**
```
buildwealth.coxandco.com
```

**Environment Variables (.env):**
```bash
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_APP_MODE=WHITE_LABEL
VITE_WHITE_LABEL_EMAIL=kc@coxandcoprofessional.com
```

**Database Setup:**
1. Use same Supabase project or separate one
2. Run `/supabase/schema.sql`
3. Create user for K.C. with email: `kc@coxandcoprofessional.com`
4. Automatically gets Cox & Co. branding

### 💰 Pricing

**Custom Pricing for K.C.:**
- One-time setup fee: $X,XXX
- Monthly hosting/support: $XXX/month
- Includes all features (Premium tier equivalent)
- No per-user limits

---

## Mode B: Multi-Tenant

### 🎯 Configuration

Edit `/src/config/app-mode.ts`:

```typescript
export const APP_MODE: AppMode = 'MULTI_TENANT';
```

### ✨ Features

**FULL CUSTOMIZATION:**
- Users upload their own logo
- Users choose their own colors
- Users set their business name
- Custom goal titles

**SUBSCRIPTION TIERS:**

| Feature | Basic (Free) | Pro ($9.99/mo) | Premium ($19.99/mo) |
|---------|--------------|----------------|---------------------|
| Logo Upload | ❌ | ✅ | ✅ |
| Color Customization | ❌ | ✅ | ✅ |
| Custom Goals | ❌ | ✅ | ✅ |
| Max Tasks/Day | 5 | 20 | Unlimited |
| Business Profile | ✅ | ✅ | ✅ |
| Credit Repair | ✅ | ✅ | ✅ |
| Grant Search | ✅ | ✅ | ✅ |
| Vehicle Finder | ❌ | ✅ | ✅ |
| Time Tracking | ❌ | ✅ | ✅ |
| Mileage/Receipts | ❌ | ✅ | ✅ |
| Priority Support | ❌ | ❌ | ✅ |

### 🌐 Deployment

**Domain:**
```
buildwealthpro.com
app.buildwealthpro.com
```

**Environment Variables (.env):**
```bash
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_APP_MODE=MULTI_TENANT
VITE_STRIPE_PUBLIC_KEY=pk_live_xxxxx
```

**Database Setup:**
1. Use separate Supabase project for multi-tenant
2. Run `/supabase/schema.sql`
3. Enable Email auth
4. Set up Stripe for subscriptions

### 💰 Pricing Strategy

**Freemium Model:**
- **Basic**: Free forever (limited features)
- **Pro**: $9.99/month (full customization)
- **Premium**: $19.99/month (unlimited + priority support)

**Annual Discounts:**
- Pro Annual: $99/year (save $20)
- Premium Annual: $199/year (save $40)

---

## Configuration

### App Mode Settings

File: `/src/config/app-mode.ts`

```typescript
// DEPLOYMENT MODE
export const APP_MODE: AppMode = 'MULTI_TENANT'; // or 'WHITE_LABEL'

// WHITE-LABEL CLIENT (only for Mode A)
export const WHITE_LABEL_CLIENT_EMAIL = 'kc@coxandcoprofessional.com';

// FEATURE FLAGS (automatically set based on mode)
export const FEATURE_FLAGS = {
  allowLogoUpload: isMultiTenantMode(),
  allowColorCustomization: isMultiTenantMode(),
  allowGoalCustomization: true,
  showBrandingSettings: isMultiTenantMode(),
  showBusinessProfile: true,
  showCoxAndCoLogo: isWhiteLabelMode(),
  enableAssistantMode: true,
};
```

### Helper Functions

```typescript
// Check current mode
isWhiteLabelMode() // returns true if WHITE_LABEL
isMultiTenantMode() // returns true if MULTI_TENANT

// Check user branding
shouldUseWhiteLabelBranding(userEmail) // returns true for K.C. in white-label mode

// Get default branding
getDefaultBranding(userEmail) // returns Cox & Co. or generic branding

// Check tier permissions
tierAllowsFeature(tier, feature) // check if user's subscription allows feature
```

---

## Database Schema

### Profiles Table

```sql
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    full_name TEXT,
    business_name TEXT,
    phone TEXT,
    subscription_tier TEXT DEFAULT 'basic', -- basic, pro, premium
    stripe_customer_id TEXT,
    
    -- MULTI-TENANT BRANDING FIELDS
    logo_url TEXT, -- Supabase storage URL
    primary_color TEXT DEFAULT '#1e3a8a',
    secondary_color TEXT DEFAULT '#c0c0c0',
    accent_color TEXT DEFAULT '#ffd700',
    business_industry TEXT,
    business_structure TEXT, -- llc, corporation, etc.
    business_founded_year INTEGER,
    business_state TEXT,
    business_ein TEXT,
    
    -- CUSTOMIZATION
    custom_goal_title TEXT DEFAULT 'Build Wealth in 120 Days',
    plan_start_date DATE,
    enable_assistant_mode BOOLEAN DEFAULT true,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### Storage Buckets

**Logos Bucket:**
- Public read access (logos visible to all)
- Users can only upload/edit their own
- Auto-optimized for performance

**Receipts Bucket:**
- Private (users only see their own)
- Encrypted at rest

---

## Deployment Strategy

### Option 1: Separate Deployments (Recommended)

**White-Label Version:**
- Deploy to: `buildwealth.coxandco.com`
- Git branch: `white-label-kc`
- Supabase project: `buildwealth-kc`
- Environment: Production (White-Label)

**Multi-Tenant Version:**
- Deploy to: `buildwealthpro.com`
- Git branch: `main`
- Supabase project: `buildwealth-saas`
- Environment: Production (SaaS)

### Option 2: Single Deployment with Runtime Config

**Single Codebase:**
- Deploy to both domains from same repo
- Use environment variables to control mode
- More complex but easier maintenance

---

## Feature Comparison

| Feature | White-Label (K.C.) | Multi-Tenant (SaaS) |
|---------|-------------------|---------------------|
| **Branding** |
| Custom Logo | ❌ (Cox & Co. locked) | ✅ (User uploads) |
| Custom Colors | ❌ (Navy/Silver/Gold) | ✅ (Full palette) |
| Business Name | ✅ (Editable) | ✅ (Editable) |
| **Core Features** |
| 120-Day Plan | ✅ | ✅ |
| Credit Repair | ✅ | ✅ |
| Grant Search | ✅ | ✅ |
| Loan Applications | ✅ | ✅ |
| **Business Tools** |
| Time Tracking | ✅ | ✅ (Pro+) |
| Mileage Tracking | ✅ | ✅ (Pro+) |
| Receipt Scanning | ✅ | ✅ (Pro+) |
| Vehicle Finder | ✅ (Trail Boss) | ✅ (Pro+) |
| **Gamification** |
| Points/Badges | ✅ | ✅ |
| Streaks | ✅ | ✅ |
| Leaderboard | ✅ | ✅ |
| **Subscription** |
| Tier | All Features | 3 Tiers |
| Price | Custom | $0-$19.99/mo |

---

## Implementation Checklist

### For White-Label Mode:

- [ ] Set `APP_MODE = 'WHITE_LABEL'` in `/src/config/app-mode.ts`
- [ ] Set K.C.'s email in `WHITE_LABEL_CLIENT_EMAIL`
- [ ] Deploy to `buildwealth.coxandco.com`
- [ ] Create Supabase project for white-label
- [ ] Run database schema
- [ ] Create K.C.'s user account
- [ ] Hide branding settings from UI
- [ ] Test: Verify Cox & Co. logo appears everywhere
- [ ] Test: Verify colors are navy/silver/gold
- [ ] Test: Verify user cannot change branding

### For Multi-Tenant Mode:

- [ ] Set `APP_MODE = 'MULTI_TENANT'` in `/src/config/app-mode.ts`
- [ ] Deploy to `buildwealthpro.com`
- [ ] Create Supabase project for SaaS
- [ ] Run database schema
- [ ] Set up Stripe integration
- [ ] Create subscription plans (Basic/Pro/Premium)
- [ ] Test logo upload functionality
- [ ] Test color customization
- [ ] Test subscription tier limits
- [ ] Test: Basic users cannot upload logos
- [ ] Test: Pro users can upload logos
- [ ] Set up email confirmation
- [ ] Create landing/marketing pages

---

## File Structure

```
src/
├── config/
│   └── app-mode.ts          # MODE CONFIGURATION HERE
├── app/
│   └── components/
│       ├── branding-screen.tsx         # K.C.'s branding kit (white-label)
│       └── custom-branding-screen.tsx  # User customization (multi-tenant)
└── ...

supabase/
└── schema.sql               # Includes multi-tenant fields

/DUAL_MODE_DEPLOYMENT.md     # This guide
/DO_THIS_NOW.md              # Backend setup
```

---

## Environment Variables

### White-Label (.env):
```bash
VITE_SUPABASE_URL=https://kc-project.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbG...
VITE_APP_MODE=WHITE_LABEL
VITE_WHITE_LABEL_EMAIL=kc@coxandcoprofessional.com
```

### Multi-Tenant (.env):
```bash
VITE_SUPABASE_URL=https://saas-project.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbG...
VITE_APP_MODE=MULTI_TENANT
VITE_STRIPE_PUBLIC_KEY=pk_live_xxxxx
```

---

## Next Steps

### For K.C. (White-Label):
1. Complete backend setup using `/DO_THIS_NOW.md`
2. Set `APP_MODE = 'WHITE_LABEL'`
3. Deploy to custom domain
4. Create K.C.'s account
5. Train K.C. on features

### For SaaS Launch:
1. Set `APP_MODE = 'MULTI_TENANT'`
2. Integrate Stripe subscriptions
3. Build landing page
4. Set up email marketing
5. Launch marketing campaign
6. Onboard first users

---

## Support

**White-Label Support (K.C.):**
- Dedicated support email
- Custom onboarding
- Regular check-ins
- Priority bug fixes

**Multi-Tenant Support (SaaS):**
- In-app help center
- Email support (Basic tier)
- Priority email (Pro tier)
- Phone + dedicated manager (Premium tier)

---

## Maintenance

### Shared Codebase Benefits:
✅ Fix bugs once, deploy to both
✅ New features benefit both versions
✅ Single development team

### Separate Deployment Benefits:
✅ Independent scaling
✅ K.C. gets stable version
✅ SaaS can experiment with new features
✅ Different update schedules

---

## Questions?

**Technical Questions:**
- Check `/BACKEND_SETUP_GUIDE.md`
- Check `/INTEGRATION_CHECKLIST.md`
- Review `/SUPABASE_BACKEND_README.md`

**Business Questions:**
- Pricing strategy
- Marketing approach
- Customer acquisition

**Deployment Questions:**
- Hosting provider selection
- Domain setup
- SSL certificates
- CI/CD pipeline

---

## 🎉 You're Ready!

You now have:
- ✅ Database schema supporting both modes
- ✅ Configuration system to switch modes
- ✅ White-label branding for K.C.
- ✅ Multi-tenant customization for SaaS
- ✅ Subscription tier system
- ✅ Complete deployment guide

**Deploy K.C.'s version first to validate the product, then launch the SaaS version to scale!** 🚀
