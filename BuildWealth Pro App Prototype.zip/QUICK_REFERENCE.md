# ⚡ BuildWealth Pro - Quick Reference Card

**Save this for quick lookups while building!**

---

## 🚨 WHAT TO DO RIGHT NOW

**👉 Open `/DO_THIS_NOW.md` → Complete 6 steps (7 minutes) → Backend ready!**

---

## 📁 Key Files Cheat Sheet

| Need to... | Open this file |
|------------|----------------|
| **Set up backend** | `/DO_THIS_NOW.md` |
| **See what you have** | `/WHAT_YOU_HAVE.md` |
| **Track integration progress** | `/INTEGRATION_CHECKLIST.md` |
| **Look up API examples** | `/SUPABASE_BACKEND_README.md` |
| **Understand architecture** | `/BACKEND_STRUCTURE.md` |
| **Check compliance** | `/COMPLIANCE_FRAMEWORK.md` |

---

## 🗄️ Database Tables

| Table | Purpose |
|-------|---------|
| `profiles` | User profiles + subscription tier |
| `daily_tasks` | 120-day plan tasks |
| `user_progress` | Points, levels, streaks, badges |
| `credit_accounts` | Credit tracking |
| `grant_applications` | Grant tracking |
| `time_entries` | Time clock |
| `mileage_entries` | Mileage tracking |
| `receipts` | Receipt management |

---

## 🛠️ Service Imports

```typescript
// Authentication
import { useAuthContext } from './contexts/AuthContext';
const { user, signIn, signUp, signOut } = useAuthContext();

// User Profile
import { profileService } from './services/profileService';
await profileService.getProfile(userId);
await profileService.updateProfile(userId, { subscription_tier: 'premium' });

// Tasks (120-Day Plan)
import { tasksService } from './services/tasksService';
await tasksService.getTasksByDay(userId, 1);
await tasksService.toggleTaskCompletion(taskId, true);

// Gamification
import { progressService } from './services/progressService';
await progressService.addPoints(userId, 25);
await progressService.updateStreak(userId);
await progressService.awardBadge(userId, badge);

// Credit Tracking
import { creditService } from './services/creditService';
await creditService.getCreditAccounts(userId);
await creditService.getCreditUtilization(userId);

// Grants
import { grantsService } from './services/grantsService';
await grantsService.getGrantApplications(userId);
await grantsService.getUpcomingDeadlines(userId);

// Business Operations
import { businessService } from './services/businessService';
await businessService.clockIn(userId, employeeName);
await businessService.clockOut(entryId);
await businessService.createMileageEntry({...});
await businessService.createReceipt({...});
```

---

## 🔐 Authentication Examples

```typescript
// Sign Up
const { user } = await signUp(
  'email@example.com',
  'password123',
  'John Doe',
  'Doe Construction LLC'
);

// Initialize new user
import { initializeUserData } from './utils/initializeUserData';
await initializeUserData(user.id, {
  fullName: 'John Doe',
  businessName: 'Doe Construction LLC',
});

// Sign In
const { user } = await signIn('email@example.com', 'password123');

// Check if logged in
const { isAuthenticated, user } = useAuthContext();
if (!isAuthenticated) {
  navigate('/login');
}

// Sign Out
await signOut();
```

---

## 📊 Common Queries

```typescript
// Get today's tasks
const tasks = await tasksService.getTasksByDay(userId, currentDay);

// Get user's progress
const progress = await progressService.getOrCreateProgress(userId);

// Calculate level from points
const level = progressService.calculateLevel(totalPoints);

// Get credit utilization
const utilization = await creditService.getCreditUtilization(userId);

// Get upcoming grant deadlines (next 30 days)
const deadlines = await grantsService.getUpcomingDeadlines(userId);

// Get this month's expenses
const startDate = '2026-01-01';
const endDate = '2026-01-31';
const total = await businessService.getTotalExpenses(userId, startDate, endDate);

// Get total mileage for year
const yearStart = '2026-01-01';
const yearEnd = '2026-12-31';
const miles = await businessService.getTotalMileage(userId, yearStart, yearEnd);
```

---

## 🎮 Gamification Formulas

```typescript
// Level calculation
const level = Math.floor(Math.sqrt(points / 100)) + 1;

// Points needed for next level
const nextLevel = currentLevel + 1;
const pointsNeeded = (nextLevel * nextLevel) * 100;

// Progress to next level (0-100%)
const currentLevelPoints = ((currentLevel - 1) ** 2) * 100;
const nextLevelPoints = (currentLevel ** 2) * 100;
const progressPercent = ((points - currentLevelPoints) / (nextLevelPoints - currentLevelPoints)) * 100;

// Tax deduction from mileage
const deduction = totalMiles * 0.67; // IRS standard rate
```

---

## 🔒 Security Checklist

```typescript
// ✅ ALWAYS check if user is authenticated
const { isAuthenticated, user } = useAuthContext();
if (!isAuthenticated) return;

// ✅ ALWAYS use user.id for queries
const data = await service.getData(user.id); // ✅ Correct
const data = await service.getData(someOtherId); // ❌ Wrong

// ✅ ALWAYS wrap in try/catch
try {
  await service.doSomething();
} catch (error) {
  console.error('Error:', error);
  toast.error('Something went wrong');
}

// ✅ NEVER expose sensitive data
const profile = {
  name: user.name, // ✅ OK
  email: user.email, // ✅ OK
  ssn: 'XXX-XX-XXXX', // ❌ NEVER store this
};
```

---

## 🚀 Common Tasks

### Create a New Task
```typescript
await tasksService.createTask({
  user_id: userId,
  day_number: 5,
  title: 'Apply for Grant',
  description: 'Submit MBDA grant application',
  category: 'grants',
  assignee: 'assistant',
  points: 50,
});
```

### Award Points & Badge
```typescript
// Award points
await progressService.addPoints(userId, 25);

// Update streak
await progressService.updateStreak(userId);

// Award badge
await progressService.awardBadge(userId, {
  id: 'first_week',
  name: 'Week Warrior',
  description: 'Completed first 7 days',
});
```

### Track Credit Account
```typescript
await creditService.createCreditAccount({
  user_id: userId,
  account_name: 'Chase Freedom',
  account_type: 'credit_card',
  credit_limit: 5000,
  current_balance: 1200,
  payment_due_date: '2026-02-01',
  status: 'active',
});
```

### Log Business Expense
```typescript
// Upload receipt photo first
const photoUrl = await businessService.uploadReceiptPhoto(userId, fileObject);

// Create receipt
await businessService.createReceipt({
  user_id: userId,
  date: '2026-01-11',
  merchant: 'Home Depot',
  amount: 425.50,
  category: 'Materials',
  photo_url: photoUrl,
});
```

---

## 💎 Subscription Tiers

| Feature | Basic | Pro | Premium |
|---------|-------|-----|---------|
| **Price** | Free | $9.99/mo | $19.99/mo |
| **Tasks/day** | 10 | Unlimited | Unlimited |
| **Receipt Photos** | ❌ | ✅ | ✅ |
| **Business Tracking** | ❌ | ✅ | ✅ |
| **Advanced Reports** | ❌ | ✅ | ✅ |
| **Export to Accounting** | ❌ | ❌ | ✅ |
| **Support** | Email | Priority | Phone + Email |

```typescript
// Check user's tier
const profile = await profileService.getProfile(userId);
if (profile.subscription_tier === 'basic') {
  // Show upgrade prompt
}

// Update tier
await profileService.updateProfile(userId, {
  subscription_tier: 'premium',
});
```

---

## 🎨 Color Scheme (Cox & Co.)

```css
/* Navy Blue */
--primary: #1e3a8a;
--primary-dark: #1e40af;

/* Silver */
--silver: #c0c0c0;
--silver-light: #d4d4d4;

/* Gold */
--gold: #fbbf24;
--gold-dark: #f59e0b;

/* Accent Red (UI) */
--accent-red: #dc2626;

/* Accent Black (UI) */
--accent-black: #1f2937;
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| "Supabase credentials not found" | Check `.env` file, restart dev server |
| "Table does not exist" | Run `/supabase/schema.sql` in Supabase SQL Editor |
| "Permission denied" | Check RLS policies, ensure `auth.uid() = user_id` |
| "Cannot read property of undefined" | Check if user is authenticated first |
| "Email already registered" | Use different email or delete user in Supabase Dashboard |

---

## 📞 Quick Links

| Resource | URL |
|----------|-----|
| **Supabase Dashboard** | https://supabase.com/dashboard |
| **Supabase Docs** | https://supabase.com/docs |
| **React Docs** | https://react.dev |
| **Tailwind Docs** | https://tailwindcss.com |
| **TypeScript Handbook** | https://typescriptlang.org/docs/handbook/ |

---

## 💡 Pro Tips

1. **Use TypeScript types** - They're already defined in `/src/lib/database.types.ts`
2. **Check auth first** - Always verify `isAuthenticated` before calling services
3. **Handle errors** - Wrap service calls in try/catch blocks
4. **Test RLS** - Create two users and verify they can't see each other's data
5. **Initialize users** - Call `initializeUserData()` after signup
6. **Use services** - Don't query Supabase directly from components
7. **Check the docs** - `/SUPABASE_BACKEND_README.md` has examples for everything

---

## 🎯 Integration Phases

| Phase | Focus | Tasks |
|-------|-------|-------|
| **1. Setup** | Backend configuration | 6 tasks |
| **2. Auth** | Login/signup | 13 tasks |
| **3. Profile** | User data | 8 tasks |
| **4. Tasks** | 120-day plan | 16 tasks |
| **5. Gamification** | Points/badges | 15 tasks |
| **6. Credit** | Credit tracking | 13 tasks |
| **7. Grants** | Grant tracking | 13 tasks |
| **8-10. Business** | Time/Mileage/Receipts | 45 tasks |
| **11. Dashboard** | Analytics | 12 tasks |
| **12. Subscriptions** | Tiers | 19 tasks |
| **13-16. Polish** | Testing/Production | 58 tasks |

**Total: 184 tasks** → See `/INTEGRATION_CHECKLIST.md`

---

## ⚡ Environment Variables

```bash
# Required in .env file
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## 🚀 Commands

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## 📊 Progress Tracking

```
Setup:           ☐☐☐☐☐☐ (0/6)
Authentication:  ☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/13)
Integration:     ☐☐☐☐☐☐☐☐☐☐... (0/165)
Total:           0/184 (0%)
```

Track your progress in `/INTEGRATION_CHECKLIST.md`

---

**📌 Keep this file open while building - it's your quick lookup guide!**
