/**
 * APP MODE CONFIGURATION
 * 
 * This file controls whether the app runs in:
 * - WHITE_LABEL mode: Custom branding for a specific client (K.C. - Cox & Co.)
 * - MULTI_TENANT mode: SaaS version where each user customizes their own branding
 * 
 * ⚠️ DEPLOYMENT INSTRUCTIONS:
 * 
 * For K.C.'s White-Label Version:
 *   - Set APP_MODE = 'WHITE_LABEL'
 *   - Set WHITE_LABEL_CLIENT_EMAIL = 'kc@example.com' (K.C.'s email)
 *   - Deploy to separate domain (e.g., buildwealth.coxandco.com)
 * 
 * For SaaS Multi-Tenant Version:
 *   - Set APP_MODE = 'MULTI_TENANT'
 *   - Deploy to main domain (e.g., buildwealthpro.com)
 */

// ============================================================================
// MODE CONFIGURATION - CHANGE THIS FOR EACH DEPLOYMENT
// ============================================================================

export type AppMode = 'WHITE_LABEL' | 'MULTI_TENANT';

/**
 * Current app mode
 * 
 * WHITE_LABEL: Cox & Co. branding locked for K.C.
 * MULTI_TENANT: Each user has full customization
 */
export const APP_MODE: AppMode = 'MULTI_TENANT'; // Change to 'WHITE_LABEL' for K.C.

/**
 * White-label client email (only used in WHITE_LABEL mode)
 * This email gets Cox & Co. branding automatically applied
 */
export const WHITE_LABEL_CLIENT_EMAIL = 'kc@coxandcoprofessional.com';

// ============================================================================
// DEFAULT BRANDING (Cox & Co. for white-label mode)
// ============================================================================

export const COX_AND_CO_BRANDING = {
  appName: "Kaiden's BuildWealth Pro",
  businessName: "Cox & Co. Professional Services LLC",
  ownerName: "Kaiden C. (K.C.)",
  tagline: "Building Wealth, Building Legacy",
  logoUrl: "/logo.png", // Cox & Co. logo
  primaryColor: "#1e3a8a", // Navy blue
  secondaryColor: "#c0c0c0", // Silver
  accentColor: "#ffd700", // Gold
  customGoalTitle: "Build Wealth in 120 Days",
};

// ============================================================================
// DEFAULT BRANDING (Generic for multi-tenant mode)
// ============================================================================

export const DEFAULT_BRANDING = {
  appName: "BuildWealth Pro",
  businessName: "BuildWealth Pro",
  ownerName: null,
  tagline: "Your Path to Financial Freedom",
  logoUrl: null, // No logo by default
  primaryColor: "#1e3a8a", // Navy blue
  secondaryColor: "#c0c0c0", // Silver
  accentColor: "#ffd700", // Gold
  customGoalTitle: "Build Wealth in 120 Days",
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Check if app is in white-label mode
 */
export function isWhiteLabelMode(): boolean {
  return APP_MODE === 'WHITE_LABEL';
}

/**
 * Check if app is in multi-tenant mode
 */
export function isMultiTenantMode(): boolean {
  return APP_MODE === 'MULTI_TENANT';
}

/**
 * Check if user should get white-label branding
 */
export function shouldUseWhiteLabelBranding(userEmail: string | null): boolean {
  if (!isWhiteLabelMode()) return false;
  return userEmail === WHITE_LABEL_CLIENT_EMAIL;
}

/**
 * Get default branding based on mode and user
 */
export function getDefaultBranding(userEmail: string | null) {
  if (isWhiteLabelMode() && shouldUseWhiteLabelBranding(userEmail)) {
    return COX_AND_CO_BRANDING;
  }
  return DEFAULT_BRANDING;
}

// ============================================================================
// FEATURE FLAGS (Different features for different modes)
// ============================================================================

export const FEATURE_FLAGS = {
  // Allow users to upload custom logos
  allowLogoUpload: isMultiTenantMode(),
  
  // Allow users to customize colors
  allowColorCustomization: isMultiTenantMode(),
  
  // Allow users to edit their 120-day plan
  allowGoalCustomization: true, // Both modes allow this
  
  // Show branding settings in settings menu
  showBrandingSettings: isMultiTenantMode(),
  
  // Show business profile customization
  showBusinessProfile: true, // Both modes allow this
  
  // Show Cox & Co. logo in app header
  showCoxAndCoLogo: isWhiteLabelMode(),
  
  // Enable assistant mode toggle
  enableAssistantMode: true, // Both modes have this
};

// ============================================================================
// UI CUSTOMIZATION LIMITS (For multi-tenant mode)
// ============================================================================

export const CUSTOMIZATION_LIMITS = {
  // Maximum logo file size (5MB)
  maxLogoSizeMB: 5,
  
  // Allowed logo file types
  allowedLogoTypes: ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml'],
  
  // Logo dimensions
  minLogoWidth: 100,
  maxLogoWidth: 2000,
  minLogoHeight: 100,
  maxLogoHeight: 2000,
};

// ============================================================================
// SUBSCRIPTION TIER LIMITS
// ============================================================================

export const TIER_FEATURES = {
  basic: {
    allowLogoUpload: false,
    allowColorCustomization: false,
    allowGoalCustomization: false,
    maxTasksPerDay: 5,
  },
  pro: {
    allowLogoUpload: true,
    allowColorCustomization: true,
    allowGoalCustomization: true,
    maxTasksPerDay: 20,
  },
  premium: {
    allowLogoUpload: true,
    allowColorCustomization: true,
    allowGoalCustomization: true,
    maxTasksPerDay: 999, // Unlimited
  },
};

/**
 * Check if user's subscription tier allows a feature
 */
export function tierAllowsFeature(
  tier: 'basic' | 'pro' | 'premium',
  feature: keyof typeof TIER_FEATURES.basic
): boolean {
  return TIER_FEATURES[tier][feature];
}