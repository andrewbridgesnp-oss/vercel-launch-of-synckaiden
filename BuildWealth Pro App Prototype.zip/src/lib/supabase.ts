/**
 * Supabase Client Configuration
 * GLBA/FCRA/CROA Compliant - Secure connection with encryption
 */

import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

// Environment variables - These will be provided by the user
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('⚠️ Supabase credentials not found. Please add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your .env file');
}

/**
 * Supabase client with TypeScript types
 * - Uses Row Level Security (RLS) for data protection
 * - All data encrypted in transit (TLS 1.3)
 * - Compliant with GLBA, FCRA, CROA requirements
 */
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    storage: window.localStorage, // Secure session storage
  },
  db: {
    schema: 'public',
  },
  global: {
    headers: {
      'X-Client-Info': 'buildwealth-pro',
    },
  },
});

/**
 * Helper to check if Supabase is configured
 */
export const isSupabaseConfigured = () => {
  return Boolean(supabaseUrl && supabaseAnonKey);
};

/**
 * Helper to get current user session
 */
export const getCurrentSession = async () => {
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error) throw error;
  return session;
};

/**
 * Helper to get current user
 */
export const getCurrentUser = async () => {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) throw error;
  return user;
};
