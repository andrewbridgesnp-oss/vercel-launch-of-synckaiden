/**
 * Supabase Database TypeScript Definitions
 * Auto-generated types for type-safe database operations
 */

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      // User Profiles (Extended user data beyond auth)
      profiles: {
        Row: {
          id: string
          user_id: string
          full_name: string | null
          business_name: string | null
          phone: string | null
          subscription_tier: 'basic' | 'pro' | 'premium'
          stripe_customer_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          full_name?: string | null
          business_name?: string | null
          phone?: string | null
          subscription_tier?: 'basic' | 'pro' | 'premium'
          stripe_customer_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          full_name?: string | null
          business_name?: string | null
          phone?: string | null
          subscription_tier?: 'basic' | 'pro' | 'premium'
          stripe_customer_id?: string | null
          created_at?: string
          updated_at?: string
        }
      }

      // 120-Day Plan Tasks
      daily_tasks: {
        Row: {
          id: string
          user_id: string
          day_number: number
          title: string
          description: string
          category: 'credit' | 'grants' | 'loans' | 'business' | 'personal'
          assignee: 'owner' | 'assistant' | 'both'
          completed: boolean
          points: number
          completed_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          day_number: number
          title: string
          description: string
          category: 'credit' | 'grants' | 'loans' | 'business' | 'personal'
          assignee: 'owner' | 'assistant' | 'both'
          completed?: boolean
          points?: number
          completed_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          day_number?: number
          title?: string
          description?: string
          category?: 'credit' | 'grants' | 'loans' | 'business' | 'personal'
          assignee?: 'owner' | 'assistant' | 'both'
          completed?: boolean
          points?: number
          completed_at?: string | null
          created_at?: string
          updated_at?: string
        }
      }

      // Gamification Progress
      user_progress: {
        Row: {
          id: string
          user_id: string
          total_points: number
          current_level: number
          current_streak: number
          longest_streak: number
          badges_earned: Json
          last_activity_date: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          total_points?: number
          current_level?: number
          current_streak?: number
          longest_streak?: number
          badges_earned?: Json
          last_activity_date?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          total_points?: number
          current_level?: number
          current_streak?: number
          longest_streak?: number
          badges_earned?: Json
          last_activity_date?: string | null
          created_at?: string
          updated_at?: string
        }
      }

      // Credit Tracking (Encrypted PII - FCRA Compliant)
      credit_accounts: {
        Row: {
          id: string
          user_id: string
          account_name: string
          account_type: 'credit_card' | 'loan' | 'mortgage' | 'auto' | 'other'
          credit_limit: number | null
          current_balance: number | null
          payment_due_date: string | null
          status: 'active' | 'closed' | 'disputed'
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          account_name: string
          account_type: 'credit_card' | 'loan' | 'mortgage' | 'auto' | 'other'
          credit_limit?: number | null
          current_balance?: number | null
          payment_due_date?: string | null
          status?: 'active' | 'closed' | 'disputed'
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          account_name?: string
          account_type?: 'credit_card' | 'loan' | 'mortgage' | 'auto' | 'other'
          credit_limit?: number | null
          current_balance?: number | null
          payment_due_date?: string | null
          status?: 'active' | 'closed' | 'disputed'
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }

      // Grant Applications Tracking
      grant_applications: {
        Row: {
          id: string
          user_id: string
          grant_name: string
          grant_amount: number | null
          deadline: string | null
          status: 'researching' | 'applying' | 'submitted' | 'approved' | 'denied'
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          grant_name: string
          grant_amount?: number | null
          deadline?: string | null
          status?: 'researching' | 'applying' | 'submitted' | 'approved' | 'denied'
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          grant_name?: string
          grant_amount?: number | null
          deadline?: string | null
          status?: 'researching' | 'applying' | 'submitted' | 'approved' | 'denied'
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }

      // Business Operations - Time Tracking
      time_entries: {
        Row: {
          id: string
          user_id: string
          employee_name: string
          clock_in: string
          clock_out: string | null
          hours_worked: number | null
          project: string | null
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          employee_name: string
          clock_in: string
          clock_out?: string | null
          hours_worked?: number | null
          project?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          employee_name?: string
          clock_in?: string
          clock_out?: string | null
          hours_worked?: number | null
          project?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }

      // Business Operations - Mileage Tracking
      mileage_entries: {
        Row: {
          id: string
          user_id: string
          date: string
          starting_location: string
          ending_location: string
          miles: number
          purpose: string
          vehicle: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          date: string
          starting_location: string
          ending_location: string
          miles: number
          purpose: string
          vehicle?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          date?: string
          starting_location?: string
          ending_location?: string
          miles?: number
          purpose?: string
          vehicle?: string | null
          created_at?: string
          updated_at?: string
        }
      }

      // Business Operations - Receipt Tracking
      receipts: {
        Row: {
          id: string
          user_id: string
          date: string
          merchant: string
          amount: number
          category: string
          payment_method: string | null
          photo_url: string | null
          notes: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          date: string
          merchant: string
          amount: number
          category: string
          payment_method?: string | null
          photo_url?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          date?: string
          merchant?: string
          amount?: number
          category?: string
          payment_method?: string | null
          photo_url?: string | null
          notes?: string | null
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      subscription_tier: 'basic' | 'pro' | 'premium'
      task_category: 'credit' | 'grants' | 'loans' | 'business' | 'personal'
      task_assignee: 'owner' | 'assistant' | 'both'
    }
  }
}
