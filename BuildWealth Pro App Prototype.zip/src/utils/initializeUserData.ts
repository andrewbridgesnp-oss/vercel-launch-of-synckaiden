/**
 * User Data Initialization Utility
 * Sets up initial data for new users
 */

import { profileService } from '../services/profileService';
import { progressService } from '../services/progressService';
import { tasksService } from '../services/tasksService';

/**
 * Initialize new user with default data
 * Call this after user signs up or first login
 */
export async function initializeUserData(userId: string, userData?: {
  fullName?: string;
  businessName?: string;
  phone?: string;
}) {
  try {
    // 1. Create or get profile
    const profile = await profileService.getOrCreateProfile(userId, {
      full_name: userData?.fullName,
      business_name: userData?.businessName,
      phone: userData?.phone,
    });

    // 2. Initialize gamification progress
    const progress = await progressService.getOrCreateProgress(userId);

    // 3. Create initial 120-day plan tasks (sample)
    const existingTasks = await tasksService.getTasks(userId);
    
    if (existingTasks.length === 0) {
      // Create first week of sample tasks
      const initialTasks = [
        // Day 1 - Owner Tasks
        {
          user_id: userId,
          day_number: 1,
          title: 'Review Credit Reports',
          description: 'Pull reports from all 3 bureaus (Equifax, Experian, TransUnion)',
          category: 'credit' as const,
          assignee: 'owner' as const,
          points: 25,
        },
        {
          user_id: userId,
          day_number: 1,
          title: 'Document Business Structure',
          description: 'Gather LLC formation documents and EIN paperwork',
          category: 'business' as const,
          assignee: 'owner' as const,
          points: 15,
        },
        // Day 1 - Assistant Tasks
        {
          user_id: userId,
          day_number: 1,
          title: 'Research Minority-Owned Business Grants',
          description: 'Create list of available grants from MBDA, SBA, and local organizations',
          category: 'grants' as const,
          assignee: 'assistant' as const,
          points: 20,
        },
        // Day 2 - Owner Tasks
        {
          user_id: userId,
          day_number: 2,
          title: 'Identify Credit Report Errors',
          description: 'Review credit reports and highlight any inaccuracies or disputes',
          category: 'credit' as const,
          assignee: 'owner' as const,
          points: 20,
        },
        {
          user_id: userId,
          day_number: 2,
          title: 'Open Business Bank Account',
          description: 'Research and open dedicated business checking account',
          category: 'business' as const,
          assignee: 'owner' as const,
          points: 15,
        },
        // Day 2 - Assistant Tasks
        {
          user_id: userId,
          day_number: 2,
          title: 'Organize Financial Documents',
          description: 'Set up digital filing system for receipts, invoices, and tax documents',
          category: 'business' as const,
          assignee: 'assistant' as const,
          points: 15,
        },
        // Day 3 - Credit Building
        {
          user_id: userId,
          day_number: 3,
          title: 'Apply for Secured Credit Card',
          description: 'Research and apply for secured credit card to build payment history',
          category: 'credit' as const,
          assignee: 'owner' as const,
          points: 25,
        },
      ];

      // Batch create tasks
      for (const task of initialTasks) {
        await tasksService.createTask(task);
      }

      console.log('✅ Created initial 120-day plan tasks');
    }

    return {
      profile,
      progress,
      success: true,
    };
  } catch (error) {
    console.error('Error initializing user data:', error);
    throw error;
  }
}

/**
 * Check if user data is initialized
 */
export async function isUserDataInitialized(userId: string): Promise<boolean> {
  try {
    const profile = await profileService.getProfile(userId);
    const progress = await progressService.getProgress(userId);
    
    return !!(profile && progress);
  } catch (error) {
    console.error('Error checking user data initialization:', error);
    return false;
  }
}
