/**
 * Profile Service
 * CRUD operations for user profiles
 */

import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];
type ProfileInsert = Database['public']['Tables']['profiles']['Insert'];
type ProfileUpdate = Database['public']['Tables']['profiles']['Update'];

export const profileService = {
  /**
   * Get user profile
   */
  async getProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error && error.code !== 'PGRST116') {
      // PGRST116 is "not found", which is okay
      throw error;
    }

    return data;
  },

  /**
   * Create user profile
   */
  async createProfile(profile: ProfileInsert): Promise<Profile> {
    const { data, error } = await supabase
      .from('profiles')
      .insert(profile)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Update user profile
   */
  async updateProfile(userId: string, updates: ProfileUpdate): Promise<Profile> {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Get or create profile (helper)
   */
  async getOrCreateProfile(userId: string, initialData?: Partial<ProfileInsert>): Promise<Profile> {
    let profile = await this.getProfile(userId);

    if (!profile) {
      profile = await this.createProfile({
        user_id: userId,
        subscription_tier: 'basic',
        ...initialData,
      });
    }

    return profile;
  },
};
