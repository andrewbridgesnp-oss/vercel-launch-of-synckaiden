/**
 * Daily Tasks Service
 * CRUD operations for 120-day plan tasks
 */

import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type DailyTask = Database['public']['Tables']['daily_tasks']['Row'];
type DailyTaskInsert = Database['public']['Tables']['daily_tasks']['Insert'];
type DailyTaskUpdate = Database['public']['Tables']['daily_tasks']['Update'];

export const tasksService = {
  /**
   * Get all tasks for a user
   */
  async getTasks(userId: string): Promise<DailyTask[]> {
    const { data, error } = await supabase
      .from('daily_tasks')
      .select('*')
      .eq('user_id', userId)
      .order('day_number', { ascending: true });

    if (error) throw error;
    return data || [];
  },

  /**
   * Get tasks for a specific day
   */
  async getTasksByDay(userId: string, dayNumber: number): Promise<DailyTask[]> {
    const { data, error } = await supabase
      .from('daily_tasks')
      .select('*')
      .eq('user_id', userId)
      .eq('day_number', dayNumber)
      .order('created_at', { ascending: true });

    if (error) throw error;
    return data || [];
  },

  /**
   * Get tasks by assignee (owner/assistant/both)
   */
  async getTasksByAssignee(userId: string, assignee: 'owner' | 'assistant' | 'both'): Promise<DailyTask[]> {
    const { data, error } = await supabase
      .from('daily_tasks')
      .select('*')
      .eq('user_id', userId)
      .eq('assignee', assignee)
      .order('day_number', { ascending: true });

    if (error) throw error;
    return data || [];
  },

  /**
   * Create a task
   */
  async createTask(task: DailyTaskInsert): Promise<DailyTask> {
    const { data, error } = await supabase
      .from('daily_tasks')
      .insert(task)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Update a task
   */
  async updateTask(taskId: string, updates: DailyTaskUpdate): Promise<DailyTask> {
    const { data, error } = await supabase
      .from('daily_tasks')
      .update(updates)
      .eq('id', taskId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Toggle task completion
   */
  async toggleTaskCompletion(taskId: string, completed: boolean): Promise<DailyTask> {
    const updates: DailyTaskUpdate = {
      completed,
      completed_at: completed ? new Date().toISOString() : null,
    };

    return this.updateTask(taskId, updates);
  },

  /**
   * Delete a task
   */
  async deleteTask(taskId: string): Promise<void> {
    const { error } = await supabase
      .from('daily_tasks')
      .delete()
      .eq('id', taskId);

    if (error) throw error;
  },

  /**
   * Get completed tasks count
   */
  async getCompletedTasksCount(userId: string): Promise<number> {
    const { count, error } = await supabase
      .from('daily_tasks')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('completed', true);

    if (error) throw error;
    return count || 0;
  },

  /**
   * Get tasks by category
   */
  async getTasksByCategory(
    userId: string,
    category: 'credit' | 'grants' | 'loans' | 'business' | 'personal'
  ): Promise<DailyTask[]> {
    const { data, error } = await supabase
      .from('daily_tasks')
      .select('*')
      .eq('user_id', userId)
      .eq('category', category)
      .order('day_number', { ascending: true });

    if (error) throw error;
    return data || [];
  },
};
