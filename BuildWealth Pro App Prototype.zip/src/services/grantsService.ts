/**
 * Grant Applications Service
 * Tracks minority-owned business grants
 */

import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type GrantApplication = Database['public']['Tables']['grant_applications']['Row'];
type GrantApplicationInsert = Database['public']['Tables']['grant_applications']['Insert'];
type GrantApplicationUpdate = Database['public']['Tables']['grant_applications']['Update'];

export const grantsService = {
  /**
   * Get all grant applications for a user
   */
  async getGrantApplications(userId: string): Promise<GrantApplication[]> {
    const { data, error } = await supabase
      .from('grant_applications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Get grant applications by status
   */
  async getGrantApplicationsByStatus(
    userId: string,
    status: 'researching' | 'applying' | 'submitted' | 'approved' | 'denied'
  ): Promise<GrantApplication[]> {
    const { data, error } = await supabase
      .from('grant_applications')
      .select('*')
      .eq('user_id', userId)
      .eq('status', status)
      .order('deadline', { ascending: true });

    if (error) throw error;
    return data || [];
  },

  /**
   * Get grants with upcoming deadlines (next 30 days)
   */
  async getUpcomingDeadlines(userId: string): Promise<GrantApplication[]> {
    const today = new Date();
    const nextMonth = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);

    const { data, error } = await supabase
      .from('grant_applications')
      .select('*')
      .eq('user_id', userId)
      .in('status', ['researching', 'applying'])
      .gte('deadline', today.toISOString().split('T')[0])
      .lte('deadline', nextMonth.toISOString().split('T')[0])
      .order('deadline', { ascending: true });

    if (error) throw error;
    return data || [];
  },

  /**
   * Create grant application
   */
  async createGrantApplication(application: GrantApplicationInsert): Promise<GrantApplication> {
    const { data, error } = await supabase
      .from('grant_applications')
      .insert(application)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Update grant application
   */
  async updateGrantApplication(
    applicationId: string,
    updates: GrantApplicationUpdate
  ): Promise<GrantApplication> {
    const { data, error } = await supabase
      .from('grant_applications')
      .update(updates)
      .eq('id', applicationId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Delete grant application
   */
  async deleteGrantApplication(applicationId: string): Promise<void> {
    const { error } = await supabase
      .from('grant_applications')
      .delete()
      .eq('id', applicationId);

    if (error) throw error;
  },

  /**
   * Calculate total potential grant funding
   */
  async getTotalPotentialFunding(userId: string): Promise<number> {
    const applications = await this.getGrantApplications(userId);
    const activeApplications = applications.filter(
      (a) => a.status === 'researching' || a.status === 'applying' || a.status === 'submitted'
    );

    return activeApplications.reduce((total, app) => {
      return total + (app.grant_amount ? Number(app.grant_amount) : 0);
    }, 0);
  },

  /**
   * Calculate total approved funding
   */
  async getTotalApprovedFunding(userId: string): Promise<number> {
    const applications = await this.getGrantApplicationsByStatus(userId, 'approved');

    return applications.reduce((total, app) => {
      return total + (app.grant_amount ? Number(app.grant_amount) : 0);
    }, 0);
  },
};
