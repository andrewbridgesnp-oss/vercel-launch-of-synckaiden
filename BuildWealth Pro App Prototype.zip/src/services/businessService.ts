/**
 * Business Operations Service
 * Time clock, mileage, and receipt tracking
 */

import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type TimeEntry = Database['public']['Tables']['time_entries']['Row'];
type TimeEntryInsert = Database['public']['Tables']['time_entries']['Insert'];
type TimeEntryUpdate = Database['public']['Tables']['time_entries']['Update'];

type MileageEntry = Database['public']['Tables']['mileage_entries']['Row'];
type MileageEntryInsert = Database['public']['Tables']['mileage_entries']['Insert'];
type MileageEntryUpdate = Database['public']['Tables']['mileage_entries']['Update'];

type Receipt = Database['public']['Tables']['receipts']['Row'];
type ReceiptInsert = Database['public']['Tables']['receipts']['Insert'];
type ReceiptUpdate = Database['public']['Tables']['receipts']['Update'];

export const businessService = {
  // ============================================================================
  // TIME ENTRIES
  // ============================================================================

  /**
   * Get all time entries for a user
   */
  async getTimeEntries(userId: string): Promise<TimeEntry[]> {
    const { data, error } = await supabase
      .from('time_entries')
      .select('*')
      .eq('user_id', userId)
      .order('clock_in', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Get time entries for date range
   */
  async getTimeEntriesInRange(userId: string, startDate: string, endDate: string): Promise<TimeEntry[]> {
    const { data, error } = await supabase
      .from('time_entries')
      .select('*')
      .eq('user_id', userId)
      .gte('clock_in', startDate)
      .lte('clock_in', endDate)
      .order('clock_in', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Clock in (start time entry)
   */
  async clockIn(userId: string, employeeName: string, project?: string): Promise<TimeEntry> {
    const { data, error } = await supabase
      .from('time_entries')
      .insert({
        user_id: userId,
        employee_name: employeeName,
        clock_in: new Date().toISOString(),
        project,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Clock out (end time entry)
   */
  async clockOut(entryId: string): Promise<TimeEntry> {
    const clockOut = new Date();

    // Get the entry to calculate hours
    const { data: entry } = await supabase
      .from('time_entries')
      .select('*')
      .eq('id', entryId)
      .single();

    if (!entry) throw new Error('Time entry not found');

    const clockIn = new Date(entry.clock_in);
    const hoursWorked = (clockOut.getTime() - clockIn.getTime()) / (1000 * 60 * 60);

    const { data, error } = await supabase
      .from('time_entries')
      .update({
        clock_out: clockOut.toISOString(),
        hours_worked: Number(hoursWorked.toFixed(2)),
      })
      .eq('id', entryId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Update time entry
   */
  async updateTimeEntry(entryId: string, updates: TimeEntryUpdate): Promise<TimeEntry> {
    const { data, error } = await supabase
      .from('time_entries')
      .update(updates)
      .eq('id', entryId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Delete time entry
   */
  async deleteTimeEntry(entryId: string): Promise<void> {
    const { error } = await supabase.from('time_entries').delete().eq('id', entryId);
    if (error) throw error;
  },

  /**
   * Get active (not clocked out) time entries
   */
  async getActiveTimeEntries(userId: string): Promise<TimeEntry[]> {
    const { data, error } = await supabase
      .from('time_entries')
      .select('*')
      .eq('user_id', userId)
      .is('clock_out', null)
      .order('clock_in', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  // ============================================================================
  // MILEAGE ENTRIES
  // ============================================================================

  /**
   * Get all mileage entries for a user
   */
  async getMileageEntries(userId: string): Promise<MileageEntry[]> {
    const { data, error } = await supabase
      .from('mileage_entries')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Get mileage entries for date range
   */
  async getMileageEntriesInRange(
    userId: string,
    startDate: string,
    endDate: string
  ): Promise<MileageEntry[]> {
    const { data, error } = await supabase
      .from('mileage_entries')
      .select('*')
      .eq('user_id', userId)
      .gte('date', startDate)
      .lte('date', endDate)
      .order('date', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Create mileage entry
   */
  async createMileageEntry(entry: MileageEntryInsert): Promise<MileageEntry> {
    const { data, error } = await supabase
      .from('mileage_entries')
      .insert(entry)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Update mileage entry
   */
  async updateMileageEntry(entryId: string, updates: MileageEntryUpdate): Promise<MileageEntry> {
    const { data, error } = await supabase
      .from('mileage_entries')
      .update(updates)
      .eq('id', entryId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Delete mileage entry
   */
  async deleteMileageEntry(entryId: string): Promise<void> {
    const { error } = await supabase.from('mileage_entries').delete().eq('id', entryId);
    if (error) throw error;
  },

  /**
   * Calculate total mileage for a period
   */
  async getTotalMileage(userId: string, startDate: string, endDate: string): Promise<number> {
    const entries = await this.getMileageEntriesInRange(userId, startDate, endDate);
    return entries.reduce((total, entry) => total + Number(entry.miles), 0);
  },

  // ============================================================================
  // RECEIPTS
  // ============================================================================

  /**
   * Get all receipts for a user
   */
  async getReceipts(userId: string): Promise<Receipt[]> {
    const { data, error } = await supabase
      .from('receipts')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Get receipts for date range
   */
  async getReceiptsInRange(userId: string, startDate: string, endDate: string): Promise<Receipt[]> {
    const { data, error } = await supabase
      .from('receipts')
      .select('*')
      .eq('user_id', userId)
      .gte('date', startDate)
      .lte('date', endDate)
      .order('date', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Get receipts by category
   */
  async getReceiptsByCategory(userId: string, category: string): Promise<Receipt[]> {
    const { data, error } = await supabase
      .from('receipts')
      .select('*')
      .eq('user_id', userId)
      .eq('category', category)
      .order('date', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Create receipt
   */
  async createReceipt(receipt: ReceiptInsert): Promise<Receipt> {
    const { data, error } = await supabase.from('receipts').insert(receipt).select().single();

    if (error) throw error;
    return data;
  },

  /**
   * Update receipt
   */
  async updateReceipt(receiptId: string, updates: ReceiptUpdate): Promise<Receipt> {
    const { data, error } = await supabase
      .from('receipts')
      .update(updates)
      .eq('id', receiptId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Delete receipt
   */
  async deleteReceipt(receiptId: string): Promise<void> {
    const { error } = await supabase.from('receipts').delete().eq('id', receiptId);
    if (error) throw error;
  },

  /**
   * Upload receipt photo
   */
  async uploadReceiptPhoto(userId: string, file: File): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/${Date.now()}.${fileExt}`;

    const { data, error } = await supabase.storage.from('receipts').upload(fileName, file);

    if (error) throw error;

    // Get public URL
    const {
      data: { publicUrl },
    } = supabase.storage.from('receipts').getPublicUrl(fileName);

    return publicUrl;
  },

  /**
   * Calculate total expenses for a period
   */
  async getTotalExpenses(userId: string, startDate: string, endDate: string): Promise<number> {
    const receipts = await this.getReceiptsInRange(userId, startDate, endDate);
    return receipts.reduce((total, receipt) => total + Number(receipt.amount), 0);
  },

  /**
   * Get expenses by category for a period
   */
  async getExpensesByCategory(
    userId: string,
    startDate: string,
    endDate: string
  ): Promise<{ category: string; total: number }[]> {
    const receipts = await this.getReceiptsInRange(userId, startDate, endDate);
    const categoryTotals = new Map<string, number>();

    receipts.forEach((receipt) => {
      const current = categoryTotals.get(receipt.category) || 0;
      categoryTotals.set(receipt.category, current + Number(receipt.amount));
    });

    return Array.from(categoryTotals.entries()).map(([category, total]) => ({
      category,
      total,
    }));
  },
};
