/**
 * Credit Accounts Service
 * FCRA Compliant - Handles credit tracking
 */

import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type CreditAccount = Database['public']['Tables']['credit_accounts']['Row'];
type CreditAccountInsert = Database['public']['Tables']['credit_accounts']['Insert'];
type CreditAccountUpdate = Database['public']['Tables']['credit_accounts']['Update'];

export const creditService = {
  /**
   * Get all credit accounts for a user
   */
  async getCreditAccounts(userId: string): Promise<CreditAccount[]> {
    const { data, error } = await supabase
      .from('credit_accounts')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Get credit accounts by type
   */
  async getCreditAccountsByType(
    userId: string,
    accountType: 'credit_card' | 'loan' | 'mortgage' | 'auto' | 'other'
  ): Promise<CreditAccount[]> {
    const { data, error } = await supabase
      .from('credit_accounts')
      .select('*')
      .eq('user_id', userId)
      .eq('account_type', accountType)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Get credit accounts by status
   */
  async getCreditAccountsByStatus(
    userId: string,
    status: 'active' | 'closed' | 'disputed'
  ): Promise<CreditAccount[]> {
    const { data, error } = await supabase
      .from('credit_accounts')
      .select('*')
      .eq('user_id', userId)
      .eq('status', status)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Create credit account
   */
  async createCreditAccount(account: CreditAccountInsert): Promise<CreditAccount> {
    const { data, error } = await supabase
      .from('credit_accounts')
      .insert(account)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Update credit account
   */
  async updateCreditAccount(accountId: string, updates: CreditAccountUpdate): Promise<CreditAccount> {
    const { data, error } = await supabase
      .from('credit_accounts')
      .update(updates)
      .eq('id', accountId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Delete credit account
   */
  async deleteCreditAccount(accountId: string): Promise<void> {
    const { error } = await supabase
      .from('credit_accounts')
      .delete()
      .eq('id', accountId);

    if (error) throw error;
  },

  /**
   * Calculate total credit utilization
   */
  async getCreditUtilization(userId: string): Promise<number> {
    const accounts = await this.getCreditAccountsByType(userId, 'credit_card');
    const activeAccounts = accounts.filter((a) => a.status === 'active');

    let totalLimit = 0;
    let totalBalance = 0;

    activeAccounts.forEach((account) => {
      if (account.credit_limit) totalLimit += Number(account.credit_limit);
      if (account.current_balance) totalBalance += Number(account.current_balance);
    });

    if (totalLimit === 0) return 0;
    return (totalBalance / totalLimit) * 100;
  },

  /**
   * Get accounts with upcoming payments (next 7 days)
   */
  async getUpcomingPayments(userId: string): Promise<CreditAccount[]> {
    const today = new Date();
    const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);

    const { data, error } = await supabase
      .from('credit_accounts')
      .select('*')
      .eq('user_id', userId)
      .eq('status', 'active')
      .gte('payment_due_date', today.toISOString().split('T')[0])
      .lte('payment_due_date', nextWeek.toISOString().split('T')[0])
      .order('payment_due_date', { ascending: true });

    if (error) throw error;
    return data || [];
  },
};
