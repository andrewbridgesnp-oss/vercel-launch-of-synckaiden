/**
 * User Progress Service
 * Gamification: points, levels, streaks, badges
 */

import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type UserProgress = Database['public']['Tables']['user_progress']['Row'];
type UserProgressInsert = Database['public']['Tables']['user_progress']['Insert'];
type UserProgressUpdate = Database['public']['Tables']['user_progress']['Update'];

export interface Badge {
  id: string;
  name: string;
  description: string;
  earnedAt: string;
}

export const progressService = {
  /**
   * Get user progress
   */
  async getProgress(userId: string): Promise<UserProgress | null> {
    const { data, error } = await supabase
      .from('user_progress')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error && error.code !== 'PGRST116') {
      throw error;
    }

    return data;
  },

  /**
   * Create initial progress
   */
  async createProgress(userId: string): Promise<UserProgress> {
    const { data, error } = await supabase
      .from('user_progress')
      .insert({
        user_id: userId,
        total_points: 0,
        current_level: 1,
        current_streak: 0,
        longest_streak: 0,
        badges_earned: [],
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Get or create progress
   */
  async getOrCreateProgress(userId: string): Promise<UserProgress> {
    let progress = await this.getProgress(userId);

    if (!progress) {
      progress = await this.createProgress(userId);
    }

    return progress;
  },

  /**
   * Add points
   */
  async addPoints(userId: string, points: number): Promise<UserProgress> {
    const progress = await this.getOrCreateProgress(userId);
    const newTotalPoints = progress.total_points + points;
    const newLevel = this.calculateLevel(newTotalPoints);

    const { data, error } = await supabase
      .from('user_progress')
      .update({
        total_points: newTotalPoints,
        current_level: newLevel,
      })
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Update streak
   */
  async updateStreak(userId: string): Promise<UserProgress> {
    const progress = await this.getOrCreateProgress(userId);
    const today = new Date().toISOString().split('T')[0];
    const lastActivity = progress.last_activity_date;

    let newStreak = progress.current_streak;
    let longestStreak = progress.longest_streak;

    if (!lastActivity) {
      // First activity
      newStreak = 1;
    } else {
      const lastDate = new Date(lastActivity);
      const currentDate = new Date(today);
      const diffDays = Math.floor(
        (currentDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
      );

      if (diffDays === 1) {
        // Consecutive day
        newStreak += 1;
      } else if (diffDays > 1) {
        // Streak broken
        newStreak = 1;
      }
      // If diffDays === 0, same day, no change
    }

    if (newStreak > longestStreak) {
      longestStreak = newStreak;
    }

    const { data, error } = await supabase
      .from('user_progress')
      .update({
        current_streak: newStreak,
        longest_streak: longestStreak,
        last_activity_date: today,
      })
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Award badge
   */
  async awardBadge(userId: string, badge: Omit<Badge, 'earnedAt'>): Promise<UserProgress> {
    const progress = await this.getOrCreateProgress(userId);
    const badges = (progress.badges_earned as Badge[]) || [];

    // Check if badge already earned
    if (badges.some((b) => b.id === badge.id)) {
      return progress;
    }

    const newBadge: Badge = {
      ...badge,
      earnedAt: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from('user_progress')
      .update({
        badges_earned: [...badges, newBadge] as any,
      })
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  /**
   * Calculate level based on points
   * Level formula: Level = floor(sqrt(points / 100)) + 1
   */
  calculateLevel(points: number): number {
    return Math.floor(Math.sqrt(points / 100)) + 1;
  },

  /**
   * Calculate points needed for next level
   */
  pointsForNextLevel(currentLevel: number): number {
    return (currentLevel * currentLevel) * 100;
  },

  /**
   * Calculate progress to next level (0-100%)
   */
  getLevelProgress(points: number): number {
    const currentLevel = this.calculateLevel(points);
    const pointsForCurrentLevel = ((currentLevel - 1) * (currentLevel - 1)) * 100;
    const pointsForNextLevel = this.pointsForNextLevel(currentLevel);
    const pointsInLevel = points - pointsForCurrentLevel;
    const pointsNeeded = pointsForNextLevel - pointsForCurrentLevel;

    return Math.floor((pointsInLevel / pointsNeeded) * 100);
  },
};
