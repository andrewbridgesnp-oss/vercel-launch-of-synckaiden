import { useState } from 'react';
import { Home, CreditCard, DollarSign, Menu } from 'lucide-react';
import { SplashScreen } from './components/splash-screen';
import { OnboardingScreen } from './components/onboarding-screen';
import { Dashboard } from './components/dashboard';
import { CreditScreen } from './components/credit-screen';
import { VehiclesScreen } from './components/vehicles-screen';
import { TrackingScreen } from './components/tracking-screen';
import { SettingsScreen } from './components/settings-screen';
import { motion } from 'motion/react';

type Screen = 'dashboard' | 'credit' | 'vehicles' | 'tracking' | 'settings';
type AppState = 'splash' | 'onboarding' | 'app';

export default function App() {
  const [appState, setAppState] = useState<AppState>('splash');
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');

  // Mock user data - in production, this would come from backend/Supabase
  const user = {
    name: 'K.C.',
    points: 1250,
    level: 'Apprentice',
    streak: 7,
    personalCredit: 620,
    businessCredit: 0,
  };

  const handleNavigate = (screen: Screen) => {
    setCurrentScreen(screen);
  };

  const handleBackToDashboard = () => {
    setCurrentScreen('dashboard');
  };

  // Show onboarding if not completed
  if (appState === 'splash') {
    return <SplashScreen onComplete={() => setAppState('onboarding')} />;
  }

  if (appState === 'onboarding') {
    return <OnboardingScreen onComplete={() => setAppState('app')} />;
  }

  // Render current screen
  const renderScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return <Dashboard user={user} onNavigate={handleNavigate} />;
      case 'credit':
        return <CreditScreen onBack={handleBackToDashboard} />;
      case 'vehicles':
        return <VehiclesScreen onBack={handleBackToDashboard} />;
      case 'tracking':
        return <TrackingScreen onBack={handleBackToDashboard} />;
      case 'settings':
        return <SettingsScreen onBack={handleBackToDashboard} />;
      default:
        return <Dashboard user={user} onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-950 to-black">
      {/* Mobile app container */}
      <div className="max-w-md mx-auto bg-transparent min-h-screen relative">
        {/* Main content */}
        <main className="pb-16">
          {renderScreen()}
        </main>

        {/* Bottom Navigation - Luxury Version */}
        {currentScreen === 'dashboard' && (
          <motion.nav 
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="fixed bottom-0 left-0 right-0 max-w-md mx-auto"
          >
            <div className="mx-4 mb-4 rounded-3xl luxury-card backdrop-blur-2xl border-zinc-800/50 px-2 py-2">
              <div className="grid grid-cols-4 gap-1">
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleNavigate('dashboard')}
                  className="flex flex-col items-center justify-center py-3 px-2 transition-all rounded-2xl bg-gradient-to-br from-[#D4AF37]/20 to-red-950/20 border border-[#D4AF37]/30"
                >
                  <Home className="w-6 h-6 mb-1 text-[#D4AF37]" strokeWidth={2.5} />
                  <span className="text-xs font-bold text-[#D4AF37]">Home</span>
                </motion.button>

                <motion.button
                  whileTap={{ scale: 0.95 }}
                  whileHover={{ scale: 1.05 }}
                  onClick={() => handleNavigate('credit')}
                  className="flex flex-col items-center justify-center py-3 px-2 transition-all rounded-2xl hover:bg-zinc-800/50 text-zinc-500 hover:text-zinc-300"
                >
                  <CreditCard className="w-6 h-6 mb-1" />
                  <span className="text-xs font-medium">Credit</span>
                </motion.button>

                <motion.button
                  whileTap={{ scale: 0.95 }}
                  whileHover={{ scale: 1.05 }}
                  onClick={() => handleNavigate('vehicles')}
                  className="flex flex-col items-center justify-center py-3 px-2 transition-all rounded-2xl hover:bg-zinc-800/50 text-zinc-500 hover:text-zinc-300"
                >
                  <DollarSign className="w-6 h-6 mb-1" />
                  <span className="text-xs font-medium">Vehicles</span>
                </motion.button>

                <motion.button
                  whileTap={{ scale: 0.95 }}
                  whileHover={{ scale: 1.05 }}
                  onClick={() => handleNavigate('settings')}
                  className="flex flex-col items-center justify-center py-3 px-2 transition-all rounded-2xl hover:bg-zinc-800/50 text-zinc-500 hover:text-zinc-300"
                >
                  <Menu className="w-6 h-6 mb-1" />
                  <span className="text-xs font-medium">More</span>
                </motion.button>
              </div>
            </div>
          </motion.nav>
        )}
      </div>
    </div>
  );
}