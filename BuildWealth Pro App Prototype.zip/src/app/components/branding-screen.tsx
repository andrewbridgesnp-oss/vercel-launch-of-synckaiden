import { useState } from 'react';
import { ChevronLeft, Download, Share2, Copy, Palette, Type, Image as ImageIcon, FileText, Truck, Mail, Monitor } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { RealisticLogo } from './realistic-logo';

interface BrandingScreenProps {
  onBack: () => void;
}

export function BrandingScreen({ onBack }: BrandingScreenProps) {
  const [selectedLogo, setSelectedLogo] = useState(1);

  const brandColors = [
    { name: 'Navy Blue', hex: '#0A1628', rgb: 'rgb(10, 22, 40)', usage: 'Primary backgrounds' },
    { name: 'Silver', hex: '#C0C0C0', rgb: 'rgb(192, 192, 192)', usage: 'Main logo text' },
    { name: 'Gold', hex: '#D4AF37', rgb: 'rgb(212, 175, 55)', usage: 'Accent, ampersand' },
    { name: 'Dark Gray', hex: '#18181B', rgb: 'rgb(24, 24, 27)', usage: 'Backgrounds, text' },
    { name: 'White', hex: '#FFFFFF', rgb: 'rgb(255, 255, 255)', usage: 'Text on dark' },
    { name: 'Red Accent', hex: '#DC2626', rgb: 'rgb(220, 38, 38)', usage: 'App UI accents' },
  ];

  const logoVariants = [
    {
      id: 1,
      name: 'Primary Logo',
      description: 'Full color on light backgrounds',
      bgColor: 'bg-white',
      textColor: 'text-zinc-900'
    },
    {
      id: 2,
      name: 'Reverse Logo',
      description: 'White on dark backgrounds',
      bgColor: 'bg-zinc-900',
      textColor: 'text-white'
    },
    {
      id: 3,
      name: 'Icon Only',
      description: 'For social media, favicons',
      bgColor: 'bg-red-600',
      textColor: 'text-white'
    },
  ];

  const businessCardDesigns = [
    {
      id: 1,
      name: 'Executive Black',
      front: {
        bg: 'bg-zinc-900',
        accentColor: 'border-red-600'
      },
      back: {
        bg: 'bg-red-600',
        accentColor: 'border-zinc-900'
      }
    },
    {
      id: 2,
      name: 'Professional White',
      front: {
        bg: 'bg-white',
        accentColor: 'border-red-600'
      },
      back: {
        bg: 'bg-zinc-100',
        accentColor: 'border-zinc-300'
      }
    },
  ];

  const marketingAssets = [
    { type: 'Vehicle Wrap', status: 'Ready to Print', icon: Truck },
    { type: 'Yard Signs', status: 'Design Complete', icon: ImageIcon },
    { type: 'Letterhead', status: 'Ready to Print', icon: FileText },
    { type: 'Email Signature', status: 'Copy & Paste', icon: Mail },
    { type: 'Social Media Kit', status: '12 Templates', icon: Monitor },
  ];

  return (
    <div className="min-h-screen bg-black pb-20">
      {/* Header */}
      <div className="bg-zinc-900 px-6 py-4 border-b border-zinc-800 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 hover:bg-zinc-800 rounded-lg -ml-2">
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-white">Professional Branding</h1>
            <p className="text-sm text-zinc-400">K.C. Construction LLC</p>
          </div>
        </div>
      </div>

      {/* Brand Overview */}
      <div className="px-6 py-6 border-b border-zinc-900">
        <Card className="p-6 bg-gradient-to-br from-red-950 to-zinc-900 border border-red-900/30">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-white mb-1">K.C. Construction LLC</h2>
              <p className="text-sm text-zinc-400">Licensed, Bonded & Insured</p>
            </div>
            <div className="w-16 h-16 rounded-xl bg-red-600 flex items-center justify-center">
              <span className="text-white font-bold text-2xl">K</span>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <p className="text-xs text-zinc-500 mb-1">License #</p>
              <p className="text-sm text-white font-semibold">GA-CON-2024-1234</p>
            </div>
            <div>
              <p className="text-xs text-zinc-500 mb-1">Years in Business</p>
              <p className="text-sm text-white font-semibold">30 Years</p>
            </div>
          </div>

          <div className="pt-4 border-t border-zinc-800">
            <p className="text-xs text-zinc-400 italic">
              "Building Georgia's Future, One Project at a Time"
            </p>
          </div>
        </Card>
      </div>

      {/* Tabs */}
      <div className="px-6 py-6">
        <Tabs defaultValue="colors" className="w-full">
          <TabsList className="w-full grid grid-cols-3 bg-zinc-900 border border-zinc-800 mb-6">
            <TabsTrigger value="colors" className="data-[state=active]:bg-red-950 data-[state=active]:text-white text-xs">
              Colors
            </TabsTrigger>
            <TabsTrigger value="logos" className="data-[state=active]:bg-red-950 data-[state=active]:text-white text-xs">
              Logos
            </TabsTrigger>
            <TabsTrigger value="assets" className="data-[state=active]:bg-red-950 data-[state=active]:text-white text-xs">
              Assets
            </TabsTrigger>
          </TabsList>

          {/* Brand Colors */}
          <TabsContent value="colors" className="space-y-4">
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Brand Color Palette</h3>
              
              <div className="space-y-3">
                {brandColors.map((color, index) => (
                  <Card key={index} className="p-4 bg-zinc-900 border border-zinc-800">
                    <div className="flex items-center gap-4">
                      <div 
                        className="w-16 h-16 rounded-xl border-2 border-zinc-700 flex-shrink-0"
                        style={{ backgroundColor: color.hex }}
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold text-white mb-1">{color.name}</h4>
                        <p className="text-sm text-zinc-400 mb-2">{color.usage}</p>
                        <div className="flex items-center gap-3 text-xs">
                          <button 
                            onClick={() => navigator.clipboard.writeText(color.hex)}
                            className="flex items-center gap-1 text-zinc-500 hover:text-white transition-colors"
                          >
                            <Copy className="w-3 h-3" />
                            <span className="font-mono">{color.hex}</span>
                          </button>
                          <span className="text-zinc-700">•</span>
                          <button 
                            onClick={() => navigator.clipboard.writeText(color.rgb)}
                            className="flex items-center gap-1 text-zinc-500 hover:text-white transition-colors"
                          >
                            <Copy className="w-3 h-3" />
                            <span className="font-mono text-xs">{color.rgb}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <Card className="p-4 bg-zinc-900 border border-zinc-800 mt-6">
                <h4 className="font-semibold text-white mb-3">Typography</h4>
                <div className="space-y-4">
                  <div>
                    <p className="text-xs text-zinc-500 mb-2">Headlines & Logo</p>
                    <p className="text-2xl font-bold text-white" style={{ fontFamily: 'system-ui' }}>
                      K.C. Construction
                    </p>
                    <p className="text-xs text-zinc-600 mt-1">Font: System UI Bold</p>
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 mb-2">Body Text</p>
                    <p className="text-base text-zinc-300" style={{ fontFamily: 'system-ui' }}>
                      Professional construction services with 30 years of experience.
                    </p>
                    <p className="text-xs text-zinc-600 mt-1">Font: System UI Regular</p>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>

          {/* Logos */}
          <TabsContent value="logos" className="space-y-4">
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Logo Variations</h3>
              
              <div className="space-y-3 mb-6">
                {logoVariants.map((variant) => (
                  <Card 
                    key={variant.id}
                    className={`p-6 border-2 cursor-pointer transition-all ${
                      selectedLogo === variant.id 
                        ? 'border-red-600 bg-zinc-900' 
                        : 'border-zinc-800 bg-zinc-950 hover:border-zinc-700'
                    }`}
                    onClick={() => setSelectedLogo(variant.id)}
                  >
                    <div className="mb-4">
                      <div className={`h-32 rounded-lg ${variant.bgColor} flex items-center justify-center border border-zinc-700 p-4`}>
                        {variant.id === 3 ? (
                          <RealisticLogo 
                            className="h-full w-auto object-contain"
                          />
                        ) : (
                          <RealisticLogo 
                            className="h-full w-auto object-contain"
                          />
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-semibold text-white mb-1">{variant.name}</h4>
                        <p className="text-sm text-zinc-400">{variant.description}</p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="bg-zinc-800 hover:bg-zinc-700 border-zinc-700 flex-shrink-0"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        PNG
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>

              <Card className="p-4 bg-zinc-900 border border-zinc-800">
                <h4 className="font-semibold text-white mb-3 flex items-center gap-2">
                  <Palette className="w-5 h-5 text-red-500" />
                  Usage Guidelines
                </h4>
                <ul className="text-sm text-zinc-400 space-y-2">
                  <li>• Maintain clear space equal to the height of "M" around logo</li>
                  <li>• Never stretch or distort the logo proportions</li>
                  <li>• Use Primary Logo on light backgrounds (white, light gray)</li>
                  <li>• Use Reverse Logo on dark backgrounds (black, dark photos)</li>
                  <li>• Minimum size: 1 inch wide for print, 150px for web</li>
                </ul>
              </Card>
            </div>
          </TabsContent>

          {/* Marketing Assets */}
          <TabsContent value="assets" className="space-y-4">
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Marketing Materials</h3>
              
              <div className="space-y-3">
                {marketingAssets.map((asset, index) => (
                  <Card key={index} className="p-4 bg-zinc-900 border border-zinc-800">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-zinc-800 flex items-center justify-center flex-shrink-0">
                        <asset.icon className="w-6 h-6 text-red-500" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-white mb-1">{asset.type}</h4>
                        <Badge className="bg-green-500/10 text-green-500 border-green-500/20 text-xs">
                          {asset.status}
                        </Badge>
                      </div>
                      <Button 
                        variant="outline"
                        size="sm"
                        className="bg-zinc-800 hover:bg-zinc-700 border-zinc-700"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Get
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Business Card Preview */}
              <div className="mt-6">
                <h4 className="font-semibold text-white mb-4">Business Card Designs</h4>
                
                {businessCardDesigns.map((design) => (
                  <div key={design.id} className="mb-6">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-sm text-zinc-400">{design.name}</p>
                      <Button 
                        variant="outline"
                        size="sm"
                        className="bg-red-600 hover:bg-red-700 border-red-600 text-white"
                      >
                        Order 500 for $49
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      {/* Front */}
                      <Card className={`p-4 ${design.front.bg} border-2 ${design.front.accentColor} aspect-[1.75/1]`}>
                        <div className="h-full flex flex-col justify-between">
                          <div>
                            <div className={`text-lg font-bold mb-1 ${design.front.bg === 'bg-white' ? 'text-zinc-900' : 'text-white'}`}>
                              K.C.
                            </div>
                            <div className={`text-xs ${design.front.bg === 'bg-white' ? 'text-zinc-600' : 'text-zinc-400'}`}>
                              CONSTRUCTION LLC
                            </div>
                          </div>
                          <div className={`text-xs ${design.front.bg === 'bg-white' ? 'text-zinc-900' : 'text-white'}`}>
                            <p className="font-bold">K.C. Johnson</p>
                            <p className={design.front.bg === 'bg-white' ? 'text-zinc-600' : 'text-zinc-400'}>Owner & Operator</p>
                          </div>
                        </div>
                      </Card>

                      {/* Back */}
                      <Card className={`p-4 ${design.back.bg} border-2 ${design.back.accentColor} aspect-[1.75/1]`}>
                        <div className="h-full flex flex-col justify-between">
                          <div className={`text-xs space-y-1 ${design.back.bg === 'bg-red-600' ? 'text-white' : 'text-zinc-900'}`}>
                            <p>📞 (706) 555-0123</p>
                            <p>✉️ kc@kcconstruction.com</p>
                            <p>🌐 kcconstruction.com</p>
                          </div>
                          <div className={`text-xs ${design.back.bg === 'bg-red-600' ? 'text-white/75' : 'text-zinc-600'}`}>
                            <p>License: GA-CON-2024-1234</p>
                            <p>Licensed • Bonded • Insured</p>
                          </div>
                        </div>
                      </Card>
                    </div>
                  </div>
                ))}
              </div>

              {/* Email Signature */}
              <Card className="p-4 bg-zinc-900 border border-zinc-800 mt-6">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold text-white">Email Signature</h4>
                  <Button 
                    variant="outline"
                    size="sm"
                    className="bg-zinc-800 hover:bg-zinc-700 border-zinc-700"
                    onClick={() => {
                      const signature = `K.C. Johnson\nOwner & Operator\nK.C. Construction LLC\n\n📞 (706) 555-0123\n✉️ kc@kcconstruction.com\n🌐 kcconstruction.com\n\nLicense: GA-CON-2024-1234 | Licensed, Bonded & Insured`;
                      navigator.clipboard.writeText(signature);
                    }}
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                </div>
                
                <div className="bg-zinc-800 p-4 rounded-lg border border-zinc-700 text-sm">
                  <p className="font-bold text-white">K.C. Johnson</p>
                  <p className="text-zinc-400 text-xs mb-3">Owner & Operator | K.C. Construction LLC</p>
                  
                  <div className="text-xs text-zinc-400 space-y-1 mb-3">
                    <p>📞 (706) 555-0123</p>
                    <p>✉️ kc@kcconstruction.com</p>
                    <p>🌐 kcconstruction.com</p>
                  </div>
                  
                  <div className="pt-3 border-t border-zinc-700">
                    <p className="text-xs text-zinc-500">
                      License: GA-CON-2024-1234 | Licensed, Bonded & Insured
                    </p>
                  </div>
                </div>
              </Card>

              {/* Vehicle Wrap Preview */}
              <Card className="p-4 bg-zinc-900 border border-zinc-800 mt-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="font-semibold text-white">Vehicle Wrap Design</h4>
                    <p className="text-xs text-zinc-500">Fits: Trucks, Vans, Trail Boss</p>
                  </div>
                  <Button 
                    variant="outline"
                    size="sm"
                    className="bg-red-600 hover:bg-red-700 border-red-600 text-white"
                  >
                    Get Quote
                  </Button>
                </div>
                
                <div className="bg-gradient-to-r from-red-600 to-zinc-900 p-6 rounded-lg border border-red-700">
                  <div className="text-white">
                    <div className="text-3xl font-bold mb-2">K.C.</div>
                    <div className="text-lg mb-4">CONSTRUCTION LLC</div>
                    <div className="text-sm space-y-1 mb-4">
                      <p>📞 (706) 555-0123</p>
                      <p>🌐 kcconstruction.com</p>
                    </div>
                    <div className="text-xs text-white/75">
                      Licensed • Bonded • Insured • GA-CON-2024-1234
                    </div>
                  </div>
                </div>
                
                <p className="text-xs text-zinc-500 mt-3">
                  Full wrap includes both sides, rear, and optional hood design
                </p>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Quick Actions */}
      <div className="px-6 py-4 border-t border-zinc-900">
        <div className="grid grid-cols-2 gap-3">
          <Button className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 flex items-center justify-center gap-2 h-12">
            <Share2 className="w-5 h-5" />
            Share Kit
          </Button>
          <Button className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 flex items-center justify-center gap-2 h-12">
            <Download className="w-5 h-5" />
            Download All
          </Button>
        </div>
      </div>
    </div>
  );
}