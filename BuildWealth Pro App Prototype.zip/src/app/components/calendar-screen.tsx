import { useState } from 'react';
import { ChevronLeft, Calendar as CalendarIcon, Trophy, Zap, CheckCircle, Clock, Flame, CheckCircle2 } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import { Progress } from './ui/progress';

interface CalendarScreenProps {
  onBack: () => void;
}

export function CalendarScreen({ onBack }: CalendarScreenProps) {
  const [selectedDay, setSelectedDay] = useState(1);
  const [completedTasks, setCompletedTasks] = useState<Record<number, boolean>>({});

  const days = Array.from({ length: 120 }, (_, i) => ({
    day: i + 1,
    date: new Date(2026, 0, 8 + i), // Starting Jan 8, 2026
    status: i === 0 ? 'current' : i < 1 ? 'completed' : 'upcoming',
    hasMilestone: [7, 22, 30, 45, 60, 90, 120].includes(i + 1),
  }));

  const tasksForDay: Record<number, { owner: string[]; assistant: string[] }> = {
    1: {
      owner: [
        'Make weekly deposit to Truist business account',
        'Log mileage for any business trips',
        'Pay spouse helper via payroll',
        'Review credit reports (Experian, Equifax, TransUnion)'
      ],
      assistant: [
        'Organize business receipts and documents',
        'Research minority-owned business grants',
        'Prepare grant proposal template'
      ]
    },
    22: {
      owner: [
        'Apply for DUNS number (D&B)',
        'Make bi-weekly deposit to Truist',
        'Continue quiet banking - no large withdrawals',
        'Track all business expenses'
      ],
      assistant: [
        'Complete NAACP Powershift grant application',
        'Draft equipment purchase justification',
        'Update business portfolio'
      ]
    },
    30: {
      owner: [
        'Verify DUNS number received',
        'Apply for NAV business credit',
        'Continue consistent deposits',
        'Review personal credit score progress'
      ],
      assistant: [
        'Submit Coalition grant application ($5k)',
        'Prepare vehicle financing documents',
        'Research Trail Boss inventory'
      ]
    },
    60: {
      owner: [
        'Apply for business credit cards (secured)',
        'Begin credit stacking sequence',
        'Start BlueVine business credit application',
        'Maintain deposit consistency'
      ],
      assistant: [
        'Apply for Wish grant ($500-2k)',
        'Research assistant vehicle options',
        'Complete MBDA grant preliminary forms'
      ]
    }
  };

  const currentTasks = tasksForDay[selectedDay] || tasksForDay[1];

  const handleTaskToggle = (taskIndex: number) => {
    setCompletedTasks(prev => ({
      ...prev,
      [taskIndex]: !prev[taskIndex]
    }));
  };

  const completedCount = Object.values(completedTasks).filter(Boolean).length;
  const totalTasks = currentTasks.owner.length + currentTasks.assistant.length;

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white p-6 sticky top-0 z-10">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-lg">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">120-Day Success Plan</h1>
            <p className="text-sm opacity-90">Jan 8 - May 7, 2026</p>
          </div>
        </div>

        <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm">Overall Progress</span>
            <span className="font-bold">1 of 120 days</span>
          </div>
          <Progress value={(1 / 120) * 100} className="h-2 bg-white/30" />
        </div>
      </div>

      {/* Mini Calendar */}
      <div className="p-4 bg-white border-b">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold">Select Day</h3>
          <div className="flex gap-2">
            <Badge className="bg-green-500">Completed</Badge>
            <Badge className="bg-blue-500">Current</Badge>
            <Badge variant="outline">Upcoming</Badge>
          </div>
        </div>
        
        <div className="grid grid-cols-7 gap-2 max-h-48 overflow-y-auto">
          {days.slice(0, 35).map((item) => (
            <button
              key={item.day}
              onClick={() => setSelectedDay(item.day)}
              className={`aspect-square rounded-lg flex flex-col items-center justify-center text-xs font-semibold relative ${
                item.status === 'current'
                  ? 'bg-blue-500 text-white'
                  : item.status === 'completed'
                  ? 'bg-green-500 text-white'
                  : 'bg-gray-100 text-gray-700'
              } ${selectedDay === item.day ? 'ring-2 ring-purple-500' : ''}`}
            >
              {item.day}
              {item.hasMilestone && (
                <Trophy className="w-3 h-3 absolute -top-1 -right-1 text-yellow-400" />
              )}
            </button>
          ))}
        </div>
        <p className="text-xs text-gray-500 text-center mt-2">Showing days 1-35 • Scroll for more</p>
      </div>

      {/* Selected Day Details */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">
            Day {selectedDay} - {days[selectedDay - 1]?.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </h2>
          {days[selectedDay - 1]?.hasMilestone && (
            <Badge className="bg-yellow-500">
              <Trophy className="w-3 h-3 mr-1" /> Milestone
            </Badge>
          )}
        </div>

        {/* Progress */}
        <Card className="p-4 mb-4 bg-gradient-to-r from-purple-50 to-pink-50">
          <div className="flex items-center justify-between mb-2">
            <span className="font-semibold">Today's Progress</span>
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-orange-500" />
              <span className="font-bold">{completedCount}/{totalTasks}</span>
            </div>
          </div>
          <Progress value={(completedCount / totalTasks) * 100} className="h-2" />
          {completedCount === totalTasks && totalTasks > 0 && (
            <p className="text-sm text-green-600 mt-2 font-semibold flex items-center gap-1">
              <Trophy className="w-4 h-4" />
              All tasks completed! +100 points earned!
            </p>
          )}
        </Card>

        {/* Owner Tasks */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-full bg-blue-500 text-white flex items-center justify-center font-bold text-sm">
              O
            </div>
            <h3 className="font-bold">Owner Tasks</h3>
            <Badge variant="secondary">+50 pts each</Badge>
          </div>
          <div className="space-y-3">
            {currentTasks.owner.map((task, index) => (
              <Card key={index} className="p-4">
                <div className="flex items-start gap-3">
                  <Checkbox
                    checked={completedTasks[index] || false}
                    onCheckedChange={() => handleTaskToggle(index)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <p className={`${completedTasks[index] ? 'line-through text-gray-400' : 'text-gray-800'}`}>
                      {task}
                    </p>
                    {completedTasks[index] && (
                      <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> +50 points earned!
                      </p>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Assistant Tasks */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-full bg-green-500 text-white flex items-center justify-center font-bold text-sm">
              A
            </div>
            <h3 className="font-bold">Assistant Tasks</h3>
            <Badge variant="secondary">+50 pts each</Badge>
          </div>
          <div className="space-y-3">
            {currentTasks.assistant.map((task, index) => {
              const taskIndex = currentTasks.owner.length + index;
              return (
                <Card key={index} className="p-4">
                  <div className="flex items-start gap-3">
                    <Checkbox
                      checked={completedTasks[taskIndex] || false}
                      onCheckedChange={() => handleTaskToggle(taskIndex)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <p className={`${completedTasks[taskIndex] ? 'line-through text-gray-400' : 'text-gray-800'}`}>
                        {task}
                      </p>
                      {completedTasks[taskIndex] && (
                        <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> +50 points earned!
                        </p>
                      )}
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Key Milestones */}
        <Card className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-300">
          <h3 className="font-bold mb-3 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-600" />
            Upcoming Milestones
          </h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between items-center">
              <span>Day 7: Complete Week 1</span>
              <Badge className="bg-yellow-500 flex items-center gap-1">
                <Trophy className="w-3 h-3" /> Badge
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span>Day 22-30: Apply for DUNS</span>
              <Badge className="bg-yellow-500 flex items-center gap-1">
                <Trophy className="w-3 h-3" /> Badge
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span>Day 60: Start Credit Stacking</span>
              <Badge className="bg-yellow-500 flex items-center gap-1">
                <Trophy className="w-3 h-3" /> Badge
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span>Day 120: Plan Complete!</span>
              <Badge className="bg-yellow-500 flex items-center gap-1">
                <Trophy className="w-3 h-3" /> Master Badge
              </Badge>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}