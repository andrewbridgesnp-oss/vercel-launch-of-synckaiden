import { useState } from 'react';
import { ArrowRight, TrendingUp, DollarSign, Building2, Car, FileText } from 'lucide-react';
import { Button } from './ui/button';
import { motion, AnimatePresence } from 'motion/react';

interface OnboardingProps {
  onComplete: () => void;
}

export function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(0);

  const slides = [
    {
      title: "Professional Credit Building",
      description: "Fix personal credit and establish business credit with proven strategies",
      icon: TrendingUp
    },
    {
      title: "Real-Time Loan Offers",
      description: "Get pre-qualified offers from Georgia credit unions and national lenders",
      icon: DollarSign
    },
    {
      title: "Business Credit Stack",
      description: "Build credit with D&B, NAV, NAV Prime, and BlueVine integrations",
      icon: Building2
    },
    {
      title: "Live Vehicle Inventory",
      description: "Browse actual Trail Boss trucks and commercial vehicles with real pricing",
      icon: Car
    },
    {
      title: "Track Everything",
      description: "Mileage, expenses, and payroll tracking for maximum tax benefits",
      icon: FileText
    }
  ];

  const handleNext = () => {
    if (step < slides.length - 1) {
      setStep(step + 1);
    } else {
      onComplete();
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  const CurrentIcon = slides[step].icon;

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-950 to-black flex flex-col relative overflow-hidden">
      {/* Background Orbs */}
      <motion.div 
        animate={{ 
          x: [0, 100, 0],
          y: [0, 50, 0],
          scale: [1, 1.2, 1]
        }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#D4AF37]/10 to-transparent rounded-full blur-3xl"
      />
      <motion.div 
        animate={{ 
          x: [0, -50, 0],
          y: [0, 100, 0],
          scale: [1, 1.1, 1]
        }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-br from-red-600/10 to-transparent rounded-full blur-3xl"
      />

      {/* Skip button */}
      {step < slides.length - 1 && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex justify-end p-6 relative z-10"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleSkip}
            className="text-sm font-semibold text-zinc-500 hover:text-[#D4AF37] transition-colors"
          >
            Skip
          </motion.button>
        </motion.div>
      )}

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 pb-20 relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
            className="flex flex-col items-center"
          >
            {/* Icon Circle */}
            <motion.div 
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ 
                duration: 0.6, 
                delay: 0.2,
                type: "spring",
                stiffness: 200
              }}
              className="w-24 h-24 rounded-3xl bg-gradient-to-br from-[#D4AF37] to-[#B8941C] flex items-center justify-center mb-8 luxury-shadow-gold relative overflow-hidden"
            >
              <div className="absolute inset-0 metallic-shine" />
              <CurrentIcon className="w-12 h-12 text-black relative z-10" />
            </motion.div>

            {/* Title */}
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="text-4xl font-bold text-center text-white mb-4 max-w-sm tracking-tight"
            >
              {slides[step].title}
            </motion.h1>

            {/* Description */}
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="text-lg text-center text-zinc-400 mb-12 max-w-sm leading-relaxed"
            >
              {slides[step].description}
            </motion.p>
          </motion.div>
        </AnimatePresence>

        {/* Progress dots */}
        <div className="flex gap-2 mb-12">
          {slides.map((_, index) => (
            <motion.div
              key={index}
              initial={false}
              animate={{
                width: index === step ? 32 : 6,
                opacity: index === step ? 1 : 0.5
              }}
              transition={{ duration: 0.3 }}
              className={`h-1.5 rounded-full ${
                index === step 
                  ? 'bg-gradient-to-r from-[#D4AF37] to-[#F4D03F]' 
                  : 'bg-zinc-700'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Bottom button */}
      <div className="p-6 relative z-10">
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Button
            onClick={handleNext}
            className="w-full h-14 text-lg font-semibold bg-gradient-to-r from-[#D4AF37] to-[#B8941C] hover:from-[#F4D03F] hover:to-[#D4AF37] text-black luxury-shadow-gold transition-all duration-300"
          >
            {step < slides.length - 1 ? (
              <>
                Continue <ArrowRight className="ml-2 w-5 h-5" />
              </>
            ) : (
              "Get Started"
            )}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}