import { useState } from 'react';
import { ChevronLeft, Filter, MapPin, Calendar, TrendingDown, Flame, AlertCircle, Search, Heart, Lightbulb } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Slider } from './ui/slider';

interface VehiclesScreenProps {
  onBack: () => void;
}

export function VehiclesScreen({ onBack }: VehiclesScreenProps) {
  const [priceRange, setPriceRange] = useState([30000, 42000]);
  const [savedVehicles, setSavedVehicles] = useState<number[]>([]);

  const vehicles = [
    {
      id: 1,
      type: 'owner',
      make: 'Chevrolet',
      model: 'Silverado 1500 Trail Boss',
      year: 2023,
      price: 38500,
      location: 'Atlanta, GA',
      distance: 45,
      daysOnLot: 18,
      mileage: 12500,
      image: '🚙',
      dealership: 'Classic Chevy',
      vin: '1GCUY***********',
      features: ['4WD', 'Crew Cab', 'Z71 Package', 'Tow Package'],
      color: 'Shadow Gray',
      dealScore: 92
    },
    {
      id: 2,
      type: 'owner',
      make: 'Chevrolet',
      model: 'Silverado 1500 Trail Boss',
      year: 2022,
      price: 35900,
      location: 'Macon, GA',
      distance: 78,
      daysOnLot: 25,
      mileage: 18200,
      image: '🚙',
      dealership: 'Macon Auto Mall',
      vin: '1GCUY***********',
      features: ['4WD', 'Crew Cab', 'Z71 Package'],
      color: 'Black',
      dealScore: 88
    },
    {
      id: 3,
      type: 'owner',
      make: 'Chevrolet',
      model: 'Silverado 1500 Trail Boss',
      year: 2024,
      price: 41200,
      location: 'Savannah, GA',
      distance: 125,
      daysOnLot: 14,
      mileage: 8900,
      image: '🚙',
      dealership: 'Coastal Chevrolet',
      vin: '1GCUY***********',
      features: ['4WD', 'Crew Cab', 'Z71 Package', 'Tow Package', 'Leather'],
      color: 'Red Hot',
      dealScore: 95
    },
    {
      id: 4,
      type: 'assistant',
      make: 'Honda',
      model: 'Civic',
      year: 2021,
      price: 18500,
      location: 'Augusta, GA',
      distance: 35,
      daysOnLot: 22,
      mileage: 32000,
      image: '🚗',
      dealership: 'Augusta Auto',
      vin: '2HGFC***********',
      features: ['Sedan', 'Automatic', 'Backup Camera'],
      color: 'Silver',
      dealScore: 85
    },
    {
      id: 5,
      type: 'assistant',
      make: 'Toyota',
      model: 'Corolla',
      year: 2020,
      price: 16900,
      location: 'Waynesboro, GA',
      distance: 18,
      daysOnLot: 31,
      mileage: 42000,
      image: '🚗',
      dealership: 'Local Motors',
      vin: '2T1BU***********',
      features: ['Sedan', 'Automatic', 'Good MPG'],
      color: 'White',
      dealScore: 82
    },
  ];

  const handleSaveVehicle = (id: number) => {
    setSavedVehicles(prev =>
      prev.includes(id) ? prev.filter(v => v !== id) : [...prev, id]
    );
  };

  const calculateMonthlyPayment = (price: number, downPayment: number = 3500, rate: number = 12, months: number = 60) => {
    const principal = price - downPayment;
    const monthlyRate = rate / 100 / 12;
    const payment = (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
    return Math.round(payment);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-600 to-orange-600 text-white p-6 sticky top-0 z-10">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-lg">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">Vehicle Finder</h1>
            <p className="text-sm opacity-90">Find your perfect work vehicles</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Search by make, model, location..."
            className="pl-10 bg-white/90 border-0 h-12"
          />
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-2 text-center">
            <p className="text-2xl font-bold">5</p>
            <p className="text-xs opacity-75">Available</p>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-2 text-center">
            <p className="text-2xl font-bold">{savedVehicles.length}</p>
            <p className="text-xs opacity-75">Saved</p>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-2 text-center">
            <p className="text-2xl font-bold">2</p>
            <p className="text-xs opacity-75">Hot Deals</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="p-4 bg-white border-b">
        <h3 className="font-bold mb-3">Filters</h3>
        
        {/* Vehicle Type */}
        <div className="mb-4">
          <p className="text-sm font-semibold mb-2">Vehicle For:</p>
          <div className="flex gap-2">
            <Badge className="bg-blue-500">All</Badge>
            <Badge variant="outline">Owner (Trail Boss)</Badge>
            <Badge variant="outline">Assistant (Car)</Badge>
          </div>
        </div>

        {/* Price Range */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <p className="text-sm font-semibold">Price Range:</p>
            <p className="text-sm font-bold">${priceRange[0].toLocaleString()} - ${priceRange[1].toLocaleString()}</p>
          </div>
          <Slider
            value={priceRange}
            onValueChange={setPriceRange}
            min={10000}
            max={50000}
            step={1000}
            className="w-full"
          />
        </div>

        {/* Days on Lot */}
        <div>
          <p className="text-sm font-semibold mb-2">Special Filters:</p>
          <div className="flex gap-2">
            <Badge variant="outline" className="text-xs">14+ Days (Better Deals)</Badge>
            <Badge variant="outline" className="text-xs">Within 100 Miles</Badge>
          </div>
        </div>
      </div>

      {/* Financing Calculator */}
      <div className="px-4 pt-4">
        <Card className="p-4 bg-gradient-to-r from-green-50 to-teal-50 border-2 border-green-300">
          <h3 className="font-bold mb-3">Financing Preview</h3>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <p className="text-gray-600">Down Payment:</p>
              <p className="font-bold">$3,500</p>
            </div>
            <div>
              <p className="text-gray-600">Interest Rate:</p>
              <p className="font-bold">10-12% APR</p>
            </div>
            <div>
              <p className="text-gray-600">Term:</p>
              <p className="font-bold">60 months</p>
            </div>
            <div>
              <p className="text-gray-600">Est. Monthly:</p>
              <p className="font-bold text-green-600">$668-$751</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Vehicle Listings */}
      <div className="p-4">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-bold">Available Vehicles ({vehicles.length})</h3>
          <Badge variant="outline" className="text-xs">Sorted by Deal Score</Badge>
        </div>
        
        <div className="space-y-4">
          {vehicles.map((vehicle) => (
            <Card key={vehicle.id} className="overflow-hidden">
              {/* Vehicle Header */}
              <div className={`p-4 ${
                vehicle.type === 'owner'
                  ? 'bg-gradient-to-r from-blue-50 to-cyan-50 border-b-2 border-blue-200'
                  : 'bg-gradient-to-r from-green-50 to-teal-50 border-b-2 border-green-200'
              }`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-start gap-3">
                    <div className="text-4xl">{vehicle.image}</div>
                    <div>
                      <Badge className={vehicle.type === 'owner' ? 'bg-blue-500' : 'bg-green-500'}>
                        For {vehicle.type === 'owner' ? 'Owner' : 'Assistant'}
                      </Badge>
                      <h4 className="font-bold text-lg mt-1">
                        {vehicle.year} {vehicle.make} {vehicle.model}
                      </h4>
                      <p className="text-sm text-gray-600">{vehicle.dealership}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleSaveVehicle(vehicle.id)}
                    className="p-2 hover:bg-white/50 rounded-lg"
                  >
                    <Heart
                      className={`w-6 h-6 ${
                        savedVehicles.includes(vehicle.id)
                          ? 'fill-red-500 text-red-500'
                          : 'text-gray-400'
                      }`}
                    />
                  </button>
                </div>

                {/* Deal Score */}
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-white rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-green-500 h-full"
                      style={{ width: `${vehicle.dealScore}%` }}
                    />
                  </div>
                  <Badge className="bg-green-500">Deal Score: {vehicle.dealScore}</Badge>
                </div>
                {vehicle.daysOnLot >= 14 && (
                  <p className="text-xs text-orange-600 font-semibold mt-1 flex items-center gap-1">
                    <Flame className="w-4 h-4" />
                    {vehicle.daysOnLot} days on lot - Great negotiation opportunity!
                  </p>
                )}
              </div>

              {/* Vehicle Details */}
              <div className="p-4">
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div>
                    <p className="text-xs text-gray-600">Price</p>
                    <p className="text-2xl font-bold text-green-600">${vehicle.price.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-600">Est. Monthly</p>
                    <p className="text-xl font-bold">${calculateMonthlyPayment(vehicle.price)}</p>
                    <p className="text-xs text-gray-500">@ 12% APR</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 mb-3 text-sm">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-400" />
                    <span>{vehicle.mileage.toLocaleString()} miles</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span>{vehicle.distance} miles away</span>
                  </div>
                </div>

                <div className="mb-3">
                  <p className="text-xs text-gray-600 mb-1">Features:</p>
                  <div className="flex flex-wrap gap-1">
                    {vehicle.features.map((feature, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="mb-3 text-xs text-gray-600">
                  <p>Color: {vehicle.color} • VIN: {vehicle.vin}</p>
                  <p className="flex items-center gap-1 mt-1">
                    <MapPin className="w-3 h-3" />
                    {vehicle.location}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" className="w-full">
                    View Details
                  </Button>
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                    Contact Dealer
                  </Button>
                </div>

                {savedVehicles.includes(vehicle.id) && (
                  <p className="text-xs text-green-600 text-center mt-2 font-semibold">
                    ✓ Saved to your list (+80 points)
                  </p>
                )}
              </div>
            </Card>
          ))}
        </div>

        {/* Tips */}
        <Card className="p-4 mt-4 mb-6 bg-yellow-50 border-2 border-yellow-300">
          <h3 className="font-bold mb-2 text-sm flex items-center gap-2">
            <Lightbulb className="w-4 h-4" />
            Vehicle Shopping Tips
          </h3>
          <ul className="text-xs text-gray-700 space-y-1">
            <li>• Look for vehicles on lot 14+ days - dealers more willing to negotiate</li>
            <li>• Trail Boss trucks in $30k-$42k range are perfect for construction work</li>
            <li>• Get pre-approved at credit union before dealer visit</li>
            <li>• Bring down payment of $2k-$5k to improve approval odds</li>
            <li>• Consider slightly used (2-3 years old) for better value</li>
            <li>• Test drive and get independent inspection before buying</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}