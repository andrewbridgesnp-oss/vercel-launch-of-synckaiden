import { ChevronLeft, ChevronRight, CheckCircle, Clock, AlertCircle, FileText, Briefcase, TrendingUp, Building2, Wrench, Upload, CheckCircle2, Lightbulb, Car as CarIcon, BarChart3, FileCheck } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Button } from './ui/button';

interface LoansScreenProps {
  onBack: () => void;
}

export function LoansScreen({ onBack }: LoansScreenProps) {
  const loanTypes = [
    {
      priority: 1,
      title: 'Local GA Credit Unions',
      subtitle: 'Commercial Auto Loans',
      providers: ['Peach State FCU', 'Georgia\'s Own CU', 'Delta Community CU'],
      amount: '$30k-$45k',
      rate: '8-12% APR',
      requirements: ['Business account history', 'Proof of income', '2 years in business'],
      color: 'from-green-600 to-teal-600',
      IconComponent: Building2,
      points: 150
    },
    {
      priority: 2,
      title: 'Equipment Finance',
      subtitle: 'Tools & Machinery',
      providers: ['Become', 'LendingTree Business', 'Balboa Capital'],
      amount: '$10k-$50k',
      rate: '10-18% APR',
      requirements: ['EIN', 'Bank statements (3 months)', 'Equipment quote'],
      color: 'from-blue-600 to-purple-600',
      IconComponent: Wrench,
      points: 125
    },
    {
      priority: 3,
      title: 'Dealer Financing',
      subtitle: 'Last Resort Option',
      providers: ['GM Financial', 'Ally Auto', 'CarMax Auto Finance'],
      amount: '$20k-$40k',
      rate: '15-22% APR',
      requirements: ['Down payment ($2k-5k)', 'Proof of income', 'Trade-in (if available)'],
      color: 'from-orange-600 to-red-600',
      IconComponent: CarIcon,
      points: 100
    },
  ];

  const requiredDocs = [
    { name: 'EIN Letter', status: 'ready', IconComponent: FileText },
    { name: 'Business Bank Statements (3 months)', status: 'ready', IconComponent: Building2 },
    { name: 'Proof of W2 Income', status: 'ready', IconComponent: Briefcase },
    { name: 'Truist Deposit Records', status: 'ready', IconComponent: BarChart3 },
    { name: 'Business License', status: 'pending', IconComponent: FileCheck },
    { name: 'Vehicle Quote/Invoice', status: 'pending', IconComponent: CarIcon },
  ];

  const applicationProgress = [
    { step: 'Gather Documents', completed: true },
    { step: 'Apply to Credit Unions', completed: false },
    { step: 'Equipment Finance Apps', completed: false },
    { step: 'Dealer Finance (if needed)', completed: false },
    { step: 'Accept Best Offer', completed: false },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6 sticky top-0 z-10">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-lg">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">Loan Application Center</h1>
            <p className="text-sm opacity-90">Prioritized application guide</p>
          </div>
        </div>

        {/* Application Progress */}
        <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm">Application Progress</span>
            <span className="font-bold">1 of 5 steps</span>
          </div>
          <Progress value={20} className="h-2 bg-white/30" />
        </div>
      </div>

      {/* Progress Steps */}
      <div className="p-4">
        <Card className="p-4 mb-4">
          <h3 className="font-bold mb-3">Your Journey</h3>
          <div className="space-y-3">
            {applicationProgress.map((item, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  item.completed ? 'bg-green-500' : 'bg-gray-300'
                } text-white font-bold`}>
                  {item.completed ? <CheckCircle2 className="w-5 h-5" /> : index + 1}
                </div>
                <span className={item.completed ? 'text-gray-400 line-through' : 'font-semibold'}>
                  {item.step}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* Required Documents */}
        <Card className="p-4 mb-4 bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200">
          <h3 className="font-bold mb-3 flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Required Documents
          </h3>
          <div className="grid grid-cols-2 gap-2">
            {requiredDocs.map((doc, index) => (
              <div key={index} className={`p-2 rounded-lg border-2 ${
                doc.status === 'ready' ? 'bg-green-50 border-green-300' : 'bg-gray-50 border-gray-300'
              }`}>
                <div className="text-2xl mb-1"><doc.IconComponent className="w-5 h-5" /></div>
                <p className="text-xs font-semibold">{doc.name}</p>
                <Badge className={`text-xs mt-1 ${
                  doc.status === 'ready' ? 'bg-green-500' : 'bg-gray-400'
                }`}>
                  {doc.status === 'ready' ? '✓ Ready' : 'Pending'}
                </Badge>
              </div>
            ))}
          </div>
          <Button className="w-full mt-3 bg-blue-600 hover:bg-blue-700">
            <Upload className="w-4 h-4 mr-2" />
            Upload Documents
          </Button>
        </Card>

        {/* Loan Types */}
        <h3 className="font-bold mb-3">Application Priority Order</h3>
        <div className="space-y-4">
          {loanTypes.map((loan) => (
            <Card key={loan.priority} className="overflow-hidden">
              <div className={`bg-gradient-to-r ${loan.color} p-4 text-white`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center text-2xl">
                      <loan.IconComponent className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Badge className="bg-white/30 text-white">Priority #{loan.priority}</Badge>
                        <Badge className="bg-yellow-500">+{loan.points} pts</Badge>
                      </div>
                      <h4 className="font-bold text-lg">{loan.title}</h4>
                      <p className="text-sm opacity-90">{loan.subtitle}</p>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <div className="bg-white/20 backdrop-blur-sm rounded-lg p-2">
                    <p className="text-xs opacity-75">Loan Amount</p>
                    <p className="font-bold">{loan.amount}</p>
                  </div>
                  <div className="bg-white/20 backdrop-blur-sm rounded-lg p-2">
                    <p className="text-xs opacity-75">Interest Rate</p>
                    <p className="font-bold">{loan.rate}</p>
                  </div>
                </div>
              </div>
              
              <div className="p-4">
                <h5 className="font-semibold text-sm mb-2">Recommended Providers:</h5>
                <div className="flex flex-wrap gap-2 mb-3">
                  {loan.providers.map((provider, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      <Building2 className="w-3 h-3 mr-1" />
                      {provider}
                    </Badge>
                  ))}
                </div>
                
                <h5 className="font-semibold text-sm mb-2">Requirements:</h5>
                <ul className="text-xs text-gray-700 space-y-1 mb-3">
                  {loan.requirements.map((req, index) => (
                    <li key={index}>• {req}</li>
                  ))}
                </ul>

                <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                  Start Application
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {/* Tips */}
        <Card className="p-4 mt-4 bg-yellow-50 border-2 border-yellow-300">
          <h3 className="font-bold mb-2 text-sm flex items-center gap-2">
            <Lightbulb className="w-4 h-4" />
            Application Strategy
          </h3>
          <ul className="text-xs text-gray-700 space-y-1">
            <li>• Start with local credit unions - they have better rates for members</li>
            <li>• Apply to 2-3 credit unions before moving to equipment finance</li>
            <li>• Use dealer financing only as last resort - highest rates</li>
            <li>• Wait 30 days between applications to avoid too many inquiries</li>
            <li>• Highlight your consistent W2 income and business deposits</li>
            <li>• Mention Burke County property as potential collateral</li>
          </ul>
        </Card>

        {/* Financing Calculator Preview */}
        <Card className="p-4 mt-4 bg-gradient-to-r from-green-50 to-teal-50 border-2 border-green-300">
          <h3 className="font-bold mb-3">Payment Calculator</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>Loan Amount:</span>
              <span className="font-semibold">$35,000</span>
            </div>
            <div className="flex justify-between">
              <span>Interest Rate:</span>
              <span className="font-semibold">10% APR</span>
            </div>
            <div className="flex justify-between">
              <span>Term:</span>
              <span className="font-semibold">60 months</span>
            </div>
            <div className="flex justify-between">
              <span>Down Payment:</span>
              <span className="font-semibold">$3,500</span>
            </div>
            <div className="border-t pt-2 flex justify-between">
              <span className="font-bold">Monthly Payment:</span>
              <span className="font-bold text-xl text-green-600">$668</span>
            </div>
          </div>
          <Button variant="outline" className="w-full mt-3">
            Adjust Calculator
          </Button>
        </Card>
      </div>
    </div>
  );
}