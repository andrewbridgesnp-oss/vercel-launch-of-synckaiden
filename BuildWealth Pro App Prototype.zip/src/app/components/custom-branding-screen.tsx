import { useState, useRef, ChangeEvent } from 'react';
import { ChevronLeft, Upload, Palette, Eye, Check, AlertCircle, Loader2, Trash2 } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CUSTOMIZATION_LIMITS, tierAllowsFeature } from '../../config/app-mode';

interface CustomBrandingScreenProps {
  onBack: () => void;
  currentBranding?: {
    logoUrl: string | null;
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    businessName: string;
    appName: string;
    customGoalTitle: string;
  };
  subscriptionTier: 'basic' | 'pro' | 'premium';
  onSave: (branding: {
    logoUrl: string | null;
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    businessName: string;
    appName: string;
    customGoalTitle: string;
  }) => Promise<void>;
}

export function CustomBrandingScreen({ 
  onBack, 
  currentBranding,
  subscriptionTier,
  onSave 
}: CustomBrandingScreenProps) {
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(currentBranding?.logoUrl || null);
  const [primaryColor, setPrimaryColor] = useState(currentBranding?.primaryColor || '#1e3a8a');
  const [secondaryColor, setSecondaryColor] = useState(currentBranding?.secondaryColor || '#c0c0c0');
  const [accentColor, setAccentColor] = useState(currentBranding?.accentColor || '#ffd700');
  const [businessName, setBusinessName] = useState(currentBranding?.businessName || '');
  const [appName, setAppName] = useState(currentBranding?.appName || 'My App');
  const [customGoalTitle, setCustomGoalTitle] = useState(currentBranding?.customGoalTitle || 'Build Wealth in 120 Days');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const canUploadLogo = tierAllowsFeature(subscriptionTier, 'allowLogoUpload');
  const canCustomizeColors = tierAllowsFeature(subscriptionTier, 'allowColorCustomization');
  const canCustomizeGoal = tierAllowsFeature(subscriptionTier, 'allowGoalCustomization');

  const handleLogoSelect = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadError(null);

    // Validate file type
    if (!CUSTOMIZATION_LIMITS.allowedLogoTypes.includes(file.type)) {
      setUploadError('Please upload a PNG, JPG, or SVG file');
      return;
    }

    // Validate file size
    const fileSizeMB = file.size / (1024 * 1024);
    if (fileSizeMB > CUSTOMIZATION_LIMITS.maxLogoSizeMB) {
      setUploadError(`Logo must be under ${CUSTOMIZATION_LIMITS.maxLogoSizeMB}MB`);
      return;
    }

    // Validate dimensions
    const img = new Image();
    img.onload = () => {
      if (
        img.width < CUSTOMIZATION_LIMITS.minLogoWidth ||
        img.width > CUSTOMIZATION_LIMITS.maxLogoWidth ||
        img.height < CUSTOMIZATION_LIMITS.minLogoHeight ||
        img.height > CUSTOMIZATION_LIMITS.maxLogoHeight
      ) {
        setUploadError(
          `Logo dimensions must be between ${CUSTOMIZATION_LIMITS.minLogoWidth}x${CUSTOMIZATION_LIMITS.minLogoHeight} and ${CUSTOMIZATION_LIMITS.maxLogoWidth}x${CUSTOMIZATION_LIMITS.maxLogoHeight} pixels`
        );
        setLogoFile(null);
        setLogoPreview(null);
        return;
      }

      setLogoFile(file);
      setLogoPreview(URL.createObjectURL(file));
    };

    img.src = URL.createObjectURL(file);
  };

  const handleRemoveLogo = () => {
    setLogoFile(null);
    setLogoPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveSuccess(false);
    
    try {
      // In a real implementation, you would upload the logo file to Supabase storage here
      // and get back a public URL. For now, we'll use the preview URL.
      
      await onSave({
        logoUrl: logoPreview,
        primaryColor,
        secondaryColor,
        accentColor,
        businessName,
        appName,
        customGoalTitle,
      });

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      setUploadError('Failed to save branding. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const presetColors = [
    { name: 'Navy Blue', primary: '#1e3a8a', secondary: '#c0c0c0', accent: '#ffd700' },
    { name: 'Forest Green', primary: '#065f46', secondary: '#d1d5db', accent: '#fbbf24' },
    { name: 'Deep Purple', primary: '#5b21b6', secondary: '#e5e7eb', accent: '#f472b6' },
    { name: 'Midnight Black', primary: '#18181b', secondary: '#a1a1aa', accent: '#ef4444' },
    { name: 'Royal Blue', primary: '#1e40af', secondary: '#cbd5e1', accent: '#fbbf24' },
  ];

  return (
    <div className="min-h-screen bg-black pb-20">
      {/* Header */}
      <div className="bg-zinc-900 px-6 py-4 border-b border-zinc-800 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 hover:bg-zinc-800 rounded-lg -ml-2">
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-white">Custom Branding</h1>
            <p className="text-sm text-zinc-400">Customize your app experience</p>
          </div>
          <Badge className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 text-yellow-500 border-yellow-500/20">
            {subscriptionTier.toUpperCase()}
          </Badge>
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Save Success Message */}
        {saveSuccess && (
          <Card className="p-4 bg-green-500/10 border border-green-500/30">
            <div className="flex items-center gap-3 text-green-500">
              <Check className="w-5 h-5" />
              <p className="text-sm font-medium">Branding saved successfully!</p>
            </div>
          </Card>
        )}

        {/* Logo Upload */}
        <Card className="p-6 bg-zinc-900 border border-zinc-800">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold text-white mb-1">Company Logo</h3>
              <p className="text-sm text-zinc-400">Upload your logo to personalize the app</p>
            </div>
            {!canUploadLogo && (
              <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                Pro Feature
              </Badge>
            )}
          </div>

          {!canUploadLogo ? (
            <div className="p-6 bg-zinc-800/50 border border-zinc-700 rounded-lg text-center">
              <Upload className="w-12 h-12 text-zinc-600 mx-auto mb-3" />
              <p className="text-zinc-400 text-sm mb-4">
                Upgrade to Pro or Premium to upload your custom logo
              </p>
              <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                Upgrade Now
              </Button>
            </div>
          ) : (
            <>
              {logoPreview ? (
                <div className="space-y-4">
                  <div className="relative w-full h-48 bg-zinc-800 rounded-lg border-2 border-zinc-700 flex items-center justify-center overflow-hidden">
                    <img 
                      src={logoPreview} 
                      alt="Logo preview" 
                      className="max-w-full max-h-full object-contain p-4"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      variant="outline"
                      className="flex-1 bg-zinc-800 hover:bg-zinc-700 border-zinc-700"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Change Logo
                    </Button>
                    <Button
                      onClick={handleRemoveLogo}
                      variant="outline"
                      className="bg-red-500/10 hover:bg-red-500/20 border-red-500/30 text-red-500"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Remove
                    </Button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full p-8 border-2 border-dashed border-zinc-700 rounded-lg hover:border-zinc-600 transition-colors"
                >
                  <Upload className="w-12 h-12 text-zinc-500 mx-auto mb-3" />
                  <p className="text-white font-medium mb-1">Click to upload logo</p>
                  <p className="text-xs text-zinc-500">
                    PNG, JPG or SVG • Max {CUSTOMIZATION_LIMITS.maxLogoSizeMB}MB • Min {CUSTOMIZATION_LIMITS.minLogoWidth}x{CUSTOMIZATION_LIMITS.minLogoHeight}px
                  </p>
                </button>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept={CUSTOMIZATION_LIMITS.allowedLogoTypes.join(',')}
                onChange={handleLogoSelect}
                className="hidden"
              />

              {uploadError && (
                <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg mt-4">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-400">{uploadError}</p>
                </div>
              )}
            </>
          )}
        </Card>

        {/* Color Customization */}
        <Card className="p-6 bg-zinc-900 border border-zinc-800">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold text-white mb-1 flex items-center gap-2">
                <Palette className="w-5 h-5 text-blue-500" />
                Brand Colors
              </h3>
              <p className="text-sm text-zinc-400">Customize your color scheme</p>
            </div>
            {!canCustomizeColors && (
              <Badge className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                Pro Feature
              </Badge>
            )}
          </div>

          {!canCustomizeColors ? (
            <div className="p-6 bg-zinc-800/50 border border-zinc-700 rounded-lg text-center">
              <Palette className="w-12 h-12 text-zinc-600 mx-auto mb-3" />
              <p className="text-zinc-400 text-sm mb-4">
                Upgrade to Pro or Premium to customize your colors
              </p>
              <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                Upgrade Now
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Color Pickers */}
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-zinc-400 mb-2 block">Primary Color</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={primaryColor}
                      onChange={(e) => setPrimaryColor(e.target.value)}
                      className="w-16 h-16 rounded-lg border-2 border-zinc-700 cursor-pointer"
                    />
                    <div className="flex-1">
                      <p className="text-white font-mono text-sm mb-1">{primaryColor}</p>
                      <p className="text-xs text-zinc-500">Main backgrounds and headers</p>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-sm text-zinc-400 mb-2 block">Secondary Color</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={secondaryColor}
                      onChange={(e) => setSecondaryColor(e.target.value)}
                      className="w-16 h-16 rounded-lg border-2 border-zinc-700 cursor-pointer"
                    />
                    <div className="flex-1">
                      <p className="text-white font-mono text-sm mb-1">{secondaryColor}</p>
                      <p className="text-xs text-zinc-500">Text and secondary elements</p>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-sm text-zinc-400 mb-2 block">Accent Color</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={accentColor}
                      onChange={(e) => setAccentColor(e.target.value)}
                      className="w-16 h-16 rounded-lg border-2 border-zinc-700 cursor-pointer"
                    />
                    <div className="flex-1">
                      <p className="text-white font-mono text-sm mb-1">{accentColor}</p>
                      <p className="text-xs text-zinc-500">Buttons and highlights</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Preset Colors */}
              <div>
                <p className="text-sm text-zinc-400 mb-3">Quick Presets</p>
                <div className="grid grid-cols-2 gap-2">
                  {presetColors.map((preset) => (
                    <button
                      key={preset.name}
                      onClick={() => {
                        setPrimaryColor(preset.primary);
                        setSecondaryColor(preset.secondary);
                        setAccentColor(preset.accent);
                      }}
                      className="p-3 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-lg transition-colors text-left"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-4 h-4 rounded" style={{ backgroundColor: preset.primary }} />
                        <div className="w-4 h-4 rounded" style={{ backgroundColor: preset.secondary }} />
                        <div className="w-4 h-4 rounded" style={{ backgroundColor: preset.accent }} />
                      </div>
                      <p className="text-xs text-white">{preset.name}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </Card>

        {/* Business Info */}
        <Card className="p-6 bg-zinc-900 border border-zinc-800">
          <h3 className="text-lg font-bold text-white mb-4">Business Information</h3>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm text-zinc-400 mb-2 block">Business Name</label>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="Your Business LLC"
                className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-white placeholder:text-zinc-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-sm text-zinc-400 mb-2 block">App Name</label>
              <input
                type="text"
                value={appName}
                onChange={(e) => setAppName(e.target.value)}
                placeholder="My App"
                className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-white placeholder:text-zinc-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-sm text-zinc-400 mb-2 block">
                Custom Goal Title
                {!canCustomizeGoal && (
                  <Badge className="ml-2 bg-yellow-500/10 text-yellow-500 border-yellow-500/20 text-xs">
                    Pro Feature
                  </Badge>
                )}
              </label>
              <input
                type="text"
                value={customGoalTitle}
                onChange={(e) => setCustomGoalTitle(e.target.value)}
                placeholder="Build Wealth in 120 Days"
                disabled={!canCustomizeGoal}
                className="w-full px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-lg text-white placeholder:text-zinc-500 focus:outline-none focus:border-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>
          </div>
        </Card>

        {/* Preview */}
        <Card className="p-6 bg-zinc-900 border border-zinc-800">
          <div className="flex items-center gap-2 mb-4">
            <Eye className="w-5 h-5 text-blue-500" />
            <h3 className="text-lg font-bold text-white">Preview</h3>
          </div>

          <div 
            className="p-6 rounded-lg border-2 border-zinc-700"
            style={{ backgroundColor: primaryColor }}
          >
            {logoPreview && (
              <img 
                src={logoPreview} 
                alt="Logo" 
                className="h-12 mb-4 object-contain"
              />
            )}
            <h2 className="text-2xl font-bold mb-2" style={{ color: secondaryColor }}>
              {businessName || 'Your Business Name'}
            </h2>
            <p className="text-sm mb-4" style={{ color: secondaryColor, opacity: 0.8 }}>
              {customGoalTitle}
            </p>
            <button 
              className="px-6 py-2 rounded-lg font-medium"
              style={{ backgroundColor: accentColor, color: '#000' }}
            >
              Sample Button
            </button>
          </div>
        </Card>

        {/* Save Button */}
        <Button
          onClick={handleSave}
          disabled={isSaving}
          className="w-full h-14 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-lg font-semibold"
        >
          {isSaving ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Check className="w-5 h-5 mr-2" />
              Save Branding
            </>
          )}
        </Button>
      </div>
    </div>
  );
}