import { TrendingUp, ChevronRight, AlertCircle, DollarSign, Building2, Car, Lock, Crown, Zap, Star } from 'lucide-react';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { RealisticLogo } from './realistic-logo';
import { motion } from 'motion/react';

interface DashboardProps {
  user: {
    name: string;
    points: number;
    level: string;
    streak: number;
    personalCredit: number;
    businessCredit: number;
  };
  onNavigate: (screen: 'dashboard' | 'credit' | 'vehicles' | 'settings') => void;
}

export function Dashboard({ user, onNavigate }: DashboardProps) {
  const liveOffers = [
    {
      type: 'Credit Card',
      provider: 'Chase Ink Business Cash',
      apr: '0% intro APR for 12 months',
      bonus: '$750 cash back',
      requirement: '680+ FICO',
      available: user.personalCredit >= 640,
      image: 'https://images.unsplash.com/photo-1585915473635-d4e5c564eec3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGNyZWRpdCUyMGNhcmR8ZW58MXx8fHwxNzY3OTAwMzQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      type: 'Commercial Loan',
      provider: 'Peach State FCU',
      amount: 'Up to $45,000',
      apr: '8.9% APR',
      requirement: '620+ FICO',
      available: true,
      image: 'https://images.unsplash.com/photo-1732905081659-3a946135b7d0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBsb2FuJTIwbW9uZXl8ZW58MXx8fHwxNzY4MDE1NzI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      type: 'Equipment Finance',
      provider: 'Become',
      amount: '$10,000 - $50,000',
      apr: '12.5% APR',
      requirement: '3 months bank statements',
      available: true,
      image: 'https://images.unsplash.com/photo-1728362369426-1647a7fd09d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBlcXVpcG1lbnQlMjB0b29sc3xlbnwxfHx8fDE3Njc5NjEzMzF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    }
  ];

  const businessCreditPlatforms = [
    { name: 'Dun & Bradstreet', status: 'Not Started', daysUntil: 21, score: null },
    { name: 'NAV', status: 'Locked', daysUntil: 29, score: null },
    { name: 'NAV Prime', status: 'Locked', daysUntil: 67, score: null },
    { name: 'BlueVine', status: 'Locked', daysUntil: 59, score: null },
  ];

  const criticalMilestones = [
    { day: 22, title: 'Apply for DUNS Number', status: 'upcoming', impact: 'Unlocks business credit tracking' },
    { day: 30, title: 'Register with NAV', status: 'upcoming', impact: 'Begin business credit monitoring' },
    { day: 60, title: 'Credit Card Stacking Day', status: 'upcoming', impact: 'Apply for 3-5 business cards' },
    { day: 90, title: 'NAV Prime Eligible', status: 'upcoming', impact: 'Premium business credit tools' },
  ];

  return (
    <div className="pb-20 bg-gradient-to-b from-black via-zinc-950 to-black min-h-screen">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="bg-gradient-to-b from-zinc-900/50 to-black/50 px-6 pt-6 pb-8 border-b border-zinc-800/50 backdrop-blur-xl"
      >
        <div className="flex justify-between items-start mb-6">
          <div>
            <p className="text-sm text-zinc-400 mb-1 flex items-center gap-2">
              Welcome back,
              <motion.span
                animate={{ rotate: [0, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Crown className="w-4 h-4 text-[#D4AF37]" />
              </motion.span>
            </p>
            <h1 className="text-4xl font-bold text-white tracking-tight luxury-text-gradient">{user.name}</h1>
          </div>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#D4AF37] to-[#B8941C] flex items-center justify-center luxury-shadow-gold metallic-shine relative overflow-hidden"
          >
            <span className="text-black font-bold text-xl">M</span>
          </motion.button>
        </div>

        {/* Credit Score - Luxury Card */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="luxury-card rounded-3xl p-6 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-[#D4AF37]/10 to-transparent rounded-full blur-3xl" />
          
          <div className="flex items-center justify-between mb-4 relative z-10">
            <div>
              <p className="text-sm text-zinc-400 mb-2 flex items-center gap-2">
                Personal Credit Score
                <Star className="w-4 h-4 text-[#D4AF37] animate-gold-shine" />
              </p>
              <div className="flex items-baseline gap-3">
                <motion.span 
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                  className="text-7xl font-bold bg-gradient-to-br from-white via-zinc-100 to-zinc-300 bg-clip-text text-transparent"
                >
                  {user.personalCredit}
                </motion.span>
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.6 }}
                  className="flex items-center gap-1 px-3 py-1 rounded-full bg-green-500/20 border border-green-500/30"
                >
                  <TrendingUp className="w-5 h-5 text-green-400" />
                  <span className="text-xl font-semibold text-green-400">+12</span>
                </motion.div>
              </div>
              <p className="text-sm text-zinc-500 mt-2">Fair • Updated Jan 8, 2026</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 pt-6 border-t border-zinc-800/50 relative z-10">
            <div>
              <p className="text-xs text-zinc-500 mb-1 uppercase tracking-wider">Target Score</p>
              <p className="text-3xl font-bold bg-gradient-to-r from-red-500 to-red-600 bg-clip-text text-transparent">680</p>
              <p className="text-xs text-zinc-400 mt-1">60 points to go</p>
            </div>
            <div>
              <p className="text-xs text-zinc-500 mb-1 uppercase tracking-wider">Est. Timeline</p>
              <p className="text-3xl font-bold text-white">90</p>
              <p className="text-xs text-zinc-400 mt-1">days with plan</p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      {/* Business Credit Platforms */}
      <div className="px-6 py-6 border-b border-zinc-900/50">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Building2 className="w-6 h-6 text-[#D4AF37]" />
            Business Credit Stack
          </h2>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('credit')}
            className="text-sm text-[#D4AF37] font-semibold flex items-center gap-1 hover:text-[#F4D03F] transition-colors"
          >
            View All
            <ChevronRight className="w-4 h-4" />
          </motion.button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {businessCreditPlatforms.map((platform, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              whileHover={{ scale: 1.02, y: -2 }}
            >
              <Card 
                className={`p-4 border transition-all duration-300 ${
                  platform.status === 'Not Started' 
                    ? 'glass-effect border-[#D4AF37]/20 hover:border-[#D4AF37]/40' 
                    : 'bg-zinc-950/50 border-zinc-800 opacity-60'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-bold text-white text-sm mb-1">{platform.name}</h3>
                    {platform.score ? (
                      <p className="text-2xl font-bold bg-gradient-to-r from-red-500 to-red-600 bg-clip-text text-transparent">{platform.score}</p>
                    ) : (
                      <p className="text-xs text-zinc-500">{platform.status}</p>
                    )}
                  </div>
                  {platform.status === 'Locked' && (
                    <Lock className="w-4 h-4 text-zinc-600" />
                  )}
                </div>
                {platform.status !== 'Active' && (
                  <p className="text-xs text-zinc-600">Available in {platform.daysUntil} days</p>
                )}
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Live Credit Offers */}
      <div className="px-6 py-6 border-b border-zinc-900/50">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Zap className="w-6 h-6 text-[#D4AF37] animate-gold-shine" />
            Pre-Qualified Offers
          </h2>
          <Badge className="bg-green-500/10 text-green-400 border-green-500/20 px-3 py-1">
            {liveOffers.filter(o => o.available).length} Available
          </Badge>
        </div>

        <div className="space-y-3">
          {liveOffers.map((offer, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
            >
              <Card 
                className={`p-4 border transition-all duration-300 ${
                  offer.available 
                    ? 'luxury-card hover:border-[#D4AF37]/30 cursor-pointer' 
                    : 'bg-zinc-950/50 border-zinc-800 opacity-50'
                }`}
                onClick={() => offer.available && onNavigate('credit')}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-xs text-zinc-500 uppercase tracking-wider">{offer.type}</p>
                      {offer.available && (
                        <Badge className="bg-green-500/20 text-green-400 text-xs border-green-500/30 animate-pulse">
                          Approved
                        </Badge>
                      )}
                    </div>
                    <h3 className="font-bold text-white mb-1">{offer.provider}</h3>
                    <p className="text-sm text-zinc-400">{offer.amount || offer.apr}</p>
                    {offer.bonus && (
                      <p className="text-sm bg-gradient-to-r from-[#D4AF37] to-[#F4D03F] bg-clip-text text-transparent font-semibold mt-1">{offer.bonus}</p>
                    )}
                  </div>
                  <ChevronRight className="w-5 h-5 text-zinc-600" />
                </div>
                <div className="pt-3 border-t border-zinc-800/50">
                  <p className="text-xs text-zinc-600">Requires: {offer.requirement}</p>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Featured Vehicle */}
      <div className="px-6 py-6 border-b border-zinc-900/50">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Car className="w-6 h-6 text-[#D4AF37]" />
            Featured Vehicle
          </h2>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('vehicles')}
            className="text-sm text-[#D4AF37] font-semibold flex items-center gap-1 hover:text-[#F4D03F] transition-colors"
          >
            View Inventory
            <ChevronRight className="w-4 h-4" />
          </motion.button>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          whileHover={{ y: -4 }}
        >
          <Card className="luxury-card overflow-hidden cursor-pointer hover:border-[#D4AF37]/30 transition-all duration-300"
                onClick={() => onNavigate('vehicles')}>
            <div className="aspect-video bg-gradient-to-br from-zinc-800 via-zinc-900 to-black flex items-center justify-center border-b border-zinc-800/50 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#D4AF37]/5 to-transparent" />
              <div className="text-center relative z-10">
                <Car className="w-16 h-16 text-zinc-700 mx-auto mb-2" />
                <p className="text-xs text-zinc-600">2023 Chevrolet Silverado Trail Boss</p>
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-bold text-white text-lg mb-1">2023 Silverado Trail Boss</h3>
                  <p className="text-sm text-zinc-400">Classic Chevy • Atlanta, GA (45 mi)</p>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold bg-gradient-to-r from-red-500 to-red-600 bg-clip-text text-transparent">$38,500</p>
                  <p className="text-xs text-zinc-500">21 days on lot</p>
                </div>
              </div>
            
              <div className="grid grid-cols-3 gap-2 mb-3 text-xs">
                <div className="glass-effect rounded-lg p-2 text-center">
                  <p className="text-zinc-500">Mileage</p>
                  <p className="text-white font-semibold">12,500</p>
                </div>
                <div className="glass-effect rounded-lg p-2 text-center">
                  <p className="text-zinc-500">Est. Payment</p>
                  <p className="text-white font-semibold">$668/mo</p>
                </div>
                <div className="glass-effect rounded-lg p-2 text-center">
                  <p className="text-zinc-500">APR</p>
                  <p className="text-white font-semibold">10.5%</p>
                </div>
              </div>

              <div className="flex gap-2">
                <Badge className="bg-green-500/10 text-green-400 text-xs border-green-500/20">
                  4WD • Crew Cab • Z71
                </Badge>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Critical Milestones */}
      <div className="px-6 py-6">
        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Star className="w-6 h-6 text-[#D4AF37] animate-gold-shine" />
          120-Day Milestones
        </h2>

        <div className="space-y-3">
          {criticalMilestones.slice(0, 3).map((milestone, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              whileHover={{ scale: 1.02, x: 4 }}
            >
              <Card className="p-4 glass-effect border-zinc-800/50 hover:border-[#D4AF37]/20 transition-all duration-300">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <motion.div 
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                      className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#D4AF37]/20 to-red-950/50 border border-[#D4AF37]/30 flex items-center justify-center luxury-shadow"
                    >
                      <span className="text-[#D4AF37] font-bold text-lg">{milestone.day}</span>
                    </motion.div>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-white mb-1">{milestone.title}</h3>
                    <p className="text-sm text-zinc-400 mb-2">{milestone.impact}</p>
                    <Badge className="bg-zinc-800/50 text-zinc-400 text-xs border-zinc-700/50">
                      Day {milestone.day} • {milestone.day - 1} days remaining
                    </Badge>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="px-6 pb-6">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="luxury-card rounded-3xl p-6 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-br from-red-500/10 to-transparent rounded-full blur-3xl" />
          
          <h3 className="text-white font-bold mb-4 relative z-10 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-[#D4AF37]" />
            This Week's Activity
          </h3>
          <div className="grid grid-cols-3 gap-4 relative z-10">
            <div>
              <p className="text-xs text-zinc-400 mb-1 uppercase tracking-wider">Deposits</p>
              <p className="text-3xl font-bold text-white">$4,400</p>
            </div>
            <div>
              <p className="text-xs text-zinc-400 mb-1 uppercase tracking-wider">Mileage</p>
              <p className="text-3xl font-bold text-white">187</p>
              <p className="text-xs text-zinc-500">miles logged</p>
            </div>
            <div>
              <p className="text-xs text-zinc-400 mb-1 uppercase tracking-wider">Tax Savings</p>
              <p className="text-3xl font-bold text-green-400">$114</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}