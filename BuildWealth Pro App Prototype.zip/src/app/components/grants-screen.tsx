import { ChevronLeft, Search, Filter, DollarSign, TrendingUp, Calendar, Trophy, FileText, Send, Lightbulb } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface GrantsScreenProps {
  onBack: () => void;
}

export function GrantsScreen({ onBack }: GrantsScreenProps) {
  const grants = [
    {
      name: 'NAACP Powershift Fund',
      amount: 'Up to $25,000',
      deadline: 'Rolling',
      difficulty: 'Medium',
      match: 95,
      for: 'Both',
      description: 'Supporting Black-owned businesses in construction and trades',
      requirements: ['Black-owned business', 'Detailed business plan', 'Financial statements'],
      color: 'from-purple-600 to-pink-600',
      icon: '💜',
      points: 200
    },
    {
      name: 'Coalition Grant',
      amount: '$5,000',
      deadline: 'Quarterly',
      difficulty: 'Easy',
      match: 90,
      for: 'Both',
      description: 'Small business grants for minority entrepreneurs',
      requirements: ['Business registration', 'Simple proposal', 'Proof of need'],
      color: 'from-blue-600 to-cyan-600',
      icon: '💙',
      points: 150
    },
    {
      name: 'Wish Grant',
      amount: '$500 - $2,000',
      deadline: 'Monthly',
      difficulty: 'Easy',
      match: 88,
      for: 'Both',
      description: 'Micro-grants for business supplies and equipment',
      requirements: ['Business license', 'Quote for purchases', 'Brief essay'],
      color: 'from-green-600 to-teal-600',
      icon: '💚',
      points: 100
    },
    {
      name: 'Freed Grant',
      amount: '$500/month',
      deadline: 'Ongoing',
      difficulty: 'Medium',
      match: 85,
      for: 'Both',
      description: 'Monthly stipends for Black entrepreneurs',
      requirements: ['Detailed application', 'Video pitch', 'Business plan'],
      color: 'from-yellow-600 to-orange-600',
      icon: '💛',
      points: 175
    },
    {
      name: 'MBDA Business Center',
      amount: 'Up to $50,000',
      deadline: 'Annual',
      difficulty: 'Hard',
      match: 80,
      for: 'Owner',
      description: 'Minority Business Development Agency funding',
      requirements: ['Comprehensive business plan', 'Financial projections', 'Market analysis'],
      color: 'from-red-600 to-pink-600',
      icon: '❤️',
      points: 250
    },
    {
      name: 'SBA 8(a) Program',
      amount: 'Up to $4,000,000',
      deadline: 'Rolling',
      difficulty: 'Hard',
      match: 75,
      for: 'Owner',
      description: 'Small Business Administration certification and contracts',
      requirements: ['3 years tax returns', 'Detailed documentation', 'Certification process'],
      color: 'from-indigo-600 to-purple-600',
      icon: '💙',
      points: 300
    },
  ];

  const applicationStatus = [
    { grant: 'Coalition Grant', status: 'In Progress', progress: 60 },
    { grant: 'Wish Grant', status: 'Drafting', progress: 30 },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-yellow-600 to-orange-600 text-white p-6 sticky top-0 z-10">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-lg">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">Grant Finder</h1>
            <p className="text-sm opacity-90">Minority-owned business grants</p>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Search grants by keyword..."
            className="pl-10 bg-white/90 border-0 h-12"
          />
        </div>
      </div>

      {/* Active Applications */}
      {applicationStatus.length > 0 && (
        <div className="p-4">
          <h3 className="font-bold mb-3">Your Applications</h3>
          <div className="space-y-3">
            {applicationStatus.map((app, index) => (
              <Card key={index} className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-semibold">{app.grant}</h4>
                  <Badge className="bg-blue-500">{app.status}</Badge>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-white rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-blue-600 h-full"
                      style={{ width: `${app.progress}%` }}
                    />
                  </div>
                  <span className="text-sm font-semibold">{app.progress}%</span>
                </div>
                <Button variant="outline" className="w-full mt-3" size="sm">
                  Continue Application
                </Button>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* AI Assistant Banner */}
      <div className="px-4 mb-4">
        <Card className="p-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <div className="flex items-start gap-3">
            <TrendingUp className="w-6 h-6 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-bold mb-1">AI Proposal Assistant</h3>
              <p className="text-sm opacity-90 mb-3">
                Let AI help you draft winning grant proposals based on your business details
              </p>
              <Badge className="bg-white text-purple-600">Premium Feature - $19.99/mo</Badge>
            </div>
          </div>
        </Card>
      </div>

      {/* Filter Chips */}
      <div className="px-4 mb-4">
        <div className="flex gap-2 overflow-x-auto pb-2">
          <Badge className="bg-blue-500 whitespace-nowrap">All Grants</Badge>
          <Badge variant="outline" className="whitespace-nowrap">For Owner</Badge>
          <Badge variant="outline" className="whitespace-nowrap">For Assistant</Badge>
          <Badge variant="outline" className="whitespace-nowrap">Easy</Badge>
          <Badge variant="outline" className="whitespace-nowrap">High Match</Badge>
        </div>
      </div>

      {/* Available Grants */}
      <div className="px-4">
        <h3 className="font-bold mb-3">Available Grants ({grants.length})</h3>
        <div className="space-y-4">
          {grants.map((grant, index) => (
            <Card key={index} className="overflow-hidden">
              <div className={`bg-gradient-to-r ${grant.color} p-4 text-white`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center text-2xl">
                      {grant.icon}
                    </div>
                    <div>
                      <h4 className="font-bold text-lg mb-1">{grant.name}</h4>
                      <div className="flex gap-2 flex-wrap">
                        <Badge className="bg-white/30 text-white text-xs">{grant.for}</Badge>
                        <Badge className="bg-white/30 text-white text-xs">{grant.difficulty}</Badge>
                        <Badge className="bg-green-500 text-xs">+{grant.points} pts</Badge>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white/20 backdrop-blur-sm rounded-lg p-3 mt-3">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm">Grant Amount</span>
                    <span className="text-xl font-bold">{grant.amount}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Match Score</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 bg-white/30 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-white h-full"
                          style={{ width: `${grant.match}%` }}
                        />
                      </div>
                      <span className="font-bold">{grant.match}%</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4">
                <p className="text-sm text-gray-700 mb-3">{grant.description}</p>
                
                <div className="mb-3">
                  <h5 className="font-semibold text-sm mb-2">Deadline: {grant.deadline}</h5>
                </div>

                <h5 className="font-semibold text-sm mb-2">Requirements:</h5>
                <ul className="text-xs text-gray-700 space-y-1 mb-4">
                  {grant.requirements.map((req, idx) => (
                    <li key={idx}>• {req}</li>
                  ))}
                </ul>

                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" className="w-full">
                    <FileText className="w-4 h-4 mr-2" />
                    View Details
                  </Button>
                  <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                    <Send className="w-4 h-4 mr-2" />
                    Apply Now
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Tips */}
        <Card className="p-4 mt-4 mb-6 bg-green-50 border-2 border-green-300">
          <h3 className="font-bold mb-2 text-sm flex items-center gap-2">
            <Lightbulb className="w-4 h-4" />
            Grant Application Tips
          </h3>
          <ul className="text-xs text-gray-700 space-y-1">
            <li>• Start with easy grants (Coalition, Wish) to build confidence</li>
            <li>• Apply to multiple grants - don't put all eggs in one basket</li>
            <li>• Tailor each proposal to the specific grant's mission</li>
            <li>• Highlight your minority-owned status and community impact</li>
            <li>• Include specific uses for funds (vehicles, equipment, etc.)</li>
            <li>• Follow up after submission - shows commitment</li>
            <li>• Both owner and assistant can apply to separate grants</li>
          </ul>
        </Card>

        {/* Challenge */}
        <Card className="p-4 mb-6 bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-300">
          <h3 className="font-bold mb-2 text-sm flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-600" />
            Weekly Challenge: Grant Guru
          </h3>
          <p className="text-xs text-gray-700 mb-2">
            Submit 3 grant applications this week
          </p>
          <div className="flex items-center gap-2 mb-2">
            <div className="flex-1 bg-white rounded-full h-2 overflow-hidden">
              <div className="bg-yellow-500 h-full" style={{ width: '33%' }} />
            </div>
            <span className="text-sm font-semibold">1/3</span>
          </div>
          <Badge className="bg-yellow-500">Reward: +500 points + "Grant Guru" badge</Badge>
        </Card>
      </div>
    </div>
  );
}