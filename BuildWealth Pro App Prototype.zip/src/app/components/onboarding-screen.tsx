import { useState } from 'react';
import { Target, TrendingUp, Users, Zap, ArrowRight, Shield, CreditCard, Briefcase, Trophy, Check, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { motion, AnimatePresence } from 'motion/react';
import { COX_AND_CO_BRANDING, isWhiteLabelMode } from '../../config/app-mode';

interface OnboardingScreenProps {
  onComplete: () => void;
}

export function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const appName = "Kaiden's Wealth Builder Pro";
  
  const slides = [
    {
      icon: Target,
      title: `Welcome to ${appName}`,
      subtitle: 'Your 120-Day Business Transformation',
      description: 'Transform your construction business with a comprehensive plan to repair credit, secure funding, and scale operations.',
      color: 'from-blue-950 to-blue-900',
      features: [
        'Personal & business credit repair',
        'Daily actionable tasks',
        'Grant & loan applications',
        'Business operations tracking'
      ]
    },
    {
      icon: CreditCard,
      title: 'Credit Building Strategy',
      subtitle: 'Stack Cards & Build Business Credit',
      description: 'Access real credit card offers, business credit platforms (D&B, NAV, BlueVine), and proven credit stacking strategies.',
      color: 'from-slate-700 to-slate-800',
      features: [
        'Credit stacking guides',
        'D&B, NAV, NAV Prime integration',
        'Real-time credit offers',
        'Professional dispute letters'
      ]
    },
    {
      icon: Briefcase,
      title: 'Business Operations',
      subtitle: 'Manage Your Construction Business',
      description: 'Track time, mileage, receipts, and expenses. Build your professional brand with logos, business cards, and marketing materials.',
      color: 'from-blue-900 to-slate-800',
      features: [
        'Time clock & mileage tracking',
        'Receipt scanning & storage',
        'Professional branding suite',
        'Digital wallet for cards'
      ]
    },
    {
      icon: Trophy,
      title: 'Gamification & Progress',
      subtitle: 'Stay Motivated with Rewards',
      description: 'Earn points, unlock badges, maintain streaks, and level up as you complete your daily tasks and hit milestones.',
      color: 'from-slate-600 to-blue-900',
      features: [
        'Points & achievement system',
        'Daily streak tracking',
        'Level progression',
        'Milestone celebrations'
      ]
    },
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      onComplete();
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  const slide = slides[currentSlide];
  const IconComponent = slide.icon;

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Header with Skip Button */}
      <div className="px-6 py-4 flex justify-between items-center">
        <div className="flex gap-2">
          {slides.map((_, index) => (
            <div
              key={index}
              className={`h-1 rounded-full transition-all ${
                index === currentSlide ? 'w-8 bg-slate-400' : 'w-4 bg-zinc-800'
              }`}
            />
          ))}
        </div>
        <button
          onClick={handleSkip}
          className="text-sm text-zinc-500 hover:text-slate-300 transition-colors"
        >
          Skip
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col justify-center px-6 py-8">
        {/* Icon */}
        <div className="flex justify-center mb-8">
          <div className={`w-28 h-28 rounded-3xl bg-gradient-to-br ${slide.color} flex items-center justify-center shadow-2xl`}>
            <IconComponent className="w-14 h-14 text-white" />
          </div>
        </div>

        {/* Title */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">{slide.title}</h2>
          <p className="text-lg text-slate-400 font-semibold">{slide.subtitle}</p>
        </div>

        {/* Description */}
        <p className="text-center text-zinc-400 mb-8 leading-relaxed">
          {slide.description}
        </p>

        {/* Features */}
        <Card className="p-6 bg-zinc-900 border border-zinc-800 mb-8">
          <div className="space-y-3">
            {slide.features.map((feature, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                  <Check className="w-4 h-4 text-green-500" />
                </div>
                <p className="text-sm text-white">{feature}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Pricing Preview (Last Slide Only) */}
        {currentSlide === slides.length - 1 && (
          <Card className="p-6 bg-gradient-to-br from-blue-950 to-slate-900 border border-blue-900/30 mb-8">
            <h3 className="font-bold text-white mb-4 text-center">Choose Your Plan</h3>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <p className="text-xs text-zinc-500 mb-1">Basic</p>
                <p className="text-lg font-bold text-white">Free</p>
              </div>
              <div className="relative">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="text-xs bg-slate-500 text-white px-2 py-1 rounded-full">Popular</span>
                </div>
                <p className="text-xs text-zinc-500 mb-1">Pro</p>
                <p className="text-lg font-bold text-slate-400">$9.99</p>
              </div>
              <div>
                <p className="text-xs text-zinc-500 mb-1">Premium</p>
                <p className="text-lg font-bold text-white">$19.99</p>
              </div>
            </div>
            <p className="text-xs text-zinc-500 text-center mt-3">per month</p>
          </Card>
        )}
      </div>

      {/* Navigation */}
      <div className="px-6 pb-8">
        <Button
          onClick={handleNext}
          className="w-full h-14 bg-gradient-to-r from-blue-900 to-blue-950 hover:from-blue-800 hover:to-blue-900 text-lg font-semibold flex items-center justify-center gap-2 border border-slate-700"
        >
          {currentSlide < slides.length - 1 ? (
            <>
              Next
              <ChevronRight className="w-6 h-6" />
            </>
          ) : (
            <>
              Get Started
              <ChevronRight className="w-6 h-6" />
            </>
          )}
        </Button>
      </div>
    </div>
  );
}