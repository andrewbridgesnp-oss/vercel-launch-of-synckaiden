import { useState } from 'react';
import { ChevronLeft, Clock, MapPin, Camera, ShoppingCart, Receipt, DollarSign, Scan, Upload, X } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';

interface TrackingScreenProps {
  onBack: () => void;
}

export function TrackingScreen({ onBack }: TrackingScreenProps) {
  const [isClockedIn, setIsClockedIn] = useState(false);
  const [showReceiptScanner, setShowReceiptScanner] = useState(false);
  const [showMileageForm, setShowMileageForm] = useState(false);

  const todayLogs = {
    timeClocked: '6.5 hrs',
    mileage: '45 miles',
    receipts: 3,
    purchases: 2
  };

  const recentMileage = [
    { id: 1, date: 'Today', from: 'Home Office', to: 'Burke County Site', miles: 32, purpose: 'Site visit', deduction: 21.44 },
    { id: 2, date: 'Today', from: 'Burke County', to: 'Home Depot', miles: 13, purpose: 'Materials', deduction: 8.71 },
    { id: 3, date: 'Yesterday', from: 'Home Office', to: 'Augusta', miles: 28, purpose: 'Client meeting', deduction: 18.76 },
  ];

  const recentReceipts = [
    { 
      id: 1, 
      date: 'Today', 
      vendor: 'Home Depot', 
      amount: 456.32, 
      category: 'Materials', 
      items: ['2x4 Lumber (50)', 'Deck Screws', 'Concrete Mix'],
      deduction: 456.32,
      scanned: true 
    },
    { 
      id: 2, 
      date: 'Today', 
      vendor: 'Lowes', 
      amount: 128.50, 
      category: 'Tools', 
      items: ['DeWalt Drill Bit Set', 'Tape Measure'],
      deduction: 128.50,
      scanned: true 
    },
    { 
      id: 3, 
      date: 'Yesterday', 
      vendor: 'Shell', 
      amount: 52.00, 
      category: 'Fuel', 
      items: ['Gas - 13.2 gal'],
      deduction: 52.00,
      scanned: false 
    },
  ];

  const weeklyStats = {
    hours: 32.5,
    mileage: 187,
    receipts: 12,
    totalExpenses: 2847.65,
    mileageDeduction: 125.29, // 187 miles * $0.67 per mile
    receiptDeduction: 2847.65,
    totalDeduction: 2972.94
  };

  const handleClockToggle = () => {
    setIsClockedIn(!isClockedIn);
  };

  return (
    <div className="min-h-screen bg-black pb-20">
      {/* Header */}
      <div className="bg-zinc-900 px-6 py-4 border-b border-zinc-800 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 hover:bg-zinc-800 rounded-lg -ml-2">
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-white">Business Tracking</h1>
            <p className="text-sm text-zinc-400">Time • Mileage • Receipts</p>
          </div>
        </div>
      </div>

      {/* Clock In/Out */}
      <div className="px-6 py-6 border-b border-zinc-900">
        <Card className={`p-6 border ${isClockedIn ? 'bg-gradient-to-br from-green-950 to-zinc-900 border-green-900' : 'bg-zinc-900 border-zinc-800'}`}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-white font-bold text-lg mb-1">
                {isClockedIn ? 'Clocked In' : 'Ready to Work'}
              </h3>
              <p className="text-sm text-zinc-400">
                {isClockedIn ? 'Started at 7:45 AM' : 'Tap to start your shift'}
              </p>
            </div>
            <div className="w-16 h-16 rounded-full bg-zinc-800 flex items-center justify-center">
              <Clock className={`w-8 h-8 ${isClockedIn ? 'text-green-500' : 'text-zinc-500'}`} />
            </div>
          </div>

          {isClockedIn && (
            <div className="mb-4 p-4 bg-black/30 rounded-xl">
              <p className="text-sm text-zinc-400 mb-1">Current Shift</p>
              <p className="text-4xl font-bold text-white">6:32:15</p>
            </div>
          )}

          <Button
            onClick={handleClockToggle}
            className={`w-full h-12 font-semibold ${
              isClockedIn 
                ? 'bg-red-600 hover:bg-red-700' 
                : 'bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800'
            }`}
          >
            {isClockedIn ? 'Clock Out' : 'Clock In'}
          </Button>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="px-6 py-4 border-b border-zinc-900">
        <div className="grid grid-cols-2 gap-3">
          <Button
            onClick={() => setShowReceiptScanner(true)}
            className="h-20 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 flex flex-col items-center justify-center gap-2"
            variant="outline"
          >
            <Scan className="w-6 h-6 text-red-500" />
            <span className="text-white text-sm font-semibold">Scan Receipt</span>
          </Button>

          <Button
            onClick={() => setShowMileageForm(true)}
            className="h-20 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 flex flex-col items-center justify-center gap-2"
            variant="outline"
          >
            <MapPin className="w-6 h-6 text-red-500" />
            <span className="text-white text-sm font-semibold">Log Mileage</span>
          </Button>
        </div>
      </div>

      {/* Weekly Summary */}
      <div className="px-6 py-6 border-b border-zinc-900">
        <h2 className="text-lg font-bold text-white mb-4">This Week's Summary</h2>
        
        <div className="grid grid-cols-2 gap-3 mb-4">
          <Card className="p-4 bg-zinc-900 border border-zinc-800">
            <p className="text-xs text-zinc-500 mb-1">Hours Worked</p>
            <p className="text-3xl font-bold text-white">{weeklyStats.hours}</p>
          </Card>

          <Card className="p-4 bg-zinc-900 border border-zinc-800">
            <p className="text-xs text-zinc-500 mb-1">Miles Driven</p>
            <p className="text-3xl font-bold text-white">{weeklyStats.mileage}</p>
          </Card>
        </div>

        <Card className="p-4 bg-gradient-to-br from-red-950 to-zinc-900 border border-red-900/30">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm text-zinc-400 mb-1">Total Tax Deductions</p>
              <p className="text-3xl font-bold text-green-500">${weeklyStats.totalDeduction.toFixed(2)}</p>
            </div>
            <DollarSign className="w-10 h-10 text-green-500" />
          </div>
          <div className="grid grid-cols-2 gap-3 text-xs pt-3 border-t border-zinc-800">
            <div>
              <p className="text-zinc-500">Mileage</p>
              <p className="text-white font-semibold">${weeklyStats.mileageDeduction.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-zinc-500">Receipts</p>
              <p className="text-white font-semibold">${weeklyStats.receiptDeduction.toFixed(2)}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Tabs */}
      <div className="px-6 py-6">
        <Tabs defaultValue="mileage" className="w-full">
          <TabsList className="w-full grid grid-cols-2 bg-zinc-900 border border-zinc-800">
            <TabsTrigger value="mileage" className="data-[state=active]:bg-red-950 data-[state=active]:text-white">
              Mileage Log
            </TabsTrigger>
            <TabsTrigger value="receipts" className="data-[state=active]:bg-red-950 data-[state=active]:text-white">
              Receipt Scanner
            </TabsTrigger>
          </TabsList>

          {/* Mileage Tab */}
          <TabsContent value="mileage" className="mt-4">
            <div className="space-y-3">
              {recentMileage.map((trip) => (
                <Card key={trip.id} className="p-4 bg-zinc-900 border border-zinc-800">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-zinc-800 text-zinc-400 text-xs">{trip.date}</Badge>
                        <Badge className="bg-red-950 text-red-400 text-xs">{trip.miles} mi</Badge>
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-start gap-2">
                          <MapPin className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                          <p className="text-sm text-white">{trip.from}</p>
                        </div>
                        <div className="flex items-start gap-2">
                          <MapPin className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                          <p className="text-sm text-white">{trip.to}</p>
                        </div>
                      </div>
                      <p className="text-xs text-zinc-500 mt-2">{trip.purpose}</p>
                    </div>
                    <div className="text-right ml-4">
                      <p className="text-sm text-zinc-500">Deduction</p>
                      <p className="text-lg font-bold text-green-500">${trip.deduction}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Receipts Tab */}
          <TabsContent value="receipts" className="mt-4">
            <div className="space-y-3">
              {recentReceipts.map((receipt) => (
                <Card key={receipt.id} className="p-4 bg-zinc-900 border border-zinc-800">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-zinc-800 text-zinc-400 text-xs">{receipt.date}</Badge>
                        <Badge className="bg-blue-950 text-blue-400 text-xs">{receipt.category}</Badge>
                        {receipt.scanned && (
                          <Badge className="bg-green-950 text-green-400 text-xs">✓ Scanned</Badge>
                        )}
                      </div>
                      <h4 className="font-bold text-white mb-1">{receipt.vendor}</h4>
                      <ul className="text-xs text-zinc-400 space-y-0.5">
                        {receipt.items.map((item, idx) => (
                          <li key={idx}>• {item}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="text-right ml-4">
                      <p className="text-sm text-zinc-500">Amount</p>
                      <p className="text-xl font-bold text-white">${receipt.amount.toFixed(2)}</p>
                      <p className="text-xs text-green-500 mt-1">-${receipt.deduction.toFixed(2)}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Receipt Scanner Modal */}
      {showReceiptScanner && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-6">
          <div className="bg-zinc-900 rounded-2xl p-6 w-full max-w-md border border-zinc-800">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">Scan Receipt</h3>
              <button onClick={() => setShowReceiptScanner(false)} className="text-zinc-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="aspect-video bg-zinc-800 rounded-xl flex items-center justify-center border-2 border-dashed border-zinc-700">
                <div className="text-center">
                  <Camera className="w-12 h-12 text-zinc-600 mx-auto mb-2" />
                  <p className="text-sm text-zinc-500">Camera view will appear here</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Button className="bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center gap-2">
                  <Camera className="w-5 h-5" />
                  Take Photo
                </Button>
                <Button className="bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center gap-2">
                  <Upload className="w-5 h-5" />
                  Upload
                </Button>
              </div>

              <div className="bg-zinc-800 rounded-xl p-4">
                <p className="text-xs text-zinc-400 mb-2">
                  <strong className="text-white">Pro Tip:</strong> Make sure the receipt is flat and well-lit for best OCR results.
                </p>
                <ul className="text-xs text-zinc-500 space-y-1">
                  <li>✓ Automatically extracts vendor, date, amount</li>
                  <li>✓ Categorizes expenses for tax time</li>
                  <li>✓ Stored securely in the cloud</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mileage Form Modal */}
      {showMileageForm && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-6">
          <div className="bg-zinc-900 rounded-2xl p-6 w-full max-w-md border border-zinc-800">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">Log Mileage</h3>
              <button onClick={() => setShowMileageForm(false)} className="text-zinc-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm text-zinc-400 mb-2 block">Starting Location</label>
                <input 
                  type="text" 
                  placeholder="e.g., Home Office" 
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-3 text-white placeholder-zinc-600"
                />
              </div>

              <div>
                <label className="text-sm text-zinc-400 mb-2 block">Destination</label>
                <input 
                  type="text" 
                  placeholder="e.g., Job Site" 
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-3 text-white placeholder-zinc-600"
                />
              </div>

              <div>
                <label className="text-sm text-zinc-400 mb-2 block">Miles</label>
                <input 
                  type="number" 
                  placeholder="0" 
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-3 text-white placeholder-zinc-600"
                />
              </div>

              <div>
                <label className="text-sm text-zinc-400 mb-2 block">Purpose</label>
                <select className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-4 py-3 text-white">
                  <option>Site Visit</option>
                  <option>Client Meeting</option>
                  <option>Materials Pickup</option>
                  <option>Equipment Delivery</option>
                  <option>Other Business</option>
                </select>
              </div>

              <div className="bg-red-950/30 border border-red-900/50 rounded-xl p-4">
                <p className="text-sm text-zinc-400 mb-1">Estimated Deduction</p>
                <p className="text-2xl font-bold text-green-500">$0.00</p>
                <p className="text-xs text-zinc-500 mt-1">At $0.67/mile (2024 IRS rate)</p>
              </div>

              <Button className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800">
                Save Mileage Log
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}