import { useState } from 'react';
import { ChevronLeft, TrendingUp, AlertCircle, CheckCircle2, Lock, ExternalLink } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { Checkbox } from './ui/checkbox';

interface CreditScreenProps {
  onBack: () => void;
}

export function CreditScreen({ onBack }: CreditScreenProps) {
  const [completedSteps, setCompletedSteps] = useState<Record<string, boolean>>({});

  // Business Credit Platforms with real details
  const businessPlatforms = [
    {
      id: 'duns',
      name: 'Dun & Bradstreet',
      logo: 'D&B',
      status: 'Ready to Apply',
      score: null,
      unlockDay: 22,
      description: 'Foundation of business credit',
      benefits: ['PAYDEX score tracking', 'Business credit file creation', 'Required for most vendors'],
      url: 'dnb.com',
      cost: 'Free DUNS',
      locked: false
    },
    {
      id: 'nav',
      name: 'NAV',
      logo: 'NAV',
      status: 'Locked',
      score: null,
      unlockDay: 30,
      description: 'Monitor business credit scores',
      benefits: ['View D&B, Experian, Equifax scores', 'Credit monitoring alerts', 'Personalized recommendations'],
      url: 'nav.com',
      cost: '$29.99/mo',
      locked: true
    },
    {
      id: 'navprime',
      name: 'NAV Prime',
      logo: 'NAV+',
      status: 'Locked',
      score: null,
      unlockDay: 90,
      description: 'Premium business credit tools',
      benefits: ['Advanced credit builder tools', 'Priority support', 'Credit tradeline recommendations'],
      url: 'nav.com/prime',
      cost: '$59.99/mo',
      locked: true
    },
    {
      id: 'bluevine',
      name: 'BlueVine',
      logo: 'BV',
      status: 'Locked',
      score: null,
      unlockDay: 60,
      description: 'Business credit & banking',
      benefits: ['Business line of credit', 'Build business credit', 'Invoice factoring'],
      url: 'bluevine.com',
      cost: 'Free account',
      locked: true
    },
  ];

  // Credit card stacking offers - real cards
  const businessCards = [
    {
      tier: 'Tier 1 - Secured',
      timing: 'Now',
      cards: [
        { name: 'Capital One Secured', limit: '$200-$3,000', deposit: '$49-$200', apr: '26.99%', available: true },
        { name: 'Discover Secured', limit: '$200-$2,500', deposit: '$200 min', apr: '28.24%', available: true },
      ]
    },
    {
      tier: 'Tier 2 - Starter Business',
      timing: 'Day 30+',
      cards: [
        { name: 'Chase Ink Business Cash', limit: '$3,000-$25,000', deposit: 'None', apr: '20.49%', available: false },
        { name: 'Bank of America Business', limit: '$2,000-$20,000', deposit: 'None', apr: '18.24%', available: false },
        { name: 'Truist Business One Rewards', limit: '$5,000-$15,000', deposit: 'None', apr: '19.74%', available: false },
      ]
    },
    {
      tier: 'Tier 3 - Premium',
      timing: 'Day 60+',
      cards: [
        { name: 'Amex Blue Business Plus', limit: '$10,000+', deposit: 'None', apr: '18.24%', available: false },
        { name: 'Capital One Spark', limit: '$5,000+', deposit: 'None', apr: '26.24%', available: false },
        { name: 'Truist Enjoy Cash', limit: '$8,000+', deposit: 'None', apr: '17.99%', available: false },
      ]
    },
    {
      tier: 'Tier 4 - Local Banking',
      timing: 'Day 90+',
      cards: [
        { name: 'Queensborough Business Card', limit: '$5,000-$10,000', deposit: 'None', apr: '16.99%', available: false },
        { name: 'Queensborough Visa Secured', limit: '$500-$5,000', deposit: '$500 min', apr: '15.99%', available: true },
      ]
    },
  ];

  const personalCreditActions = [
    { id: 'p1', title: 'Dispute Repossession', impact: '+40-60 pts', status: 'High Priority', locked: false },
    { id: 'p2', title: 'Dispute Late Payments', impact: '+20-30 pts', status: 'High Priority', locked: false },
    { id: 'p3', title: 'Pay Down to 30% Utilization', impact: '+15-25 pts', status: 'Medium Priority', locked: false },
    { id: 'p4', title: 'Setup Autopay', impact: '+5-10 pts', status: 'Ongoing', locked: false },
  ];

  const handleToggle = (id: string) => {
    setCompletedSteps(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  return (
    <div className="min-h-screen bg-black pb-20">
      {/* Header */}
      <div className="bg-zinc-900 px-6 py-4 border-b border-zinc-800 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 hover:bg-zinc-800 rounded-lg -ml-2">
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-white">Credit Builder</h1>
            <p className="text-sm text-zinc-400">Personal & Business Credit</p>
          </div>
        </div>
      </div>

      {/* Score Overview */}
      <div className="px-6 py-6 border-b border-zinc-900">
        <div className="grid grid-cols-2 gap-4">
          <Card className="p-4 bg-zinc-900 border border-zinc-800">
            <p className="text-xs text-zinc-500 mb-2">Personal FICO</p>
            <div className="flex items-baseline gap-2 mb-1">
              <span className="text-4xl font-bold text-white">620</span>
              <TrendingUp className="w-4 h-4 text-green-500" />
            </div>
            <p className="text-xs text-zinc-500">Fair • Target: 680</p>
            <div className="mt-3 h-1 bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-red-500 to-yellow-500" style={{ width: '73%' }} />
            </div>
          </Card>

          <Card className="p-4 bg-zinc-900 border border-zinc-800">
            <p className="text-xs text-zinc-500 mb-2">Business Credit</p>
            <span className="text-4xl font-bold text-zinc-700">--</span>
            <p className="text-xs text-zinc-500 mt-1">Day 22 to start</p>
            <Badge className="mt-3 bg-zinc-800 text-zinc-500 text-xs">21 days</Badge>
          </Card>
        </div>
      </div>

      {/* Business Credit Platforms */}
      <div className="px-6 py-6 border-b border-zinc-900">
        <h2 className="text-lg font-bold text-white mb-4">Business Credit Stack</h2>
        
        <div className="space-y-3">
          {businessPlatforms.map((platform) => (
            <Card 
              key={platform.id}
              className={`p-4 border ${
                platform.locked 
                  ? 'bg-zinc-950 border-zinc-800 opacity-60' 
                  : 'bg-zinc-900 border-red-900/30 hover:border-red-600/50 cursor-pointer'
              } transition-all`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3 flex-1">
                  <div className="w-12 h-12 rounded-xl bg-zinc-800 border border-zinc-700 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-zinc-400">{platform.logo}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-white">{platform.name}</h3>
                      {platform.locked && <Lock className="w-4 h-4 text-zinc-600" />}
                    </div>
                    <p className="text-sm text-zinc-400 mb-2">{platform.description}</p>
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge className={`text-xs ${
                        platform.locked 
                          ? 'bg-zinc-800 text-zinc-500' 
                          : 'bg-green-500/10 text-green-500 border-green-500/20'
                      }`}>
                        {platform.status}
                      </Badge>
                      <Badge className="bg-zinc-800 text-zinc-400 text-xs">
                        {platform.cost}
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t border-zinc-800 pt-3">
                <p className="text-xs text-zinc-500 mb-2">Benefits:</p>
                <ul className="space-y-1">
                  {platform.benefits.map((benefit, idx) => (
                    <li key={idx} className="text-xs text-zinc-400 flex items-start gap-2">
                      <span className="text-red-500 mt-0.5">•</span>
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {!platform.locked ? (
                <button className="w-full mt-3 bg-gradient-to-r from-red-600 to-red-700 text-white py-2 rounded-lg font-semibold text-sm hover:from-red-700 hover:to-red-800 flex items-center justify-center gap-2">
                  Apply Now <ExternalLink className="w-4 h-4" />
                </button>
              ) : (
                <div className="mt-3 text-center">
                  <p className="text-xs text-zinc-600">Available on Day {platform.unlockDay}</p>
                </div>
              )}
            </Card>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="px-6 py-6">
        <Tabs defaultValue="personal" className="w-full">
          <TabsList className="w-full grid grid-cols-2 bg-zinc-900 border border-zinc-800">
            <TabsTrigger value="personal" className="data-[state=active]:bg-red-950 data-[state=active]:text-white">
              Personal Credit
            </TabsTrigger>
            <TabsTrigger value="stacking" className="data-[state=active]:bg-red-950 data-[state=active]:text-white">
              Credit Stacking
            </TabsTrigger>
          </TabsList>

          {/* Personal Credit Tab */}
          <TabsContent value="personal" className="mt-4">
            <Card className="p-4 bg-gradient-to-br from-red-950 to-zinc-900 border border-red-900/50 mb-4">
              <h3 className="text-white font-bold mb-2">Score Improvement Potential</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-zinc-400">Current</p>
                  <p className="text-3xl font-bold text-white">620</p>
                </div>
                <div>
                  <p className="text-xs text-zinc-400">Potential</p>
                  <p className="text-3xl font-bold text-red-500">695-735</p>
                </div>
              </div>
            </Card>

            <div className="space-y-3">
              {personalCreditActions.map((action) => (
                <Card key={action.id} className="p-4 bg-zinc-900 border border-zinc-800">
                  <div className="flex items-start gap-3">
                    <Checkbox
                      checked={completedSteps[action.id] || false}
                      onCheckedChange={() => handleToggle(action.id)}
                      className="mt-1 border-zinc-700 data-[state=checked]:bg-red-600"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className={`font-semibold text-white ${completedSteps[action.id] ? 'line-through opacity-50' : ''}`}>
                            {action.title}
                          </h4>
                          <Badge className="bg-zinc-800 text-zinc-400 text-xs mt-1">
                            {action.status}
                          </Badge>
                        </div>
                        <Badge className="bg-green-500/10 text-green-500 border-green-500/20 ml-2">
                          {action.impact}
                        </Badge>
                      </div>
                      {completedSteps[action.id] && (
                        <p className="text-xs text-green-500 flex items-center gap-1 mt-2">
                          <CheckCircle2 className="w-3 h-3" /> Completed
                        </p>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            <Card className="p-4 bg-zinc-900 border border-zinc-800 mt-4">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-zinc-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-white text-sm mb-1">Dispute Strategy</p>
                  <ul className="text-xs text-zinc-400 space-y-1">
                    <li>• File disputes with all 3 bureaus simultaneously</li>
                    <li>• Use certified mail for goodwill deletion requests</li>
                    <li>• Follow up every 30 days until resolved</li>
                  </ul>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Credit Stacking Tab */}
          <TabsContent value="stacking" className="mt-4">
            <Card className="p-4 bg-zinc-900 border border-red-900/30 mb-4">
              <h3 className="text-white font-bold mb-2">Credit Stacking Strategy</h3>
              <p className="text-sm text-zinc-400">
                Apply for multiple business credit cards on the same day before inquiries appear on your credit report. 
                This maximizes approval rates.
              </p>
            </Card>

            <div className="space-y-4">
              {businessCards.map((tier, index) => (
                <div key={index}>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-white">{tier.tier}</h3>
                    <Badge className="bg-zinc-800 text-zinc-400 text-xs">
                      {tier.timing}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    {tier.cards.map((card, idx) => (
                      <Card 
                        key={idx}
                        className={`p-4 border ${
                          card.available 
                            ? 'bg-zinc-900 border-red-900/30 hover:border-red-600/50 cursor-pointer' 
                            : 'bg-zinc-950 border-zinc-800 opacity-60'
                        } transition-all`}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <h4 className="font-semibold text-white mb-1">{card.name}</h4>
                            <div className="grid grid-cols-3 gap-2 text-xs">
                              <div>
                                <p className="text-zinc-500">Limit</p>
                                <p className="text-zinc-300">{card.limit}</p>
                              </div>
                              <div>
                                <p className="text-zinc-500">Deposit</p>
                                <p className="text-zinc-300">{card.deposit}</p>
                              </div>
                              <div>
                                <p className="text-zinc-500">APR</p>
                                <p className="text-zinc-300">{card.apr}</p>
                              </div>
                            </div>
                          </div>
                          {card.available ? (
                            <Badge className="bg-green-500/10 text-green-500 border-green-500/20 ml-2">
                              Available
                            </Badge>
                          ) : (
                            <Lock className="w-4 h-4 text-zinc-600 ml-2" />
                          )}
                        </div>
                        {card.available && (
                          <button className="w-full mt-2 bg-red-600 text-white py-2 rounded-lg font-semibold text-sm hover:bg-red-700 flex items-center justify-center gap-2">
                            Apply Now <ExternalLink className="w-4 h-4" />
                          </button>
                        )}
                      </Card>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}