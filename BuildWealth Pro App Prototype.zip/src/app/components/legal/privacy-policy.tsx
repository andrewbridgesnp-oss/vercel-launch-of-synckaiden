import { ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';

interface PrivacyPolicyProps {
  onBack: () => void;
}

export function PrivacyPolicy({ onBack }: PrivacyPolicyProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-950 to-black text-white">
      {/* Header */}
      <div className="sticky top-0 z-10 backdrop-blur-xl bg-black/50 border-b border-zinc-800/50">
        <div className="flex items-center gap-4 p-4">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onBack}
            className="p-2 hover:bg-zinc-800/50 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#D4AF37]" />
          </motion.button>
          <h1 className="text-xl font-bold">Privacy Policy</h1>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 pb-24 max-w-3xl mx-auto">
        <div className="space-y-6 text-zinc-300">
          <p className="text-sm text-zinc-500">Last Updated: January 11, 2026</p>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">1. Introduction</h2>
            <p className="mb-2">
              Cox & Co. Professional Services LLC ("BuildWealth Pro," "we," "us," or "our") is committed to protecting your privacy and complying with the Gramm-Leach-Bliley Act (GLBA) and other applicable financial privacy laws.
            </p>
            <p>
              This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our financial services application.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">2. Information We Collect</h2>
            
            <h3 className="font-semibold text-white mt-4 mb-2">2.1 Personal Information</h3>
            <p className="mb-2">We may collect the following types of personal information:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Name, email address, phone number</li>
              <li>Financial information (credit scores, account details) - for display purposes only</li>
              <li>Business information (EIN, business address, revenue)</li>
              <li>Usage data and app analytics</li>
            </ul>

            <h3 className="font-semibold text-white mt-4 mb-2">2.2 Automatically Collected Information</h3>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Device information (IP address, browser type)</li>
              <li>Usage patterns and preferences</li>
              <li>Cookies and similar tracking technologies</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">3. How We Use Your Information</h2>
            <p className="mb-2">We use your information to:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Provide financial education and credit improvement guidance</li>
              <li>Display your financial progress and achievements</li>
              <li>Send you task reminders and notifications</li>
              <li>Improve our services and user experience</li>
              <li>Comply with legal obligations</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">4. Information Sharing and Disclosure</h2>
            <p className="mb-2">We do NOT sell your personal information. We may share your information with:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li><strong>Service Providers:</strong> Third-party vendors who assist in app operations (e.g., hosting, analytics)</li>
              <li><strong>Legal Requirements:</strong> When required by law or to protect our rights</li>
              <li><strong>Business Transfers:</strong> In connection with a merger or acquisition</li>
            </ul>
            <p className="mt-2 text-sm">
              <strong>Note:</strong> BuildWealth Pro is an educational tool. We do NOT directly access or store your actual credit reports or financial account credentials.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">5. Data Security (GLBA Compliance)</h2>
            <p className="mb-2">We implement industry-standard security measures to protect your information:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Encryption of data in transit (TLS/SSL)</li>
              <li>Encryption of sensitive data at rest</li>
              <li>Regular security audits and assessments</li>
              <li>Limited employee access to personal information</li>
              <li>Secure authentication and authorization protocols</li>
            </ul>
            <p className="mt-2 text-sm text-yellow-500">
              <strong>Important:</strong> No method of transmission over the internet is 100% secure. While we strive to protect your information, we cannot guarantee absolute security.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">6. Your Privacy Rights</h2>
            <p className="mb-2">You have the right to:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li><strong>Access:</strong> Request a copy of your personal information</li>
              <li><strong>Correction:</strong> Request correction of inaccurate information</li>
              <li><strong>Deletion:</strong> Request deletion of your account and data</li>
              <li><strong>Opt-Out:</strong> Unsubscribe from marketing communications</li>
              <li><strong>Data Portability:</strong> Receive your data in a structured format</li>
            </ul>
            <p className="mt-2 text-sm">
              To exercise these rights, contact us at privacy@coxcopros.com
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">7. Data Retention</h2>
            <p>
              We retain your personal information for as long as necessary to provide our services and comply with legal obligations. When you delete your account, we will delete or anonymize your personal information within 30 days, except as required by law.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">8. Children's Privacy</h2>
            <p>
              BuildWealth Pro is not intended for use by individuals under 18 years of age. We do not knowingly collect personal information from children.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">9. California Privacy Rights (CCPA)</h2>
            <p>
              California residents have additional rights under the California Consumer Privacy Act (CCPA), including the right to know what personal information is collected, the right to delete personal information, and the right to opt-out of the sale of personal information (we do not sell personal information).
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">10. Changes to This Policy</h2>
            <p>
              We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the new policy on this page and updating the "Last Updated" date.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">11. Contact Us</h2>
            <p className="mb-2">
              If you have questions about this Privacy Policy, please contact us:
            </p>
            <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800/50">
              <p><strong>Cox & Co. Professional Services LLC</strong></p>
              <p>Email: privacy@coxcopros.com</p>
              <p>Address: [Your Business Address]</p>
              <p>Phone: [Your Phone Number]</p>
            </div>
          </section>

          <div className="mt-8 p-4 bg-blue-950/30 border border-blue-800/50 rounded-xl">
            <p className="text-sm text-blue-300">
              <strong>GLBA Notice:</strong> As a financial service provider, we are required to inform you of our privacy practices. This Privacy Policy serves as our GLBA Privacy Notice. We do not share your nonpublic personal information with non-affiliated third parties for marketing purposes.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
