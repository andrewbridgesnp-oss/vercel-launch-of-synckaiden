import { ArrowLeft, AlertTriangle, Scale, FileText, Shield } from 'lucide-react';
import { motion } from 'motion/react';

interface FinancialDisclaimerProps {
  onBack: () => void;
}

export function FinancialDisclaimer({ onBack }: FinancialDisclaimerProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-950 to-black text-white">
      {/* Header */}
      <div className="sticky top-0 z-10 backdrop-blur-xl bg-black/50 border-b border-zinc-800/50">
        <div className="flex items-center gap-4 p-4">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onBack}
            className="p-2 hover:bg-zinc-800/50 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#D4AF37]" />
          </motion.button>
          <h1 className="text-xl font-bold">Financial Disclaimer</h1>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 pb-24 max-w-3xl mx-auto">
        <div className="space-y-6 text-zinc-300">
          
          <div className="p-4 bg-red-950/30 border border-red-800/50 rounded-xl">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-bold text-red-400 mb-2">IMPORTANT LEGAL DISCLAIMER</h3>
                <p className="text-sm text-red-300">
                  BuildWealth Pro is for educational and informational purposes ONLY. This is NOT financial advice, legal advice, or credit repair services. Always consult licensed professionals.
                </p>
              </div>
            </div>
          </div>

          <section>
            <div className="flex items-center gap-3 mb-4">
              <FileText className="w-6 h-6 text-[#D4AF37]" />
              <h2 className="text-lg font-bold text-white">Not Financial Advice</h2>
            </div>
            <p className="mb-3">
              BuildWealth Pro provides general educational content about credit repair, business management, and financial literacy. This information:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li><strong>Is NOT personalized financial advice</strong></li>
              <li>Should NOT be considered a recommendation to take any specific action</li>
              <li>Does NOT constitute a financial planning service</li>
              <li>Is NOT a substitute for professional financial advisors, CPAs, or attorneys</li>
            </ul>
            <div className="mt-4 p-3 bg-blue-950/30 border border-blue-800/50 rounded-lg">
              <p className="text-sm text-blue-300">
                <strong>Recommendation:</strong> Always consult with a licensed financial advisor, certified public accountant (CPA), or attorney before making significant financial decisions.
              </p>
            </div>
          </section>

          <section>
            <div className="flex items-center gap-3 mb-4">
              <Scale className="w-6 h-6 text-[#D4AF37]" />
              <h2 className="text-lg font-bold text-white">Not Credit Repair Services (CROA Compliance)</h2>
            </div>
            <p className="mb-3">
              Under the Credit Repair Organizations Act (CROA), we expressly state that:
            </p>
            <div className="p-4 bg-yellow-950/30 border border-yellow-800/50 rounded-lg space-y-3">
              <p className="text-sm text-yellow-300">
                <strong>1. You have the right to:</strong>
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-sm text-yellow-300">
                <li>Review and dispute inaccurate information in your credit report yourself</li>
                <li>File a complaint with the Consumer Financial Protection Bureau (CFPB)</li>
                <li>Sue a credit repair organization that violates CROA</li>
              </ul>

              <p className="text-sm text-yellow-300 mt-3">
                <strong>2. Educational Tool Only:</strong>
              </p>
              <p className="text-sm text-yellow-300">
                BuildWealth Pro does NOT:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-sm text-yellow-300">
                <li>Provide credit repair services</li>
                <li>Directly dispute items on your credit report</li>
                <li>Communicate with credit bureaus on your behalf</li>
                <li>Guarantee any specific credit score improvements</li>
              </ul>

              <p className="text-sm text-yellow-300 mt-3">
                <strong>3. Free Resources Available:</strong>
              </p>
              <p className="text-sm text-yellow-300">
                You can dispute credit report errors for FREE through:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-sm text-yellow-300">
                <li>Experian: www.experian.com/disputes</li>
                <li>Equifax: www.equifax.com/disputes</li>
                <li>TransUnion: www.transunion.com/disputes</li>
                <li>AnnualCreditReport.com (free annual credit reports)</li>
              </ul>
            </div>
          </section>

          <section>
            <div className="flex items-center gap-3 mb-4">
              <Shield className="w-6 h-6 text-[#D4AF37]" />
              <h2 className="text-lg font-bold text-white">Fair Credit Reporting Act (FCRA) Notice</h2>
            </div>
            <p className="mb-3">
              Under the Fair Credit Reporting Act, you have important rights:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li><strong>Access:</strong> You have the right to obtain a free copy of your credit report annually from each of the three major credit bureaus</li>
              <li><strong>Accuracy:</strong> Credit bureaus must correct or delete inaccurate, incomplete, or unverifiable information</li>
              <li><strong>Dispute:</strong> You can dispute inaccurate information in your credit report</li>
              <li><strong>Consent:</strong> Creditors must have your permission before obtaining your credit report (with some exceptions)</li>
            </ul>
            <div className="mt-4 p-3 bg-zinc-900/50 border border-zinc-700/50 rounded-lg">
              <p className="text-sm">
                <strong>Learn More:</strong> Visit{' '}
                <a href="https://www.consumerfinance.gov/credit-reports-and-scores/" target="_blank" rel="noopener noreferrer" className="text-[#D4AF37] underline">
                  consumerfinance.gov
                </a>{' '}
                for complete information about your rights under FCRA.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">No Guarantees or Warranties</h2>
            <p className="mb-3">
              BuildWealth Pro makes NO guarantees regarding:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Credit score improvements or specific point increases</li>
              <li>Approval for loans, credit cards, or financing</li>
              <li>Approval for government or private grants</li>
              <li>Business profitability or success</li>
              <li>Accuracy of third-party data or information</li>
              <li>Specific timeframes for achieving financial goals</li>
            </ul>
            <p className="mt-3 text-sm text-zinc-400">
              Individual results vary based on personal circumstances, credit history, financial behavior, and factors beyond our control.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">Third-Party Information</h2>
            <p className="mb-2">
              BuildWealth Pro may display or link to third-party content, including:
            </p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Credit card and loan offers</li>
              <li>Grant opportunities</li>
              <li>Vehicle listings</li>
              <li>Educational resources</li>
            </ul>
            <p className="mt-3">
              We do NOT endorse or guarantee any third-party products, services, or information. Always verify information independently and read all terms and conditions before applying for financial products.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">Risk Acknowledgment</h2>
            <p className="mb-2">
              You acknowledge and understand that:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Financial decisions carry inherent risks</li>
              <li>Credit applications may result in hard inquiries that temporarily lower your credit score</li>
              <li>Taking on debt (loans, credit cards) creates financial obligations</li>
              <li>Business ventures involve risk of financial loss</li>
              <li>Past performance does not guarantee future results</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">Data Accuracy</h2>
            <p>
              While we strive for accuracy, BuildWealth Pro does NOT verify the accuracy of:
            </p>
            <ul className="list-disc list-inside space-y-1 ml-4 mt-2">
              <li>User-entered credit scores or financial information</li>
              <li>Third-party grant or loan listings</li>
              <li>Vehicle inventory or pricing data</li>
            </ul>
            <p className="mt-3">
              Users are responsible for verifying all information before making financial decisions.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">Limitation of Liability</h2>
            <p>
              TO THE FULLEST EXTENT PERMITTED BY LAW, COX & CO. PROFESSIONAL SERVICES LLC SHALL NOT BE LIABLE FOR:
            </p>
            <ul className="list-disc list-inside space-y-1 ml-4 mt-2">
              <li>Financial losses resulting from use of BuildWealth Pro</li>
              <li>Credit score decreases or denial of credit applications</li>
              <li>Business losses or missed opportunities</li>
              <li>Errors or omissions in educational content</li>
              <li>Actions taken based on app information</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">Regulatory Compliance</h2>
            <p className="mb-2">
              BuildWealth Pro operates in compliance with applicable federal and state regulations, including:
            </p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Credit Repair Organizations Act (CROA)</li>
              <li>Fair Credit Reporting Act (FCRA)</li>
              <li>Equal Credit Opportunity Act (ECOA)</li>
              <li>Gramm-Leach-Bliley Act (GLBA)</li>
              <li>California Consumer Privacy Act (CCPA)</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">Contact Information</h2>
            <p className="mb-3">
              For questions about this disclaimer or to report concerns:
            </p>
            <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800/50">
              <p><strong>Cox & Co. Professional Services LLC</strong></p>
              <p>Email: legal@coxcopros.com</p>
              <p>Consumer Complaints: complaints@coxcopros.com</p>
            </div>
          </section>

          <div className="mt-8 p-4 bg-zinc-900 border border-[#D4AF37]/50 rounded-xl">
            <p className="text-sm font-semibold text-[#D4AF37] mb-2">
              Acknowledgment of Understanding
            </p>
            <p className="text-sm text-zinc-400">
              By using BuildWealth Pro, you acknowledge that you have read, understood, and agree to this Financial Disclaimer. You understand that this app is for educational purposes only and does not constitute professional financial, legal, or credit repair services.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
