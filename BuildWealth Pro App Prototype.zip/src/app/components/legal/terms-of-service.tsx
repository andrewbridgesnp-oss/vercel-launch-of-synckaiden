import { ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';

interface TermsOfServiceProps {
  onBack: () => void;
}

export function TermsOfService({ onBack }: TermsOfServiceProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-950 to-black text-white">
      {/* Header */}
      <div className="sticky top-0 z-10 backdrop-blur-xl bg-black/50 border-b border-zinc-800/50">
        <div className="flex items-center gap-4 p-4">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onBack}
            className="p-2 hover:bg-zinc-800/50 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-6 h-6 text-[#D4AF37]" />
          </motion.button>
          <h1 className="text-xl font-bold">Terms of Service</h1>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 pb-24 max-w-3xl mx-auto">
        <div className="space-y-6 text-zinc-300">
          <p className="text-sm text-zinc-500">Last Updated: January 11, 2026</p>

          <div className="p-4 bg-red-950/30 border border-red-800/50 rounded-xl text-red-300">
            <p className="font-semibold mb-2">IMPORTANT LEGAL NOTICE</p>
            <p className="text-sm">
              By using BuildWealth Pro, you agree to these Terms of Service. If you do not agree, do not use this application.
            </p>
          </div>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">1. Acceptance of Terms</h2>
            <p>
              These Terms of Service ("Terms") govern your access to and use of BuildWealth Pro, a financial education and business management application provided by Cox & Co. Professional Services LLC ("Company," "we," "us," or "our").
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">2. Description of Service</h2>
            <p className="mb-2">BuildWealth Pro provides:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Credit repair education and task management</li>
              <li>Business operation tracking (time, mileage, receipts)</li>
              <li>Grant and loan application assistance</li>
              <li>Financial progress tracking and gamification</li>
            </ul>
            <p className="mt-3">
              <strong className="text-white">BuildWealth Pro is an EDUCATIONAL TOOL ONLY.</strong> We do not provide financial advice, legal advice, or credit repair services as defined under the Credit Repair Organizations Act (CROA).
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">3. User Eligibility</h2>
            <p>
              You must be at least 18 years old and legally able to enter into contracts to use BuildWealth Pro. By using this service, you represent that you meet these requirements.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">4. User Accounts</h2>
            <h3 className="font-semibold text-white mt-3 mb-2">4.1 Account Creation</h3>
            <p className="mb-2">You agree to:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Provide accurate and complete information</li>
              <li>Maintain the security of your account credentials</li>
              <li>Notify us immediately of unauthorized access</li>
              <li>Be responsible for all activity under your account</li>
            </ul>

            <h3 className="font-semibold text-white mt-3 mb-2">4.2 Account Termination</h3>
            <p>
              We reserve the right to suspend or terminate your account for violation of these Terms, fraudulent activity, or other reasonable cause.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">5. Subscription and Payment</h2>
            <h3 className="font-semibold text-white mt-3 mb-2">5.1 Pricing Tiers</h3>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li><strong>Basic:</strong> Free with limited features</li>
              <li><strong>Pro:</strong> $9.99/month</li>
              <li><strong>Premium:</strong> $19.99/month</li>
            </ul>

            <h3 className="font-semibold text-white mt-3 mb-2">5.2 Billing</h3>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Subscriptions automatically renew monthly unless canceled</li>
              <li>You authorize us to charge your payment method</li>
              <li>Prices are subject to change with 30 days notice</li>
              <li>No refunds for partial months or unused features</li>
            </ul>

            <h3 className="font-semibold text-white mt-3 mb-2">5.3 Cancellation</h3>
            <p>
              You may cancel your subscription at any time through the app settings. Cancellation takes effect at the end of the current billing period.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">6. Prohibited Uses</h2>
            <p className="mb-2">You agree NOT to:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Use the service for any illegal purpose</li>
              <li>Attempt to gain unauthorized access to our systems</li>
              <li>Interfere with or disrupt the service</li>
              <li>Upload malicious code or viruses</li>
              <li>Violate any applicable laws or regulations</li>
              <li>Impersonate another person or entity</li>
              <li>Collect or store personal data of other users</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">7. Intellectual Property</h2>
            <p className="mb-2">
              All content, features, and functionality of BuildWealth Pro are owned by Cox & Co. Professional Services LLC and protected by copyright, trademark, and other intellectual property laws.
            </p>
            <p>
              You are granted a limited, non-exclusive, non-transferable license to use the service for personal or business purposes only.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">8. Disclaimers</h2>
            
            <div className="p-4 bg-yellow-950/30 border border-yellow-800/50 rounded-xl text-yellow-300">
              <h3 className="font-semibold mb-2">8.1 NOT FINANCIAL OR LEGAL ADVICE</h3>
              <p className="text-sm mb-2">
                BuildWealth Pro provides general educational information only. It is NOT:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-sm">
                <li>Financial advice or planning</li>
                <li>Legal advice or representation</li>
                <li>Tax advice or preparation</li>
                <li>Credit repair services (as defined under CROA)</li>
              </ul>
              <p className="text-sm mt-2">
                <strong>Consult with licensed professionals</strong> for personalized financial, legal, or tax advice.
              </p>
            </div>

            <h3 className="font-semibold text-white mt-4 mb-2">8.2 No Guarantees</h3>
            <p>
              We make NO GUARANTEES regarding:
            </p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Credit score improvements</li>
              <li>Loan or grant approval</li>
              <li>Business success or profitability</li>
              <li>Accuracy of third-party information</li>
            </ul>

            <h3 className="font-semibold text-white mt-4 mb-2">8.3 Service "As Is"</h3>
            <p>
              THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">9. Limitation of Liability</h2>
            <p className="mb-2">
              TO THE MAXIMUM EXTENT PERMITTED BY LAW, COX & CO. PROFESSIONAL SERVICES LLC SHALL NOT BE LIABLE FOR:
            </p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Indirect, incidental, or consequential damages</li>
              <li>Lost profits or business opportunities</li>
              <li>Data loss or corruption</li>
              <li>Third-party actions or content</li>
            </ul>
            <p className="mt-2">
              OUR TOTAL LIABILITY SHALL NOT EXCEED THE AMOUNT YOU PAID FOR THE SERVICE IN THE PAST 12 MONTHS.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">10. Indemnification</h2>
            <p>
              You agree to indemnify and hold harmless Cox & Co. Professional Services LLC, its officers, employees, and agents from any claims, damages, or expenses arising from your use of the service or violation of these Terms.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">11. Privacy</h2>
            <p>
              Your use of BuildWealth Pro is subject to our Privacy Policy, which is incorporated into these Terms by reference.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">12. Changes to Terms</h2>
            <p>
              We reserve the right to modify these Terms at any time. Material changes will be notified via email or in-app notification. Continued use of the service after changes constitutes acceptance of the new Terms.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">13. Governing Law and Dispute Resolution</h2>
            <h3 className="font-semibold text-white mt-3 mb-2">13.1 Governing Law</h3>
            <p className="mb-2">
              These Terms are governed by the laws of the State of Georgia, United States, without regard to conflict of law principles.
            </p>

            <h3 className="font-semibold text-white mt-3 mb-2">13.2 Dispute Resolution</h3>
            <p className="mb-2">
              Any disputes shall be resolved through binding arbitration in accordance with the rules of the American Arbitration Association, except that you may bring claims in small claims court.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">14. Severability</h2>
            <p>
              If any provision of these Terms is found to be unenforceable, the remaining provisions shall remain in full force and effect.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-white mb-3">15. Contact Information</h2>
            <div className="bg-zinc-900/50 p-4 rounded-xl border border-zinc-800/50">
              <p><strong>Cox & Co. Professional Services LLC</strong></p>
              <p>Email: legal@coxcopros.com</p>
              <p>Address: [Your Business Address]</p>
              <p>Phone: [Your Phone Number]</p>
            </div>
          </section>

          <div className="mt-8 p-4 bg-zinc-900/50 border border-[#D4AF37]/30 rounded-xl">
            <p className="text-sm">
              By clicking "I Accept" or by using BuildWealth Pro, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
