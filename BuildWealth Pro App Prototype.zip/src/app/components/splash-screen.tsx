import { useEffect } from 'react';
import { RealisticLogo } from './realistic-logo';
import { motion } from 'motion/react';
import { COX_AND_CO_BRANDING, isWhiteLabelMode } from '../../config/app-mode';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  useEffect(() => {
    // Auto-advance after 2.5 seconds
    const timer = setTimeout(() => {
      onComplete();
    }, 2500);

    return () => clearTimeout(timer);
  }, [onComplete]);

  const appName = isWhiteLabelMode() ? COX_AND_CO_BRANDING.appName : "BuildWealth Pro";
  const tagline = isWhiteLabelMode() ? COX_AND_CO_BRANDING.tagline : "Your Path to Financial Freedom";

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-zinc-950 to-black flex items-center justify-center p-6 relative overflow-hidden">
      {/* Animated Background Orbs */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 0.3, scale: 1 }}
        transition={{ duration: 1.5 }}
        className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-br from-[#D4AF37]/20 to-transparent rounded-full blur-3xl"
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 0.2, scale: 1 }}
        transition={{ duration: 1.5, delay: 0.3 }}
        className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gradient-to-br from-red-600/20 to-transparent rounded-full blur-3xl"
      />

      <div className="text-center relative z-10">
        {/* Logo */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
          className="mb-8 flex justify-center"
        >
          <RealisticLogo className="w-full max-w-md h-auto drop-shadow-2xl" variant="full" />
        </motion.div>

        {/* App Name with Kaiden's Branding */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="mb-6"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2 luxury-text-gold">
            {appName}
          </h1>
          <p className="text-sm md:text-base text-zinc-400 italic">
            {tagline}
          </p>
        </motion.div>

        {/* Loading Animation - Luxury Version */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="mt-8 flex justify-center"
        >
          <div className="flex gap-3">
            {[0, 150, 300].map((delay, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0 }}
                animate={{ 
                  scale: [1, 1.3, 1],
                  opacity: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: delay / 1000,
                  ease: "easeInOut"
                }}
                className="w-3 h-3 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#F4D03F] luxury-shadow-gold"
              />
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}