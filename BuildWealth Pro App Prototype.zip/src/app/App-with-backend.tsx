/**
 * BuildWealth Pro - Main Application with Backend Integration
 * Production-ready with Supabase authentication and data persistence
 */

import { useState, useEffect } from 'react';
import { Home, CreditCard, DollarSign, Menu, LogIn } from 'lucide-react';
import { SplashScreen } from './components/splash-screen';
import { OnboardingScreen } from './components/onboarding-screen';
import { Dashboard } from './components/dashboard';
import { CreditScreen } from './components/credit-screen';
import { VehiclesScreen } from './components/vehicles-screen';
import { TrackingScreen } from './components/tracking-screen';
import { SettingsScreen } from './components/settings-screen';
import { AuthProvider, useAuthContext } from '../contexts/AuthContext';
import { motion } from 'motion/react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { getProfile, createProfile } from '../services/profileService';
import { getUserProgress } from '../services/progressService';
import { initializeUserData } from '../utils/initializeUserData';

type Screen = 'dashboard' | 'credit' | 'vehicles' | 'tracking' | 'settings';
type AppState = 'splash' | 'onboarding' | 'login' | 'app';

function AppContent() {
  const { user, loading: authLoading, signIn, signUp } = useAuthContext();
  const [appState, setAppState] = useState<AppState>('splash');
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');
  const [userData, setUserData] = useState<any>(null);
  const [userProgress, setUserProgress] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Login form state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [authError, setAuthError] = useState('');

  // Check if Supabase is configured
  useEffect(() => {
    if (!isSupabaseConfigured()) {
      setError('Supabase not configured. Please add credentials to .env file.');
      setLoading(false);
    }
  }, []);

  // Load user data when authenticated
  useEffect(() => {
    async function loadUserData() {
      if (!user) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        
        // Get or create profile
        let profile = await getProfile(user.id);
        
        if (!profile) {
          // First time user - initialize their data
          await initializeUserData(user.id, user.email || '', fullName || user.user_metadata?.full_name || 'User');
          profile = await getProfile(user.id);
        }

        // Get progress
        const progress = await getUserProgress(user.id);

        setUserData(profile);
        setUserProgress(progress);
        setLoading(false);
      } catch (err) {
        console.error('Error loading user data:', err);
        setError('Failed to load user data');
        setLoading(false);
      }
    }

    loadUserData();
  }, [user, fullName]);

  const handleNavigate = (screen: Screen) => {
    setCurrentScreen(screen);
  };

  const handleBackToDashboard = () => {
    setCurrentScreen('dashboard');
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    
    try {
      if (isSignUp) {
        await signUp(email, password, fullName || email.split('@')[0]);
      } else {
        await signIn(email, password);
      }
      setAppState('app');
    } catch (err: any) {
      setAuthError(err.message || 'Authentication failed');
    }
  };

  // Show splash screen
  if (appState === 'splash' && !authLoading) {
    return <SplashScreen onComplete={() => {
      if (user) {
        setAppState('app');
      } else {
        setAppState('onboarding');
      }
    }} />;
  }

  // Show onboarding if not completed
  if (appState === 'onboarding') {
    return <OnboardingScreen onComplete={() => {
      if (user) {
        setAppState('app');
      } else {
        setAppState('login');
      }
    }} />;
  }

  // Show login screen if not authenticated
  if (!user && (appState === 'login' || appState === 'app')) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-zinc-950 to-black flex items-center justify-center p-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <div className="glass-card rounded-3xl p-8 border border-zinc-800/50">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-white mb-2 luxury-text-gold">
                {isSignUp ? 'Create Account' : 'Welcome Back'}
              </h1>
              <p className="text-zinc-400">
                {isSignUp ? 'Start your wealth journey' : 'Sign in to continue'}
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              {isSignUp && (
                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-2">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-4 py-3 bg-zinc-900/50 border border-zinc-800 rounded-xl text-white focus:outline-none focus:border-[#D4AF37]"
                    placeholder="Your name"
                    required
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 bg-zinc-900/50 border border-zinc-800 rounded-xl text-white focus:outline-none focus:border-[#D4AF37]"
                  placeholder="your@email.com"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-2">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 bg-zinc-900/50 border border-zinc-800 rounded-xl text-white focus:outline-none focus:border-[#D4AF37]"
                  placeholder="••••••••"
                  required
                  minLength={6}
                />
              </div>

              {authError && (
                <div className="p-3 bg-red-500/10 border border-red-500/50 rounded-xl text-red-400 text-sm">
                  {authError}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-[#D4AF37] to-[#F4D03F] text-black font-semibold rounded-xl hover:opacity-90 transition-opacity"
              >
                {isSignUp ? 'Create Account' : 'Sign In'}
              </button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => {
                  setIsSignUp(!isSignUp);
                  setAuthError('');
                }}
                className="text-[#D4AF37] hover:underline text-sm"
              >
                {isSignUp ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  // Show loading while fetching data
  if (loading || authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-zinc-950 to-black flex items-center justify-center">
        <div className="text-center">
          <div className="flex gap-3 mb-4 justify-center">
            {[0, 150, 300].map((delay, i) => (
              <motion.div
                key={i}
                animate={{ 
                  scale: [1, 1.3, 1],
                  opacity: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: delay / 1000,
                }}
                className="w-3 h-3 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#F4D03F]"
              />
            ))}
          </div>
          <p className="text-zinc-400">Loading your data...</p>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-zinc-950 to-black flex items-center justify-center p-6">
        <div className="text-center">
          <p className="text-red-400 mb-4">{error}</p>
          <p className="text-zinc-500 text-sm">Check /DO_THIS_NOW.md for setup instructions</p>
        </div>
      </div>
    );
  }

  // Build user object for components
  const userForComponents = {
    name: userData?.full_name || 'User',
    points: userProgress?.points || 0,
    level: userProgress?.level || 1,
    streak: userProgress?.streak || 0,
    personalCredit: userData?.personal_credit_score || 0,
    businessCredit: userData?.business_credit_score || 0,
  };

  // Render current screen
  const renderScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return <Dashboard user={userForComponents} onNavigate={handleNavigate} />;
      case 'credit':
        return <CreditScreen onBack={handleBackToDashboard} />;
      case 'vehicles':
        return <VehiclesScreen onBack={handleBackToDashboard} />;
      case 'tracking':
        return <TrackingScreen onBack={handleBackToDashboard} />;
      case 'settings':
        return <SettingsScreen onBack={handleBackToDashboard} />;
      default:
        return <Dashboard user={userForComponents} onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-zinc-950 to-black">
      {renderScreen()}

      {/* Bottom Navigation */}
      {currentScreen !== 'settings' && (
        <motion.nav 
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="fixed bottom-0 left-0 right-0 glass-card border-t border-zinc-800/50 backdrop-blur-xl"
        >
          <div className="max-w-md mx-auto px-6 py-4">
            <div className="flex justify-around items-center">
              <button 
                onClick={() => handleNavigate('dashboard')}
                className={`flex flex-col items-center gap-1 transition-colors ${
                  currentScreen === 'dashboard' ? 'text-[#D4AF37]' : 'text-zinc-500'
                }`}
              >
                <Home className="w-6 h-6" />
                <span className="text-xs font-medium">Home</span>
              </button>
              <button 
                onClick={() => handleNavigate('credit')}
                className={`flex flex-col items-center gap-1 transition-colors ${
                  currentScreen === 'credit' ? 'text-[#D4AF37]' : 'text-zinc-500'
                }`}
              >
                <CreditCard className="w-6 h-6" />
                <span className="text-xs font-medium">Credit</span>
              </button>
              <button 
                onClick={() => handleNavigate('tracking')}
                className={`flex flex-col items-center gap-1 transition-colors ${
                  currentScreen === 'tracking' ? 'text-[#D4AF37]' : 'text-zinc-500'
                }`}
              >
                <DollarSign className="w-6 h-6" />
                <span className="text-xs font-medium">Business</span>
              </button>
              <button 
                onClick={() => handleNavigate('settings')}
                className={`flex flex-col items-center gap-1 transition-colors ${
                  currentScreen === 'settings' ? 'text-[#D4AF37]' : 'text-zinc-500'
                }`}
              >
                <Menu className="w-6 h-6" />
                <span className="text-xs font-medium">More</span>
              </button>
            </div>
          </div>
        </motion.nav>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
