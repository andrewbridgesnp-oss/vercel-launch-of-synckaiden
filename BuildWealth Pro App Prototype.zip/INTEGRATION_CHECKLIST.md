# ✅ BuildWealth Pro - Backend Integration Checklist

Use this checklist to track your progress integrating the backend with your frontend.

---

## 🔧 Phase 1: Setup (Required - Do First!)

- [ ] **1.1** Created Supabase project at https://supabase.com
- [ ] **1.2** Created `.env` file with `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`
- [ ] **1.3** Ran `/supabase/schema.sql` in Supabase SQL Editor
- [ ] **1.4** Enabled Email authentication in Supabase Dashboard
- [ ] **1.5** Restarted dev server to load environment variables
- [ ] **1.6** Verified connection with `isSupabaseConfigured()` returns `true`

---

## 🔐 Phase 2: Authentication Integration

### Login/Signup Screens

- [ ] **2.1** Wrapped app with `<AuthProvider>` in main entry point
- [ ] **2.2** Updated **Login Screen** to use `signIn()` from `useAuthContext()`
- [ ] **2.3** Updated **Signup Screen** to use `signUp()` from `useAuthContext()`
- [ ] **2.4** Added `initializeUserData()` call after successful signup
- [ ] **2.5** Updated **Logout** functionality to use `signOut()`
- [ ] **2.6** Added **Protected Route** wrapper for authenticated screens
- [ ] **2.7** Redirect unauthenticated users to login page
- [ ] **2.8** Show user email/name in navigation bar

### Testing

- [ ] **2.9** Can sign up new user successfully
- [ ] **2.10** Can log in with existing user
- [ ] **2.11** Can log out successfully
- [ ] **2.12** Protected routes redirect when not logged in
- [ ] **2.13** Session persists after page reload

---

## 👤 Phase 3: User Profile

- [ ] **3.1** Load user profile on dashboard load with `profileService.getProfile()`
- [ ] **3.2** Display user's full name
- [ ] **3.3** Display user's business name
- [ ] **3.4** Display current subscription tier (Basic/Pro/Premium)
- [ ] **3.5** Create **Profile Settings** screen
- [ ] **3.6** Allow editing full name, business name, phone
- [ ] **3.7** Update profile with `profileService.updateProfile()`
- [ ] **3.8** Show success message after update

---

## 🎯 Phase 4: 120-Day Plan Integration

### Today's Tasks Screen

- [ ] **4.1** Load tasks for current day with `tasksService.getTasksByDay(userId, dayNumber)`
- [ ] **4.2** Display tasks grouped by assignee (Owner/Assistant/Both)
- [ ] **4.3** Show task completion status (checked/unchecked)
- [ ] **4.4** Implement task completion toggle with `tasksService.toggleTaskCompletion()`
- [ ] **4.5** Award points when task completed with `progressService.addPoints()`
- [ ] **4.6** Update streak when task completed with `progressService.updateStreak()`
- [ ] **4.7** Show visual feedback (animation) when task completed
- [ ] **4.8** Show points earned per task

### Full Plan View

- [ ] **4.9** Create **120-Day Plan** screen showing all 120 days
- [ ] **4.10** Load all tasks with `tasksService.getTasks(userId)`
- [ ] **4.11** Show progress indicators (e.g., "Day 15 of 120")
- [ ] **4.12** Allow creating new tasks with `tasksService.createTask()`
- [ ] **4.13** Allow editing tasks with `tasksService.updateTask()`
- [ ] **4.14** Allow deleting tasks with `tasksService.deleteTask()`
- [ ] **4.15** Filter tasks by category (Credit/Grants/Loans/Business/Personal)
- [ ] **4.16** Filter tasks by assignee (Owner/Assistant/Both)

---

## 🎮 Phase 5: Gamification

### Dashboard Display

- [ ] **5.1** Load user progress with `progressService.getOrCreateProgress(userId)`
- [ ] **5.2** Display total points
- [ ] **5.3** Display current level
- [ ] **5.4** Display level progress bar (% to next level)
- [ ] **5.5** Display current streak (consecutive days)
- [ ] **5.6** Display longest streak
- [ ] **5.7** Display earned badges with icons
- [ ] **5.8** Add level-up animation when user gains a level
- [ ] **5.9** Add badge unlock animation

### Badge System

- [ ] **5.10** Create badge definitions (first task, 7-day, 30-day, etc.)
- [ ] **5.11** Check for badge unlock after task completion
- [ ] **5.12** Award badges with `progressService.awardBadge()`
- [ ] **5.13** Show badge notification/modal when earned
- [ ] **5.14** Create **Badges** screen showing all available badges
- [ ] **5.15** Show locked vs unlocked badge states

---

## 💳 Phase 6: Credit Repair

### Credit Accounts Screen

- [ ] **6.1** Load credit accounts with `creditService.getCreditAccounts(userId)`
- [ ] **6.2** Display all credit accounts in list/card view
- [ ] **6.3** Show account name, type, limit, balance
- [ ] **6.4** Show payment due dates
- [ ] **6.5** Calculate and display credit utilization with `creditService.getCreditUtilization()`
- [ ] **6.6** Add **New Credit Account** form
- [ ] **6.7** Create account with `creditService.createCreditAccount()`
- [ ] **6.8** Edit account with `creditService.updateCreditAccount()`
- [ ] **6.9** Delete account with `creditService.deleteCreditAccount()`
- [ ] **6.10** Show upcoming payments with `creditService.getUpcomingPayments()`
- [ ] **6.11** Show payment due alerts (red if < 7 days)
- [ ] **6.12** Filter by account type (Credit Card/Loan/Mortgage/Auto)
- [ ] **6.13** Filter by status (Active/Closed/Disputed)

---

## 💰 Phase 7: Grant Tracking

### Grant Applications Screen

- [ ] **7.1** Load grants with `grantsService.getGrantApplications(userId)`
- [ ] **7.2** Display grant name, amount, deadline, status
- [ ] **7.3** Show visual status indicators (Researching/Applying/Submitted/Approved/Denied)
- [ ] **7.4** Add **New Grant Application** form
- [ ] **7.5** Create grant with `grantsService.createGrantApplication()`
- [ ] **7.6** Edit grant with `grantsService.updateGrantApplication()`
- [ ] **7.7** Delete grant with `grantsService.deleteGrantApplication()`
- [ ] **7.8** Show upcoming deadlines with `grantsService.getUpcomingDeadlines()`
- [ ] **7.9** Show deadline alerts (red if < 7 days)
- [ ] **7.10** Calculate total potential funding with `grantsService.getTotalPotentialFunding()`
- [ ] **7.11** Calculate approved funding with `grantsService.getTotalApprovedFunding()`
- [ ] **7.12** Filter by status
- [ ] **7.13** Sort by deadline (nearest first)

---

## 🏢 Phase 8: Business Operations - Time Clock

### Time Clock Screen

- [ ] **8.1** Show currently clocked-in employees with `businessService.getActiveTimeEntries()`
- [ ] **8.2** Add **Clock In** button/form
- [ ] **8.3** Clock in with `businessService.clockIn(userId, employeeName, project)`
- [ ] **8.4** Show live timer for clocked-in employees
- [ ] **8.5** Add **Clock Out** button
- [ ] **8.6** Clock out with `businessService.clockOut(entryId)`
- [ ] **8.7** Automatically calculate hours worked
- [ ] **8.8** Show time entry history with `businessService.getTimeEntries()`
- [ ] **8.9** Allow editing time entries with `businessService.updateTimeEntry()`
- [ ] **8.10** Allow deleting time entries with `businessService.deleteTimeEntry()`
- [ ] **8.11** Filter by date range with `businessService.getTimeEntriesInRange()`
- [ ] **8.12** Filter by employee name
- [ ] **8.13** Filter by project
- [ ] **8.14** Show total hours worked for period
- [ ] **8.15** Export time entries (CSV or PDF)

---

## 🚗 Phase 9: Business Operations - Mileage

### Mileage Tracker Screen

- [ ] **9.1** Load mileage entries with `businessService.getMileageEntries(userId)`
- [ ] **9.2** Display date, start/end locations, miles, purpose
- [ ] **9.3** Add **New Mileage Entry** form
- [ ] **9.4** Create entry with `businessService.createMileageEntry()`
- [ ] **9.5** Edit entry with `businessService.updateMileageEntry()`
- [ ] **9.6** Delete entry with `businessService.deleteMileageEntry()`
- [ ] **9.7** Calculate total mileage with `businessService.getTotalMileage()`
- [ ] **9.8** Calculate tax deduction (miles × $0.67)
- [ ] **9.9** Filter by date range
- [ ] **9.10** Filter by vehicle
- [ ] **9.11** Show monthly mileage summary
- [ ] **9.12** Show year-to-date mileage
- [ ] **9.13** Export mileage log for taxes

---

## 🧾 Phase 10: Business Operations - Receipts

### Receipt Tracker Screen

- [ ] **10.1** Load receipts with `businessService.getReceipts(userId)`
- [ ] **10.2** Display date, merchant, amount, category
- [ ] **10.3** Show receipt photo thumbnail if available
- [ ] **10.4** Add **New Receipt** form
- [ ] **10.5** Create receipt with `businessService.createReceipt()`
- [ ] **10.6** Upload photo with `businessService.uploadReceiptPhoto()`
- [ ] **10.7** Edit receipt with `businessService.updateReceipt()`
- [ ] **10.8** Delete receipt with `businessService.deleteReceipt()`
- [ ] **10.9** View full-size receipt photo in modal
- [ ] **10.10** Calculate total expenses with `businessService.getTotalExpenses()`
- [ ] **10.11** Show expenses by category with `businessService.getExpensesByCategory()`
- [ ] **10.12** Filter by date range
- [ ] **10.13** Filter by category
- [ ] **10.14** Filter by payment method
- [ ] **10.15** Show monthly expense summary
- [ ] **10.16** Show category breakdown (pie chart)
- [ ] **10.17** Export receipts for taxes

---

## 📊 Phase 11: Dashboard Analytics

- [ ] **11.1** Show total points and current level
- [ ] **11.2** Show current streak
- [ ] **11.3** Show tasks completed today
- [ ] **11.4** Show tasks completed this week
- [ ] **11.5** Show overall completion percentage
- [ ] **11.6** Show credit utilization percentage
- [ ] **11.7** Show number of active grant applications
- [ ] **11.8** Show upcoming deadlines (grants + credit payments)
- [ ] **11.9** Show this month's business expenses
- [ ] **11.10** Show this month's mileage
- [ ] **11.11** Show recent activity feed
- [ ] **11.12** Add charts/graphs for visual data

---

## 💎 Phase 12: Subscription Tiers

- [ ] **12.1** Show current tier (Basic/Pro/Premium) in profile
- [ ] **12.2** Create **Upgrade** screen with tier comparison
- [ ] **12.3** Disable premium features for Basic users
- [ ] **12.4** Show upgrade prompts for locked features
- [ ] **12.5** Update tier with `profileService.updateProfile(userId, { subscription_tier })`
- [ ] **12.6** (Optional) Integrate Stripe for payments
- [ ] **12.7** Handle subscription status in UI

### Feature Gating by Tier

**Basic (Free):**
- [ ] **12.8** Max 10 tasks per day
- [ ] **12.9** No receipt photo uploads
- [ ] **12.10** Basic reports only

**Pro ($9.99/mo):**
- [ ] **12.11** Unlimited tasks
- [ ] **12.12** Receipt photo uploads
- [ ] **12.13** Advanced reports
- [ ] **12.14** Email reminders

**Premium ($19.99/mo):**
- [ ] **12.15** Everything in Pro
- [ ] **12.16** Priority support
- [ ] **12.17** Custom branding
- [ ] **12.18** Advanced analytics
- [ ] **12.19** Export to accounting software

---

## 🔄 Phase 13: Real-time Updates (Optional)

- [ ] **13.1** Subscribe to task changes for live updates
- [ ] **13.2** Subscribe to progress changes for live updates
- [ ] **13.3** Subscribe to time entries for live clock updates
- [ ] **13.4** Show live notifications when data changes
- [ ] **13.5** Update UI automatically without refresh

---

## ✨ Phase 14: Polish & UX

- [ ] **14.1** Add loading states for all data fetching
- [ ] **14.2** Add error handling for all API calls
- [ ] **14.3** Show error messages to user (toast notifications)
- [ ] **14.4** Add success messages after actions
- [ ] **14.5** Add confirmation dialogs for delete actions
- [ ] **14.6** Add form validation before submit
- [ ] **14.7** Add optimistic UI updates (update UI before server confirms)
- [ ] **14.8** Add skeleton loaders for better perceived performance
- [ ] **14.9** Add empty states (e.g., "No tasks yet")
- [ ] **14.10** Add search functionality where needed

---

## 🧪 Phase 15: Testing

### Manual Testing

- [ ] **15.1** Sign up new user and verify data initialization
- [ ] **15.2** Log in and verify session persists
- [ ] **15.3** Complete tasks and verify points awarded
- [ ] **15.4** Test streak by completing tasks on consecutive days
- [ ] **15.5** Add credit accounts and verify utilization calculation
- [ ] **15.6** Add grants and verify deadline alerts
- [ ] **15.7** Clock in/out and verify hours calculation
- [ ] **15.8** Add mileage and verify tax deduction calculation
- [ ] **15.9** Upload receipt photo and verify storage
- [ ] **15.10** Test all CRUD operations (Create, Read, Update, Delete)

### Security Testing

- [ ] **15.11** Create second test user
- [ ] **15.12** Verify User A cannot see User B's data
- [ ] **15.13** Verify User A cannot edit User B's data
- [ ] **15.14** Verify unauthenticated requests are rejected
- [ ] **15.15** Check browser console for exposed credentials (should be none)

### Performance Testing

- [ ] **15.16** Test with 100+ tasks - should load quickly
- [ ] **15.17** Test with large receipt photos - should upload successfully
- [ ] **15.18** Test on slow network - should show loading states
- [ ] **15.19** Check for memory leaks (subscriptions cleaned up)

---

## 🚀 Phase 16: Production Prep

- [ ] **16.1** Create production Supabase project
- [ ] **16.2** Run schema on production database
- [ ] **16.3** Update production environment variables
- [ ] **16.4** Enable email confirmations for production
- [ ] **16.5** Set up custom email templates (welcome, reset password)
- [ ] **16.6** Enable rate limiting in Supabase
- [ ] **16.7** Set up database backups
- [ ] **16.8** Set up monitoring and alerts
- [ ] **16.9** Test production environment thoroughly
- [ ] **16.10** Create user documentation/help guide

---

## 📈 Progress Tracker

**Setup:** ☐☐☐☐☐☐ (0/6)
**Authentication:** ☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/13)
**Profile:** ☐☐☐☐☐☐☐☐ (0/8)
**Tasks:** ☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/16)
**Gamification:** ☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/15)
**Credit:** ☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/13)
**Grants:** ☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/13)
**Time Clock:** ☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/15)
**Mileage:** ☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/13)
**Receipts:** ☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/17)
**Dashboard:** ☐☐☐☐☐☐☐☐☐☐☐☐ (0/12)
**Subscriptions:** ☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/19)
**Real-time:** ☐☐☐☐☐ (0/5)
**Polish:** ☐☐☐☐☐☐☐☐☐☐ (0/10)
**Testing:** ☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐☐ (0/19)
**Production:** ☐☐☐☐☐☐☐☐☐☐ (0/10)

---

**Total Progress: 0/184 tasks (0%)**

---

## 💡 Tips for Success

1. **Work in order** - Complete Setup (Phase 1) first, then Authentication (Phase 2)
2. **Test as you go** - Don't move to next phase until current one works
3. **Check RLS** - Always verify users can't see each other's data
4. **Handle errors** - Add try/catch blocks and show user-friendly messages
5. **Commit often** - Save your progress with git commits
6. **Use the docs** - Refer to `/SUPABASE_BACKEND_README.md` for API reference

---

**🎯 Start with Phase 1 and work your way down! You've got this! 💪**
