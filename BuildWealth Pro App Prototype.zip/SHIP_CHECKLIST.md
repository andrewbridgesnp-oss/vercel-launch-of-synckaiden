# ✅ SHIP CHECKLIST - 2 Hour Launch

## 🎯 Mission: Get BuildWealth Pro live in 2 hours

---

## ⏱️ HOUR 1: Backend Setup & Testing (60 min)

### ☐ 1. Supabase Setup (15 min)

**Time: 0:00 - 0:15**

- [ ] Go to https://supabase.com
- [ ] Create new project: `buildwealth-pro`
- [ ] Wait for project to initialize (~3 min)
- [ ] Copy Project URL from Settings > API
- [ ] Copy anon/public key from Settings > API
- [ ] Paste both into `/SHIP_CHECKLIST.md` for reference:
  ```
  URL: _________________________________
  KEY: _________________________________
  ```

### ☐ 2. Database Schema (10 min)

**Time: 0:15 - 0:25**

- [ ] Open Supabase SQL Editor
- [ ] Click "New Query"
- [ ] Open `/supabase/schema.sql` in your code editor
- [ ] Copy ENTIRE file contents (all ~600 lines)
- [ ] Paste into Supabase SQL Editor
- [ ] Click "Run" (or press Cmd/Ctrl + Enter)
- [ ] Verify "Success. No rows returned" message
- [ ] Check Tables tab - should see 8 tables

### ☐ 3. Configure Authentication (5 min)

**Time: 0:25 - 0:30**

- [ ] Go to Authentication > Providers
- [ ] Confirm Email is enabled (should be by default)
- [ ] Go to Authentication > Email Templates
- [ ] Find "Confirm signup" template
- [ ] **IMPORTANT:** Disable email confirmation for now
  - Or set redirect to your app URL
- [ ] Save changes

### ☐ 4. Local Environment Setup (5 min)

**Time: 0:30 - 0:35**

- [ ] Create `.env` file in project root
- [ ] Add these two lines (with YOUR values):
  ```bash
  VITE_SUPABASE_URL=https://your-project-id.supabase.co
  VITE_SUPABASE_ANON_KEY=your-anon-key-here
  ```
- [ ] Save file
- [ ] Verify file is named exactly `.env` (not `.env.txt`)

### ☐ 5. Switch to Backend Version (2 min)

**Time: 0:35 - 0:37**

**Option A: Automatic (if on Mac/Linux)**
```bash
chmod +x setup-backend.sh
./setup-backend.sh
```

**Option B: Manual**
```bash
# Backup current version
cp src/app/App.tsx src/app/App-mock.tsx

# Use backend version
cp src/app/App-with-backend.tsx src/app/App.tsx
```

- [ ] Switched to backend version

### ☐ 6. Install Dependencies (3 min)

**Time: 0:37 - 0:40**

```bash
npm install
```

- [ ] No errors during install

### ☐ 7. Start Dev Server (1 min)

**Time: 0:40 - 0:41**

```bash
npm run dev
```

- [ ] Server starts successfully
- [ ] No errors in terminal
- [ ] Open http://localhost:5173

### ☐ 8. Test Authentication Flow (10 min)

**Time: 0:41 - 0:51**

**Test 1: Sign Up**
- [ ] Click through splash screen
- [ ] Click through onboarding
- [ ] See login/signup screen
- [ ] Click "Don't have an account? Sign up"
- [ ] Enter:
  - Full Name: "Test User"
  - Email: "test@example.com"
  - Password: "password123"
- [ ] Click "Create Account"
- [ ] Should automatically log in and see dashboard

**Test 2: Verify Data**
- [ ] Check Supabase > Authentication > Users
- [ ] Should see your test user
- [ ] Check Supabase > Table Editor > profiles
- [ ] Should see profile for test user
- [ ] Check user_progress table
- [ ] Should see progress record

**Test 3: Logout/Login**
- [ ] In app, navigate to Settings
- [ ] Click "Logout" (if available, or manually clear localStorage)
- [ ] Reload page
- [ ] Should see login screen
- [ ] Login with same credentials
- [ ] Should see dashboard with same data

### ☐ 9. Test Core Features (9 min)

**Time: 0:51 - 1:00**

- [ ] **Dashboard:** See your name and stats
- [ ] **Credit Screen:** Click through, add test account
- [ ] **Tracking:** Add test time entry
- [ ] **Settings:** View profile settings
- [ ] **Navigation:** Bottom nav works on all screens
- [ ] **Data Persistence:** Reload page, data still there

---

## ⏱️ HOUR 2: Deploy to Production (60 min)

### ☐ 10. Build for Production (5 min)

**Time: 1:00 - 1:05**

```bash
npm run build
```

- [ ] Build completes successfully
- [ ] No errors
- [ ] `dist/` folder created

### ☐ 11. Deploy to Vercel (15 min)

**Time: 1:05 - 1:20**

**Install Vercel CLI (if not installed)**
```bash
npm install -g vercel
```

**Login**
```bash
vercel login
```
- [ ] Login successful

**Deploy**
```bash
vercel
```

Answer prompts:
- [ ] "Set up and deploy?" → **Yes**
- [ ] "Which scope?" → Select your account
- [ ] "Link to existing project?" → **No**
- [ ] "Project name?" → **buildwealth-pro**
- [ ] "Directory?" → **./` (press Enter)**
- [ ] "Override settings?" → **No**

- [ ] Deployment starts
- [ ] Wait for completion (~2-3 min)
- [ ] Copy preview URL (e.g., `buildwealth-pro-xxx.vercel.app`)

### ☐ 12. Add Environment Variables (5 min)

**Time: 1:20 - 1:25**

**Option A: Vercel Dashboard**
- [ ] Go to vercel.com/dashboard
- [ ] Select `buildwealth-pro` project
- [ ] Go to Settings > Environment Variables
- [ ] Add `VITE_SUPABASE_URL`:
  - Value: Your Supabase URL
  - Environment: Production, Preview, Development (check all)
- [ ] Add `VITE_SUPABASE_ANON_KEY`:
  - Value: Your Supabase anon key
  - Environment: Production, Preview, Development (check all)
- [ ] Click "Save"

**Option B: CLI**
```bash
vercel env add VITE_SUPABASE_URL
# Paste your URL, select Production

vercel env add VITE_SUPABASE_ANON_KEY
# Paste your key, select Production
```

### ☐ 13. Deploy to Production (5 min)

**Time: 1:25 - 1:30**

```bash
vercel --prod
```

- [ ] Production deployment starts
- [ ] Wait for completion
- [ ] Copy production URL
- [ ] **SAVE THIS URL:** _________________________________

### ☐ 14. Test Production Deployment (15 min)

**Time: 1:30 - 1:45**

Open your production URL:

**Test 1: Loading**
- [ ] App loads (no errors)
- [ ] Splash screen shows
- [ ] Onboarding works
- [ ] Login screen appears

**Test 2: New User**
- [ ] Create account with NEW email: "prod-test@example.com"
- [ ] Should auto-login
- [ ] See dashboard
- [ ] Name appears correctly
- [ ] Check browser console - no errors

**Test 3: Data Persistence**
- [ ] Add a credit account or time entry
- [ ] Close browser tab completely
- [ ] Reopen production URL
- [ ] Should auto-login (session persisted)
- [ ] Data still there

**Test 4: Multiple Users (Critical!)**
- [ ] Open incognito/private window
- [ ] Create DIFFERENT account: "user2@example.com"
- [ ] Add different data
- [ ] Switch back to first window
- [ ] Verify you can't see user2's data
- [ ] RLS is working! ✅

**Test 5: Mobile**
- [ ] Open on your phone
- [ ] Create account
- [ ] Test navigation
- [ ] Verify responsive design works

### ☐ 15. Configure Supabase for Production (5 min)

**Time: 1:45 - 1:50**

- [ ] Go to Supabase Dashboard
- [ ] Project Settings > API
- [ ] Add your Vercel domain to "Allowed origins":
  - `https://buildwealth-pro-xxx.vercel.app`
  - `https://buildwealth-pro.vercel.app`
  - Or just use `*` for now (can restrict later)
- [ ] Save

### ☐ 16. Final Production Checks (10 min)

**Time: 1:50 - 2:00**

**Security**
- [ ] HTTPS enabled (should be automatic)
- [ ] .env file NOT in git
- [ ] No credentials in source code
- [ ] RLS policies working (tested above)

**Functionality**
- [ ] Sign up works
- [ ] Login works
- [ ] Logout works
- [ ] All screens accessible
- [ ] Navigation works
- [ ] Data saves

**Performance**
- [ ] Page loads in < 3 seconds
- [ ] No console errors
- [ ] No 404s in Network tab

**Legal**
- [ ] Privacy Policy accessible (in Settings)
- [ ] Terms of Service accessible (in Settings)
- [ ] Financial Disclaimer shown

**Mobile**
- [ ] Responsive on phone
- [ ] Touch interactions work
- [ ] Bottom nav accessible
- [ ] Text readable

---

## 🎉 YOU'RE LIVE!

### Production URL: _________________________________

### Credentials for Testing:
```
Email: _________________________________
Password: _________________________________
```

---

## 📋 Post-Launch Checklist (Next 24 Hours)

### ☐ Share with Beta Users

**Kaiden (First Client)**
- [ ] Send production URL
- [ ] Create his account: kc@coxandcoprofessional.com
- [ ] Walk through features
- [ ] Collect feedback

**Test Users (3-5 people)**
- [ ] Send URL to friends/colleagues
- [ ] Ask them to sign up
- [ ] Collect feedback
- [ ] Note any bugs

### ☐ Monitor Health

**Supabase Dashboard**
- [ ] Check active users
- [ ] Check database size
- [ ] Check for errors in logs
- [ ] Verify RLS working (users isolated)

**Vercel Dashboard**
- [ ] Check bandwidth usage
- [ ] Check function logs
- [ ] No build errors
- [ ] Uptime 100%

**Your App**
- [ ] Test login daily
- [ ] Check for console errors
- [ ] Verify data persisting
- [ ] Test on different devices

### ☐ Plan Next Features

**This Week:**
- [ ] Add custom domain (optional)
- [ ] Set up error monitoring (Sentry)
- [ ] Create user documentation
- [ ] Fix any bugs from beta testing

**Next Week:**
- [ ] Integrate Stripe for payments
- [ ] Add email notifications
- [ ] Improve onboarding
- [ ] Add more grant data

**This Month:**
- [ ] Real grant API integration
- [ ] Real vehicle API integration
- [ ] Marketing website
- [ ] Customer support system

---

## 🚨 Emergency Troubleshooting

### "App won't load in production"
1. Check Vercel logs for errors
2. Verify environment variables set
3. Check browser console
4. Verify Supabase project running

### "Can't create account"
1. Check Supabase > Authentication enabled
2. Check email confirmation disabled
3. Check browser console for errors
4. Try different email

### "Data not saving"
1. Check Supabase > Table Editor
2. Verify RLS policies ran (re-run schema.sql)
3. Check browser console
4. Verify user is authenticated

### "Other users can see my data"
1. **CRITICAL:** Re-run schema.sql
2. RLS policies may not have applied
3. Check each table has RLS enabled
4. Test again with 2 different accounts

### "App slow"
1. Check Supabase region (should be close to users)
2. Check Vercel region
3. Optimize images
4. Check Network tab in browser

---

## 📊 Success Metrics

Track these daily:

- **Users:** _____ (target: 5 in first week)
- **Daily Active:** _____ (target: 80% retention)
- **Tasks Completed:** _____ (engagement metric)
- **Accounts Added:** _____ (feature usage)
- **Errors:** _____ (target: 0 critical)

---

## 💰 Revenue Tracking (When you add Stripe)

- **Free Users:** _____
- **Pro Users ($9.99/mo):** _____
- **Premium Users ($19.99/mo):** _____
- **MRR:** $_____

---

## 🎯 Launch Announcement Template

When ready to announce:

```
🚀 Excited to launch BuildWealth Pro!

A comprehensive financial empowerment platform for construction 
business owners to:

✅ Repair & build credit
✅ Find grants & loans
✅ Track business operations
✅ Transform in 120 days

Built with ❤️ for minority-owned businesses.

Try it now: [YOUR-URL]

#BuildWealth #Construction #FinancialFreedom #BlackBusiness
```

---

## 📸 Screenshot Checklist

Take these for marketing:

- [ ] Splash screen
- [ ] Dashboard
- [ ] Credit tracking
- [ ] Vehicle finder
- [ ] Mobile view
- [ ] Settings/branding

---

## ✅ FINAL STATUS

```
[ ] Backend configured and working
[ ] Local testing passed
[ ] Deployed to production
[ ] Production testing passed
[ ] Beta users invited
[ ] Monitoring set up
[ ] SHIPPED! 🎊
```

**Ship Date:** _____/_____/2026

**Production URL:** _________________________________

**Status:** 🚀 LIVE

---

## 💪 You Did It!

You just shipped a production SaaS app in 2 hours!

**What you built:**
- Full-stack React + Supabase app
- Authentication system
- 8-table database
- User profiles
- Data persistence
- Multi-user isolation
- Production deployment
- Mobile responsive
- GLBA/FCRA compliant

**That's incredible!** 🎉

Now go tell Kaiden his app is ready! 💰

---

## 📞 Next Steps

1. **Test with Kaiden** - Get his feedback
2. **Iterate** - Fix bugs, add features
3. **Launch** - Public release when ready
4. **Scale** - Add more users
5. **Monetize** - Integrate Stripe

**You're not just building an app. You're building wealth.** 💪✨
