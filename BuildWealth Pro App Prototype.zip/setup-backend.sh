#!/bin/bash

# ============================================================================
# BuildWealth Pro - Backend Setup Script
# ============================================================================
# This script sets up the backend connection in one command
# ============================================================================

set -e

echo "🚀 BuildWealth Pro - Backend Setup"
echo "===================================="
echo ""

# Check if .env exists
if [ -f .env ]; then
    echo "✅ .env file found"
    source .env
else
    echo "❌ .env file not found!"
    echo ""
    echo "📝 Creating .env file..."
    echo "Please enter your Supabase credentials:"
    echo ""
    
    read -p "Supabase URL (https://xxx.supabase.co): " SUPABASE_URL
    read -p "Supabase Anon Key: " SUPABASE_KEY
    
    cat > .env << EOF
VITE_SUPABASE_URL=$SUPABASE_URL
VITE_SUPABASE_ANON_KEY=$SUPABASE_KEY
EOF
    
    echo "✅ .env file created"
fi

echo ""
echo "📦 Installing dependencies..."
npm install

echo ""
echo "🔄 Switching to backend-enabled App.tsx..."
if [ -f src/app/App-with-backend.tsx ]; then
    # Backup mock version
    if [ ! -f src/app/App-mock.tsx ]; then
        cp src/app/App.tsx src/app/App-mock.tsx
        echo "✅ Backed up mock version to App-mock.tsx"
    fi
    
    # Switch to backend version
    cp src/app/App-with-backend.tsx src/app/App.tsx
    echo "✅ Switched to backend-enabled version"
else
    echo "⚠️  App-with-backend.tsx not found, using current App.tsx"
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. Make sure you've run the SQL schema in Supabase"
echo "   (Copy /supabase/schema.sql to Supabase SQL Editor)"
echo ""
echo "2. Start the dev server:"
echo "   npm run dev"
echo ""
echo "3. Open http://localhost:5173"
echo ""
echo "4. Sign up to create your first user!"
echo ""
echo "🎉 Happy building!"
