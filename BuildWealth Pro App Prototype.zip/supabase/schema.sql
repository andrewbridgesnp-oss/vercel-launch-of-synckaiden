-- BuildWealth Pro Database Schema
-- GLBA/FCRA/CROA Compliant Database Design
-- All PII encrypted at rest, Row Level Security (RLS) enabled

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- USER PROFILES TABLE
-- Extends auth.users with business-specific data
-- MULTI-TENANT SUPPORT: Includes custom branding fields
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT,
    business_name TEXT,
    phone TEXT,
    subscription_tier TEXT NOT NULL DEFAULT 'basic' CHECK (subscription_tier IN ('basic', 'pro', 'premium')),
    stripe_customer_id TEXT,
    
    -- CUSTOM BRANDING FIELDS (for multi-tenant SaaS mode)
    logo_url TEXT,
    primary_color TEXT DEFAULT '#1e3a8a', -- Navy blue default
    secondary_color TEXT DEFAULT '#c0c0c0', -- Silver default
    accent_color TEXT DEFAULT '#ffd700', -- Gold default
    business_industry TEXT,
    business_structure TEXT CHECK (business_structure IN ('llc', 'corporation', 's_corp', 'sole_proprietor', 'partnership', 'other')),
    business_founded_year INTEGER,
    business_state TEXT,
    business_ein TEXT,
    
    -- CUSTOMIZATION PREFERENCES
    app_name TEXT, -- Custom app name (e.g., "Kaiden's BuildWealth Pro")
    custom_goal_title TEXT DEFAULT 'Build Wealth in 120 Days',
    plan_start_date DATE,
    enable_assistant_mode BOOLEAN DEFAULT true,
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(user_id)
);

-- RLS Policies for profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
    ON public.profiles FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile"
    ON public.profiles FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
    ON public.profiles FOR UPDATE
    USING (auth.uid() = user_id);

-- ============================================================================
-- DAILY TASKS TABLE (120-Day Plan)
-- Tracks daily tasks for owner and assistant
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.daily_tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    day_number INTEGER NOT NULL CHECK (day_number >= 1 AND day_number <= 120),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN ('credit', 'grants', 'loans', 'business', 'personal')),
    assignee TEXT NOT NULL CHECK (assignee IN ('owner', 'assistant', 'both')),
    completed BOOLEAN NOT NULL DEFAULT FALSE,
    points INTEGER NOT NULL DEFAULT 10,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- RLS Policies for daily_tasks
ALTER TABLE public.daily_tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own tasks"
    ON public.daily_tasks FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own tasks"
    ON public.daily_tasks FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tasks"
    ON public.daily_tasks FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own tasks"
    ON public.daily_tasks FOR DELETE
    USING (auth.uid() = user_id);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_daily_tasks_user_day 
    ON public.daily_tasks(user_id, day_number);

-- ============================================================================
-- USER PROGRESS TABLE (Gamification)
-- Tracks points, levels, streaks, and badges
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.user_progress (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    total_points INTEGER NOT NULL DEFAULT 0,
    current_level INTEGER NOT NULL DEFAULT 1,
    current_streak INTEGER NOT NULL DEFAULT 0,
    longest_streak INTEGER NOT NULL DEFAULT 0,
    badges_earned JSONB NOT NULL DEFAULT '[]'::jsonb,
    last_activity_date DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(user_id)
);

-- RLS Policies for user_progress
ALTER TABLE public.user_progress ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own progress"
    ON public.user_progress FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own progress"
    ON public.user_progress FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own progress"
    ON public.user_progress FOR UPDATE
    USING (auth.uid() = user_id);

-- ============================================================================
-- CREDIT ACCOUNTS TABLE
-- FCRA Compliant - Encrypted PII, minimal data retention
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.credit_accounts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    account_name TEXT NOT NULL,
    account_type TEXT NOT NULL CHECK (account_type IN ('credit_card', 'loan', 'mortgage', 'auto', 'other')),
    credit_limit DECIMAL(10, 2),
    current_balance DECIMAL(10, 2),
    payment_due_date DATE,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'closed', 'disputed')),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- RLS Policies for credit_accounts
ALTER TABLE public.credit_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own credit accounts"
    ON public.credit_accounts FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own credit accounts"
    ON public.credit_accounts FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own credit accounts"
    ON public.credit_accounts FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own credit accounts"
    ON public.credit_accounts FOR DELETE
    USING (auth.uid() = user_id);

-- ============================================================================
-- GRANT APPLICATIONS TABLE
-- Tracks minority-owned business grants
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.grant_applications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    grant_name TEXT NOT NULL,
    grant_amount DECIMAL(12, 2),
    deadline DATE,
    status TEXT NOT NULL DEFAULT 'researching' CHECK (status IN ('researching', 'applying', 'submitted', 'approved', 'denied')),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- RLS Policies for grant_applications
ALTER TABLE public.grant_applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own grant applications"
    ON public.grant_applications FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own grant applications"
    ON public.grant_applications FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own grant applications"
    ON public.grant_applications FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own grant applications"
    ON public.grant_applications FOR DELETE
    USING (auth.uid() = user_id);

-- ============================================================================
-- TIME ENTRIES TABLE (Business Operations)
-- Employee time clock tracking
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.time_entries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    employee_name TEXT NOT NULL,
    clock_in TIMESTAMPTZ NOT NULL,
    clock_out TIMESTAMPTZ,
    hours_worked DECIMAL(5, 2),
    project TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- RLS Policies for time_entries
ALTER TABLE public.time_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own time entries"
    ON public.time_entries FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own time entries"
    ON public.time_entries FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own time entries"
    ON public.time_entries FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own time entries"
    ON public.time_entries FOR DELETE
    USING (auth.uid() = user_id);

-- Index for date range queries
CREATE INDEX IF NOT EXISTS idx_time_entries_user_date 
    ON public.time_entries(user_id, clock_in);

-- ============================================================================
-- MILEAGE ENTRIES TABLE (Business Operations)
-- Vehicle mileage tracking for tax deductions
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.mileage_entries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    starting_location TEXT NOT NULL,
    ending_location TEXT NOT NULL,
    miles DECIMAL(8, 2) NOT NULL,
    purpose TEXT NOT NULL,
    vehicle TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- RLS Policies for mileage_entries
ALTER TABLE public.mileage_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own mileage entries"
    ON public.mileage_entries FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own mileage entries"
    ON public.mileage_entries FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own mileage entries"
    ON public.mileage_entries FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own mileage entries"
    ON public.mileage_entries FOR DELETE
    USING (auth.uid() = user_id);

-- Index for date range queries
CREATE INDEX IF NOT EXISTS idx_mileage_entries_user_date 
    ON public.mileage_entries(user_id, date);

-- ============================================================================
-- RECEIPTS TABLE (Business Operations)
-- Receipt tracking with photo storage
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.receipts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    merchant TEXT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    category TEXT NOT NULL,
    payment_method TEXT,
    photo_url TEXT,
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- RLS Policies for receipts
ALTER TABLE public.receipts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own receipts"
    ON public.receipts FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own receipts"
    ON public.receipts FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own receipts"
    ON public.receipts FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own receipts"
    ON public.receipts FOR DELETE
    USING (auth.uid() = user_id);

-- Index for date range queries
CREATE INDEX IF NOT EXISTS idx_receipts_user_date 
    ON public.receipts(user_id, date);

-- ============================================================================
-- FUNCTIONS & TRIGGERS
-- Auto-update timestamps
-- ============================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers to all tables
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_daily_tasks_updated_at BEFORE UPDATE ON public.daily_tasks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_progress_updated_at BEFORE UPDATE ON public.user_progress FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_credit_accounts_updated_at BEFORE UPDATE ON public.credit_accounts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_grant_applications_updated_at BEFORE UPDATE ON public.grant_applications FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_time_entries_updated_at BEFORE UPDATE ON public.time_entries FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_mileage_entries_updated_at BEFORE UPDATE ON public.mileage_entries FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_receipts_updated_at BEFORE UPDATE ON public.receipts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- STORAGE BUCKETS
-- For receipt photos and document uploads
-- ============================================================================
INSERT INTO storage.buckets (id, name, public) 
VALUES ('receipts', 'receipts', false)
ON CONFLICT (id) DO NOTHING;

-- Logo storage bucket (for multi-tenant custom branding)
INSERT INTO storage.buckets (id, name, public) 
VALUES ('logos', 'logos', true)
ON CONFLICT (id) DO NOTHING;

-- RLS Policies for storage
CREATE POLICY "Users can upload own receipts"
    ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'receipts' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view own receipts"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'receipts' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update own receipts"
    ON storage.objects FOR UPDATE
    USING (bucket_id = 'receipts' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete own receipts"
    ON storage.objects FOR DELETE
    USING (bucket_id = 'receipts' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Logo storage policies
CREATE POLICY "Users can upload own logo"
    ON storage.objects FOR INSERT
    WITH CHECK (bucket_id = 'logos' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Anyone can view logos"
    ON storage.objects FOR SELECT
    USING (bucket_id = 'logos');

CREATE POLICY "Users can update own logo"
    ON storage.objects FOR UPDATE
    USING (bucket_id = 'logos' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete own logo"
    ON storage.objects FOR DELETE
    USING (bucket_id = 'logos' AND auth.uid()::text = (storage.foldername(name))[1]);