#!/usr/bin/env node

/**
 * BuildWealth Pro - Setup Verification Script
 * Checks if everything is configured correctly before deploying
 */

const fs = require('fs');
const path = require('path');

console.log('🔍 BuildWealth Pro - Setup Verification\n');
console.log('==========================================\n');

let errors = 0;
let warnings = 0;

// Check 1: .env file exists
console.log('✓ Checking .env file...');
if (fs.existsSync('.env')) {
  const envContent = fs.readFileSync('.env', 'utf8');
  
  if (envContent.includes('VITE_SUPABASE_URL=')) {
    if (envContent.includes('your-project-id.supabase.co')) {
      console.log('  ❌ VITE_SUPABASE_URL not configured (using placeholder)');
      errors++;
    } else {
      console.log('  ✅ VITE_SUPABASE_URL configured');
    }
  } else {
    console.log('  ❌ VITE_SUPABASE_URL missing');
    errors++;
  }
  
  if (envContent.includes('VITE_SUPABASE_ANON_KEY=')) {
    if (envContent.includes('your-anon-key-here')) {
      console.log('  ❌ VITE_SUPABASE_ANON_KEY not configured (using placeholder)');
      errors++;
    } else {
      console.log('  ✅ VITE_SUPABASE_ANON_KEY configured');
    }
  } else {
    console.log('  ❌ VITE_SUPABASE_ANON_KEY missing');
    errors++;
  }
} else {
  console.log('  ❌ .env file not found');
  console.log('  → Create .env file with your Supabase credentials');
  errors++;
}

console.log('');

// Check 2: Dependencies installed
console.log('✓ Checking dependencies...');
if (fs.existsSync('node_modules')) {
  console.log('  ✅ node_modules exists');
} else {
  console.log('  ❌ node_modules not found');
  console.log('  → Run: npm install');
  errors++;
}

console.log('');

// Check 3: Required files
console.log('✓ Checking required files...');
const requiredFiles = [
  'src/app/App.tsx',
  'src/lib/supabase.ts',
  'src/contexts/AuthContext.tsx',
  'src/hooks/useAuth.ts',
  'supabase/schema.sql',
  'package.json',
  'index.html'
];

requiredFiles.forEach(file => {
  if (fs.existsSync(file)) {
    console.log(`  ✅ ${file}`);
  } else {
    console.log(`  ❌ ${file} missing`);
    errors++;
  }
});

console.log('');

// Check 4: Backend connection
console.log('✓ Checking backend connection...');
const appContent = fs.readFileSync('src/app/App.tsx', 'utf8');
if (appContent.includes('AuthProvider')) {
  console.log('  ✅ Backend-enabled App.tsx detected');
} else {
  console.log('  ⚠️  Using mock data version');
  console.log('  → To enable backend, run: ./setup-backend.sh');
  console.log('  → Or manually: cp src/app/App-with-backend.tsx src/app/App.tsx');
  warnings++;
}

console.log('');

// Check 5: Schema file
console.log('✓ Checking database schema...');
const schemaContent = fs.readFileSync('supabase/schema.sql', 'utf8');
if (schemaContent.includes('CREATE TABLE')) {
  console.log('  ✅ Schema contains table definitions');
  
  const tables = [
    'profiles',
    'daily_tasks',
    'user_progress',
    'credit_accounts',
    'grant_applications',
    'time_entries',
    'mileage_entries',
    'receipts'
  ];
  
  let missingTables = [];
  tables.forEach(table => {
    if (!schemaContent.includes(`CREATE TABLE IF NOT EXISTS public.${table}`)) {
      missingTables.push(table);
    }
  });
  
  if (missingTables.length > 0) {
    console.log(`  ⚠️  Missing tables: ${missingTables.join(', ')}`);
    warnings++;
  } else {
    console.log('  ✅ All 8 tables defined');
  }
} else {
  console.log('  ❌ Schema file appears invalid');
  errors++;
}

console.log('');

// Check 6: Git safety
console.log('✓ Checking Git configuration...');
if (fs.existsSync('.gitignore')) {
  const gitignoreContent = fs.readFileSync('.gitignore', 'utf8');
  if (gitignoreContent.includes('.env')) {
    console.log('  ✅ .env in .gitignore');
  } else {
    console.log('  ❌ .env NOT in .gitignore - SECURITY RISK!');
    errors++;
  }
} else {
  console.log('  ⚠️  .gitignore not found');
  warnings++;
}

console.log('');

// Summary
console.log('==========================================\n');
console.log('📊 Summary:\n');

if (errors === 0 && warnings === 0) {
  console.log('✅ All checks passed! You\'re ready to deploy.\n');
  console.log('Next steps:');
  console.log('1. Make sure you ran schema.sql in Supabase SQL Editor');
  console.log('2. Run: npm run dev (to test locally)');
  console.log('3. Run: vercel --prod (to deploy)\n');
  console.log('📖 See /SHIP_CHECKLIST.md for detailed deployment guide\n');
} else {
  if (errors > 0) {
    console.log(`❌ ${errors} error(s) found - must fix before deploying\n`);
  }
  if (warnings > 0) {
    console.log(`⚠️  ${warnings} warning(s) - recommended to fix\n`);
  }
  console.log('📖 Check /DEPLOY_NOW.md for setup instructions\n');
}

process.exit(errors > 0 ? 1 : 0);
