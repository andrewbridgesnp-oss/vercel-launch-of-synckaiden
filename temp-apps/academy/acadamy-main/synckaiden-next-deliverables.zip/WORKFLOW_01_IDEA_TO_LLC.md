
# WORKFLOW 1: IDEA → LLC → EIN → BANK

## Education
Explains entity choice, liability, funding impact.

## Execution Steps
1. Choose state
2. Select entity type
3. File LLC
4. Obtain EIN
5. Select bank
6. Open account
7. Initial compliance tasks

## Automation Option
- Checklist automation
- EIN readiness validator
- Bank shortlist engine

## Risks
- Filing mistakes
- Wrong NAICS
- Bank rejection

## Tier
Starter+
