Next deliverables: database schema + first executable workflow.
