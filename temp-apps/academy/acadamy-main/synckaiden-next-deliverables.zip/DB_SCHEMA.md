
# DATABASE SCHEMA (Phase 0–1)

## Core Tables

users
- id (uuid, pk)
- email
- password_hash
- role (admin, member)
- tier (starter, builder, operator, empire)
- created_at

organizations
- id
- owner_user_id
- name
- state
- created_at

modules
- id
- name
- phase
- gated_tier

workflows
- id
- name
- tier_required
- description

workflow_runs
- id
- workflow_id
- user_id
- status
- created_at

progress
- id
- user_id
- module_id
- percent_complete

audit_logs
- id
- user_id
- action
- metadata
- created_at
