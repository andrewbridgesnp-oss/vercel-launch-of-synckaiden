## Goal
Increase retention + ARPU.

## New Modules
- Employees (Hiring + Onboarding)
- CRM education + integrations
- Advanced automation templates
- Certification-based unlocks
- Hosted website add-on logic
