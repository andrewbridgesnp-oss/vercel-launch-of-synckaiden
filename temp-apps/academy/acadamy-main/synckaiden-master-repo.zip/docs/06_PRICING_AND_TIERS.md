Starter Sync — $49/mo
Builder Sync — $149/mo
Operator Sync — $399/mo
Empire Sync — $999/mo
Hosted Sync — add-on + revenue cut
