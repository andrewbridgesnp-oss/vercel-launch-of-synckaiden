## V1 WORKFLOWS
1. Idea → LLC → EIN → Bank
2. EIN → Business Credit (No SSN first)
3. Funding Path Selector
4. SBA Readiness Engine
5. AI-First Business Setup
6. Hire First Employee
7. Consultant → Agency Scale
8. Hosted Website → Revenue Share
9. Learn → Certify → Unlock
10. Ask Kayden → Execute
