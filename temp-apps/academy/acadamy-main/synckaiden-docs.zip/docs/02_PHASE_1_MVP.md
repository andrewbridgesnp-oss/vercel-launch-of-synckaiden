## Goal
Ship what people will pay for immediately.

## MVP MODULES (ONLY THESE)
1. Dashboard
2. Business
3. Finance
4. Automation
5. AI Academy (Lite)
6. Help / Kayden

## MVP EXIT CRITERIA
- Paying users onboard successfully
- Users complete at least 1 workflow
- Clear upgrade paths visible
