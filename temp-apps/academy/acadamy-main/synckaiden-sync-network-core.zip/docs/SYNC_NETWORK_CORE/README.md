SYNC_NETWORK_CORE: Canonical docs mirror for Codex ingestion (read in numeric order).
