Goal

Increase retention + ARPU.

New Modules

Employees (Hiring + Onboarding only)

CRM education + integrations

Advanced automation templates

Certification-based unlocks

Hosted website add-on logic

Enhancements

Tier comparisons inside app

Automation marketplace (internal)

Better analytics (not vanity)

Monetization

Upsell from Builder → Operator

Hosted Sync add-on
