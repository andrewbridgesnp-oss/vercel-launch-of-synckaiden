Environments

Local

Staging

Production

Hosting Requirements

Self-host capable

Environment variable driven

No hardcoded credentials

CI/CD

GitHub Actions

Automated tests before deploy
