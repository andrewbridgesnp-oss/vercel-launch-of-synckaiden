(REVENUE PHASE)

Goal

Ship what people will pay for immediately.

MVP MODULES (ONLY THESE)

1. Dashboard

Progress tracker

“Next Best Action”

Kayden query bar

2. Business

LLC formation (education + checklist)

EIN workflow

NAICS/SIC selector

Banking shortlist

Business credit roadmap

Funding readiness score (simplified)

3. Finance

Top 10 banks (rules-based)

Top 10 business cards

SBA readiness checklist

Loan vs credit decision engine

4. Automation

5 real workflows (see workflows doc)

Clone + edit

Tier gating

5. AI Academy (Lite)

AI foundations

Prompt engineering for business

Automation logic basics

6. Help / Kayden

Top 25 business questions

Intake-aware answers

Clear next action CTA

MVP EXIT CRITERIA

Paying users onboard successfully

Users complete at least 1 workflow

Clear upgrade paths visible
