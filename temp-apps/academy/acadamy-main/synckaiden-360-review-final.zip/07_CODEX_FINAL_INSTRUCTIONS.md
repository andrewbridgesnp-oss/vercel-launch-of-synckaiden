## FINAL INSTRUCTION TO CODEX (OVERRIDES ALL)

- Read /docs first (00 → 10)
- Apply all fixes in this 360 review pack
- Implement Phase 0 and Phase 1 only
- Prioritize security, clarity, and monetization
- Do not introduce new features
- Redeliver full repo as zip

This is the final build.
