## High-Level Threat Model (MVP)

Assets:
- User strategic business data
- Workflow blueprints
- Automation logic

Threats:
- Local data exfiltration
- Over-privileged workflows
- Social engineering via AI outputs

Controls:
- Encryption at rest
- Least privilege by tier
- Human approval for sensitive actions
- Audit logs

Residual risk accepted for MVP.
