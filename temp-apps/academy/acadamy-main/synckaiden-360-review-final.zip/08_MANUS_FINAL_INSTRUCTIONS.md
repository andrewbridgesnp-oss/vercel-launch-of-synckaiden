## FINAL INSTRUCTION TO MANUS

- UI/UX polish only
- Smooth transitions, spacing, readability
- No logic changes
- No scope expansion
- Respect /docs and 360 review

Goal: Enterprise-grade feel with startup velocity.
