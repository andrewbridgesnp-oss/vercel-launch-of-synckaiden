## Cybersecurity Review

### Strengths
- Offline-first MVP reduces attack surface
- Explicit avoidance of unauthorized automation
- Audit logging philosophy present

### Critical Risks
- localStorage contains sensitive strategic data
- No encryption at rest (client-side)
- No threat model documented

### Fixes (MANDATORY)
- Encrypt sensitive local data (Web Crypto API)
- Add threat-model.md
- Add permission tiers for workflows touching money/identity
- Add rate limits and kill switches (Phase 1)

Status: CRITICAL
