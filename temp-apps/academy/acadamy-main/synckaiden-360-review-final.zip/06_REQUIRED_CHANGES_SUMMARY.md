## Required Changes Before Public Launch

MUST FIX:
- Encrypt client-side stored data
- Add onboarding wizard
- Add workflow permission tiers
- Add threat model doc

SHOULD FIX:
- Add test scaffolding
- Improve state modularity
- Improve copy around professional escalation

NICE TO HAVE:
- Visual workflow builder polish
- Analytics dashboard

Codex should implement MUST + SHOULD.
Manus handles NICE TO HAVE (visual only).
