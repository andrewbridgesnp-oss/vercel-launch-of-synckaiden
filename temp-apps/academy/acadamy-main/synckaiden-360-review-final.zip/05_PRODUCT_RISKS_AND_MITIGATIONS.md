## Product Risks

1. Over-automation without understanding
   → Mitigation: Certification gates

2. User dependency on AI decisions
   → Mitigation: Always show reasoning + alternatives

3. Scope creep killing velocity
   → Mitigation: Phase locks via /docs

4. Security complacency
   → Mitigation: Default-deny philosophy

Status: MONITORED
